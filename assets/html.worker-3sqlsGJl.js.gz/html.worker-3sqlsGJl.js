(function() {
	const e = new class {
		constructor() {
			this.listeners = [], this.unexpectedErrorHandler = function(e) {
				setTimeout(() => {
					if (e.stack) {
						if (a.isErrorNoTelemetry(e)) throw new a(e.message + "\n\n" + e.stack);
						throw new Error(e.message + "\n\n" + e.stack);
					}
					throw e;
				}, 0);
			};
		}
		emit(e) {
			this.listeners.forEach((t) => {
				t(e);
			});
		}
		onUnexpectedError(e) {
			this.unexpectedErrorHandler(e), this.emit(e);
		}
		onUnexpectedExternalError(e) {
			this.unexpectedErrorHandler(e);
		}
	}();
	function t(t) {
		var n;
		(n = t) instanceof r || n instanceof Error && "Canceled" === n.name && "Canceled" === n.message || e.onUnexpectedError(t);
	}
	function n(e) {
		if (e instanceof Error) {
			const { name: t, message: i, cause: r } = e;
			return {
				$isError: !0,
				name: t,
				message: i,
				stack: e.stacktrace || e.stack,
				noTelemetry: a.isErrorNoTelemetry(e),
				cause: r ? n(r) : void 0,
				code: e.code
			};
		}
		return e;
	}
	var i, r = class extends Error {
		constructor() {
			super("Canceled"), this.name = this.message;
		}
	}, a = class e extends Error {
		constructor(e) {
			super(e), this.name = "CodeExpectedError";
		}
		static fromError(t) {
			if (t instanceof e) return t;
			const n = new e();
			return n.message = t.message, n.stack = t.stack, n;
		}
		static isErrorNoTelemetry(e) {
			return "CodeExpectedError" === e.name;
		}
	}, o = class e extends Error {
		constructor(t) {
			super(t || "An unexpected bug occurred."), Object.setPrototypeOf(this, e.prototype);
		}
	};
	function s(e, t = "Unreachable") {
		throw new Error(t);
	}
	function l(e) {
		e() || (e(), t(new o("Assertion Failed")));
	}
	function c(e, t) {
		let n = 0;
		for (; n < e.length - 1;) {
			if (!t(e[n], e[n + 1])) return !1;
			n++;
		}
		return !0;
	}
	function h(e) {
		return !!e && "function" == typeof e[Symbol.iterator];
	}
	function d(e) {
		if (i.is(e)) {
			const n = [];
			for (const i of e) if (i) try {
				i.dispose();
			} catch (t) {
				n.push(t);
			}
			if (1 === n.length) throw n[0];
			if (n.length > 1) throw new AggregateError(n, "Encountered errors while disposing of store");
			return Array.isArray(e) ? [] : e;
		}
		if (e) return e.dispose(), e;
	}
	(function(e) {
		function t(e) {
			return !!e && "object" == typeof e && "function" == typeof e[Symbol.iterator];
		}
		e.is = t;
		const n = Object.freeze([]);
		function* i(e) {
			yield e;
		}
		e.empty = function() {
			return n;
		}, e.single = i, e.wrap = function(e) {
			return t(e) ? e : i(e);
		}, e.from = function(e) {
			return e || n;
		}, e.reverse = function* (e) {
			for (let t = e.length - 1; t >= 0; t--) yield e[t];
		}, e.isEmpty = function(e) {
			return !e || !0 === e[Symbol.iterator]().next().done;
		}, e.first = function(e) {
			return e[Symbol.iterator]().next().value;
		}, e.some = function(e, t) {
			let n = 0;
			for (const i of e) if (t(i, n++)) return !0;
			return !1;
		}, e.every = function(e, t) {
			let n = 0;
			for (const i of e) if (!t(i, n++)) return !1;
			return !0;
		}, e.find = function(e, t) {
			for (const n of e) if (t(n)) return n;
		}, e.filter = function* (e, t) {
			for (const n of e) t(n) && (yield n);
		}, e.map = function* (e, t) {
			let n = 0;
			for (const i of e) yield t(i, n++);
		}, e.flatMap = function* (e, t) {
			let n = 0;
			for (const i of e) yield* t(i, n++);
		}, e.concat = function* (...e) {
			for (const t of e) h(t) ? yield* t : yield t;
		}, e.reduce = function(e, t, n) {
			let i = n;
			for (const r of e) i = t(i, r);
			return i;
		}, e.length = function(e) {
			let t = 0;
			for (const n of e) t++;
			return t;
		}, e.slice = function* (e, t, n = e.length) {
			for (t < -e.length && (t = 0), t < 0 && (t += e.length), n < 0 ? n += e.length : n > e.length && (n = e.length); t < n; t++) yield e[t];
		}, e.consume = function(t, n = Number.POSITIVE_INFINITY) {
			const i = [];
			if (0 === n) return [i, t];
			const r = t[Symbol.iterator]();
			for (let a = 0; a < n; a++) {
				const t = r.next();
				if (t.done) return [i, e.empty()];
				i.push(t.value);
			}
			return [i, { [Symbol.iterator]: () => r }];
		}, e.asyncToArray = async function(e) {
			const t = [];
			for await (const n of e) t.push(n);
			return t;
		}, e.asyncToArrayFlat = async function(e) {
			let t = [];
			for await (const n of e) t = t.concat(n);
			return t;
		};
	})(i || (i = {}));
	var u = class {
		constructor(e) {
			this._isDisposed = !1, this._fn = e;
		}
		dispose() {
			if (!this._isDisposed) {
				if (!this._fn) throw new Error("Unbound disposable context: Need to use an arrow function to preserve the value of this");
				this._isDisposed = !0, this._fn();
			}
		}
	};
	function m(e) {
		return new u(e);
	}
	var p = class e {
		static {
			this.DISABLE_DISPOSED_WARNING = !1;
		}
		constructor() {
			this._toDispose = /* @__PURE__ */ new Set(), this._isDisposed = !1;
		}
		dispose() {
			this._isDisposed || (this._isDisposed = !0, this.clear());
		}
		get isDisposed() {
			return this._isDisposed;
		}
		clear() {
			if (0 !== this._toDispose.size) try {
				d(this._toDispose);
			} finally {
				this._toDispose.clear();
			}
		}
		add(t) {
			if (!t || t === g.None) return t;
			if (t === this) throw new Error("Cannot register a disposable on itself!");
			return this._isDisposed ? e.DISABLE_DISPOSED_WARNING : this._toDispose.add(t), t;
		}
		delete(e) {
			if (e) {
				if (e === this) throw new Error("Cannot dispose a disposable on itself!");
				this._toDispose.delete(e), e.dispose();
			}
		}
	}, g = class {
		static {
			this.None = Object.freeze({ dispose() {} });
		}
		constructor() {
			this._store = new p(), this._store;
		}
		dispose() {
			this._store.dispose();
		}
		_register(e) {
			if (e === this) throw new Error("Cannot register a disposable on itself!");
			return this._store.add(e);
		}
	}, f = class e {
		static {
			this.Undefined = new e(void 0);
		}
		constructor(t) {
			this.element = t, this.next = e.Undefined, this.prev = e.Undefined;
		}
	}, b = class {
		constructor() {
			this._first = f.Undefined, this._last = f.Undefined, this._size = 0;
		}
		get size() {
			return this._size;
		}
		isEmpty() {
			return this._first === f.Undefined;
		}
		clear() {
			let e = this._first;
			for (; e !== f.Undefined;) {
				const t = e.next;
				e.prev = f.Undefined, e.next = f.Undefined, e = t;
			}
			this._first = f.Undefined, this._last = f.Undefined, this._size = 0;
		}
		unshift(e) {
			return this._insert(e, !1);
		}
		push(e) {
			return this._insert(e, !0);
		}
		_insert(e, t) {
			const n = new f(e);
			if (this._first === f.Undefined) this._first = n, this._last = n;
			else if (t) {
				const e = this._last;
				this._last = n, n.prev = e, e.next = n;
			} else {
				const e = this._first;
				this._first = n, n.next = e, e.prev = n;
			}
			this._size += 1;
			let i = !1;
			return () => {
				i || (i = !0, this._remove(n));
			};
		}
		shift() {
			if (this._first !== f.Undefined) {
				const e = this._first.element;
				return this._remove(this._first), e;
			}
		}
		pop() {
			if (this._last !== f.Undefined) {
				const e = this._last.element;
				return this._remove(this._last), e;
			}
		}
		_remove(e) {
			if (e.prev !== f.Undefined && e.next !== f.Undefined) {
				const t = e.prev;
				t.next = e.next, e.next.prev = t;
			} else e.prev === f.Undefined && e.next === f.Undefined ? (this._first = f.Undefined, this._last = f.Undefined) : e.next === f.Undefined ? (this._last = this._last.prev, this._last.next = f.Undefined) : e.prev === f.Undefined && (this._first = this._first.next, this._first.prev = f.Undefined);
			this._size -= 1;
		}
		*[Symbol.iterator]() {
			let e = this._first;
			for (; e !== f.Undefined;) yield e.element, e = e.next;
		}
	};
	const _ = globalThis.performance.now.bind(globalThis.performance);
	var w, v = class e {
		static create(t) {
			return new e(t);
		}
		constructor(e) {
			this._now = !1 === e ? Date.now : _, this._startTime = this._now(), this._stopTime = -1;
		}
		stop() {
			this._stopTime = this._now();
		}
		reset() {
			this._startTime = this._now(), this._stopTime = -1;
		}
		elapsed() {
			return -1 !== this._stopTime ? this._stopTime - this._startTime : this._now() - this._startTime;
		}
	};
	(function(e) {
		function t(e) {
			return (t, n = null, i) => {
				let r, a = !1;
				return r = e((e) => {
					if (!a) return r ? r.dispose() : a = !0, t.call(n, e);
				}, null, i), a && r.dispose(), r;
			};
		}
		function n(e, t, n) {
			return r((n, i = null, r) => e((e) => n.call(i, t(e)), null, r), n);
		}
		function i(e, t, n) {
			return r((n, i = null, r) => e((e) => t(e) && n.call(i, e), null, r), n);
		}
		function r(e, t) {
			let n;
			const i = new C({
				onWillAddFirstListener() {
					n = e(i.fire, i);
				},
				onDidRemoveLastListener() {
					n?.dispose();
				}
			});
			return t?.add(i), i.event;
		}
		function a(e, t, n = 100, i = !1, r = !1, a, o) {
			let s, l, c, h, d = 0;
			const u = new C({
				leakWarningThreshold: a,
				onWillAddFirstListener() {
					s = e((e) => {
						d++, l = t(l, e), i && !c && (u.fire(l), l = void 0), h = () => {
							const e = l;
							l = void 0, c = void 0, (!i || d > 1) && u.fire(e), d = 0;
						}, "number" == typeof n ? (c && clearTimeout(c), c = setTimeout(h, n)) : void 0 === c && (c = null, queueMicrotask(h));
					});
				},
				onWillRemoveListener() {
					r && d > 0 && h?.();
				},
				onDidRemoveLastListener() {
					h = void 0, s.dispose();
				}
			});
			return o?.add(u), u.event;
		}
		e.None = () => g.None, e.defer = function(e, t) {
			return a(e, () => {}, 0, void 0, !0, void 0, t);
		}, e.once = t, e.onceIf = function(t, n) {
			return e.once(e.filter(t, n));
		}, e.map = n, e.forEach = function(e, t, n) {
			return r((n, i = null, r) => e((e) => {
				t(e), n.call(i, e);
			}, null, r), n);
		}, e.filter = i, e.signal = function(e) {
			return e;
		}, e.any = function(...e) {
			return (t, n = null, i) => function(e, t) {
				t instanceof Array ? t.push(e) : t && t.add(e);
				return e;
			}(function(...e) {
				return m(() => d(e));
			}(...e.map((e) => e((e) => t.call(n, e)))), i);
		}, e.reduce = function(e, t, i, r) {
			let a = i;
			return n(e, (e) => (a = t(a, e), a), r);
		}, e.debounce = a, e.accumulate = function(t, n = 0, i) {
			return e.debounce(t, (e, t) => e ? (e.push(t), e) : [t], n, void 0, !0, void 0, i);
		}, e.latch = function(e, t = (e, t) => e === t, n) {
			let r, a = !0;
			return i(e, (e) => {
				const n = a || !t(e, r);
				return a = !1, r = e, n;
			}, n);
		}, e.split = function(t, n, i) {
			return [e.filter(t, n, i), e.filter(t, (e) => !n(e), i)];
		}, e.buffer = function(e, t = !1, n = [], i) {
			let r = n.slice(), a = e((e) => {
				r ? r.push(e) : s.fire(e);
			});
			i && i.add(a);
			const o = () => {
				r?.forEach((e) => s.fire(e)), r = null;
			}, s = new C({
				onWillAddFirstListener() {
					a || (a = e((e) => s.fire(e)), i && i.add(a));
				},
				onDidAddFirstListener() {
					r && (t ? setTimeout(o) : o());
				},
				onDidRemoveLastListener() {
					a && a.dispose(), a = null;
				}
			});
			return i && i.add(s), s.event;
		}, e.chain = function(e, t) {
			return (n, i, r) => {
				const a = t(new s());
				return e(function(e) {
					const t = a.evaluate(e);
					t !== o && n.call(i, t);
				}, void 0, r);
			};
		};
		const o = Symbol("HaltChainable");
		class s {
			constructor() {
				this.steps = [];
			}
			map(e) {
				return this.steps.push(e), this;
			}
			forEach(e) {
				return this.steps.push((t) => (e(t), t)), this;
			}
			filter(e) {
				return this.steps.push((t) => e(t) ? t : o), this;
			}
			reduce(e, t) {
				let n = t;
				return this.steps.push((t) => (n = e(n, t), n)), this;
			}
			latch(e = (e, t) => e === t) {
				let t, n = !0;
				return this.steps.push((i) => {
					const r = n || !e(i, t);
					return n = !1, t = i, r ? i : o;
				}), this;
			}
			evaluate(e) {
				for (const t of this.steps) if ((e = t(e)) === o) break;
				return e;
			}
		}
		e.fromNodeEventEmitter = function(e, t, n = (e) => e) {
			const i = (...e) => r.fire(n(...e)), r = new C({
				onWillAddFirstListener: () => e.on(t, i),
				onDidRemoveLastListener: () => e.removeListener(t, i)
			});
			return r.event;
		}, e.fromDOMEventEmitter = function(e, t, n = (e) => e) {
			const i = (...e) => r.fire(n(...e)), r = new C({
				onWillAddFirstListener: () => e.addEventListener(t, i),
				onDidRemoveLastListener: () => e.removeEventListener(t, i)
			});
			return r.event;
		}, e.toPromise = function(e, n) {
			let i;
			const r = new Promise((r, a) => {
				const o = t(e)(r, null, n);
				i = () => o.dispose();
			});
			return r.cancel = i, r;
		}, e.forward = function(e, t) {
			return e((e) => t.fire(e));
		}, e.runAndSubscribe = function(e, t, n) {
			return t(n), e((e) => t(e));
		};
		class l {
			constructor(e, t) {
				this._observable = e, this._counter = 0, this._hasChanged = !1, this.emitter = new C({
					onWillAddFirstListener: () => {
						e.addObserver(this), this._observable.reportChanges();
					},
					onDidRemoveLastListener: () => {
						e.removeObserver(this);
					}
				}), t && t.add(this.emitter);
			}
			beginUpdate(e) {
				this._counter++;
			}
			handlePossibleChange(e) {}
			handleChange(e, t) {
				this._hasChanged = !0;
			}
			endUpdate(e) {
				this._counter--, 0 === this._counter && (this._observable.reportChanges(), this._hasChanged && (this._hasChanged = !1, this.emitter.fire(this._observable.get())));
			}
		}
		e.fromObservable = function(e, t) {
			return new l(e, t).emitter.event;
		}, e.fromObservableLight = function(e) {
			return (t, n, i) => {
				let r = 0, a = !1;
				const o = {
					beginUpdate() {
						r++;
					},
					endUpdate() {
						r--, 0 === r && (e.reportChanges(), a && (a = !1, t.call(n)));
					},
					handlePossibleChange() {},
					handleChange() {
						a = !0;
					}
				};
				e.addObserver(o), e.reportChanges();
				const s = { dispose() {
					e.removeObserver(o);
				} };
				return i instanceof p ? i.add(s) : Array.isArray(i) && i.push(s), s;
			};
		};
	})(w || (w = {}));
	var y = class e {
		static {
			this.all = /* @__PURE__ */ new Set();
		}
		static {
			this._idPool = 0;
		}
		constructor(t) {
			this.listenerCount = 0, this.invocationCount = 0, this.elapsedOverall = 0, this.durations = [], this.name = `${t}_${e._idPool++}`, e.all.add(this);
		}
		start(e) {
			this._stopWatch = new v(), this.listenerCount = e;
		}
		stop() {
			if (this._stopWatch) {
				const e = this._stopWatch.elapsed();
				this.durations.push(e), this.elapsedOverall += e, this.invocationCount += 1, this._stopWatch = void 0;
			}
		}
	};
	var T = class e {
		static {
			this._idPool = 1;
		}
		constructor(t, n, i = (e._idPool++).toString(16).padStart(3, "0")) {
			this._errorHandler = t, this.threshold = n, this.name = i, this._warnCountdown = 0;
		}
		dispose() {
			this._stacks?.clear();
		}
		check(e, t) {
			const n = this.threshold;
			if (n <= 0 || t < n) return;
			this._stacks || (this._stacks = /* @__PURE__ */ new Map());
			const i = this._stacks.get(e.value) || 0;
			if (this._stacks.set(e.value, i + 1), this._warnCountdown -= 1, this._warnCountdown <= 0) {
				this._warnCountdown = .5 * n;
				const [e, i] = this.getMostFrequentStack(), a = new S(`[${this.name}] potential listener LEAK detected, having ${t} listeners already. MOST frequent listener (${i}):`, e);
				this._errorHandler(a);
			}
			return () => {
				const t = this._stacks.get(e.value) || 0;
				this._stacks.set(e.value, t - 1);
			};
		}
		getMostFrequentStack() {
			if (!this._stacks) return;
			let e, t = 0;
			for (const [n, i] of this._stacks) (!e || t < i) && (e = [n, i], t = i);
			return e;
		}
	}, k = class e {
		static create() {
			return new e((/* @__PURE__ */ new Error()).stack ?? "");
		}
		constructor(e) {
			this.value = e;
		}
		print() {}
	}, S = class extends Error {
		constructor(e, t) {
			super(e), this.name = "ListenerLeakError", this.stack = t;
		}
	}, L = class extends Error {
		constructor(e, t) {
			super(e), this.name = "ListenerRefusalError", this.stack = t;
		}
	}, x = class {
		constructor(e) {
			this.value = e;
		}
	};
	var C = class {
		constructor(e) {
			this._size = 0, this._options = e, this._leakageMon = this._options?.leakWarningThreshold ? new T(e?.onListenerError ?? t, this._options?.leakWarningThreshold ?? -1) : void 0, this._perfMon = this._options?._profName ? new y(this._options._profName) : void 0, this._deliveryQueue = this._options?.deliveryQueue;
		}
		dispose() {
			this._disposed || (this._disposed = !0, this._deliveryQueue?.current === this && this._deliveryQueue.reset(), this._listeners && (this._listeners = void 0, this._size = 0), this._options?.onDidRemoveLastListener?.(), this._leakageMon?.dispose());
		}
		get event() {
			return this._event ??= (e, n, i) => {
				if (this._leakageMon && this._size > this._leakageMon.threshold ** 2) {
					const e = `[${this._leakageMon.name}] REFUSES to accept new listeners because it exceeded its threshold by far (${this._size} vs ${this._leakageMon.threshold})`, n = this._leakageMon.getMostFrequentStack() ?? ["UNKNOWN stack", -1], i = new L(`${e}. HINT: Stack shows most frequent listener (${n[1]}-times)`, n[0]);
					return (this._options?.onListenerError || t)(i), g.None;
				}
				if (this._disposed) return g.None;
				n && (e = e.bind(n));
				const r = new x(e);
				let a;
				this._leakageMon && this._size >= Math.ceil(.2 * this._leakageMon.threshold) && (r.stack = k.create(), a = this._leakageMon.check(r.stack, this._size + 1)), this._listeners ? this._listeners instanceof x ? (this._deliveryQueue ??= new E(), this._listeners = [this._listeners, r]) : this._listeners.push(r) : (this._options?.onWillAddFirstListener?.(this), this._listeners = r, this._options?.onDidAddFirstListener?.(this)), this._options?.onDidAddListener?.(this), this._size++;
				const o = m(() => {
					a?.(), this._removeListener(r);
				});
				return i instanceof p ? i.add(o) : Array.isArray(i) && i.push(o), o;
			}, this._event;
		}
		_removeListener(e) {
			if (this._options?.onWillRemoveListener?.(this), !this._listeners) return;
			if (1 === this._size) return this._listeners = void 0, this._options?.onDidRemoveLastListener?.(this), void (this._size = 0);
			const t = this._listeners, n = t.indexOf(e);
			if (-1 === n) throw new Error("Attempted to dispose unknown listener");
			this._size--, t[n] = void 0;
			const i = this._deliveryQueue.current === this;
			if (2 * this._size <= t.length) {
				let e = 0;
				for (let n = 0; n < t.length; n++) t[n] ? t[e++] = t[n] : i && e < this._deliveryQueue.end && (this._deliveryQueue.end--, e < this._deliveryQueue.i && this._deliveryQueue.i--);
				t.length = e;
			}
		}
		_deliver(e, n) {
			if (!e) return;
			const i = this._options?.onListenerError || t;
			if (i) try {
				e.value(n);
			} catch (r) {
				i(r);
			}
			else e.value(n);
		}
		_deliverQueue(e) {
			const t = e.current._listeners;
			for (; e.i < e.end;) this._deliver(t[e.i++], e.value);
			e.reset();
		}
		fire(e) {
			if (this._deliveryQueue?.current && (this._deliverQueue(this._deliveryQueue), this._perfMon?.stop()), this._perfMon?.start(this._size), this._listeners) if (this._listeners instanceof x) this._deliver(this._listeners, e);
			else {
				const t = this._deliveryQueue;
				t.enqueue(this, e, this._listeners.length), this._deliverQueue(t);
			}
			this._perfMon?.stop();
		}
		hasListeners() {
			return this._size > 0;
		}
	}, E = class {
		constructor() {
			this.i = -1, this.end = 0;
		}
		enqueue(e, t, n) {
			this.i = 0, this.end = n, this.current = e, this.value = t;
		}
		reset() {
			this.i = this.end, this.current = void 0, this.value = void 0;
		}
	};
	function A() {
		return globalThis._VSCODE_NLS_LANGUAGE;
	}
	const R = "pseudo" === A() || "undefined" != typeof document && document.location && "string" == typeof document.location.hash && document.location.hash.indexOf("pseudo=true") >= 0;
	function M(e, t) {
		let n;
		return n = 0 === t.length ? e : e.replace(/\{(\d+)\}/g, (e, n) => {
			const i = t[n[0]];
			let r = e;
			return "string" == typeof i ? r = i : "number" != typeof i && "boolean" != typeof i && null != i || (r = String(i)), r;
		}), R && (n = "［" + n.replace(/[aouei]/g, "$&$&") + "］"), n;
	}
	function N(e, t, ...n) {
		return M("number" == typeof e ? function(e, t) {
			const n = globalThis._VSCODE_NLS_MESSAGES?.[e];
			if ("string" != typeof n) {
				if ("string" == typeof t) return t;
				throw new Error(`!!! NLS MISSING: ${e} !!!`);
			}
			return n;
		}(e, t) : t, n);
	}
	let I, z = !1, O = !1, U = !1, D = !1;
	const F = globalThis;
	let V;
	void 0 !== F.vscode && void 0 !== F.vscode.process ? V = F.vscode.process : "undefined" != typeof process && "string" == typeof process?.versions?.node && (V = process);
	const B = "string" == typeof V?.versions?.electron && "renderer" === V?.type;
	if ("object" == typeof V) {
		z = "win32" === V.platform, O = "darwin" === V.platform, U = "linux" === V.platform, U && V.env.SNAP && V.env.SNAP_REVISION, V.env.CI || V.env.BUILD_ARTIFACTSTAGINGDIRECTORY || V.env.GITHUB_WORKSPACE;
		const e = V.env.VSCODE_NLS_CONFIG;
		if (e) try {
			const t = JSON.parse(e);
			t.userLocale, t.osLocale, t.resolvedLanguage, t.languagePack;
		} catch (El) {}
	} else "object" != typeof navigator || B || (I = navigator.userAgent, z = I.indexOf("Windows") >= 0, O = I.indexOf("Macintosh") >= 0, (I.indexOf("Macintosh") >= 0 || I.indexOf("iPad") >= 0 || I.indexOf("iPhone") >= 0) && navigator.maxTouchPoints && navigator.maxTouchPoints, U = I.indexOf("Linux") >= 0, I?.indexOf("Mobi"), D = !0, A(), navigator.language.toLowerCase());
	const j = z, G = O, $ = (D && "function" == typeof F.importScripts && F.origin, I), X = "function" == typeof F.postMessage && !F.importScripts;
	(() => {
		if (X) {
			const e = [];
			F.addEventListener("message", (t) => {
				if (t.data && t.data.vscodeScheduleAsyncWork) for (let n = 0, i = e.length; n < i; n++) {
					const i = e[n];
					if (i.id === t.data.vscodeScheduleAsyncWork) return e.splice(n, 1), void i.callback();
				}
			});
			let t = 0;
			return (n) => {
				const i = ++t;
				e.push({
					id: i,
					callback: n
				}), F.postMessage({ vscodeScheduleAsyncWork: i }, "*");
			};
		}
		return (e) => setTimeout(e);
	})();
	const Y = !!($ && $.indexOf("Chrome") >= 0);
	$ && $.indexOf("Firefox"), !Y && $ && $.indexOf("Safari"), $ && $.indexOf("Edg/"), $ && $.indexOf("Android");
	function Q(e) {
		return e;
	}
	var Z, ee = class {
		constructor(e, t) {
			this.lastCache = void 0, this.lastArgKey = void 0, "function" == typeof e ? (this._fn = e, this._computeKey = Q) : (this._fn = t, this._computeKey = e.getCacheKey);
		}
		get(e) {
			const t = this._computeKey(e);
			return this.lastArgKey !== t && (this.lastArgKey = t, this.lastCache = this._fn(e)), this.lastCache;
		}
	};
	(function(e) {
		e[e.Uninitialized = 0] = "Uninitialized", e[e.Running = 1] = "Running", e[e.Completed = 2] = "Completed";
	})(Z || (Z = {}));
	var te = class {
		constructor(e) {
			this.executor = e, this._state = Z.Uninitialized;
		}
		get value() {
			if (this._state === Z.Uninitialized) {
				this._state = Z.Running;
				try {
					this._value = this.executor();
				} catch (e) {
					this._error = e;
				} finally {
					this._state = Z.Completed;
				}
			} else if (this._state === Z.Running) throw new Error("Cannot read the value of a lazy that is being initialized");
			if (this._error) throw this._error;
			return this._value;
		}
		get rawValue() {
			return this._value;
		}
	};
	function ne(e) {
		return e >= 65 && e <= 90;
	}
	function ie(e) {
		return 55296 <= e && e <= 56319;
	}
	function re(e) {
		return 56320 <= e && e <= 57343;
	}
	function ae(e, t) {
		return t - 56320 + (e - 55296 << 10) + 65536;
	}
	function oe(e, t, n) {
		const i = e.charCodeAt(n);
		if (ie(i) && n + 1 < t) {
			const t = e.charCodeAt(n + 1);
			if (re(t)) return ae(i, t);
		}
		return i;
	}
	const se = /^[\t\n\r\x20-\x7E]*$/;
	function le(e) {
		return se.test(e);
	}
	(class e {
		static {
			this._INSTANCE = null;
		}
		static getInstance() {
			return e._INSTANCE || (e._INSTANCE = new e()), e._INSTANCE;
		}
		constructor() {
			this._data = JSON.parse("[0,0,0,51229,51255,12,44061,44087,12,127462,127487,6,7083,7085,5,47645,47671,12,54813,54839,12,128678,128678,14,3270,3270,5,9919,9923,14,45853,45879,12,49437,49463,12,53021,53047,12,71216,71218,7,128398,128399,14,129360,129374,14,2519,2519,5,4448,4519,9,9742,9742,14,12336,12336,14,44957,44983,12,46749,46775,12,48541,48567,12,50333,50359,12,52125,52151,12,53917,53943,12,69888,69890,5,73018,73018,5,127990,127990,14,128558,128559,14,128759,128760,14,129653,129655,14,2027,2035,5,2891,2892,7,3761,3761,5,6683,6683,5,8293,8293,4,9825,9826,14,9999,9999,14,43452,43453,5,44509,44535,12,45405,45431,12,46301,46327,12,47197,47223,12,48093,48119,12,48989,49015,12,49885,49911,12,50781,50807,12,51677,51703,12,52573,52599,12,53469,53495,12,54365,54391,12,65279,65279,4,70471,70472,7,72145,72147,7,119173,119179,5,127799,127818,14,128240,128244,14,128512,128512,14,128652,128652,14,128721,128722,14,129292,129292,14,129445,129450,14,129734,129743,14,1476,1477,5,2366,2368,7,2750,2752,7,3076,3076,5,3415,3415,5,4141,4144,5,6109,6109,5,6964,6964,5,7394,7400,5,9197,9198,14,9770,9770,14,9877,9877,14,9968,9969,14,10084,10084,14,43052,43052,5,43713,43713,5,44285,44311,12,44733,44759,12,45181,45207,12,45629,45655,12,46077,46103,12,46525,46551,12,46973,46999,12,47421,47447,12,47869,47895,12,48317,48343,12,48765,48791,12,49213,49239,12,49661,49687,12,50109,50135,12,50557,50583,12,51005,51031,12,51453,51479,12,51901,51927,12,52349,52375,12,52797,52823,12,53245,53271,12,53693,53719,12,54141,54167,12,54589,54615,12,55037,55063,12,69506,69509,5,70191,70193,5,70841,70841,7,71463,71467,5,72330,72342,5,94031,94031,5,123628,123631,5,127763,127765,14,127941,127941,14,128043,128062,14,128302,128317,14,128465,128467,14,128539,128539,14,128640,128640,14,128662,128662,14,128703,128703,14,128745,128745,14,129004,129007,14,129329,129330,14,129402,129402,14,129483,129483,14,129686,129704,14,130048,131069,14,173,173,4,1757,1757,1,2200,2207,5,2434,2435,7,2631,2632,5,2817,2817,5,3008,3008,5,3201,3201,5,3387,3388,5,3542,3542,5,3902,3903,7,4190,4192,5,6002,6003,5,6439,6440,5,6765,6770,7,7019,7027,5,7154,7155,7,8205,8205,13,8505,8505,14,9654,9654,14,9757,9757,14,9792,9792,14,9852,9853,14,9890,9894,14,9937,9937,14,9981,9981,14,10035,10036,14,11035,11036,14,42654,42655,5,43346,43347,7,43587,43587,5,44006,44007,7,44173,44199,12,44397,44423,12,44621,44647,12,44845,44871,12,45069,45095,12,45293,45319,12,45517,45543,12,45741,45767,12,45965,45991,12,46189,46215,12,46413,46439,12,46637,46663,12,46861,46887,12,47085,47111,12,47309,47335,12,47533,47559,12,47757,47783,12,47981,48007,12,48205,48231,12,48429,48455,12,48653,48679,12,48877,48903,12,49101,49127,12,49325,49351,12,49549,49575,12,49773,49799,12,49997,50023,12,50221,50247,12,50445,50471,12,50669,50695,12,50893,50919,12,51117,51143,12,51341,51367,12,51565,51591,12,51789,51815,12,52013,52039,12,52237,52263,12,52461,52487,12,52685,52711,12,52909,52935,12,53133,53159,12,53357,53383,12,53581,53607,12,53805,53831,12,54029,54055,12,54253,54279,12,54477,54503,12,54701,54727,12,54925,54951,12,55149,55175,12,68101,68102,5,69762,69762,7,70067,70069,7,70371,70378,5,70720,70721,7,71087,71087,5,71341,71341,5,71995,71996,5,72249,72249,7,72850,72871,5,73109,73109,5,118576,118598,5,121505,121519,5,127245,127247,14,127568,127569,14,127777,127777,14,127872,127891,14,127956,127967,14,128015,128016,14,128110,128172,14,128259,128259,14,128367,128368,14,128424,128424,14,128488,128488,14,128530,128532,14,128550,128551,14,128566,128566,14,128647,128647,14,128656,128656,14,128667,128673,14,128691,128693,14,128715,128715,14,128728,128732,14,128752,128752,14,128765,128767,14,129096,129103,14,129311,129311,14,129344,129349,14,129394,129394,14,129413,129425,14,129466,129471,14,129511,129535,14,129664,129666,14,129719,129722,14,129760,129767,14,917536,917631,5,13,13,2,1160,1161,5,1564,1564,4,1807,1807,1,2085,2087,5,2307,2307,7,2382,2383,7,2497,2500,5,2563,2563,7,2677,2677,5,2763,2764,7,2879,2879,5,2914,2915,5,3021,3021,5,3142,3144,5,3263,3263,5,3285,3286,5,3398,3400,7,3530,3530,5,3633,3633,5,3864,3865,5,3974,3975,5,4155,4156,7,4229,4230,5,5909,5909,7,6078,6085,7,6277,6278,5,6451,6456,7,6744,6750,5,6846,6846,5,6972,6972,5,7074,7077,5,7146,7148,7,7222,7223,5,7416,7417,5,8234,8238,4,8417,8417,5,9000,9000,14,9203,9203,14,9730,9731,14,9748,9749,14,9762,9763,14,9776,9783,14,9800,9811,14,9831,9831,14,9872,9873,14,9882,9882,14,9900,9903,14,9929,9933,14,9941,9960,14,9974,9974,14,9989,9989,14,10006,10006,14,10062,10062,14,10160,10160,14,11647,11647,5,12953,12953,14,43019,43019,5,43232,43249,5,43443,43443,5,43567,43568,7,43696,43696,5,43765,43765,7,44013,44013,5,44117,44143,12,44229,44255,12,44341,44367,12,44453,44479,12,44565,44591,12,44677,44703,12,44789,44815,12,44901,44927,12,45013,45039,12,45125,45151,12,45237,45263,12,45349,45375,12,45461,45487,12,45573,45599,12,45685,45711,12,45797,45823,12,45909,45935,12,46021,46047,12,46133,46159,12,46245,46271,12,46357,46383,12,46469,46495,12,46581,46607,12,46693,46719,12,46805,46831,12,46917,46943,12,47029,47055,12,47141,47167,12,47253,47279,12,47365,47391,12,47477,47503,12,47589,47615,12,47701,47727,12,47813,47839,12,47925,47951,12,48037,48063,12,48149,48175,12,48261,48287,12,48373,48399,12,48485,48511,12,48597,48623,12,48709,48735,12,48821,48847,12,48933,48959,12,49045,49071,12,49157,49183,12,49269,49295,12,49381,49407,12,49493,49519,12,49605,49631,12,49717,49743,12,49829,49855,12,49941,49967,12,50053,50079,12,50165,50191,12,50277,50303,12,50389,50415,12,50501,50527,12,50613,50639,12,50725,50751,12,50837,50863,12,50949,50975,12,51061,51087,12,51173,51199,12,51285,51311,12,51397,51423,12,51509,51535,12,51621,51647,12,51733,51759,12,51845,51871,12,51957,51983,12,52069,52095,12,52181,52207,12,52293,52319,12,52405,52431,12,52517,52543,12,52629,52655,12,52741,52767,12,52853,52879,12,52965,52991,12,53077,53103,12,53189,53215,12,53301,53327,12,53413,53439,12,53525,53551,12,53637,53663,12,53749,53775,12,53861,53887,12,53973,53999,12,54085,54111,12,54197,54223,12,54309,54335,12,54421,54447,12,54533,54559,12,54645,54671,12,54757,54783,12,54869,54895,12,54981,55007,12,55093,55119,12,55243,55291,10,66045,66045,5,68325,68326,5,69688,69702,5,69817,69818,5,69957,69958,7,70089,70092,5,70198,70199,5,70462,70462,5,70502,70508,5,70750,70750,5,70846,70846,7,71100,71101,5,71230,71230,7,71351,71351,5,71737,71738,5,72000,72000,7,72160,72160,5,72273,72278,5,72752,72758,5,72882,72883,5,73031,73031,5,73461,73462,7,94192,94193,7,119149,119149,7,121403,121452,5,122915,122916,5,126980,126980,14,127358,127359,14,127535,127535,14,127759,127759,14,127771,127771,14,127792,127793,14,127825,127867,14,127897,127899,14,127945,127945,14,127985,127986,14,128000,128007,14,128021,128021,14,128066,128100,14,128184,128235,14,128249,128252,14,128266,128276,14,128335,128335,14,128379,128390,14,128407,128419,14,128444,128444,14,128481,128481,14,128499,128499,14,128526,128526,14,128536,128536,14,128543,128543,14,128556,128556,14,128564,128564,14,128577,128580,14,128643,128645,14,128649,128649,14,128654,128654,14,128660,128660,14,128664,128664,14,128675,128675,14,128686,128689,14,128695,128696,14,128705,128709,14,128717,128719,14,128725,128725,14,128736,128741,14,128747,128748,14,128755,128755,14,128762,128762,14,128981,128991,14,129009,129023,14,129160,129167,14,129296,129304,14,129320,129327,14,129340,129342,14,129356,129356,14,129388,129392,14,129399,129400,14,129404,129407,14,129432,129442,14,129454,129455,14,129473,129474,14,129485,129487,14,129648,129651,14,129659,129660,14,129671,129679,14,129709,129711,14,129728,129730,14,129751,129753,14,129776,129782,14,917505,917505,4,917760,917999,5,10,10,3,127,159,4,768,879,5,1471,1471,5,1536,1541,1,1648,1648,5,1767,1768,5,1840,1866,5,2070,2073,5,2137,2139,5,2274,2274,1,2363,2363,7,2377,2380,7,2402,2403,5,2494,2494,5,2507,2508,7,2558,2558,5,2622,2624,7,2641,2641,5,2691,2691,7,2759,2760,5,2786,2787,5,2876,2876,5,2881,2884,5,2901,2902,5,3006,3006,5,3014,3016,7,3072,3072,5,3134,3136,5,3157,3158,5,3260,3260,5,3266,3266,5,3274,3275,7,3328,3329,5,3391,3392,7,3405,3405,5,3457,3457,5,3536,3537,7,3551,3551,5,3636,3642,5,3764,3772,5,3895,3895,5,3967,3967,7,3993,4028,5,4146,4151,5,4182,4183,7,4226,4226,5,4253,4253,5,4957,4959,5,5940,5940,7,6070,6070,7,6087,6088,7,6158,6158,4,6432,6434,5,6448,6449,7,6679,6680,5,6742,6742,5,6754,6754,5,6783,6783,5,6912,6915,5,6966,6970,5,6978,6978,5,7042,7042,7,7080,7081,5,7143,7143,7,7150,7150,7,7212,7219,5,7380,7392,5,7412,7412,5,8203,8203,4,8232,8232,4,8265,8265,14,8400,8412,5,8421,8432,5,8617,8618,14,9167,9167,14,9200,9200,14,9410,9410,14,9723,9726,14,9733,9733,14,9745,9745,14,9752,9752,14,9760,9760,14,9766,9766,14,9774,9774,14,9786,9786,14,9794,9794,14,9823,9823,14,9828,9828,14,9833,9850,14,9855,9855,14,9875,9875,14,9880,9880,14,9885,9887,14,9896,9897,14,9906,9916,14,9926,9927,14,9935,9935,14,9939,9939,14,9962,9962,14,9972,9972,14,9978,9978,14,9986,9986,14,9997,9997,14,10002,10002,14,10017,10017,14,10055,10055,14,10071,10071,14,10133,10135,14,10548,10549,14,11093,11093,14,12330,12333,5,12441,12442,5,42608,42610,5,43010,43010,5,43045,43046,5,43188,43203,7,43302,43309,5,43392,43394,5,43446,43449,5,43493,43493,5,43571,43572,7,43597,43597,7,43703,43704,5,43756,43757,5,44003,44004,7,44009,44010,7,44033,44059,12,44089,44115,12,44145,44171,12,44201,44227,12,44257,44283,12,44313,44339,12,44369,44395,12,44425,44451,12,44481,44507,12,44537,44563,12,44593,44619,12,44649,44675,12,44705,44731,12,44761,44787,12,44817,44843,12,44873,44899,12,44929,44955,12,44985,45011,12,45041,45067,12,45097,45123,12,45153,45179,12,45209,45235,12,45265,45291,12,45321,45347,12,45377,45403,12,45433,45459,12,45489,45515,12,45545,45571,12,45601,45627,12,45657,45683,12,45713,45739,12,45769,45795,12,45825,45851,12,45881,45907,12,45937,45963,12,45993,46019,12,46049,46075,12,46105,46131,12,46161,46187,12,46217,46243,12,46273,46299,12,46329,46355,12,46385,46411,12,46441,46467,12,46497,46523,12,46553,46579,12,46609,46635,12,46665,46691,12,46721,46747,12,46777,46803,12,46833,46859,12,46889,46915,12,46945,46971,12,47001,47027,12,47057,47083,12,47113,47139,12,47169,47195,12,47225,47251,12,47281,47307,12,47337,47363,12,47393,47419,12,47449,47475,12,47505,47531,12,47561,47587,12,47617,47643,12,47673,47699,12,47729,47755,12,47785,47811,12,47841,47867,12,47897,47923,12,47953,47979,12,48009,48035,12,48065,48091,12,48121,48147,12,48177,48203,12,48233,48259,12,48289,48315,12,48345,48371,12,48401,48427,12,48457,48483,12,48513,48539,12,48569,48595,12,48625,48651,12,48681,48707,12,48737,48763,12,48793,48819,12,48849,48875,12,48905,48931,12,48961,48987,12,49017,49043,12,49073,49099,12,49129,49155,12,49185,49211,12,49241,49267,12,49297,49323,12,49353,49379,12,49409,49435,12,49465,49491,12,49521,49547,12,49577,49603,12,49633,49659,12,49689,49715,12,49745,49771,12,49801,49827,12,49857,49883,12,49913,49939,12,49969,49995,12,50025,50051,12,50081,50107,12,50137,50163,12,50193,50219,12,50249,50275,12,50305,50331,12,50361,50387,12,50417,50443,12,50473,50499,12,50529,50555,12,50585,50611,12,50641,50667,12,50697,50723,12,50753,50779,12,50809,50835,12,50865,50891,12,50921,50947,12,50977,51003,12,51033,51059,12,51089,51115,12,51145,51171,12,51201,51227,12,51257,51283,12,51313,51339,12,51369,51395,12,51425,51451,12,51481,51507,12,51537,51563,12,51593,51619,12,51649,51675,12,51705,51731,12,51761,51787,12,51817,51843,12,51873,51899,12,51929,51955,12,51985,52011,12,52041,52067,12,52097,52123,12,52153,52179,12,52209,52235,12,52265,52291,12,52321,52347,12,52377,52403,12,52433,52459,12,52489,52515,12,52545,52571,12,52601,52627,12,52657,52683,12,52713,52739,12,52769,52795,12,52825,52851,12,52881,52907,12,52937,52963,12,52993,53019,12,53049,53075,12,53105,53131,12,53161,53187,12,53217,53243,12,53273,53299,12,53329,53355,12,53385,53411,12,53441,53467,12,53497,53523,12,53553,53579,12,53609,53635,12,53665,53691,12,53721,53747,12,53777,53803,12,53833,53859,12,53889,53915,12,53945,53971,12,54001,54027,12,54057,54083,12,54113,54139,12,54169,54195,12,54225,54251,12,54281,54307,12,54337,54363,12,54393,54419,12,54449,54475,12,54505,54531,12,54561,54587,12,54617,54643,12,54673,54699,12,54729,54755,12,54785,54811,12,54841,54867,12,54897,54923,12,54953,54979,12,55009,55035,12,55065,55091,12,55121,55147,12,55177,55203,12,65024,65039,5,65520,65528,4,66422,66426,5,68152,68154,5,69291,69292,5,69633,69633,5,69747,69748,5,69811,69814,5,69826,69826,5,69932,69932,7,70016,70017,5,70079,70080,7,70095,70095,5,70196,70196,5,70367,70367,5,70402,70403,7,70464,70464,5,70487,70487,5,70709,70711,7,70725,70725,7,70833,70834,7,70843,70844,7,70849,70849,7,71090,71093,5,71103,71104,5,71227,71228,7,71339,71339,5,71344,71349,5,71458,71461,5,71727,71735,5,71985,71989,7,71998,71998,5,72002,72002,7,72154,72155,5,72193,72202,5,72251,72254,5,72281,72283,5,72344,72345,5,72766,72766,7,72874,72880,5,72885,72886,5,73023,73029,5,73104,73105,5,73111,73111,5,92912,92916,5,94095,94098,5,113824,113827,4,119142,119142,7,119155,119162,4,119362,119364,5,121476,121476,5,122888,122904,5,123184,123190,5,125252,125258,5,127183,127183,14,127340,127343,14,127377,127386,14,127491,127503,14,127548,127551,14,127744,127756,14,127761,127761,14,127769,127769,14,127773,127774,14,127780,127788,14,127796,127797,14,127820,127823,14,127869,127869,14,127894,127895,14,127902,127903,14,127943,127943,14,127947,127950,14,127972,127972,14,127988,127988,14,127992,127994,14,128009,128011,14,128019,128019,14,128023,128041,14,128064,128064,14,128102,128107,14,128174,128181,14,128238,128238,14,128246,128247,14,128254,128254,14,128264,128264,14,128278,128299,14,128329,128330,14,128348,128359,14,128371,128377,14,128392,128393,14,128401,128404,14,128421,128421,14,128433,128434,14,128450,128452,14,128476,128478,14,128483,128483,14,128495,128495,14,128506,128506,14,128519,128520,14,128528,128528,14,128534,128534,14,128538,128538,14,128540,128542,14,128544,128549,14,128552,128555,14,128557,128557,14,128560,128563,14,128565,128565,14,128567,128576,14,128581,128591,14,128641,128642,14,128646,128646,14,128648,128648,14,128650,128651,14,128653,128653,14,128655,128655,14,128657,128659,14,128661,128661,14,128663,128663,14,128665,128666,14,128674,128674,14,128676,128677,14,128679,128685,14,128690,128690,14,128694,128694,14,128697,128702,14,128704,128704,14,128710,128714,14,128716,128716,14,128720,128720,14,128723,128724,14,128726,128727,14,128733,128735,14,128742,128744,14,128746,128746,14,128749,128751,14,128753,128754,14,128756,128758,14,128761,128761,14,128763,128764,14,128884,128895,14,128992,129003,14,129008,129008,14,129036,129039,14,129114,129119,14,129198,129279,14,129293,129295,14,129305,129310,14,129312,129319,14,129328,129328,14,129331,129338,14,129343,129343,14,129351,129355,14,129357,129359,14,129375,129387,14,129393,129393,14,129395,129398,14,129401,129401,14,129403,129403,14,129408,129412,14,129426,129431,14,129443,129444,14,129451,129453,14,129456,129465,14,129472,129472,14,129475,129482,14,129484,129484,14,129488,129510,14,129536,129647,14,129652,129652,14,129656,129658,14,129661,129663,14,129667,129670,14,129680,129685,14,129705,129708,14,129712,129718,14,129723,129727,14,129731,129733,14,129744,129750,14,129754,129759,14,129768,129775,14,129783,129791,14,917504,917504,4,917506,917535,4,917632,917759,4,918000,921599,4,0,9,4,11,12,4,14,31,4,169,169,14,174,174,14,1155,1159,5,1425,1469,5,1473,1474,5,1479,1479,5,1552,1562,5,1611,1631,5,1750,1756,5,1759,1764,5,1770,1773,5,1809,1809,5,1958,1968,5,2045,2045,5,2075,2083,5,2089,2093,5,2192,2193,1,2250,2273,5,2275,2306,5,2362,2362,5,2364,2364,5,2369,2376,5,2381,2381,5,2385,2391,5,2433,2433,5,2492,2492,5,2495,2496,7,2503,2504,7,2509,2509,5,2530,2531,5,2561,2562,5,2620,2620,5,2625,2626,5,2635,2637,5,2672,2673,5,2689,2690,5,2748,2748,5,2753,2757,5,2761,2761,7,2765,2765,5,2810,2815,5,2818,2819,7,2878,2878,5,2880,2880,7,2887,2888,7,2893,2893,5,2903,2903,5,2946,2946,5,3007,3007,7,3009,3010,7,3018,3020,7,3031,3031,5,3073,3075,7,3132,3132,5,3137,3140,7,3146,3149,5,3170,3171,5,3202,3203,7,3262,3262,7,3264,3265,7,3267,3268,7,3271,3272,7,3276,3277,5,3298,3299,5,3330,3331,7,3390,3390,5,3393,3396,5,3402,3404,7,3406,3406,1,3426,3427,5,3458,3459,7,3535,3535,5,3538,3540,5,3544,3550,7,3570,3571,7,3635,3635,7,3655,3662,5,3763,3763,7,3784,3789,5,3893,3893,5,3897,3897,5,3953,3966,5,3968,3972,5,3981,3991,5,4038,4038,5,4145,4145,7,4153,4154,5,4157,4158,5,4184,4185,5,4209,4212,5,4228,4228,7,4237,4237,5,4352,4447,8,4520,4607,10,5906,5908,5,5938,5939,5,5970,5971,5,6068,6069,5,6071,6077,5,6086,6086,5,6089,6099,5,6155,6157,5,6159,6159,5,6313,6313,5,6435,6438,7,6441,6443,7,6450,6450,5,6457,6459,5,6681,6682,7,6741,6741,7,6743,6743,7,6752,6752,5,6757,6764,5,6771,6780,5,6832,6845,5,6847,6862,5,6916,6916,7,6965,6965,5,6971,6971,7,6973,6977,7,6979,6980,7,7040,7041,5,7073,7073,7,7078,7079,7,7082,7082,7,7142,7142,5,7144,7145,5,7149,7149,5,7151,7153,5,7204,7211,7,7220,7221,7,7376,7378,5,7393,7393,7,7405,7405,5,7415,7415,7,7616,7679,5,8204,8204,5,8206,8207,4,8233,8233,4,8252,8252,14,8288,8292,4,8294,8303,4,8413,8416,5,8418,8420,5,8482,8482,14,8596,8601,14,8986,8987,14,9096,9096,14,9193,9196,14,9199,9199,14,9201,9202,14,9208,9210,14,9642,9643,14,9664,9664,14,9728,9729,14,9732,9732,14,9735,9741,14,9743,9744,14,9746,9746,14,9750,9751,14,9753,9756,14,9758,9759,14,9761,9761,14,9764,9765,14,9767,9769,14,9771,9773,14,9775,9775,14,9784,9785,14,9787,9791,14,9793,9793,14,9795,9799,14,9812,9822,14,9824,9824,14,9827,9827,14,9829,9830,14,9832,9832,14,9851,9851,14,9854,9854,14,9856,9861,14,9874,9874,14,9876,9876,14,9878,9879,14,9881,9881,14,9883,9884,14,9888,9889,14,9895,9895,14,9898,9899,14,9904,9905,14,9917,9918,14,9924,9925,14,9928,9928,14,9934,9934,14,9936,9936,14,9938,9938,14,9940,9940,14,9961,9961,14,9963,9967,14,9970,9971,14,9973,9973,14,9975,9977,14,9979,9980,14,9982,9985,14,9987,9988,14,9992,9996,14,9998,9998,14,10000,10001,14,10004,10004,14,10013,10013,14,10024,10024,14,10052,10052,14,10060,10060,14,10067,10069,14,10083,10083,14,10085,10087,14,10145,10145,14,10175,10175,14,11013,11015,14,11088,11088,14,11503,11505,5,11744,11775,5,12334,12335,5,12349,12349,14,12951,12951,14,42607,42607,5,42612,42621,5,42736,42737,5,43014,43014,5,43043,43044,7,43047,43047,7,43136,43137,7,43204,43205,5,43263,43263,5,43335,43345,5,43360,43388,8,43395,43395,7,43444,43445,7,43450,43451,7,43454,43456,7,43561,43566,5,43569,43570,5,43573,43574,5,43596,43596,5,43644,43644,5,43698,43700,5,43710,43711,5,43755,43755,7,43758,43759,7,43766,43766,5,44005,44005,5,44008,44008,5,44012,44012,7,44032,44032,11,44060,44060,11,44088,44088,11,44116,44116,11,44144,44144,11,44172,44172,11,44200,44200,11,44228,44228,11,44256,44256,11,44284,44284,11,44312,44312,11,44340,44340,11,44368,44368,11,44396,44396,11,44424,44424,11,44452,44452,11,44480,44480,11,44508,44508,11,44536,44536,11,44564,44564,11,44592,44592,11,44620,44620,11,44648,44648,11,44676,44676,11,44704,44704,11,44732,44732,11,44760,44760,11,44788,44788,11,44816,44816,11,44844,44844,11,44872,44872,11,44900,44900,11,44928,44928,11,44956,44956,11,44984,44984,11,45012,45012,11,45040,45040,11,45068,45068,11,45096,45096,11,45124,45124,11,45152,45152,11,45180,45180,11,45208,45208,11,45236,45236,11,45264,45264,11,45292,45292,11,45320,45320,11,45348,45348,11,45376,45376,11,45404,45404,11,45432,45432,11,45460,45460,11,45488,45488,11,45516,45516,11,45544,45544,11,45572,45572,11,45600,45600,11,45628,45628,11,45656,45656,11,45684,45684,11,45712,45712,11,45740,45740,11,45768,45768,11,45796,45796,11,45824,45824,11,45852,45852,11,45880,45880,11,45908,45908,11,45936,45936,11,45964,45964,11,45992,45992,11,46020,46020,11,46048,46048,11,46076,46076,11,46104,46104,11,46132,46132,11,46160,46160,11,46188,46188,11,46216,46216,11,46244,46244,11,46272,46272,11,46300,46300,11,46328,46328,11,46356,46356,11,46384,46384,11,46412,46412,11,46440,46440,11,46468,46468,11,46496,46496,11,46524,46524,11,46552,46552,11,46580,46580,11,46608,46608,11,46636,46636,11,46664,46664,11,46692,46692,11,46720,46720,11,46748,46748,11,46776,46776,11,46804,46804,11,46832,46832,11,46860,46860,11,46888,46888,11,46916,46916,11,46944,46944,11,46972,46972,11,47000,47000,11,47028,47028,11,47056,47056,11,47084,47084,11,47112,47112,11,47140,47140,11,47168,47168,11,47196,47196,11,47224,47224,11,47252,47252,11,47280,47280,11,47308,47308,11,47336,47336,11,47364,47364,11,47392,47392,11,47420,47420,11,47448,47448,11,47476,47476,11,47504,47504,11,47532,47532,11,47560,47560,11,47588,47588,11,47616,47616,11,47644,47644,11,47672,47672,11,47700,47700,11,47728,47728,11,47756,47756,11,47784,47784,11,47812,47812,11,47840,47840,11,47868,47868,11,47896,47896,11,47924,47924,11,47952,47952,11,47980,47980,11,48008,48008,11,48036,48036,11,48064,48064,11,48092,48092,11,48120,48120,11,48148,48148,11,48176,48176,11,48204,48204,11,48232,48232,11,48260,48260,11,48288,48288,11,48316,48316,11,48344,48344,11,48372,48372,11,48400,48400,11,48428,48428,11,48456,48456,11,48484,48484,11,48512,48512,11,48540,48540,11,48568,48568,11,48596,48596,11,48624,48624,11,48652,48652,11,48680,48680,11,48708,48708,11,48736,48736,11,48764,48764,11,48792,48792,11,48820,48820,11,48848,48848,11,48876,48876,11,48904,48904,11,48932,48932,11,48960,48960,11,48988,48988,11,49016,49016,11,49044,49044,11,49072,49072,11,49100,49100,11,49128,49128,11,49156,49156,11,49184,49184,11,49212,49212,11,49240,49240,11,49268,49268,11,49296,49296,11,49324,49324,11,49352,49352,11,49380,49380,11,49408,49408,11,49436,49436,11,49464,49464,11,49492,49492,11,49520,49520,11,49548,49548,11,49576,49576,11,49604,49604,11,49632,49632,11,49660,49660,11,49688,49688,11,49716,49716,11,49744,49744,11,49772,49772,11,49800,49800,11,49828,49828,11,49856,49856,11,49884,49884,11,49912,49912,11,49940,49940,11,49968,49968,11,49996,49996,11,50024,50024,11,50052,50052,11,50080,50080,11,50108,50108,11,50136,50136,11,50164,50164,11,50192,50192,11,50220,50220,11,50248,50248,11,50276,50276,11,50304,50304,11,50332,50332,11,50360,50360,11,50388,50388,11,50416,50416,11,50444,50444,11,50472,50472,11,50500,50500,11,50528,50528,11,50556,50556,11,50584,50584,11,50612,50612,11,50640,50640,11,50668,50668,11,50696,50696,11,50724,50724,11,50752,50752,11,50780,50780,11,50808,50808,11,50836,50836,11,50864,50864,11,50892,50892,11,50920,50920,11,50948,50948,11,50976,50976,11,51004,51004,11,51032,51032,11,51060,51060,11,51088,51088,11,51116,51116,11,51144,51144,11,51172,51172,11,51200,51200,11,51228,51228,11,51256,51256,11,51284,51284,11,51312,51312,11,51340,51340,11,51368,51368,11,51396,51396,11,51424,51424,11,51452,51452,11,51480,51480,11,51508,51508,11,51536,51536,11,51564,51564,11,51592,51592,11,51620,51620,11,51648,51648,11,51676,51676,11,51704,51704,11,51732,51732,11,51760,51760,11,51788,51788,11,51816,51816,11,51844,51844,11,51872,51872,11,51900,51900,11,51928,51928,11,51956,51956,11,51984,51984,11,52012,52012,11,52040,52040,11,52068,52068,11,52096,52096,11,52124,52124,11,52152,52152,11,52180,52180,11,52208,52208,11,52236,52236,11,52264,52264,11,52292,52292,11,52320,52320,11,52348,52348,11,52376,52376,11,52404,52404,11,52432,52432,11,52460,52460,11,52488,52488,11,52516,52516,11,52544,52544,11,52572,52572,11,52600,52600,11,52628,52628,11,52656,52656,11,52684,52684,11,52712,52712,11,52740,52740,11,52768,52768,11,52796,52796,11,52824,52824,11,52852,52852,11,52880,52880,11,52908,52908,11,52936,52936,11,52964,52964,11,52992,52992,11,53020,53020,11,53048,53048,11,53076,53076,11,53104,53104,11,53132,53132,11,53160,53160,11,53188,53188,11,53216,53216,11,53244,53244,11,53272,53272,11,53300,53300,11,53328,53328,11,53356,53356,11,53384,53384,11,53412,53412,11,53440,53440,11,53468,53468,11,53496,53496,11,53524,53524,11,53552,53552,11,53580,53580,11,53608,53608,11,53636,53636,11,53664,53664,11,53692,53692,11,53720,53720,11,53748,53748,11,53776,53776,11,53804,53804,11,53832,53832,11,53860,53860,11,53888,53888,11,53916,53916,11,53944,53944,11,53972,53972,11,54000,54000,11,54028,54028,11,54056,54056,11,54084,54084,11,54112,54112,11,54140,54140,11,54168,54168,11,54196,54196,11,54224,54224,11,54252,54252,11,54280,54280,11,54308,54308,11,54336,54336,11,54364,54364,11,54392,54392,11,54420,54420,11,54448,54448,11,54476,54476,11,54504,54504,11,54532,54532,11,54560,54560,11,54588,54588,11,54616,54616,11,54644,54644,11,54672,54672,11,54700,54700,11,54728,54728,11,54756,54756,11,54784,54784,11,54812,54812,11,54840,54840,11,54868,54868,11,54896,54896,11,54924,54924,11,54952,54952,11,54980,54980,11,55008,55008,11,55036,55036,11,55064,55064,11,55092,55092,11,55120,55120,11,55148,55148,11,55176,55176,11,55216,55238,9,64286,64286,5,65056,65071,5,65438,65439,5,65529,65531,4,66272,66272,5,68097,68099,5,68108,68111,5,68159,68159,5,68900,68903,5,69446,69456,5,69632,69632,7,69634,69634,7,69744,69744,5,69759,69761,5,69808,69810,7,69815,69816,7,69821,69821,1,69837,69837,1,69927,69931,5,69933,69940,5,70003,70003,5,70018,70018,7,70070,70078,5,70082,70083,1,70094,70094,7,70188,70190,7,70194,70195,7,70197,70197,7,70206,70206,5,70368,70370,7,70400,70401,5,70459,70460,5,70463,70463,7,70465,70468,7,70475,70477,7,70498,70499,7,70512,70516,5,70712,70719,5,70722,70724,5,70726,70726,5,70832,70832,5,70835,70840,5,70842,70842,5,70845,70845,5,70847,70848,5,70850,70851,5,71088,71089,7,71096,71099,7,71102,71102,7,71132,71133,5,71219,71226,5,71229,71229,5,71231,71232,5,71340,71340,7,71342,71343,7,71350,71350,7,71453,71455,5,71462,71462,7,71724,71726,7,71736,71736,7,71984,71984,5,71991,71992,7,71997,71997,7,71999,71999,1,72001,72001,1,72003,72003,5,72148,72151,5,72156,72159,7,72164,72164,7,72243,72248,5,72250,72250,1,72263,72263,5,72279,72280,7,72324,72329,1,72343,72343,7,72751,72751,7,72760,72765,5,72767,72767,5,72873,72873,7,72881,72881,7,72884,72884,7,73009,73014,5,73020,73021,5,73030,73030,1,73098,73102,7,73107,73108,7,73110,73110,7,73459,73460,5,78896,78904,4,92976,92982,5,94033,94087,7,94180,94180,5,113821,113822,5,118528,118573,5,119141,119141,5,119143,119145,5,119150,119154,5,119163,119170,5,119210,119213,5,121344,121398,5,121461,121461,5,121499,121503,5,122880,122886,5,122907,122913,5,122918,122922,5,123566,123566,5,125136,125142,5,126976,126979,14,126981,127182,14,127184,127231,14,127279,127279,14,127344,127345,14,127374,127374,14,127405,127461,14,127489,127490,14,127514,127514,14,127538,127546,14,127561,127567,14,127570,127743,14,127757,127758,14,127760,127760,14,127762,127762,14,127766,127768,14,127770,127770,14,127772,127772,14,127775,127776,14,127778,127779,14,127789,127791,14,127794,127795,14,127798,127798,14,127819,127819,14,127824,127824,14,127868,127868,14,127870,127871,14,127892,127893,14,127896,127896,14,127900,127901,14,127904,127940,14,127942,127942,14,127944,127944,14,127946,127946,14,127951,127955,14,127968,127971,14,127973,127984,14,127987,127987,14,127989,127989,14,127991,127991,14,127995,127999,5,128008,128008,14,128012,128014,14,128017,128018,14,128020,128020,14,128022,128022,14,128042,128042,14,128063,128063,14,128065,128065,14,128101,128101,14,128108,128109,14,128173,128173,14,128182,128183,14,128236,128237,14,128239,128239,14,128245,128245,14,128248,128248,14,128253,128253,14,128255,128258,14,128260,128263,14,128265,128265,14,128277,128277,14,128300,128301,14,128326,128328,14,128331,128334,14,128336,128347,14,128360,128366,14,128369,128370,14,128378,128378,14,128391,128391,14,128394,128397,14,128400,128400,14,128405,128406,14,128420,128420,14,128422,128423,14,128425,128432,14,128435,128443,14,128445,128449,14,128453,128464,14,128468,128475,14,128479,128480,14,128482,128482,14,128484,128487,14,128489,128494,14,128496,128498,14,128500,128505,14,128507,128511,14,128513,128518,14,128521,128525,14,128527,128527,14,128529,128529,14,128533,128533,14,128535,128535,14,128537,128537,14]");
		}
		getGraphemeBreakType(e) {
			if (e < 32) return 10 === e ? 3 : 13 === e ? 2 : 4;
			if (e < 127) return 0;
			const t = this._data, n = t.length / 3;
			let i = 1;
			for (; i <= n;) if (e < t[3 * i]) i *= 2;
			else {
				if (!(e > t[3 * i + 1])) return t[3 * i + 2];
				i = 2 * i + 1;
			}
			return 0;
		}
	});
	var ce = class e {
		static {
			this.ambiguousCharacterData = new te(() => JSON.parse("{\"_common\":[8232,32,8233,32,5760,32,8192,32,8193,32,8194,32,8195,32,8196,32,8197,32,8198,32,8200,32,8201,32,8202,32,8287,32,8199,32,8239,32,2042,95,65101,95,65102,95,65103,95,8208,45,8209,45,8210,45,65112,45,1748,45,8259,45,727,45,8722,45,10134,45,11450,45,1549,44,1643,44,184,44,42233,44,894,59,2307,58,2691,58,1417,58,1795,58,1796,58,5868,58,65072,58,6147,58,6153,58,8282,58,1475,58,760,58,42889,58,8758,58,720,58,42237,58,451,33,11601,33,660,63,577,63,2429,63,5038,63,42731,63,119149,46,8228,46,1793,46,1794,46,42510,46,68176,46,1632,46,1776,46,42232,46,1373,96,65287,96,8219,96,1523,96,8242,96,1370,96,8175,96,65344,96,900,96,8189,96,8125,96,8127,96,8190,96,697,96,884,96,712,96,714,96,715,96,756,96,699,96,701,96,700,96,702,96,42892,96,1497,96,2036,96,2037,96,5194,96,5836,96,94033,96,94034,96,65339,91,10088,40,10098,40,12308,40,64830,40,65341,93,10089,41,10099,41,12309,41,64831,41,10100,123,119060,123,10101,125,65342,94,8270,42,1645,42,8727,42,66335,42,5941,47,8257,47,8725,47,8260,47,9585,47,10187,47,10744,47,119354,47,12755,47,12339,47,11462,47,20031,47,12035,47,65340,92,65128,92,8726,92,10189,92,10741,92,10745,92,119311,92,119355,92,12756,92,20022,92,12034,92,42872,38,708,94,710,94,5869,43,10133,43,66203,43,8249,60,10094,60,706,60,119350,60,5176,60,5810,60,5120,61,11840,61,12448,61,42239,61,8250,62,10095,62,707,62,119351,62,5171,62,94015,62,8275,126,732,126,8128,126,8764,126,65372,124,65293,45,118002,50,120784,50,120794,50,120804,50,120814,50,120824,50,130034,50,42842,50,423,50,1000,50,42564,50,5311,50,42735,50,119302,51,118003,51,120785,51,120795,51,120805,51,120815,51,120825,51,130035,51,42923,51,540,51,439,51,42858,51,11468,51,1248,51,94011,51,71882,51,118004,52,120786,52,120796,52,120806,52,120816,52,120826,52,130036,52,5070,52,71855,52,118005,53,120787,53,120797,53,120807,53,120817,53,120827,53,130037,53,444,53,71867,53,118006,54,120788,54,120798,54,120808,54,120818,54,120828,54,130038,54,11474,54,5102,54,71893,54,119314,55,118007,55,120789,55,120799,55,120809,55,120819,55,120829,55,130039,55,66770,55,71878,55,2819,56,2538,56,2666,56,125131,56,118008,56,120790,56,120800,56,120810,56,120820,56,120830,56,130040,56,547,56,546,56,66330,56,2663,57,2920,57,2541,57,3437,57,118009,57,120791,57,120801,57,120811,57,120821,57,120831,57,130041,57,42862,57,11466,57,71884,57,71852,57,71894,57,9082,97,65345,97,119834,97,119886,97,119938,97,119990,97,120042,97,120094,97,120146,97,120198,97,120250,97,120302,97,120354,97,120406,97,120458,97,593,97,945,97,120514,97,120572,97,120630,97,120688,97,120746,97,65313,65,117974,65,119808,65,119860,65,119912,65,119964,65,120016,65,120068,65,120120,65,120172,65,120224,65,120276,65,120328,65,120380,65,120432,65,913,65,120488,65,120546,65,120604,65,120662,65,120720,65,5034,65,5573,65,42222,65,94016,65,66208,65,119835,98,119887,98,119939,98,119991,98,120043,98,120095,98,120147,98,120199,98,120251,98,120303,98,120355,98,120407,98,120459,98,388,98,5071,98,5234,98,5551,98,65314,66,8492,66,117975,66,119809,66,119861,66,119913,66,120017,66,120069,66,120121,66,120173,66,120225,66,120277,66,120329,66,120381,66,120433,66,42932,66,914,66,120489,66,120547,66,120605,66,120663,66,120721,66,5108,66,5623,66,42192,66,66178,66,66209,66,66305,66,65347,99,8573,99,119836,99,119888,99,119940,99,119992,99,120044,99,120096,99,120148,99,120200,99,120252,99,120304,99,120356,99,120408,99,120460,99,7428,99,1010,99,11429,99,43951,99,66621,99,128844,67,71913,67,71922,67,65315,67,8557,67,8450,67,8493,67,117976,67,119810,67,119862,67,119914,67,119966,67,120018,67,120174,67,120226,67,120278,67,120330,67,120382,67,120434,67,1017,67,11428,67,5087,67,42202,67,66210,67,66306,67,66581,67,66844,67,8574,100,8518,100,119837,100,119889,100,119941,100,119993,100,120045,100,120097,100,120149,100,120201,100,120253,100,120305,100,120357,100,120409,100,120461,100,1281,100,5095,100,5231,100,42194,100,8558,68,8517,68,117977,68,119811,68,119863,68,119915,68,119967,68,120019,68,120071,68,120123,68,120175,68,120227,68,120279,68,120331,68,120383,68,120435,68,5024,68,5598,68,5610,68,42195,68,8494,101,65349,101,8495,101,8519,101,119838,101,119890,101,119942,101,120046,101,120098,101,120150,101,120202,101,120254,101,120306,101,120358,101,120410,101,120462,101,43826,101,1213,101,8959,69,65317,69,8496,69,117978,69,119812,69,119864,69,119916,69,120020,69,120072,69,120124,69,120176,69,120228,69,120280,69,120332,69,120384,69,120436,69,917,69,120492,69,120550,69,120608,69,120666,69,120724,69,11577,69,5036,69,42224,69,71846,69,71854,69,66182,69,119839,102,119891,102,119943,102,119995,102,120047,102,120099,102,120151,102,120203,102,120255,102,120307,102,120359,102,120411,102,120463,102,43829,102,42905,102,383,102,7837,102,1412,102,119315,70,8497,70,117979,70,119813,70,119865,70,119917,70,120021,70,120073,70,120125,70,120177,70,120229,70,120281,70,120333,70,120385,70,120437,70,42904,70,988,70,120778,70,5556,70,42205,70,71874,70,71842,70,66183,70,66213,70,66853,70,65351,103,8458,103,119840,103,119892,103,119944,103,120048,103,120100,103,120152,103,120204,103,120256,103,120308,103,120360,103,120412,103,120464,103,609,103,7555,103,397,103,1409,103,117980,71,119814,71,119866,71,119918,71,119970,71,120022,71,120074,71,120126,71,120178,71,120230,71,120282,71,120334,71,120386,71,120438,71,1292,71,5056,71,5107,71,42198,71,65352,104,8462,104,119841,104,119945,104,119997,104,120049,104,120101,104,120153,104,120205,104,120257,104,120309,104,120361,104,120413,104,120465,104,1211,104,1392,104,5058,104,65320,72,8459,72,8460,72,8461,72,117981,72,119815,72,119867,72,119919,72,120023,72,120179,72,120231,72,120283,72,120335,72,120387,72,120439,72,919,72,120494,72,120552,72,120610,72,120668,72,120726,72,11406,72,5051,72,5500,72,42215,72,66255,72,731,105,9075,105,65353,105,8560,105,8505,105,8520,105,119842,105,119894,105,119946,105,119998,105,120050,105,120102,105,120154,105,120206,105,120258,105,120310,105,120362,105,120414,105,120466,105,120484,105,618,105,617,105,953,105,8126,105,890,105,120522,105,120580,105,120638,105,120696,105,120754,105,1110,105,42567,105,1231,105,43893,105,5029,105,71875,105,65354,106,8521,106,119843,106,119895,106,119947,106,119999,106,120051,106,120103,106,120155,106,120207,106,120259,106,120311,106,120363,106,120415,106,120467,106,1011,106,1112,106,65322,74,117983,74,119817,74,119869,74,119921,74,119973,74,120025,74,120077,74,120129,74,120181,74,120233,74,120285,74,120337,74,120389,74,120441,74,42930,74,895,74,1032,74,5035,74,5261,74,42201,74,119844,107,119896,107,119948,107,120000,107,120052,107,120104,107,120156,107,120208,107,120260,107,120312,107,120364,107,120416,107,120468,107,8490,75,65323,75,117984,75,119818,75,119870,75,119922,75,119974,75,120026,75,120078,75,120130,75,120182,75,120234,75,120286,75,120338,75,120390,75,120442,75,922,75,120497,75,120555,75,120613,75,120671,75,120729,75,11412,75,5094,75,5845,75,42199,75,66840,75,1472,108,8739,73,9213,73,65512,73,1633,108,1777,73,66336,108,125127,108,118001,108,120783,73,120793,73,120803,73,120813,73,120823,73,130033,73,65321,73,8544,73,8464,73,8465,73,117982,108,119816,73,119868,73,119920,73,120024,73,120128,73,120180,73,120232,73,120284,73,120336,73,120388,73,120440,73,65356,108,8572,73,8467,108,119845,108,119897,108,119949,108,120001,108,120053,108,120105,73,120157,73,120209,73,120261,73,120313,73,120365,73,120417,73,120469,73,448,73,120496,73,120554,73,120612,73,120670,73,120728,73,11410,73,1030,73,1216,73,1493,108,1503,108,1575,108,126464,108,126592,108,65166,108,65165,108,1994,108,11599,73,5825,73,42226,73,93992,73,66186,124,66313,124,119338,76,8556,76,8466,76,117985,76,119819,76,119871,76,119923,76,120027,76,120079,76,120131,76,120183,76,120235,76,120287,76,120339,76,120391,76,120443,76,11472,76,5086,76,5290,76,42209,76,93974,76,71843,76,71858,76,66587,76,66854,76,65325,77,8559,77,8499,77,117986,77,119820,77,119872,77,119924,77,120028,77,120080,77,120132,77,120184,77,120236,77,120288,77,120340,77,120392,77,120444,77,924,77,120499,77,120557,77,120615,77,120673,77,120731,77,1018,77,11416,77,5047,77,5616,77,5846,77,42207,77,66224,77,66321,77,119847,110,119899,110,119951,110,120003,110,120055,110,120107,110,120159,110,120211,110,120263,110,120315,110,120367,110,120419,110,120471,110,1400,110,1404,110,65326,78,8469,78,117987,78,119821,78,119873,78,119925,78,119977,78,120029,78,120081,78,120185,78,120237,78,120289,78,120341,78,120393,78,120445,78,925,78,120500,78,120558,78,120616,78,120674,78,120732,78,11418,78,42208,78,66835,78,3074,111,3202,111,3330,111,3458,111,2406,111,2662,111,2790,111,3046,111,3174,111,3302,111,3430,111,3664,111,3792,111,4160,111,1637,111,1781,111,65359,111,8500,111,119848,111,119900,111,119952,111,120056,111,120108,111,120160,111,120212,111,120264,111,120316,111,120368,111,120420,111,120472,111,7439,111,7441,111,43837,111,959,111,120528,111,120586,111,120644,111,120702,111,120760,111,963,111,120532,111,120590,111,120648,111,120706,111,120764,111,11423,111,4351,111,1413,111,1505,111,1607,111,126500,111,126564,111,126596,111,65259,111,65260,111,65258,111,65257,111,1726,111,64428,111,64429,111,64427,111,64426,111,1729,111,64424,111,64425,111,64423,111,64422,111,1749,111,3360,111,4125,111,66794,111,71880,111,71895,111,66604,111,1984,79,2534,79,2918,79,12295,79,70864,79,71904,79,118000,79,120782,79,120792,79,120802,79,120812,79,120822,79,130032,79,65327,79,117988,79,119822,79,119874,79,119926,79,119978,79,120030,79,120082,79,120134,79,120186,79,120238,79,120290,79,120342,79,120394,79,120446,79,927,79,120502,79,120560,79,120618,79,120676,79,120734,79,11422,79,1365,79,11604,79,4816,79,2848,79,66754,79,42227,79,71861,79,66194,79,66219,79,66564,79,66838,79,9076,112,65360,112,119849,112,119901,112,119953,112,120005,112,120057,112,120109,112,120161,112,120213,112,120265,112,120317,112,120369,112,120421,112,120473,112,961,112,120530,112,120544,112,120588,112,120602,112,120646,112,120660,112,120704,112,120718,112,120762,112,120776,112,11427,112,65328,80,8473,80,117989,80,119823,80,119875,80,119927,80,119979,80,120031,80,120083,80,120187,80,120239,80,120291,80,120343,80,120395,80,120447,80,929,80,120504,80,120562,80,120620,80,120678,80,120736,80,11426,80,5090,80,5229,80,42193,80,66197,80,119850,113,119902,113,119954,113,120006,113,120058,113,120110,113,120162,113,120214,113,120266,113,120318,113,120370,113,120422,113,120474,113,1307,113,1379,113,1382,113,8474,81,117990,81,119824,81,119876,81,119928,81,119980,81,120032,81,120084,81,120188,81,120240,81,120292,81,120344,81,120396,81,120448,81,11605,81,119851,114,119903,114,119955,114,120007,114,120059,114,120111,114,120163,114,120215,114,120267,114,120319,114,120371,114,120423,114,120475,114,43847,114,43848,114,7462,114,11397,114,43905,114,119318,82,8475,82,8476,82,8477,82,117991,82,119825,82,119877,82,119929,82,120033,82,120189,82,120241,82,120293,82,120345,82,120397,82,120449,82,422,82,5025,82,5074,82,66740,82,5511,82,42211,82,94005,82,65363,115,119852,115,119904,115,119956,115,120008,115,120060,115,120112,115,120164,115,120216,115,120268,115,120320,115,120372,115,120424,115,120476,115,42801,115,445,115,1109,115,43946,115,71873,115,66632,115,65331,83,117992,83,119826,83,119878,83,119930,83,119982,83,120034,83,120086,83,120138,83,120190,83,120242,83,120294,83,120346,83,120398,83,120450,83,1029,83,1359,83,5077,83,5082,83,42210,83,94010,83,66198,83,66592,83,119853,116,119905,116,119957,116,120009,116,120061,116,120113,116,120165,116,120217,116,120269,116,120321,116,120373,116,120425,116,120477,116,8868,84,10201,84,128872,84,65332,84,117993,84,119827,84,119879,84,119931,84,119983,84,120035,84,120087,84,120139,84,120191,84,120243,84,120295,84,120347,84,120399,84,120451,84,932,84,120507,84,120565,84,120623,84,120681,84,120739,84,11430,84,5026,84,42196,84,93962,84,71868,84,66199,84,66225,84,66325,84,119854,117,119906,117,119958,117,120010,117,120062,117,120114,117,120166,117,120218,117,120270,117,120322,117,120374,117,120426,117,120478,117,42911,117,7452,117,43854,117,43858,117,651,117,965,117,120534,117,120592,117,120650,117,120708,117,120766,117,1405,117,66806,117,71896,117,8746,85,8899,85,117994,85,119828,85,119880,85,119932,85,119984,85,120036,85,120088,85,120140,85,120192,85,120244,85,120296,85,120348,85,120400,85,120452,85,1357,85,4608,85,66766,85,5196,85,42228,85,94018,85,71864,85,8744,118,8897,118,65366,118,8564,118,119855,118,119907,118,119959,118,120011,118,120063,118,120115,118,120167,118,120219,118,120271,118,120323,118,120375,118,120427,118,120479,118,7456,118,957,118,120526,118,120584,118,120642,118,120700,118,120758,118,1141,118,1496,118,71430,118,43945,118,71872,118,119309,86,1639,86,1783,86,8548,86,117995,86,119829,86,119881,86,119933,86,119985,86,120037,86,120089,86,120141,86,120193,86,120245,86,120297,86,120349,86,120401,86,120453,86,1140,86,11576,86,5081,86,5167,86,42719,86,42214,86,93960,86,71840,86,66845,86,623,119,119856,119,119908,119,119960,119,120012,119,120064,119,120116,119,120168,119,120220,119,120272,119,120324,119,120376,119,120428,119,120480,119,7457,119,1121,119,1309,119,1377,119,71434,119,71438,119,71439,119,43907,119,71910,87,71919,87,117996,87,119830,87,119882,87,119934,87,119986,87,120038,87,120090,87,120142,87,120194,87,120246,87,120298,87,120350,87,120402,87,120454,87,1308,87,5043,87,5076,87,42218,87,5742,120,10539,120,10540,120,10799,120,65368,120,8569,120,119857,120,119909,120,119961,120,120013,120,120065,120,120117,120,120169,120,120221,120,120273,120,120325,120,120377,120,120429,120,120481,120,5441,120,5501,120,5741,88,9587,88,66338,88,71916,88,65336,88,8553,88,117997,88,119831,88,119883,88,119935,88,119987,88,120039,88,120091,88,120143,88,120195,88,120247,88,120299,88,120351,88,120403,88,120455,88,42931,88,935,88,120510,88,120568,88,120626,88,120684,88,120742,88,11436,88,11613,88,5815,88,42219,88,66192,88,66228,88,66327,88,66855,88,611,121,7564,121,65369,121,119858,121,119910,121,119962,121,120014,121,120066,121,120118,121,120170,121,120222,121,120274,121,120326,121,120378,121,120430,121,120482,121,655,121,7935,121,43866,121,947,121,8509,121,120516,121,120574,121,120632,121,120690,121,120748,121,1199,121,4327,121,71900,121,65337,89,117998,89,119832,89,119884,89,119936,89,119988,89,120040,89,120092,89,120144,89,120196,89,120248,89,120300,89,120352,89,120404,89,120456,89,933,89,978,89,120508,89,120566,89,120624,89,120682,89,120740,89,11432,89,1198,89,5033,89,5053,89,42220,89,94019,89,71844,89,66226,89,119859,122,119911,122,119963,122,120015,122,120067,122,120119,122,120171,122,120223,122,120275,122,120327,122,120379,122,120431,122,120483,122,7458,122,43923,122,71876,122,71909,90,66293,90,65338,90,8484,90,8488,90,117999,90,119833,90,119885,90,119937,90,119989,90,120041,90,120197,90,120249,90,120301,90,120353,90,120405,90,120457,90,918,90,120493,90,120551,90,120609,90,120667,90,120725,90,5059,90,42204,90,71849,90,65282,34,65283,35,65284,36,65285,37,65286,38,65290,42,65291,43,65294,46,65295,47,65296,48,65298,50,65299,51,65300,52,65301,53,65302,54,65303,55,65304,56,65305,57,65308,60,65309,61,65310,62,65312,64,65316,68,65318,70,65319,71,65324,76,65329,81,65330,82,65333,85,65334,86,65335,87,65343,95,65346,98,65348,100,65350,102,65355,107,65357,109,65358,110,65361,113,65362,114,65364,116,65365,117,65367,119,65370,122,65371,123,65373,125,119846,109],\"_default\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8217,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"cs\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"de\":[65374,126,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"es\":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"fr\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"it\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"ja\":[8211,45,8218,44,65281,33,8216,96,8245,96,180,96,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65292,44,65297,49,65307,59],\"ko\":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"pl\":[65374,126,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"pt-BR\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"qps-ploc\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"ru\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,305,105,921,73,1009,112,215,120,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"tr\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"zh-hans\":[160,32,65374,126,8218,44,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65297,49],\"zh-hant\":[8211,45,65374,126,8218,44,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89]}"));
		}
		static {
			this.cache = new ee({ getCacheKey: JSON.stringify }, (t) => {
				function n(e) {
					const t = /* @__PURE__ */ new Map();
					for (let n = 0; n < e.length; n += 2) t.set(e[n], e[n + 1]);
					return t;
				}
				function i(e, t) {
					if (!e) return t;
					const n = /* @__PURE__ */ new Map();
					for (const [i, r] of e) t.has(i) && n.set(i, r);
					return n;
				}
				const r = this.ambiguousCharacterData.value;
				let a, o = t.filter((e) => !e.startsWith("_") && Object.hasOwn(r, e));
				0 === o.length && (o = ["_default"]);
				for (const e of o) a = i(a, n(r[e]));
				return new e(function(e, t) {
					const n = new Map(e);
					for (const [i, r] of t) n.set(i, r);
					return n;
				}(n(r._common), a));
			});
		}
		static getInstance(t) {
			return e.cache.get(Array.from(t));
		}
		static {
			this._locales = new te(() => Object.keys(e.ambiguousCharacterData.value).filter((e) => !e.startsWith("_")));
		}
		static getLocales() {
			return e._locales.value;
		}
		constructor(e) {
			this.confusableDictionary = e;
		}
		isAmbiguous(e) {
			return this.confusableDictionary.has(e);
		}
		getPrimaryConfusable(e) {
			return this.confusableDictionary.get(e);
		}
		getConfusableCodePoints() {
			return new Set(this.confusableDictionary.keys());
		}
	}, he = class e {
		static getRawData() {
			return JSON.parse("{\"_common\":[11,12,13,127,847,1564,4447,4448,6068,6069,6155,6156,6157,6158,7355,7356,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8204,8205,8206,8207,8234,8235,8236,8237,8238,8239,8287,8288,8289,8290,8291,8292,8293,8294,8295,8296,8297,8298,8299,8300,8301,8302,8303,10240,12644,65024,65025,65026,65027,65028,65029,65030,65031,65032,65033,65034,65035,65036,65037,65038,65039,65279,65440,65520,65521,65522,65523,65524,65525,65526,65527,65528,65532,78844,119155,119156,119157,119158,119159,119160,119161,119162,917504,917505,917506,917507,917508,917509,917510,917511,917512,917513,917514,917515,917516,917517,917518,917519,917520,917521,917522,917523,917524,917525,917526,917527,917528,917529,917530,917531,917532,917533,917534,917535,917536,917537,917538,917539,917540,917541,917542,917543,917544,917545,917546,917547,917548,917549,917550,917551,917552,917553,917554,917555,917556,917557,917558,917559,917560,917561,917562,917563,917564,917565,917566,917567,917568,917569,917570,917571,917572,917573,917574,917575,917576,917577,917578,917579,917580,917581,917582,917583,917584,917585,917586,917587,917588,917589,917590,917591,917592,917593,917594,917595,917596,917597,917598,917599,917600,917601,917602,917603,917604,917605,917606,917607,917608,917609,917610,917611,917612,917613,917614,917615,917616,917617,917618,917619,917620,917621,917622,917623,917624,917625,917626,917627,917628,917629,917630,917631,917760,917761,917762,917763,917764,917765,917766,917767,917768,917769,917770,917771,917772,917773,917774,917775,917776,917777,917778,917779,917780,917781,917782,917783,917784,917785,917786,917787,917788,917789,917790,917791,917792,917793,917794,917795,917796,917797,917798,917799,917800,917801,917802,917803,917804,917805,917806,917807,917808,917809,917810,917811,917812,917813,917814,917815,917816,917817,917818,917819,917820,917821,917822,917823,917824,917825,917826,917827,917828,917829,917830,917831,917832,917833,917834,917835,917836,917837,917838,917839,917840,917841,917842,917843,917844,917845,917846,917847,917848,917849,917850,917851,917852,917853,917854,917855,917856,917857,917858,917859,917860,917861,917862,917863,917864,917865,917866,917867,917868,917869,917870,917871,917872,917873,917874,917875,917876,917877,917878,917879,917880,917881,917882,917883,917884,917885,917886,917887,917888,917889,917890,917891,917892,917893,917894,917895,917896,917897,917898,917899,917900,917901,917902,917903,917904,917905,917906,917907,917908,917909,917910,917911,917912,917913,917914,917915,917916,917917,917918,917919,917920,917921,917922,917923,917924,917925,917926,917927,917928,917929,917930,917931,917932,917933,917934,917935,917936,917937,917938,917939,917940,917941,917942,917943,917944,917945,917946,917947,917948,917949,917950,917951,917952,917953,917954,917955,917956,917957,917958,917959,917960,917961,917962,917963,917964,917965,917966,917967,917968,917969,917970,917971,917972,917973,917974,917975,917976,917977,917978,917979,917980,917981,917982,917983,917984,917985,917986,917987,917988,917989,917990,917991,917992,917993,917994,917995,917996,917997,917998,917999],\"cs\":[173,8203,12288],\"de\":[173,8203,12288],\"es\":[8203,12288],\"fr\":[173,8203,12288],\"it\":[160,173,12288],\"ja\":[173],\"ko\":[173,12288],\"pl\":[173,8203,12288],\"pt-BR\":[173,8203,12288],\"qps-ploc\":[160,173,8203,12288],\"ru\":[173,12288],\"tr\":[160,173,8203,12288],\"zh-hans\":[160,173,8203,12288],\"zh-hant\":[173,12288]}");
		}
		static {
			this._data = void 0;
		}
		static getData() {
			return this._data || (this._data = new Set([...Object.values(e.getRawData())].flat())), this._data;
		}
		static isInvisibleCharacter(t) {
			return e.getData().has(t);
		}
		static get codePoints() {
			return e.getData();
		}
	};
	const de = "default";
	var ue = class {
		constructor(e, t, n, i, r) {
			this.vsWorker = e, this.req = t, this.channel = n, this.method = i, this.args = r, this.type = 0;
		}
	}, me = class {
		constructor(e, t, n, i) {
			this.vsWorker = e, this.seq = t, this.res = n, this.err = i, this.type = 1;
		}
	}, pe = class {
		constructor(e, t, n, i, r) {
			this.vsWorker = e, this.req = t, this.channel = n, this.eventName = i, this.arg = r, this.type = 2;
		}
	}, ge = class {
		constructor(e, t, n) {
			this.vsWorker = e, this.req = t, this.event = n, this.type = 3;
		}
	}, fe = class {
		constructor(e, t) {
			this.vsWorker = e, this.req = t, this.type = 4;
		}
	}, be = class {
		constructor(e) {
			this._workerId = -1, this._handler = e, this._lastSentReq = 0, this._pendingReplies = Object.create(null), this._pendingEmitters = /* @__PURE__ */ new Map(), this._pendingEvents = /* @__PURE__ */ new Map();
		}
		setWorkerId(e) {
			this._workerId = e;
		}
		async sendMessage(e, t, n) {
			const i = String(++this._lastSentReq);
			return new Promise((r, a) => {
				this._pendingReplies[i] = {
					resolve: r,
					reject: a
				}, this._send(new ue(this._workerId, i, e, t, n));
			});
		}
		listen(e, t, n) {
			let i = null;
			const r = new C({
				onWillAddFirstListener: () => {
					i = String(++this._lastSentReq), this._pendingEmitters.set(i, r), this._send(new pe(this._workerId, i, e, t, n));
				},
				onDidRemoveLastListener: () => {
					this._pendingEmitters.delete(i), this._send(new fe(this._workerId, i)), i = null;
				}
			});
			return r.event;
		}
		handleMessage(e) {
			e && e.vsWorker && (-1 !== this._workerId && e.vsWorker !== this._workerId || this._handleMessage(e));
		}
		createProxyToRemoteChannel(e, t) {
			return new Proxy(Object.create(null), { get: (n, i) => ("string" != typeof i || n[i] || (we(i) ? n[i] = (t) => this.listen(e, i, t) : _e(i) ? n[i] = this.listen(e, i, void 0) : 36 === i.charCodeAt(0) && (n[i] = async (...n) => (await t?.(), this.sendMessage(e, i, n)))), n[i]) });
		}
		_handleMessage(e) {
			switch (e.type) {
				case 1: return this._handleReplyMessage(e);
				case 0: return this._handleRequestMessage(e);
				case 2: return this._handleSubscribeEventMessage(e);
				case 3: return this._handleEventMessage(e);
				case 4: return this._handleUnsubscribeEventMessage(e);
			}
		}
		_handleReplyMessage(e) {
			if (!this._pendingReplies[e.seq]) return;
			const t = this._pendingReplies[e.seq];
			if (delete this._pendingReplies[e.seq], e.err) {
				let n = e.err;
				if (e.err.$isError) {
					const t = /* @__PURE__ */ new Error();
					t.name = e.err.name, t.message = e.err.message, t.stack = e.err.stack, n = t;
				}
				t.reject(n);
				return;
			}
			t.resolve(e.res);
		}
		_handleRequestMessage(e) {
			const t = e.req;
			this._handler.handleMessage(e.channel, e.method, e.args).then((e) => {
				this._send(new me(this._workerId, t, e, void 0));
			}, (e) => {
				e.detail instanceof Error && (e.detail = n(e.detail)), this._send(new me(this._workerId, t, void 0, n(e)));
			});
		}
		_handleSubscribeEventMessage(e) {
			const t = e.req, n = this._handler.handleEvent(e.channel, e.eventName, e.arg)((e) => {
				this._send(new ge(this._workerId, t, e));
			});
			this._pendingEvents.set(t, n);
		}
		_handleEventMessage(e) {
			this._pendingEmitters.has(e.req) && this._pendingEmitters.get(e.req).fire(e.event);
		}
		_handleUnsubscribeEventMessage(e) {
			this._pendingEvents.has(e.req) && (this._pendingEvents.get(e.req).dispose(), this._pendingEvents.delete(e.req));
		}
		_send(e) {
			const t = [];
			if (0 === e.type) for (let n = 0; n < e.args.length; n++) {
				const i = e.args[n];
				i instanceof ArrayBuffer && t.push(i);
			}
			else 1 === e.type && e.res instanceof ArrayBuffer && t.push(e.res);
			this._handler.sendMessage(e, t);
		}
	};
	function _e(e) {
		return "o" === e[0] && "n" === e[1] && ne(e.charCodeAt(2));
	}
	function we(e) {
		return /^onDynamic/.test(e) && ne(e.charCodeAt(9));
	}
	var ve = class {
		constructor(e, t) {
			this._localChannels = /* @__PURE__ */ new Map(), this._remoteChannels = /* @__PURE__ */ new Map(), this._protocol = new be({
				sendMessage: (t, n) => {
					e(t, n);
				},
				handleMessage: (e, t, n) => this._handleMessage(e, t, n),
				handleEvent: (e, t, n) => this._handleEvent(e, t, n)
			}), this.requestHandler = t(this);
		}
		onmessage(e) {
			this._protocol.handleMessage(e);
		}
		_handleMessage(e, t, n) {
			if (e === de && "$initialize" === t) return this.initialize(n[0]);
			const i = e === de ? this.requestHandler : this._localChannels.get(e);
			if (!i) return Promise.reject(/* @__PURE__ */ new Error(`Missing channel ${e} on worker thread`));
			const r = i[t];
			if ("function" != typeof r) return Promise.reject(/* @__PURE__ */ new Error(`Missing method ${t} on worker thread channel ${e}`));
			try {
				return Promise.resolve(r.apply(i, n));
			} catch (El) {
				return Promise.reject(El);
			}
		}
		_handleEvent(e, t, n) {
			const i = e === de ? this.requestHandler : this._localChannels.get(e);
			if (!i) throw new Error(`Missing channel ${e} on worker thread`);
			if (we(t)) {
				const e = i[t];
				if ("function" != typeof e) throw new Error(`Missing dynamic event ${t} on request handler.`);
				const r = e.call(i, n);
				if ("function" != typeof r) throw new Error(`Missing dynamic event ${t} on request handler.`);
				return r;
			}
			if (_e(t)) {
				const e = i[t];
				if ("function" != typeof e) throw new Error(`Missing event ${t} on request handler.`);
				return e;
			}
			throw new Error(`Malformed event name ${t}`);
		}
		getChannel(e) {
			if (!this._remoteChannels.has(e)) {
				const t = this._protocol.createProxyToRemoteChannel(e);
				this._remoteChannels.set(e, t);
			}
			return this._remoteChannels.get(e);
		}
		async initialize(e) {
			this._protocol.setWorkerId(e);
		}
	};
	let ye = !1;
	var Te = class {
		constructor(e, t, n, i) {
			this.originalStart = e, this.originalLength = t, this.modifiedStart = n, this.modifiedLength = i;
		}
		getOriginalEnd() {
			return this.originalStart + this.originalLength;
		}
		getModifiedEnd() {
			return this.modifiedStart + this.modifiedLength;
		}
	};
	const ke = "undefined" != typeof Buffer;
	let Se;
	new te(() => new Uint8Array(256));
	var Le = class e {
		static wrap(t) {
			return ke && !Buffer.isBuffer(t) && (t = Buffer.from(t.buffer, t.byteOffset, t.byteLength)), new e(t);
		}
		constructor(e) {
			this.buffer = e, this.byteLength = this.buffer.byteLength;
		}
		toString() {
			return ke ? this.buffer.toString() : (Se || (Se = new TextDecoder()), Se.decode(this.buffer));
		}
	};
	const xe = "0123456789abcdef";
	function Ce(e, t) {
		return (t << 5) - t + e | 0;
	}
	function Ee(e, t) {
		t = Ce(149417, t);
		for (let n = 0, i = e.length; n < i; n++) t = Ce(e.charCodeAt(n), t);
		return t;
	}
	function Ae(e, t, n = 32) {
		const i = n - t;
		return (e << t | (~((1 << i) - 1) & e) >>> i) >>> 0;
	}
	function Re(e, t = 32) {
		return e instanceof ArrayBuffer ? function({ buffer: e }) {
			let t = "";
			for (let n = 0; n < e.length; n++) {
				const i = e[n];
				t += xe[i >>> 4], t += xe[15 & i];
			}
			return t;
		}(Le.wrap(new Uint8Array(e))) : (e >>> 0).toString(16).padStart(t / 4, "0");
	}
	(class e {
		static {
			this._bigBlock32 = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(320));
		}
		constructor() {
			this._h0 = 1732584193, this._h1 = 4023233417, this._h2 = 2562383102, this._h3 = 271733878, this._h4 = 3285377520, this._buff = new Uint8Array(67), this._buffDV = new DataView(this._buff.buffer), this._buffLen = 0, this._totalLen = 0, this._leftoverHighSurrogate = 0, this._finished = !1;
		}
		update(e) {
			const t = e.length;
			if (0 === t) return;
			const n = this._buff;
			let i, r, a = this._buffLen, o = this._leftoverHighSurrogate;
			for (0 !== o ? (i = o, r = -1, o = 0) : (i = e.charCodeAt(0), r = 0);;) {
				let s = i;
				if (ie(i)) {
					if (!(r + 1 < t)) {
						o = i;
						break;
					}
					{
						const t = e.charCodeAt(r + 1);
						re(t) ? (r++, s = ae(i, t)) : s = 65533;
					}
				} else re(i) && (s = 65533);
				if (a = this._push(n, a, s), r++, !(r < t)) break;
				i = e.charCodeAt(r);
			}
			this._buffLen = a, this._leftoverHighSurrogate = o;
		}
		_push(e, t, n) {
			return n < 128 ? e[t++] = n : n < 2048 ? (e[t++] = 192 | (1984 & n) >>> 6, e[t++] = 128 | (63 & n) >>> 0) : n < 65536 ? (e[t++] = 224 | (61440 & n) >>> 12, e[t++] = 128 | (4032 & n) >>> 6, e[t++] = 128 | (63 & n) >>> 0) : (e[t++] = 240 | (1835008 & n) >>> 18, e[t++] = 128 | (258048 & n) >>> 12, e[t++] = 128 | (4032 & n) >>> 6, e[t++] = 128 | (63 & n) >>> 0), t >= 64 && (this._step(), t -= 64, this._totalLen += 64, e[0] = e[64], e[1] = e[65], e[2] = e[66]), t;
		}
		digest() {
			return this._finished || (this._finished = !0, this._leftoverHighSurrogate && (this._leftoverHighSurrogate = 0, this._buffLen = this._push(this._buff, this._buffLen, 65533)), this._totalLen += this._buffLen, this._wrapUp()), Re(this._h0) + Re(this._h1) + Re(this._h2) + Re(this._h3) + Re(this._h4);
		}
		_wrapUp() {
			this._buff[this._buffLen++] = 128, this._buff.subarray(this._buffLen).fill(0), this._buffLen > 56 && (this._step(), this._buff.fill(0));
			const e = 8 * this._totalLen;
			this._buffDV.setUint32(56, Math.floor(e / 4294967296), !1), this._buffDV.setUint32(60, e % 4294967296, !1), this._step();
		}
		_step() {
			const t = e._bigBlock32, n = this._buffDV;
			for (let e = 0; e < 64; e += 4) t.setUint32(e, n.getUint32(e, !1), !1);
			for (let e = 64; e < 320; e += 4) t.setUint32(e, Ae(t.getUint32(e - 12, !1) ^ t.getUint32(e - 32, !1) ^ t.getUint32(e - 56, !1) ^ t.getUint32(e - 64, !1), 1), !1);
			let i, r, a, o = this._h0, s = this._h1, l = this._h2, c = this._h3, h = this._h4;
			for (let e = 0; e < 80; e++) e < 20 ? (i = s & l | ~s & c, r = 1518500249) : e < 40 ? (i = s ^ l ^ c, r = 1859775393) : e < 60 ? (i = s & l | s & c | l & c, r = 2400959708) : (i = s ^ l ^ c, r = 3395469782), a = Ae(o, 5) + i + h + r + t.getUint32(4 * e, !1) & 4294967295, h = c, c = l, l = Ae(s, 30), s = o, o = a;
			this._h0 = this._h0 + o & 4294967295, this._h1 = this._h1 + s & 4294967295, this._h2 = this._h2 + l & 4294967295, this._h3 = this._h3 + c & 4294967295, this._h4 = this._h4 + h & 4294967295;
		}
	});
	var Me = class {
		constructor(e) {
			this.source = e;
		}
		getElements() {
			const e = this.source, t = new Int32Array(e.length);
			for (let n = 0, i = e.length; n < i; n++) t[n] = e.charCodeAt(n);
			return t;
		}
	};
	function Ne(e, t, n) {
		return new Ue(new Me(e), new Me(t)).ComputeDiff(n).changes;
	}
	var Ie = class {
		static Assert(e, t) {
			if (!e) throw new Error(t);
		}
	}, ze = class {
		static Copy(e, t, n, i, r) {
			for (let a = 0; a < r; a++) n[i + a] = e[t + a];
		}
		static Copy2(e, t, n, i, r) {
			for (let a = 0; a < r; a++) n[i + a] = e[t + a];
		}
	}, Oe = class {
		constructor() {
			this.m_changes = [], this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824, this.m_originalCount = 0, this.m_modifiedCount = 0;
		}
		MarkNextChange() {
			(this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.m_changes.push(new Te(this.m_originalStart, this.m_originalCount, this.m_modifiedStart, this.m_modifiedCount)), this.m_originalCount = 0, this.m_modifiedCount = 0, this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824;
		}
		AddOriginalElement(e, t) {
			this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, t), this.m_originalCount++;
		}
		AddModifiedElement(e, t) {
			this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, t), this.m_modifiedCount++;
		}
		getChanges() {
			return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes;
		}
		getReverseChanges() {
			return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes.reverse(), this.m_changes;
		}
	}, Ue = class e {
		constructor(t, n, i = null) {
			this.ContinueProcessingPredicate = i, this._originalSequence = t, this._modifiedSequence = n;
			const [r, a, o] = e._getElements(t), [s, l, c] = e._getElements(n);
			this._hasStrings = o && c, this._originalStringElements = r, this._originalElementsOrHash = a, this._modifiedStringElements = s, this._modifiedElementsOrHash = l, this.m_forwardHistory = [], this.m_reverseHistory = [];
		}
		static _isStringArray(e) {
			return e.length > 0 && "string" == typeof e[0];
		}
		static _getElements(t) {
			const n = t.getElements();
			if (e._isStringArray(n)) {
				const e = new Int32Array(n.length);
				for (let t = 0, i = n.length; t < i; t++) e[t] = Ee(n[t], 0);
				return [
					n,
					e,
					!0
				];
			}
			return n instanceof Int32Array ? [
				[],
				n,
				!1
			] : [
				[],
				new Int32Array(n),
				!1
			];
		}
		ElementsAreEqual(e, t) {
			return this._originalElementsOrHash[e] === this._modifiedElementsOrHash[t] && (!this._hasStrings || this._originalStringElements[e] === this._modifiedStringElements[t]);
		}
		ElementsAreStrictEqual(t, n) {
			return !!this.ElementsAreEqual(t, n) && e._getStrictElement(this._originalSequence, t) === e._getStrictElement(this._modifiedSequence, n);
		}
		static _getStrictElement(e, t) {
			return "function" == typeof e.getStrictElement ? e.getStrictElement(t) : null;
		}
		OriginalElementsAreEqual(e, t) {
			return this._originalElementsOrHash[e] === this._originalElementsOrHash[t] && (!this._hasStrings || this._originalStringElements[e] === this._originalStringElements[t]);
		}
		ModifiedElementsAreEqual(e, t) {
			return this._modifiedElementsOrHash[e] === this._modifiedElementsOrHash[t] && (!this._hasStrings || this._modifiedStringElements[e] === this._modifiedStringElements[t]);
		}
		ComputeDiff(e) {
			return this._ComputeDiff(0, this._originalElementsOrHash.length - 1, 0, this._modifiedElementsOrHash.length - 1, e);
		}
		_ComputeDiff(e, t, n, i, r) {
			const a = [!1];
			let o = this.ComputeDiffRecursive(e, t, n, i, a);
			return r && (o = this.PrettifyChanges(o)), {
				quitEarly: a[0],
				changes: o
			};
		}
		ComputeDiffRecursive(e, t, n, i, r) {
			for (r[0] = !1; e <= t && n <= i && this.ElementsAreEqual(e, n);) e++, n++;
			for (; t >= e && i >= n && this.ElementsAreEqual(t, i);) t--, i--;
			if (e > t || n > i) {
				let r;
				return n <= i ? (Ie.Assert(e === t + 1, "originalStart should only be one more than originalEnd"), r = [new Te(e, 0, n, i - n + 1)]) : e <= t ? (Ie.Assert(n === i + 1, "modifiedStart should only be one more than modifiedEnd"), r = [new Te(e, t - e + 1, n, 0)]) : (Ie.Assert(e === t + 1, "originalStart should only be one more than originalEnd"), Ie.Assert(n === i + 1, "modifiedStart should only be one more than modifiedEnd"), r = []), r;
			}
			const a = [0], o = [0], s = this.ComputeRecursionPoint(e, t, n, i, a, o, r), l = a[0], c = o[0];
			if (null !== s) return s;
			if (!r[0]) {
				const a = this.ComputeDiffRecursive(e, l, n, c, r);
				let o = [];
				return o = r[0] ? [new Te(l + 1, t - (l + 1) + 1, c + 1, i - (c + 1) + 1)] : this.ComputeDiffRecursive(l + 1, t, c + 1, i, r), this.ConcatenateChanges(a, o);
			}
			return [new Te(e, t - e + 1, n, i - n + 1)];
		}
		WALKTRACE(e, t, n, i, r, a, o, s, l, c, h, d, u, m, p, g, f, b) {
			let _ = null, w = null, v = new Oe(), y = t, T = n, k = u[0] - g[0] - i, S = -1073741824, L = this.m_forwardHistory.length - 1;
			do {
				const t = k + e;
				t === y || t < T && l[t - 1] < l[t + 1] ? (m = (h = l[t + 1]) - k - i, h < S && v.MarkNextChange(), S = h, v.AddModifiedElement(h + 1, m), k = t + 1 - e) : (m = (h = l[t - 1] + 1) - k - i, h < S && v.MarkNextChange(), S = h - 1, v.AddOriginalElement(h, m + 1), k = t - 1 - e), L >= 0 && (e = (l = this.m_forwardHistory[L])[0], y = 1, T = l.length - 1);
			} while (--L >= -1);
			if (_ = v.getReverseChanges(), b[0]) {
				let e = u[0] + 1, t = g[0] + 1;
				if (null !== _ && _.length > 0) {
					const n = _[_.length - 1];
					e = Math.max(e, n.getOriginalEnd()), t = Math.max(t, n.getModifiedEnd());
				}
				w = [new Te(e, d - e + 1, t, p - t + 1)];
			} else {
				v = new Oe(), y = a, T = o, k = u[0] - g[0] - s, S = 1073741824, L = f ? this.m_reverseHistory.length - 1 : this.m_reverseHistory.length - 2;
				do {
					const e = k + r;
					e === y || e < T && c[e - 1] >= c[e + 1] ? (m = (h = c[e + 1] - 1) - k - s, h > S && v.MarkNextChange(), S = h + 1, v.AddOriginalElement(h + 1, m + 1), k = e + 1 - r) : (m = (h = c[e - 1]) - k - s, h > S && v.MarkNextChange(), S = h, v.AddModifiedElement(h + 1, m + 1), k = e - 1 - r), L >= 0 && (r = (c = this.m_reverseHistory[L])[0], y = 1, T = c.length - 1);
				} while (--L >= -1);
				w = v.getChanges();
			}
			return this.ConcatenateChanges(_, w);
		}
		ComputeRecursionPoint(e, t, n, i, r, a, o) {
			let s = 0, l = 0, c = 0, h = 0, d = 0, u = 0;
			e--, n--, r[0] = 0, a[0] = 0, this.m_forwardHistory = [], this.m_reverseHistory = [];
			const m = t - e + (i - n), p = m + 1, g = new Int32Array(p), f = new Int32Array(p), b = i - n, _ = t - e, w = e - n, v = t - i, y = (_ - b) % 2 == 0;
			g[b] = e, f[_] = t, o[0] = !1;
			for (let T = 1; T <= m / 2 + 1; T++) {
				let m = 0, k = 0;
				c = this.ClipDiagonalBound(b - T, T, b, p), h = this.ClipDiagonalBound(b + T, T, b, p);
				for (let e = c; e <= h; e += 2) {
					s = e === c || e < h && g[e - 1] < g[e + 1] ? g[e + 1] : g[e - 1] + 1, l = s - (e - b) - w;
					const n = s;
					for (; s < t && l < i && this.ElementsAreEqual(s + 1, l + 1);) s++, l++;
					if (g[e] = s, s + l > m + k && (m = s, k = l), !y && Math.abs(e - _) <= T - 1 && s >= f[e]) return r[0] = s, a[0] = l, n <= f[e] && T <= 1448 ? this.WALKTRACE(b, c, h, w, _, d, u, v, g, f, s, t, r, l, i, a, y, o) : null;
				}
				const S = (m - e + (k - n) - T) / 2;
				if (null !== this.ContinueProcessingPredicate && !this.ContinueProcessingPredicate(m, S)) return o[0] = !0, r[0] = m, a[0] = k, S > 0 && T <= 1448 ? this.WALKTRACE(b, c, h, w, _, d, u, v, g, f, s, t, r, l, i, a, y, o) : (e++, n++, [new Te(e, t - e + 1, n, i - n + 1)]);
				d = this.ClipDiagonalBound(_ - T, T, _, p), u = this.ClipDiagonalBound(_ + T, T, _, p);
				for (let p = d; p <= u; p += 2) {
					s = p === d || p < u && f[p - 1] >= f[p + 1] ? f[p + 1] - 1 : f[p - 1], l = s - (p - _) - v;
					const m = s;
					for (; s > e && l > n && this.ElementsAreEqual(s, l);) s--, l--;
					if (f[p] = s, y && Math.abs(p - b) <= T && s <= g[p]) return r[0] = s, a[0] = l, m >= g[p] && T <= 1448 ? this.WALKTRACE(b, c, h, w, _, d, u, v, g, f, s, t, r, l, i, a, y, o) : null;
				}
				if (T <= 1447) {
					let e = new Int32Array(h - c + 2);
					e[0] = b - c + 1, ze.Copy2(g, c, e, 1, h - c + 1), this.m_forwardHistory.push(e), e = new Int32Array(u - d + 2), e[0] = _ - d + 1, ze.Copy2(f, d, e, 1, u - d + 1), this.m_reverseHistory.push(e);
				}
			}
			return this.WALKTRACE(b, c, h, w, _, d, u, v, g, f, s, t, r, l, i, a, y, o);
		}
		PrettifyChanges(e) {
			for (let t = 0; t < e.length; t++) {
				const n = e[t], i = t < e.length - 1 ? e[t + 1].originalStart : this._originalElementsOrHash.length, r = t < e.length - 1 ? e[t + 1].modifiedStart : this._modifiedElementsOrHash.length, a = n.originalLength > 0, o = n.modifiedLength > 0;
				for (; n.originalStart + n.originalLength < i && n.modifiedStart + n.modifiedLength < r && (!a || this.OriginalElementsAreEqual(n.originalStart, n.originalStart + n.originalLength)) && (!o || this.ModifiedElementsAreEqual(n.modifiedStart, n.modifiedStart + n.modifiedLength));) {
					const e = this.ElementsAreStrictEqual(n.originalStart, n.modifiedStart);
					if (this.ElementsAreStrictEqual(n.originalStart + n.originalLength, n.modifiedStart + n.modifiedLength) && !e) break;
					n.originalStart++, n.modifiedStart++;
				}
				const s = [null];
				t < e.length - 1 && this.ChangesOverlap(e[t], e[t + 1], s) && (e[t] = s[0], e.splice(t + 1, 1), t--);
			}
			for (let t = e.length - 1; t >= 0; t--) {
				const n = e[t];
				let i = 0, r = 0;
				if (t > 0) {
					const n = e[t - 1];
					i = n.originalStart + n.originalLength, r = n.modifiedStart + n.modifiedLength;
				}
				const a = n.originalLength > 0, o = n.modifiedLength > 0;
				let s = 0, l = this._boundaryScore(n.originalStart, n.originalLength, n.modifiedStart, n.modifiedLength);
				for (let e = 1;; e++) {
					const t = n.originalStart - e, c = n.modifiedStart - e;
					if (t < i || c < r) break;
					if (a && !this.OriginalElementsAreEqual(t, t + n.originalLength)) break;
					if (o && !this.ModifiedElementsAreEqual(c, c + n.modifiedLength)) break;
					const h = (t === i && c === r ? 5 : 0) + this._boundaryScore(t, n.originalLength, c, n.modifiedLength);
					h > l && (l = h, s = e);
				}
				n.originalStart -= s, n.modifiedStart -= s;
				const c = [null];
				t > 0 && this.ChangesOverlap(e[t - 1], e[t], c) && (e[t - 1] = c[0], e.splice(t, 1), t++);
			}
			if (this._hasStrings) for (let t = 1, n = e.length; t < n; t++) {
				const n = e[t - 1], i = e[t], r = i.originalStart - n.originalStart - n.originalLength, a = n.originalStart, o = i.originalStart + i.originalLength, s = o - a, l = n.modifiedStart, c = i.modifiedStart + i.modifiedLength, h = c - l;
				if (r < 5 && s < 20 && h < 20) {
					const e = this._findBetterContiguousSequence(a, s, l, h, r);
					if (e) {
						const [t, a] = e;
						t === n.originalStart + n.originalLength && a === n.modifiedStart + n.modifiedLength || (n.originalLength = t - n.originalStart, n.modifiedLength = a - n.modifiedStart, i.originalStart = t + r, i.modifiedStart = a + r, i.originalLength = o - i.originalStart, i.modifiedLength = c - i.modifiedStart);
					}
				}
			}
			return e;
		}
		_findBetterContiguousSequence(e, t, n, i, r) {
			if (t < r || i < r) return null;
			const a = e + t - r + 1, o = n + i - r + 1;
			let s = 0, l = 0, c = 0;
			for (let h = e; h < a; h++) for (let e = n; e < o; e++) {
				const t = this._contiguousSequenceScore(h, e, r);
				t > 0 && t > s && (s = t, l = h, c = e);
			}
			return s > 0 ? [l, c] : null;
		}
		_contiguousSequenceScore(e, t, n) {
			let i = 0;
			for (let r = 0; r < n; r++) {
				if (!this.ElementsAreEqual(e + r, t + r)) return 0;
				i += this._originalStringElements[e + r].length;
			}
			return i;
		}
		_OriginalIsBoundary(e) {
			return e <= 0 || e >= this._originalElementsOrHash.length - 1 || this._hasStrings && /^\s*$/.test(this._originalStringElements[e]);
		}
		_OriginalRegionIsBoundary(e, t) {
			if (this._OriginalIsBoundary(e) || this._OriginalIsBoundary(e - 1)) return !0;
			if (t > 0) {
				const n = e + t;
				if (this._OriginalIsBoundary(n - 1) || this._OriginalIsBoundary(n)) return !0;
			}
			return !1;
		}
		_ModifiedIsBoundary(e) {
			return e <= 0 || e >= this._modifiedElementsOrHash.length - 1 || this._hasStrings && /^\s*$/.test(this._modifiedStringElements[e]);
		}
		_ModifiedRegionIsBoundary(e, t) {
			if (this._ModifiedIsBoundary(e) || this._ModifiedIsBoundary(e - 1)) return !0;
			if (t > 0) {
				const n = e + t;
				if (this._ModifiedIsBoundary(n - 1) || this._ModifiedIsBoundary(n)) return !0;
			}
			return !1;
		}
		_boundaryScore(e, t, n, i) {
			return (this._OriginalRegionIsBoundary(e, t) ? 1 : 0) + (this._ModifiedRegionIsBoundary(n, i) ? 1 : 0);
		}
		ConcatenateChanges(e, t) {
			const n = [];
			if (0 === e.length || 0 === t.length) return t.length > 0 ? t : e;
			if (this.ChangesOverlap(e[e.length - 1], t[0], n)) {
				const i = new Array(e.length + t.length - 1);
				return ze.Copy(e, 0, i, 0, e.length - 1), i[e.length - 1] = n[0], ze.Copy(t, 1, i, e.length, t.length - 1), i;
			}
			{
				const n = new Array(e.length + t.length);
				return ze.Copy(e, 0, n, 0, e.length), ze.Copy(t, 0, n, e.length, t.length), n;
			}
		}
		ChangesOverlap(e, t, n) {
			if (Ie.Assert(e.originalStart <= t.originalStart, "Left change is not less than or equal to right change"), Ie.Assert(e.modifiedStart <= t.modifiedStart, "Left change is not less than or equal to right change"), e.originalStart + e.originalLength >= t.originalStart || e.modifiedStart + e.modifiedLength >= t.modifiedStart) {
				const i = e.originalStart;
				let r = e.originalLength;
				const a = e.modifiedStart;
				let o = e.modifiedLength;
				return e.originalStart + e.originalLength >= t.originalStart && (r = t.originalStart + t.originalLength - e.originalStart), e.modifiedStart + e.modifiedLength >= t.modifiedStart && (o = t.modifiedStart + t.modifiedLength - e.modifiedStart), n[0] = new Te(i, r, a, o), !0;
			}
			return n[0] = null, !1;
		}
		ClipDiagonalBound(e, t, n, i) {
			if (e >= 0 && e < i) return e;
			const r = t % 2 == 0;
			return e < 0 ? r === (n % 2 == 0) ? 0 : 1 : r === ((i - n - 1) % 2 == 0) ? i - 1 : i - 2;
		}
	}, He = class e {
		constructor(e, t) {
			this.lineNumber = e, this.column = t;
		}
		with(t = this.lineNumber, n = this.column) {
			return t === this.lineNumber && n === this.column ? this : new e(t, n);
		}
		delta(e = 0, t = 0) {
			return this.with(Math.max(1, this.lineNumber + e), Math.max(1, this.column + t));
		}
		equals(t) {
			return e.equals(this, t);
		}
		static equals(e, t) {
			return !e && !t || !!e && !!t && e.lineNumber === t.lineNumber && e.column === t.column;
		}
		isBefore(t) {
			return e.isBefore(this, t);
		}
		static isBefore(e, t) {
			return e.lineNumber < t.lineNumber || !(t.lineNumber < e.lineNumber) && e.column < t.column;
		}
		isBeforeOrEqual(t) {
			return e.isBeforeOrEqual(this, t);
		}
		static isBeforeOrEqual(e, t) {
			return e.lineNumber < t.lineNumber || !(t.lineNumber < e.lineNumber) && e.column <= t.column;
		}
		static compare(e, t) {
			const n = 0 | e.lineNumber, i = 0 | t.lineNumber;
			return n === i ? (0 | e.column) - (0 | t.column) : n - i;
		}
		clone() {
			return new e(this.lineNumber, this.column);
		}
		toString() {
			return "(" + this.lineNumber + "," + this.column + ")";
		}
		static lift(t) {
			return new e(t.lineNumber, t.column);
		}
		static isIPosition(e) {
			return !!e && "number" == typeof e.lineNumber && "number" == typeof e.column;
		}
		toJSON() {
			return {
				lineNumber: this.lineNumber,
				column: this.column
			};
		}
	}, De = class e {
		constructor(e, t, n, i) {
			e > n || e === n && t > i ? (this.startLineNumber = n, this.startColumn = i, this.endLineNumber = e, this.endColumn = t) : (this.startLineNumber = e, this.startColumn = t, this.endLineNumber = n, this.endColumn = i);
		}
		isEmpty() {
			return e.isEmpty(this);
		}
		static isEmpty(e) {
			return e.startLineNumber === e.endLineNumber && e.startColumn === e.endColumn;
		}
		containsPosition(t) {
			return e.containsPosition(this, t);
		}
		static containsPosition(e, t) {
			return !(t.lineNumber < e.startLineNumber || t.lineNumber > e.endLineNumber) && !(t.lineNumber === e.startLineNumber && t.column < e.startColumn) && !(t.lineNumber === e.endLineNumber && t.column > e.endColumn);
		}
		static strictContainsPosition(e, t) {
			return !(t.lineNumber < e.startLineNumber || t.lineNumber > e.endLineNumber) && !(t.lineNumber === e.startLineNumber && t.column <= e.startColumn) && !(t.lineNumber === e.endLineNumber && t.column >= e.endColumn);
		}
		containsRange(t) {
			return e.containsRange(this, t);
		}
		static containsRange(e, t) {
			return !(t.startLineNumber < e.startLineNumber || t.endLineNumber < e.startLineNumber) && !(t.startLineNumber > e.endLineNumber || t.endLineNumber > e.endLineNumber) && !(t.startLineNumber === e.startLineNumber && t.startColumn < e.startColumn) && !(t.endLineNumber === e.endLineNumber && t.endColumn > e.endColumn);
		}
		strictContainsRange(t) {
			return e.strictContainsRange(this, t);
		}
		static strictContainsRange(e, t) {
			return !(t.startLineNumber < e.startLineNumber || t.endLineNumber < e.startLineNumber) && !(t.startLineNumber > e.endLineNumber || t.endLineNumber > e.endLineNumber) && !(t.startLineNumber === e.startLineNumber && t.startColumn <= e.startColumn) && !(t.endLineNumber === e.endLineNumber && t.endColumn >= e.endColumn);
		}
		plusRange(t) {
			return e.plusRange(this, t);
		}
		static plusRange(t, n) {
			let i, r, a, o;
			return n.startLineNumber < t.startLineNumber ? (i = n.startLineNumber, r = n.startColumn) : n.startLineNumber === t.startLineNumber ? (i = n.startLineNumber, r = Math.min(n.startColumn, t.startColumn)) : (i = t.startLineNumber, r = t.startColumn), n.endLineNumber > t.endLineNumber ? (a = n.endLineNumber, o = n.endColumn) : n.endLineNumber === t.endLineNumber ? (a = n.endLineNumber, o = Math.max(n.endColumn, t.endColumn)) : (a = t.endLineNumber, o = t.endColumn), new e(i, r, a, o);
		}
		intersectRanges(t) {
			return e.intersectRanges(this, t);
		}
		static intersectRanges(t, n) {
			let i = t.startLineNumber, r = t.startColumn, a = t.endLineNumber, o = t.endColumn;
			const s = n.startLineNumber, l = n.startColumn, c = n.endLineNumber, h = n.endColumn;
			return i < s ? (i = s, r = l) : i === s && (r = Math.max(r, l)), a > c ? (a = c, o = h) : a === c && (o = Math.min(o, h)), i > a || i === a && r > o ? null : new e(i, r, a, o);
		}
		equalsRange(t) {
			return e.equalsRange(this, t);
		}
		static equalsRange(e, t) {
			return !e && !t || !!e && !!t && e.startLineNumber === t.startLineNumber && e.startColumn === t.startColumn && e.endLineNumber === t.endLineNumber && e.endColumn === t.endColumn;
		}
		getEndPosition() {
			return e.getEndPosition(this);
		}
		static getEndPosition(e) {
			return new He(e.endLineNumber, e.endColumn);
		}
		getStartPosition() {
			return e.getStartPosition(this);
		}
		static getStartPosition(e) {
			return new He(e.startLineNumber, e.startColumn);
		}
		toString() {
			return "[" + this.startLineNumber + "," + this.startColumn + " -> " + this.endLineNumber + "," + this.endColumn + "]";
		}
		setEndPosition(t, n) {
			return new e(this.startLineNumber, this.startColumn, t, n);
		}
		setStartPosition(t, n) {
			return new e(t, n, this.endLineNumber, this.endColumn);
		}
		collapseToStart() {
			return e.collapseToStart(this);
		}
		static collapseToStart(t) {
			return new e(t.startLineNumber, t.startColumn, t.startLineNumber, t.startColumn);
		}
		collapseToEnd() {
			return e.collapseToEnd(this);
		}
		static collapseToEnd(t) {
			return new e(t.endLineNumber, t.endColumn, t.endLineNumber, t.endColumn);
		}
		delta(t) {
			return new e(this.startLineNumber + t, this.startColumn, this.endLineNumber + t, this.endColumn);
		}
		isSingleLine() {
			return this.startLineNumber === this.endLineNumber;
		}
		static fromPositions(t, n = t) {
			return new e(t.lineNumber, t.column, n.lineNumber, n.column);
		}
		static lift(t) {
			return t ? new e(t.startLineNumber, t.startColumn, t.endLineNumber, t.endColumn) : null;
		}
		static isIRange(e) {
			return !!e && "number" == typeof e.startLineNumber && "number" == typeof e.startColumn && "number" == typeof e.endLineNumber && "number" == typeof e.endColumn;
		}
		static areIntersectingOrTouching(e, t) {
			return !(e.endLineNumber < t.startLineNumber || e.endLineNumber === t.startLineNumber && e.endColumn < t.startColumn) && !(t.endLineNumber < e.startLineNumber || t.endLineNumber === e.startLineNumber && t.endColumn < e.startColumn);
		}
		static areIntersecting(e, t) {
			return !(e.endLineNumber < t.startLineNumber || e.endLineNumber === t.startLineNumber && e.endColumn <= t.startColumn) && !(t.endLineNumber < e.startLineNumber || t.endLineNumber === e.startLineNumber && t.endColumn <= e.startColumn);
		}
		static areOnlyIntersecting(e, t) {
			return !(e.endLineNumber < t.startLineNumber - 1 || e.endLineNumber === t.startLineNumber && e.endColumn < t.startColumn - 1) && !(t.endLineNumber < e.startLineNumber - 1 || t.endLineNumber === e.startLineNumber && t.endColumn < e.startColumn - 1);
		}
		static compareRangesUsingStarts(e, t) {
			if (e && t) {
				const n = 0 | e.startLineNumber, i = 0 | t.startLineNumber;
				if (n === i) {
					const n = 0 | e.startColumn, i = 0 | t.startColumn;
					if (n === i) {
						const n = 0 | e.endLineNumber, i = 0 | t.endLineNumber;
						return n === i ? (0 | e.endColumn) - (0 | t.endColumn) : n - i;
					}
					return n - i;
				}
				return n - i;
			}
			return (e ? 1 : 0) - (t ? 1 : 0);
		}
		static compareRangesUsingEnds(e, t) {
			return e.endLineNumber === t.endLineNumber ? e.endColumn === t.endColumn ? e.startLineNumber === t.startLineNumber ? e.startColumn - t.startColumn : e.startLineNumber - t.startLineNumber : e.endColumn - t.endColumn : e.endLineNumber - t.endLineNumber;
		}
		static spansMultipleLines(e) {
			return e.endLineNumber > e.startLineNumber;
		}
		toJSON() {
			return this;
		}
	};
	function We(e) {
		return e < 0 ? 0 : e > 255 ? 255 : 0 | e;
	}
	function Pe(e) {
		return e < 0 ? 0 : e > 4294967295 ? 4294967295 : 0 | e;
	}
	var qe = class e {
		constructor(t) {
			const n = We(t);
			this._defaultValue = n, this._asciiMap = e._createAsciiMap(n), this._map = /* @__PURE__ */ new Map();
		}
		static _createAsciiMap(e) {
			const t = new Uint8Array(256);
			return t.fill(e), t;
		}
		set(e, t) {
			const n = We(t);
			e >= 0 && e < 256 ? this._asciiMap[e] = n : this._map.set(e, n);
		}
		get(e) {
			return e >= 0 && e < 256 ? this._asciiMap[e] : this._map.get(e) || this._defaultValue;
		}
		clear() {
			this._asciiMap.fill(this._defaultValue), this._map.clear();
		}
	}, Fe = class {
		constructor(e, t, n) {
			const i = new Uint8Array(e * t);
			for (let r = 0, a = e * t; r < a; r++) i[r] = n;
			this._data = i, this.rows = e, this.cols = t;
		}
		get(e, t) {
			return this._data[e * this.cols + t];
		}
		set(e, t, n) {
			this._data[e * this.cols + t] = n;
		}
	}, Ve = class {
		constructor(e) {
			let t = 0, n = 0;
			for (let r = 0, a = e.length; r < a; r++) {
				const [i, a, o] = e[r];
				a > t && (t = a), i > n && (n = i), o > n && (n = o);
			}
			t++, n++;
			const i = new Fe(n, t, 0);
			for (let r = 0, a = e.length; r < a; r++) {
				const [t, n, a] = e[r];
				i.set(t, n, a);
			}
			this._states = i, this._maxCharCode = t;
		}
		nextState(e, t) {
			return t < 0 || t >= this._maxCharCode ? 0 : this._states.get(e, t);
		}
	};
	let Be = null;
	let Ke = null;
	var je = class e {
		static _createLink(e, t, n, i, r) {
			let a = r - 1;
			do {
				const n = t.charCodeAt(a);
				if (2 !== e.get(n)) break;
				a--;
			} while (a > i);
			if (i > 0) {
				const e = t.charCodeAt(i - 1), n = t.charCodeAt(a);
				(40 === e && 41 === n || 91 === e && 93 === n || 123 === e && 125 === n) && a--;
			}
			return {
				range: {
					startLineNumber: n,
					startColumn: i + 1,
					endLineNumber: n,
					endColumn: a + 2
				},
				url: t.substring(i, a + 1)
			};
		}
		static computeLinks(t, n = function() {
			return null === Be && (Be = new Ve([
				[
					1,
					104,
					2
				],
				[
					1,
					72,
					2
				],
				[
					1,
					102,
					6
				],
				[
					1,
					70,
					6
				],
				[
					2,
					116,
					3
				],
				[
					2,
					84,
					3
				],
				[
					3,
					116,
					4
				],
				[
					3,
					84,
					4
				],
				[
					4,
					112,
					5
				],
				[
					4,
					80,
					5
				],
				[
					5,
					115,
					9
				],
				[
					5,
					83,
					9
				],
				[
					5,
					58,
					10
				],
				[
					6,
					105,
					7
				],
				[
					6,
					73,
					7
				],
				[
					7,
					108,
					8
				],
				[
					7,
					76,
					8
				],
				[
					8,
					101,
					9
				],
				[
					8,
					69,
					9
				],
				[
					9,
					58,
					10
				],
				[
					10,
					47,
					11
				],
				[
					11,
					47,
					12
				]
			])), Be;
		}()) {
			const i = function() {
				if (null === Ke) {
					Ke = new qe(0);
					const e = " 	<>'\"、。｡､，．：；‘〈「『〔（［｛｢｣｝］）〕』」〉’｀～…|";
					for (let n = 0; n < 36; n++) Ke.set(e.charCodeAt(n), 1);
					const t = ".,;:";
					for (let n = 0; n < 4; n++) Ke.set(t.charCodeAt(n), 2);
				}
				return Ke;
			}(), r = [];
			for (let a = 1, o = t.getLineCount(); a <= o; a++) {
				const o = t.getLineContent(a), s = o.length;
				let l = 0, c = 0, h = 0, d = 1, u = !1, m = !1, p = !1, g = !1;
				for (; l < s;) {
					let t = !1;
					const s = o.charCodeAt(l);
					if (13 === d) {
						let n;
						switch (s) {
							case 40:
								u = !0, n = 0;
								break;
							case 41:
								n = u ? 0 : 1;
								break;
							case 91:
								p = !0, m = !0, n = 0;
								break;
							case 93:
								p = !1, n = m ? 0 : 1;
								break;
							case 123:
								g = !0, n = 0;
								break;
							case 125:
								n = g ? 0 : 1;
								break;
							case 39:
							case 34:
							case 96:
								n = h === s ? 1 : 39 === h || 34 === h || 96 === h ? 0 : 1;
								break;
							case 42:
								n = 42 === h ? 1 : 0;
								break;
							case 32:
								n = p ? 0 : 1;
								break;
							default: n = i.get(s);
						}
						1 === n && (r.push(e._createLink(i, o, a, c, l)), t = !0);
					} else if (12 === d) {
						let e;
						91 === s ? (m = !0, e = 0) : e = i.get(s), 1 === e ? t = !0 : d = 13;
					} else d = n.nextState(d, s), 0 === d && (t = !0);
					t && (d = 1, u = !1, m = !1, g = !1, c = l + 1, h = s), l++;
				}
				13 === d && r.push(e._createLink(i, o, a, c, s));
			}
			return r;
		}
	};
	var Ge = class e {
		constructor() {
			this._defaultValueSet = [
				["true", "false"],
				["True", "False"],
				[
					"Private",
					"Public",
					"Friend",
					"ReadOnly",
					"Partial",
					"Protected",
					"WriteOnly"
				],
				[
					"public",
					"protected",
					"private"
				]
			];
		}
		static {
			this.INSTANCE = new e();
		}
		navigateValueSet(e, t, n, i, r) {
			if (e && t) {
				const n = this.doNavigateValueSet(t, r);
				if (n) return {
					range: e,
					value: n
				};
			}
			if (n && i) {
				const e = this.doNavigateValueSet(i, r);
				if (e) return {
					range: n,
					value: e
				};
			}
			return null;
		}
		doNavigateValueSet(e, t) {
			const n = this.numberReplace(e, t);
			return null !== n ? n : this.textReplace(e, t);
		}
		numberReplace(e, t) {
			const n = Math.pow(10, e.length - (e.lastIndexOf(".") + 1));
			let i = Number(e);
			const r = parseFloat(e);
			return isNaN(i) || isNaN(r) || i !== r ? null : 0 !== i || t ? (i = Math.floor(i * n), i += t ? n : -n, String(i / n)) : null;
		}
		textReplace(e, t) {
			return this.valueSetsReplace(this._defaultValueSet, e, t);
		}
		valueSetsReplace(e, t, n) {
			let i = null;
			for (let r = 0, a = e.length; null === i && r < a; r++) i = this.valueSetReplace(e[r], t, n);
			return i;
		}
		valueSetReplace(e, t, n) {
			let i = e.indexOf(t);
			return i >= 0 ? (i += n ? 1 : -1, i < 0 ? i = e.length - 1 : i %= e.length, e[i]) : null;
		}
	};
	const $e = Object.freeze(function(e, t) {
		const n = setTimeout(e.bind(t), 0);
		return { dispose() {
			clearTimeout(n);
		} };
	});
	var Xe;
	(function(e) {
		e.isCancellationToken = function(t) {
			return t === e.None || t === e.Cancelled || t instanceof Je || !(!t || "object" != typeof t) && "boolean" == typeof t.isCancellationRequested && "function" == typeof t.onCancellationRequested;
		}, e.None = Object.freeze({
			isCancellationRequested: !1,
			onCancellationRequested: w.None
		}), e.Cancelled = Object.freeze({
			isCancellationRequested: !0,
			onCancellationRequested: $e
		});
	})(Xe || (Xe = {}));
	var Je = class {
		constructor() {
			this._isCancelled = !1, this._emitter = null;
		}
		cancel() {
			this._isCancelled || (this._isCancelled = !0, this._emitter && (this._emitter.fire(void 0), this.dispose()));
		}
		get isCancellationRequested() {
			return this._isCancelled;
		}
		get onCancellationRequested() {
			return this._isCancelled ? $e : (this._emitter || (this._emitter = new C()), this._emitter.event);
		}
		dispose() {
			this._emitter && (this._emitter.dispose(), this._emitter = null);
		}
	}, Ye = class {
		constructor(e) {
			this._token = void 0, this._parentListener = void 0, this._parentListener = e && e.onCancellationRequested(this.cancel, this);
		}
		get token() {
			return this._token || (this._token = new Je()), this._token;
		}
		cancel() {
			this._token ? this._token instanceof Je && this._token.cancel() : this._token = Xe.Cancelled;
		}
		dispose(e = !1) {
			e && this.cancel(), this._parentListener?.dispose(), this._token ? this._token instanceof Je && this._token.dispose() : this._token = Xe.None;
		}
	}, Qe = class {
		constructor() {
			this._keyCodeToStr = [], this._strToKeyCode = Object.create(null);
		}
		define(e, t) {
			this._keyCodeToStr[e] = t, this._strToKeyCode[t.toLowerCase()] = e;
		}
		keyCodeToStr(e) {
			return this._keyCodeToStr[e];
		}
		strToKeyCode(e) {
			return this._strToKeyCode[e.toLowerCase()] || 0;
		}
	};
	const Ze = new Qe(), et = new Qe(), tt = new Qe(), nt = new Array(230), it = Object.create(null), rt = Object.create(null), at = [];
	for (let Al = 0; Al <= 193; Al++) at[Al] = -1;
	var ot;
	let st;
	(function() {
		const e = "", t = [
			[
				1,
				0,
				"None",
				0,
				"unknown",
				0,
				"VK_UNKNOWN",
				e,
				e
			],
			[
				1,
				1,
				"Hyper",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				2,
				"Super",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				3,
				"Fn",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				4,
				"FnLock",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				5,
				"Suspend",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				6,
				"Resume",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				7,
				"Turbo",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				8,
				"Sleep",
				0,
				e,
				0,
				"VK_SLEEP",
				e,
				e
			],
			[
				1,
				9,
				"WakeUp",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				0,
				10,
				"KeyA",
				31,
				"A",
				65,
				"VK_A",
				e,
				e
			],
			[
				0,
				11,
				"KeyB",
				32,
				"B",
				66,
				"VK_B",
				e,
				e
			],
			[
				0,
				12,
				"KeyC",
				33,
				"C",
				67,
				"VK_C",
				e,
				e
			],
			[
				0,
				13,
				"KeyD",
				34,
				"D",
				68,
				"VK_D",
				e,
				e
			],
			[
				0,
				14,
				"KeyE",
				35,
				"E",
				69,
				"VK_E",
				e,
				e
			],
			[
				0,
				15,
				"KeyF",
				36,
				"F",
				70,
				"VK_F",
				e,
				e
			],
			[
				0,
				16,
				"KeyG",
				37,
				"G",
				71,
				"VK_G",
				e,
				e
			],
			[
				0,
				17,
				"KeyH",
				38,
				"H",
				72,
				"VK_H",
				e,
				e
			],
			[
				0,
				18,
				"KeyI",
				39,
				"I",
				73,
				"VK_I",
				e,
				e
			],
			[
				0,
				19,
				"KeyJ",
				40,
				"J",
				74,
				"VK_J",
				e,
				e
			],
			[
				0,
				20,
				"KeyK",
				41,
				"K",
				75,
				"VK_K",
				e,
				e
			],
			[
				0,
				21,
				"KeyL",
				42,
				"L",
				76,
				"VK_L",
				e,
				e
			],
			[
				0,
				22,
				"KeyM",
				43,
				"M",
				77,
				"VK_M",
				e,
				e
			],
			[
				0,
				23,
				"KeyN",
				44,
				"N",
				78,
				"VK_N",
				e,
				e
			],
			[
				0,
				24,
				"KeyO",
				45,
				"O",
				79,
				"VK_O",
				e,
				e
			],
			[
				0,
				25,
				"KeyP",
				46,
				"P",
				80,
				"VK_P",
				e,
				e
			],
			[
				0,
				26,
				"KeyQ",
				47,
				"Q",
				81,
				"VK_Q",
				e,
				e
			],
			[
				0,
				27,
				"KeyR",
				48,
				"R",
				82,
				"VK_R",
				e,
				e
			],
			[
				0,
				28,
				"KeyS",
				49,
				"S",
				83,
				"VK_S",
				e,
				e
			],
			[
				0,
				29,
				"KeyT",
				50,
				"T",
				84,
				"VK_T",
				e,
				e
			],
			[
				0,
				30,
				"KeyU",
				51,
				"U",
				85,
				"VK_U",
				e,
				e
			],
			[
				0,
				31,
				"KeyV",
				52,
				"V",
				86,
				"VK_V",
				e,
				e
			],
			[
				0,
				32,
				"KeyW",
				53,
				"W",
				87,
				"VK_W",
				e,
				e
			],
			[
				0,
				33,
				"KeyX",
				54,
				"X",
				88,
				"VK_X",
				e,
				e
			],
			[
				0,
				34,
				"KeyY",
				55,
				"Y",
				89,
				"VK_Y",
				e,
				e
			],
			[
				0,
				35,
				"KeyZ",
				56,
				"Z",
				90,
				"VK_Z",
				e,
				e
			],
			[
				0,
				36,
				"Digit1",
				22,
				"1",
				49,
				"VK_1",
				e,
				e
			],
			[
				0,
				37,
				"Digit2",
				23,
				"2",
				50,
				"VK_2",
				e,
				e
			],
			[
				0,
				38,
				"Digit3",
				24,
				"3",
				51,
				"VK_3",
				e,
				e
			],
			[
				0,
				39,
				"Digit4",
				25,
				"4",
				52,
				"VK_4",
				e,
				e
			],
			[
				0,
				40,
				"Digit5",
				26,
				"5",
				53,
				"VK_5",
				e,
				e
			],
			[
				0,
				41,
				"Digit6",
				27,
				"6",
				54,
				"VK_6",
				e,
				e
			],
			[
				0,
				42,
				"Digit7",
				28,
				"7",
				55,
				"VK_7",
				e,
				e
			],
			[
				0,
				43,
				"Digit8",
				29,
				"8",
				56,
				"VK_8",
				e,
				e
			],
			[
				0,
				44,
				"Digit9",
				30,
				"9",
				57,
				"VK_9",
				e,
				e
			],
			[
				0,
				45,
				"Digit0",
				21,
				"0",
				48,
				"VK_0",
				e,
				e
			],
			[
				1,
				46,
				"Enter",
				3,
				"Enter",
				13,
				"VK_RETURN",
				e,
				e
			],
			[
				1,
				47,
				"Escape",
				9,
				"Escape",
				27,
				"VK_ESCAPE",
				e,
				e
			],
			[
				1,
				48,
				"Backspace",
				1,
				"Backspace",
				8,
				"VK_BACK",
				e,
				e
			],
			[
				1,
				49,
				"Tab",
				2,
				"Tab",
				9,
				"VK_TAB",
				e,
				e
			],
			[
				1,
				50,
				"Space",
				10,
				"Space",
				32,
				"VK_SPACE",
				e,
				e
			],
			[
				0,
				51,
				"Minus",
				88,
				"-",
				189,
				"VK_OEM_MINUS",
				"-",
				"OEM_MINUS"
			],
			[
				0,
				52,
				"Equal",
				86,
				"=",
				187,
				"VK_OEM_PLUS",
				"=",
				"OEM_PLUS"
			],
			[
				0,
				53,
				"BracketLeft",
				92,
				"[",
				219,
				"VK_OEM_4",
				"[",
				"OEM_4"
			],
			[
				0,
				54,
				"BracketRight",
				94,
				"]",
				221,
				"VK_OEM_6",
				"]",
				"OEM_6"
			],
			[
				0,
				55,
				"Backslash",
				93,
				"\\",
				220,
				"VK_OEM_5",
				"\\",
				"OEM_5"
			],
			[
				0,
				56,
				"IntlHash",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				0,
				57,
				"Semicolon",
				85,
				";",
				186,
				"VK_OEM_1",
				";",
				"OEM_1"
			],
			[
				0,
				58,
				"Quote",
				95,
				"'",
				222,
				"VK_OEM_7",
				"'",
				"OEM_7"
			],
			[
				0,
				59,
				"Backquote",
				91,
				"`",
				192,
				"VK_OEM_3",
				"`",
				"OEM_3"
			],
			[
				0,
				60,
				"Comma",
				87,
				",",
				188,
				"VK_OEM_COMMA",
				",",
				"OEM_COMMA"
			],
			[
				0,
				61,
				"Period",
				89,
				".",
				190,
				"VK_OEM_PERIOD",
				".",
				"OEM_PERIOD"
			],
			[
				0,
				62,
				"Slash",
				90,
				"/",
				191,
				"VK_OEM_2",
				"/",
				"OEM_2"
			],
			[
				1,
				63,
				"CapsLock",
				8,
				"CapsLock",
				20,
				"VK_CAPITAL",
				e,
				e
			],
			[
				1,
				64,
				"F1",
				59,
				"F1",
				112,
				"VK_F1",
				e,
				e
			],
			[
				1,
				65,
				"F2",
				60,
				"F2",
				113,
				"VK_F2",
				e,
				e
			],
			[
				1,
				66,
				"F3",
				61,
				"F3",
				114,
				"VK_F3",
				e,
				e
			],
			[
				1,
				67,
				"F4",
				62,
				"F4",
				115,
				"VK_F4",
				e,
				e
			],
			[
				1,
				68,
				"F5",
				63,
				"F5",
				116,
				"VK_F5",
				e,
				e
			],
			[
				1,
				69,
				"F6",
				64,
				"F6",
				117,
				"VK_F6",
				e,
				e
			],
			[
				1,
				70,
				"F7",
				65,
				"F7",
				118,
				"VK_F7",
				e,
				e
			],
			[
				1,
				71,
				"F8",
				66,
				"F8",
				119,
				"VK_F8",
				e,
				e
			],
			[
				1,
				72,
				"F9",
				67,
				"F9",
				120,
				"VK_F9",
				e,
				e
			],
			[
				1,
				73,
				"F10",
				68,
				"F10",
				121,
				"VK_F10",
				e,
				e
			],
			[
				1,
				74,
				"F11",
				69,
				"F11",
				122,
				"VK_F11",
				e,
				e
			],
			[
				1,
				75,
				"F12",
				70,
				"F12",
				123,
				"VK_F12",
				e,
				e
			],
			[
				1,
				76,
				"PrintScreen",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				77,
				"ScrollLock",
				84,
				"ScrollLock",
				145,
				"VK_SCROLL",
				e,
				e
			],
			[
				1,
				78,
				"Pause",
				7,
				"PauseBreak",
				19,
				"VK_PAUSE",
				e,
				e
			],
			[
				1,
				79,
				"Insert",
				19,
				"Insert",
				45,
				"VK_INSERT",
				e,
				e
			],
			[
				1,
				80,
				"Home",
				14,
				"Home",
				36,
				"VK_HOME",
				e,
				e
			],
			[
				1,
				81,
				"PageUp",
				11,
				"PageUp",
				33,
				"VK_PRIOR",
				e,
				e
			],
			[
				1,
				82,
				"Delete",
				20,
				"Delete",
				46,
				"VK_DELETE",
				e,
				e
			],
			[
				1,
				83,
				"End",
				13,
				"End",
				35,
				"VK_END",
				e,
				e
			],
			[
				1,
				84,
				"PageDown",
				12,
				"PageDown",
				34,
				"VK_NEXT",
				e,
				e
			],
			[
				1,
				85,
				"ArrowRight",
				17,
				"RightArrow",
				39,
				"VK_RIGHT",
				"Right",
				e
			],
			[
				1,
				86,
				"ArrowLeft",
				15,
				"LeftArrow",
				37,
				"VK_LEFT",
				"Left",
				e
			],
			[
				1,
				87,
				"ArrowDown",
				18,
				"DownArrow",
				40,
				"VK_DOWN",
				"Down",
				e
			],
			[
				1,
				88,
				"ArrowUp",
				16,
				"UpArrow",
				38,
				"VK_UP",
				"Up",
				e
			],
			[
				1,
				89,
				"NumLock",
				83,
				"NumLock",
				144,
				"VK_NUMLOCK",
				e,
				e
			],
			[
				1,
				90,
				"NumpadDivide",
				113,
				"NumPad_Divide",
				111,
				"VK_DIVIDE",
				e,
				e
			],
			[
				1,
				91,
				"NumpadMultiply",
				108,
				"NumPad_Multiply",
				106,
				"VK_MULTIPLY",
				e,
				e
			],
			[
				1,
				92,
				"NumpadSubtract",
				111,
				"NumPad_Subtract",
				109,
				"VK_SUBTRACT",
				e,
				e
			],
			[
				1,
				93,
				"NumpadAdd",
				109,
				"NumPad_Add",
				107,
				"VK_ADD",
				e,
				e
			],
			[
				1,
				94,
				"NumpadEnter",
				3,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				95,
				"Numpad1",
				99,
				"NumPad1",
				97,
				"VK_NUMPAD1",
				e,
				e
			],
			[
				1,
				96,
				"Numpad2",
				100,
				"NumPad2",
				98,
				"VK_NUMPAD2",
				e,
				e
			],
			[
				1,
				97,
				"Numpad3",
				101,
				"NumPad3",
				99,
				"VK_NUMPAD3",
				e,
				e
			],
			[
				1,
				98,
				"Numpad4",
				102,
				"NumPad4",
				100,
				"VK_NUMPAD4",
				e,
				e
			],
			[
				1,
				99,
				"Numpad5",
				103,
				"NumPad5",
				101,
				"VK_NUMPAD5",
				e,
				e
			],
			[
				1,
				100,
				"Numpad6",
				104,
				"NumPad6",
				102,
				"VK_NUMPAD6",
				e,
				e
			],
			[
				1,
				101,
				"Numpad7",
				105,
				"NumPad7",
				103,
				"VK_NUMPAD7",
				e,
				e
			],
			[
				1,
				102,
				"Numpad8",
				106,
				"NumPad8",
				104,
				"VK_NUMPAD8",
				e,
				e
			],
			[
				1,
				103,
				"Numpad9",
				107,
				"NumPad9",
				105,
				"VK_NUMPAD9",
				e,
				e
			],
			[
				1,
				104,
				"Numpad0",
				98,
				"NumPad0",
				96,
				"VK_NUMPAD0",
				e,
				e
			],
			[
				1,
				105,
				"NumpadDecimal",
				112,
				"NumPad_Decimal",
				110,
				"VK_DECIMAL",
				e,
				e
			],
			[
				0,
				106,
				"IntlBackslash",
				97,
				"OEM_102",
				226,
				"VK_OEM_102",
				e,
				e
			],
			[
				1,
				107,
				"ContextMenu",
				58,
				"ContextMenu",
				93,
				e,
				e,
				e
			],
			[
				1,
				108,
				"Power",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				109,
				"NumpadEqual",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				110,
				"F13",
				71,
				"F13",
				124,
				"VK_F13",
				e,
				e
			],
			[
				1,
				111,
				"F14",
				72,
				"F14",
				125,
				"VK_F14",
				e,
				e
			],
			[
				1,
				112,
				"F15",
				73,
				"F15",
				126,
				"VK_F15",
				e,
				e
			],
			[
				1,
				113,
				"F16",
				74,
				"F16",
				127,
				"VK_F16",
				e,
				e
			],
			[
				1,
				114,
				"F17",
				75,
				"F17",
				128,
				"VK_F17",
				e,
				e
			],
			[
				1,
				115,
				"F18",
				76,
				"F18",
				129,
				"VK_F18",
				e,
				e
			],
			[
				1,
				116,
				"F19",
				77,
				"F19",
				130,
				"VK_F19",
				e,
				e
			],
			[
				1,
				117,
				"F20",
				78,
				"F20",
				131,
				"VK_F20",
				e,
				e
			],
			[
				1,
				118,
				"F21",
				79,
				"F21",
				132,
				"VK_F21",
				e,
				e
			],
			[
				1,
				119,
				"F22",
				80,
				"F22",
				133,
				"VK_F22",
				e,
				e
			],
			[
				1,
				120,
				"F23",
				81,
				"F23",
				134,
				"VK_F23",
				e,
				e
			],
			[
				1,
				121,
				"F24",
				82,
				"F24",
				135,
				"VK_F24",
				e,
				e
			],
			[
				1,
				122,
				"Open",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				123,
				"Help",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				124,
				"Select",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				125,
				"Again",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				126,
				"Undo",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				127,
				"Cut",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				128,
				"Copy",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				129,
				"Paste",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				130,
				"Find",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				131,
				"AudioVolumeMute",
				117,
				"AudioVolumeMute",
				173,
				"VK_VOLUME_MUTE",
				e,
				e
			],
			[
				1,
				132,
				"AudioVolumeUp",
				118,
				"AudioVolumeUp",
				175,
				"VK_VOLUME_UP",
				e,
				e
			],
			[
				1,
				133,
				"AudioVolumeDown",
				119,
				"AudioVolumeDown",
				174,
				"VK_VOLUME_DOWN",
				e,
				e
			],
			[
				1,
				134,
				"NumpadComma",
				110,
				"NumPad_Separator",
				108,
				"VK_SEPARATOR",
				e,
				e
			],
			[
				0,
				135,
				"IntlRo",
				115,
				"ABNT_C1",
				193,
				"VK_ABNT_C1",
				e,
				e
			],
			[
				1,
				136,
				"KanaMode",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				0,
				137,
				"IntlYen",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				138,
				"Convert",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				139,
				"NonConvert",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				140,
				"Lang1",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				141,
				"Lang2",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				142,
				"Lang3",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				143,
				"Lang4",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				144,
				"Lang5",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				145,
				"Abort",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				146,
				"Props",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				147,
				"NumpadParenLeft",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				148,
				"NumpadParenRight",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				149,
				"NumpadBackspace",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				150,
				"NumpadMemoryStore",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				151,
				"NumpadMemoryRecall",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				152,
				"NumpadMemoryClear",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				153,
				"NumpadMemoryAdd",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				154,
				"NumpadMemorySubtract",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				155,
				"NumpadClear",
				131,
				"Clear",
				12,
				"VK_CLEAR",
				e,
				e
			],
			[
				1,
				156,
				"NumpadClearEntry",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				0,
				e,
				5,
				"Ctrl",
				17,
				"VK_CONTROL",
				e,
				e
			],
			[
				1,
				0,
				e,
				4,
				"Shift",
				16,
				"VK_SHIFT",
				e,
				e
			],
			[
				1,
				0,
				e,
				6,
				"Alt",
				18,
				"VK_MENU",
				e,
				e
			],
			[
				1,
				0,
				e,
				57,
				"Meta",
				91,
				"VK_COMMAND",
				e,
				e
			],
			[
				1,
				157,
				"ControlLeft",
				5,
				e,
				0,
				"VK_LCONTROL",
				e,
				e
			],
			[
				1,
				158,
				"ShiftLeft",
				4,
				e,
				0,
				"VK_LSHIFT",
				e,
				e
			],
			[
				1,
				159,
				"AltLeft",
				6,
				e,
				0,
				"VK_LMENU",
				e,
				e
			],
			[
				1,
				160,
				"MetaLeft",
				57,
				e,
				0,
				"VK_LWIN",
				e,
				e
			],
			[
				1,
				161,
				"ControlRight",
				5,
				e,
				0,
				"VK_RCONTROL",
				e,
				e
			],
			[
				1,
				162,
				"ShiftRight",
				4,
				e,
				0,
				"VK_RSHIFT",
				e,
				e
			],
			[
				1,
				163,
				"AltRight",
				6,
				e,
				0,
				"VK_RMENU",
				e,
				e
			],
			[
				1,
				164,
				"MetaRight",
				57,
				e,
				0,
				"VK_RWIN",
				e,
				e
			],
			[
				1,
				165,
				"BrightnessUp",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				166,
				"BrightnessDown",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				167,
				"MediaPlay",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				168,
				"MediaRecord",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				169,
				"MediaFastForward",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				170,
				"MediaRewind",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				171,
				"MediaTrackNext",
				124,
				"MediaTrackNext",
				176,
				"VK_MEDIA_NEXT_TRACK",
				e,
				e
			],
			[
				1,
				172,
				"MediaTrackPrevious",
				125,
				"MediaTrackPrevious",
				177,
				"VK_MEDIA_PREV_TRACK",
				e,
				e
			],
			[
				1,
				173,
				"MediaStop",
				126,
				"MediaStop",
				178,
				"VK_MEDIA_STOP",
				e,
				e
			],
			[
				1,
				174,
				"Eject",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				175,
				"MediaPlayPause",
				127,
				"MediaPlayPause",
				179,
				"VK_MEDIA_PLAY_PAUSE",
				e,
				e
			],
			[
				1,
				176,
				"MediaSelect",
				128,
				"LaunchMediaPlayer",
				181,
				"VK_MEDIA_LAUNCH_MEDIA_SELECT",
				e,
				e
			],
			[
				1,
				177,
				"LaunchMail",
				129,
				"LaunchMail",
				180,
				"VK_MEDIA_LAUNCH_MAIL",
				e,
				e
			],
			[
				1,
				178,
				"LaunchApp2",
				130,
				"LaunchApp2",
				183,
				"VK_MEDIA_LAUNCH_APP2",
				e,
				e
			],
			[
				1,
				179,
				"LaunchApp1",
				0,
				e,
				0,
				"VK_MEDIA_LAUNCH_APP1",
				e,
				e
			],
			[
				1,
				180,
				"SelectTask",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				181,
				"LaunchScreenSaver",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				182,
				"BrowserSearch",
				120,
				"BrowserSearch",
				170,
				"VK_BROWSER_SEARCH",
				e,
				e
			],
			[
				1,
				183,
				"BrowserHome",
				121,
				"BrowserHome",
				172,
				"VK_BROWSER_HOME",
				e,
				e
			],
			[
				1,
				184,
				"BrowserBack",
				122,
				"BrowserBack",
				166,
				"VK_BROWSER_BACK",
				e,
				e
			],
			[
				1,
				185,
				"BrowserForward",
				123,
				"BrowserForward",
				167,
				"VK_BROWSER_FORWARD",
				e,
				e
			],
			[
				1,
				186,
				"BrowserStop",
				0,
				e,
				0,
				"VK_BROWSER_STOP",
				e,
				e
			],
			[
				1,
				187,
				"BrowserRefresh",
				0,
				e,
				0,
				"VK_BROWSER_REFRESH",
				e,
				e
			],
			[
				1,
				188,
				"BrowserFavorites",
				0,
				e,
				0,
				"VK_BROWSER_FAVORITES",
				e,
				e
			],
			[
				1,
				189,
				"ZoomToggle",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				190,
				"MailReply",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				191,
				"MailForward",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				192,
				"MailSend",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				0,
				e,
				114,
				"KeyInComposition",
				229,
				e,
				e,
				e
			],
			[
				1,
				0,
				e,
				116,
				"ABNT_C2",
				194,
				"VK_ABNT_C2",
				e,
				e
			],
			[
				1,
				0,
				e,
				96,
				"OEM_8",
				223,
				"VK_OEM_8",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_KANA",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_HANGUL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_JUNJA",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_FINAL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_HANJA",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_KANJI",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_CONVERT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_NONCONVERT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_ACCEPT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_MODECHANGE",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_SELECT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PRINT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_EXECUTE",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_SNAPSHOT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_HELP",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_APPS",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PROCESSKEY",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PACKET",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_DBE_SBCSCHAR",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_DBE_DBCSCHAR",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_ATTN",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_CRSEL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_EXSEL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_EREOF",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PLAY",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_ZOOM",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_NONAME",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PA1",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_OEM_CLEAR",
				e,
				e
			]
		], n = [], i = [];
		for (const r of t) {
			const [e, t, a, o, s, l, c, h, d] = r;
			if (i[t] || (i[t] = !0, it[a] = t, rt[a.toLowerCase()] = t, e && (at[t] = o)), !n[o]) {
				if (n[o] = !0, !s) throw new Error(`String representation missing for key code ${o} around scan code ${a}`);
				Ze.define(o, s), et.define(o, h || s), tt.define(o, d || h || s);
			}
			l && (nt[l] = o);
		}
	})(), function(e) {
		e.toString = function(e) {
			return Ze.keyCodeToStr(e);
		}, e.fromString = function(e) {
			return Ze.strToKeyCode(e);
		}, e.toUserSettingsUS = function(e) {
			return et.keyCodeToStr(e);
		}, e.toUserSettingsGeneral = function(e) {
			return tt.keyCodeToStr(e);
		}, e.fromUserSettings = function(e) {
			return et.strToKeyCode(e) || tt.strToKeyCode(e);
		}, e.toElectronAccelerator = function(e) {
			if (e >= 98 && e <= 113) return null;
			switch (e) {
				case 16: return "Up";
				case 18: return "Down";
				case 15: return "Left";
				case 17: return "Right";
			}
			return Ze.keyCodeToStr(e);
		};
	}(ot || (ot = {}));
	const lt = globalThis.vscode;
	if (void 0 !== lt && void 0 !== lt.process) {
		const e = lt.process;
		st = {
			get platform() {
				return e.platform;
			},
			get arch() {
				return e.arch;
			},
			get env() {
				return e.env;
			},
			cwd: () => e.cwd()
		};
	} else st = "undefined" != typeof process && "string" == typeof process?.versions?.node ? {
		get platform() {
			return process.platform;
		},
		get arch() {
			return process.arch;
		},
		get env() {
			return {};
		},
		cwd: () => ({}).VSCODE_CWD || process.cwd()
	} : {
		get platform() {
			return j ? "win32" : G ? "darwin" : "linux";
		},
		get arch() {},
		get env() {
			return {};
		},
		cwd: () => "/"
	};
	const ct = st.cwd, ht = st.env, dt = st.platform, ut = 46, mt = 47, pt = 92, gt = 58;
	var ft = class extends Error {
		constructor(e, t, n) {
			let i;
			"string" == typeof t && 0 === t.indexOf("not ") ? (i = "must not be", t = t.replace(/^not /, "")) : i = "must be";
			let r = `The "${e}" ${-1 !== e.indexOf(".") ? "property" : "argument"} ${i} of type ${t}`;
			r += ". Received type " + typeof n, super(r), this.code = "ERR_INVALID_ARG_TYPE";
		}
	};
	function bt(e, t) {
		if ("string" != typeof e) throw new ft(t, "string", e);
	}
	const _t = "win32" === dt;
	function wt(e) {
		return e === mt || e === pt;
	}
	function vt(e) {
		return e === mt;
	}
	function yt(e) {
		return e >= 65 && e <= 90 || e >= 97 && e <= 122;
	}
	function Tt(e, t, n, i) {
		let r = "", a = 0, o = -1, s = 0, l = 0;
		for (let c = 0; c <= e.length; ++c) {
			if (c < e.length) l = e.charCodeAt(c);
			else {
				if (i(l)) break;
				l = mt;
			}
			if (i(l)) {
				if (o === c - 1 || 1 === s);
				else if (2 === s) {
					if (r.length < 2 || 2 !== a || r.charCodeAt(r.length - 1) !== ut || r.charCodeAt(r.length - 2) !== ut) {
						if (r.length > 2) {
							const e = r.lastIndexOf(n);
							-1 === e ? (r = "", a = 0) : (r = r.slice(0, e), a = r.length - 1 - r.lastIndexOf(n)), o = c, s = 0;
							continue;
						}
						if (0 !== r.length) {
							r = "", a = 0, o = c, s = 0;
							continue;
						}
					}
					t && (r += r.length > 0 ? `${n}..` : "..", a = 2);
				} else r.length > 0 ? r += `${n}${e.slice(o + 1, c)}` : r = e.slice(o + 1, c), a = c - o - 1;
				o = c, s = 0;
			} else l === ut && -1 !== s ? ++s : s = -1;
		}
		return r;
	}
	function kt(e, t) {
		(function(e, t) {
			if (null === e || "object" != typeof e) throw new ft(t, "Object", e);
		})(t, "pathObject");
		const n = t.dir || t.root, i = t.base || `${t.name || ""}${r = t.ext, r ? `${"." === r[0] ? "" : "."}${r}` : ""}`;
		var r;
		return n ? n === t.root ? `${n}${i}` : `${n}${e}${i}` : i;
	}
	const St = {
		resolve(...e) {
			let t = "", n = "", i = !1;
			for (let r = e.length - 1; r >= -1; r--) {
				let a;
				if (r >= 0) {
					if (a = e[r], bt(a, `paths[${r}]`), 0 === a.length) continue;
				} else 0 === t.length ? a = ct() : (a = ht[`=${t}`] || ct(), (void 0 === a || a.slice(0, 2).toLowerCase() !== t.toLowerCase() && a.charCodeAt(2) === pt) && (a = `${t}\\`));
				const o = a.length;
				let s = 0, l = "", c = !1;
				const h = a.charCodeAt(0);
				if (1 === o) wt(h) && (s = 1, c = !0);
				else if (wt(h)) if (c = !0, wt(a.charCodeAt(1))) {
					let e = 2, t = e;
					for (; e < o && !wt(a.charCodeAt(e));) e++;
					if (e < o && e !== t) {
						const n = a.slice(t, e);
						for (t = e; e < o && wt(a.charCodeAt(e));) e++;
						if (e < o && e !== t) {
							for (t = e; e < o && !wt(a.charCodeAt(e));) e++;
							e !== o && e === t || (l = `\\\\${n}\\${a.slice(t, e)}`, s = e);
						}
					}
				} else s = 1;
				else yt(h) && a.charCodeAt(1) === gt && (l = a.slice(0, 2), s = 2, o > 2 && wt(a.charCodeAt(2)) && (c = !0, s = 3));
				if (l.length > 0) if (t.length > 0) {
					if (l.toLowerCase() !== t.toLowerCase()) continue;
				} else t = l;
				if (i) {
					if (t.length > 0) break;
				} else if (n = `${a.slice(s)}\\${n}`, i = c, c && t.length > 0) break;
			}
			return n = Tt(n, !i, "\\", wt), i ? `${t}\\${n}` : `${t}${n}` || ".";
		},
		normalize(e) {
			bt(e, "path");
			const t = e.length;
			if (0 === t) return ".";
			let n, i = 0, r = !1;
			const a = e.charCodeAt(0);
			if (1 === t) return vt(a) ? "\\" : e;
			if (wt(a)) if (r = !0, wt(e.charCodeAt(1))) {
				let r = 2, a = r;
				for (; r < t && !wt(e.charCodeAt(r));) r++;
				if (r < t && r !== a) {
					const o = e.slice(a, r);
					for (a = r; r < t && wt(e.charCodeAt(r));) r++;
					if (r < t && r !== a) {
						for (a = r; r < t && !wt(e.charCodeAt(r));) r++;
						if (r === t) return `\\\\${o}\\${e.slice(a)}\\`;
						r !== a && (n = `\\\\${o}\\${e.slice(a, r)}`, i = r);
					}
				}
			} else i = 1;
			else yt(a) && e.charCodeAt(1) === gt && (n = e.slice(0, 2), i = 2, t > 2 && wt(e.charCodeAt(2)) && (r = !0, i = 3));
			let o = i < t ? Tt(e.slice(i), !r, "\\", wt) : "";
			if (0 !== o.length || r || (o = "."), o.length > 0 && wt(e.charCodeAt(t - 1)) && (o += "\\"), !r && void 0 === n && e.includes(":")) {
				if (o.length >= 2 && yt(o.charCodeAt(0)) && o.charCodeAt(1) === gt) return `.\\${o}`;
				let n = e.indexOf(":");
				do
					if (n === t - 1 || wt(e.charCodeAt(n + 1))) return `.\\${o}`;
				while (-1 !== (n = e.indexOf(":", n + 1)));
			}
			return void 0 === n ? r ? `\\${o}` : o : r ? `${n}\\${o}` : `${n}${o}`;
		},
		isAbsolute(e) {
			bt(e, "path");
			const t = e.length;
			if (0 === t) return !1;
			const n = e.charCodeAt(0);
			return wt(n) || t > 2 && yt(n) && e.charCodeAt(1) === gt && wt(e.charCodeAt(2));
		},
		join(...e) {
			if (0 === e.length) return ".";
			let t, n;
			for (let a = 0; a < e.length; ++a) {
				const i = e[a];
				bt(i, "path"), i.length > 0 && (void 0 === t ? t = n = i : t += `\\${i}`);
			}
			if (void 0 === t) return ".";
			let i = !0, r = 0;
			if ("string" == typeof n && wt(n.charCodeAt(0))) {
				++r;
				const e = n.length;
				e > 1 && wt(n.charCodeAt(1)) && (++r, e > 2 && (wt(n.charCodeAt(2)) ? ++r : i = !1));
			}
			if (i) {
				for (; r < t.length && wt(t.charCodeAt(r));) r++;
				r >= 2 && (t = `\\${t.slice(r)}`);
			}
			return St.normalize(t);
		},
		relative(e, t) {
			if (bt(e, "from"), bt(t, "to"), e === t) return "";
			const n = St.resolve(e), i = St.resolve(t);
			if (n === i) return "";
			if ((e = n.toLowerCase()) === (t = i.toLowerCase())) return "";
			if (n.length !== e.length || i.length !== t.length) {
				const e = n.split("\\"), t = i.split("\\");
				"" === e[e.length - 1] && e.pop(), "" === t[t.length - 1] && t.pop();
				const r = e.length, a = t.length, o = r < a ? r : a;
				let s;
				for (s = 0; s < o && e[s].toLowerCase() === t[s].toLowerCase(); s++);
				return 0 === s ? i : s === o ? a > o ? t.slice(s).join("\\") : r > o ? "..\\".repeat(r - 1 - s) + ".." : "" : "..\\".repeat(r - s) + t.slice(s).join("\\");
			}
			let r = 0;
			for (; r < e.length && e.charCodeAt(r) === pt;) r++;
			let a = e.length;
			for (; a - 1 > r && e.charCodeAt(a - 1) === pt;) a--;
			const o = a - r;
			let s = 0;
			for (; s < t.length && t.charCodeAt(s) === pt;) s++;
			let l = t.length;
			for (; l - 1 > s && t.charCodeAt(l - 1) === pt;) l--;
			const c = l - s, h = o < c ? o : c;
			let d = -1, u = 0;
			for (; u < h; u++) {
				const n = e.charCodeAt(r + u);
				if (n !== t.charCodeAt(s + u)) break;
				n === pt && (d = u);
			}
			if (u !== h) {
				if (-1 === d) return i;
			} else {
				if (c > h) {
					if (t.charCodeAt(s + u) === pt) return i.slice(s + u + 1);
					if (2 === u) return i.slice(s + u);
				}
				o > h && (e.charCodeAt(r + u) === pt ? d = u : 2 === u && (d = 3)), -1 === d && (d = 0);
			}
			let m = "";
			for (u = r + d + 1; u <= a; ++u) u !== a && e.charCodeAt(u) !== pt || (m += 0 === m.length ? ".." : "\\..");
			return s += d, m.length > 0 ? `${m}${i.slice(s, l)}` : (i.charCodeAt(s) === pt && ++s, i.slice(s, l));
		},
		toNamespacedPath(e) {
			if ("string" != typeof e || 0 === e.length) return e;
			const t = St.resolve(e);
			if (t.length <= 2) return e;
			if (t.charCodeAt(0) === pt) {
				if (t.charCodeAt(1) === pt) {
					const e = t.charCodeAt(2);
					if (63 !== e && e !== ut) return `\\\\?\\UNC\\${t.slice(2)}`;
				}
			} else if (yt(t.charCodeAt(0)) && t.charCodeAt(1) === gt && t.charCodeAt(2) === pt) return `\\\\?\\${t}`;
			return t;
		},
		dirname(e) {
			bt(e, "path");
			const t = e.length;
			if (0 === t) return ".";
			let n = -1, i = 0;
			const r = e.charCodeAt(0);
			if (1 === t) return wt(r) ? e : ".";
			if (wt(r)) {
				if (n = i = 1, wt(e.charCodeAt(1))) {
					let r = 2, a = r;
					for (; r < t && !wt(e.charCodeAt(r));) r++;
					if (r < t && r !== a) {
						for (a = r; r < t && wt(e.charCodeAt(r));) r++;
						if (r < t && r !== a) {
							for (a = r; r < t && !wt(e.charCodeAt(r));) r++;
							if (r === t) return e;
							r !== a && (n = i = r + 1);
						}
					}
				}
			} else yt(r) && e.charCodeAt(1) === gt && (n = t > 2 && wt(e.charCodeAt(2)) ? 3 : 2, i = n);
			let a = -1, o = !0;
			for (let s = t - 1; s >= i; --s) if (wt(e.charCodeAt(s))) {
				if (!o) {
					a = s;
					break;
				}
			} else o = !1;
			if (-1 === a) {
				if (-1 === n) return ".";
				a = n;
			}
			return e.slice(0, a);
		},
		basename(e, t) {
			void 0 !== t && bt(t, "suffix"), bt(e, "path");
			let n, i = 0, r = -1, a = !0;
			if (e.length >= 2 && yt(e.charCodeAt(0)) && e.charCodeAt(1) === gt && (i = 2), void 0 !== t && t.length > 0 && t.length <= e.length) {
				if (t === e) return "";
				let o = t.length - 1, s = -1;
				for (n = e.length - 1; n >= i; --n) {
					const l = e.charCodeAt(n);
					if (wt(l)) {
						if (!a) {
							i = n + 1;
							break;
						}
					} else -1 === s && (a = !1, s = n + 1), o >= 0 && (l === t.charCodeAt(o) ? -1 === --o && (r = n) : (o = -1, r = s));
				}
				return i === r ? r = s : -1 === r && (r = e.length), e.slice(i, r);
			}
			for (n = e.length - 1; n >= i; --n) if (wt(e.charCodeAt(n))) {
				if (!a) {
					i = n + 1;
					break;
				}
			} else -1 === r && (a = !1, r = n + 1);
			return -1 === r ? "" : e.slice(i, r);
		},
		extname(e) {
			bt(e, "path");
			let t = 0, n = -1, i = 0, r = -1, a = !0, o = 0;
			e.length >= 2 && e.charCodeAt(1) === gt && yt(e.charCodeAt(0)) && (t = i = 2);
			for (let s = e.length - 1; s >= t; --s) {
				const t = e.charCodeAt(s);
				if (wt(t)) {
					if (!a) {
						i = s + 1;
						break;
					}
				} else -1 === r && (a = !1, r = s + 1), t === ut ? -1 === n ? n = s : 1 !== o && (o = 1) : -1 !== n && (o = -1);
			}
			return -1 === n || -1 === r || 0 === o || 1 === o && n === r - 1 && n === i + 1 ? "" : e.slice(n, r);
		},
		format: kt.bind(null, "\\"),
		parse(e) {
			bt(e, "path");
			const t = {
				root: "",
				dir: "",
				base: "",
				ext: "",
				name: ""
			};
			if (0 === e.length) return t;
			const n = e.length;
			let i = 0, r = e.charCodeAt(0);
			if (1 === n) return wt(r) ? (t.root = t.dir = e, t) : (t.base = t.name = e, t);
			if (wt(r)) {
				if (i = 1, wt(e.charCodeAt(1))) {
					let t = 2, r = t;
					for (; t < n && !wt(e.charCodeAt(t));) t++;
					if (t < n && t !== r) {
						for (r = t; t < n && wt(e.charCodeAt(t));) t++;
						if (t < n && t !== r) {
							for (r = t; t < n && !wt(e.charCodeAt(t));) t++;
							t === n ? i = t : t !== r && (i = t + 1);
						}
					}
				}
			} else if (yt(r) && e.charCodeAt(1) === gt) {
				if (n <= 2) return t.root = t.dir = e, t;
				if (i = 2, wt(e.charCodeAt(2))) {
					if (3 === n) return t.root = t.dir = e, t;
					i = 3;
				}
			}
			i > 0 && (t.root = e.slice(0, i));
			let a = -1, o = i, s = -1, l = !0, c = e.length - 1, h = 0;
			for (; c >= i; --c) if (r = e.charCodeAt(c), wt(r)) {
				if (!l) {
					o = c + 1;
					break;
				}
			} else -1 === s && (l = !1, s = c + 1), r === ut ? -1 === a ? a = c : 1 !== h && (h = 1) : -1 !== a && (h = -1);
			return -1 !== s && (-1 === a || 0 === h || 1 === h && a === s - 1 && a === o + 1 ? t.base = t.name = e.slice(o, s) : (t.name = e.slice(o, a), t.base = e.slice(o, s), t.ext = e.slice(a, s))), t.dir = o > 0 && o !== i ? e.slice(0, o - 1) : t.root, t;
		},
		sep: "\\",
		delimiter: ";",
		win32: null,
		posix: null
	}, Lt = (() => {
		if (_t) {
			const e = /\\/g;
			return () => {
				const t = ct().replace(e, "/");
				return t.slice(t.indexOf("/"));
			};
		}
		return () => ct();
	})(), xt = {
		resolve(...e) {
			let t = "", n = !1;
			for (let i = e.length - 1; i >= 0 && !n; i--) {
				const r = e[i];
				bt(r, `paths[${i}]`), 0 !== r.length && (t = `${r}/${t}`, n = r.charCodeAt(0) === mt);
			}
			if (!n) {
				const e = Lt();
				t = `${e}/${t}`, n = e.charCodeAt(0) === mt;
			}
			return t = Tt(t, !n, "/", vt), n ? `/${t}` : t.length > 0 ? t : ".";
		},
		normalize(e) {
			if (bt(e, "path"), 0 === e.length) return ".";
			const t = e.charCodeAt(0) === mt, n = e.charCodeAt(e.length - 1) === mt;
			return 0 === (e = Tt(e, !t, "/", vt)).length ? t ? "/" : n ? "./" : "." : (n && (e += "/"), t ? `/${e}` : e);
		},
		isAbsolute: (e) => (bt(e, "path"), e.length > 0 && e.charCodeAt(0) === mt),
		join(...e) {
			if (0 === e.length) return ".";
			const t = [];
			for (let n = 0; n < e.length; ++n) {
				const i = e[n];
				bt(i, "path"), i.length > 0 && t.push(i);
			}
			return 0 === t.length ? "." : xt.normalize(t.join("/"));
		},
		relative(e, t) {
			if (bt(e, "from"), bt(t, "to"), e === t) return "";
			if ((e = xt.resolve(e)) === (t = xt.resolve(t))) return "";
			const n = e.length, i = n - 1, r = t.length - 1, a = i < r ? i : r;
			let o = -1, s = 0;
			for (; s < a; s++) {
				const n = e.charCodeAt(1 + s);
				if (n !== t.charCodeAt(1 + s)) break;
				n === mt && (o = s);
			}
			if (s === a) if (r > a) {
				if (t.charCodeAt(1 + s) === mt) return t.slice(1 + s + 1);
				if (0 === s) return t.slice(1 + s);
			} else i > a && (e.charCodeAt(1 + s) === mt ? o = s : 0 === s && (o = 0));
			let l = "";
			for (s = 1 + o + 1; s <= n; ++s) s !== n && e.charCodeAt(s) !== mt || (l += 0 === l.length ? ".." : "/..");
			return `${l}${t.slice(1 + o)}`;
		},
		toNamespacedPath: (e) => e,
		dirname(e) {
			if (bt(e, "path"), 0 === e.length) return ".";
			const t = e.charCodeAt(0) === mt;
			let n = -1, i = !0;
			for (let r = e.length - 1; r >= 1; --r) if (e.charCodeAt(r) === mt) {
				if (!i) {
					n = r;
					break;
				}
			} else i = !1;
			return -1 === n ? t ? "/" : "." : t && 1 === n ? "//" : e.slice(0, n);
		},
		basename(e, t) {
			void 0 !== t && bt(t, "suffix"), bt(e, "path");
			let n, i = 0, r = -1, a = !0;
			if (void 0 !== t && t.length > 0 && t.length <= e.length) {
				if (t === e) return "";
				let o = t.length - 1, s = -1;
				for (n = e.length - 1; n >= 0; --n) {
					const l = e.charCodeAt(n);
					if (l === mt) {
						if (!a) {
							i = n + 1;
							break;
						}
					} else -1 === s && (a = !1, s = n + 1), o >= 0 && (l === t.charCodeAt(o) ? -1 === --o && (r = n) : (o = -1, r = s));
				}
				return i === r ? r = s : -1 === r && (r = e.length), e.slice(i, r);
			}
			for (n = e.length - 1; n >= 0; --n) if (e.charCodeAt(n) === mt) {
				if (!a) {
					i = n + 1;
					break;
				}
			} else -1 === r && (a = !1, r = n + 1);
			return -1 === r ? "" : e.slice(i, r);
		},
		extname(e) {
			bt(e, "path");
			let t = -1, n = 0, i = -1, r = !0, a = 0;
			for (let o = e.length - 1; o >= 0; --o) {
				const s = e[o];
				if ("/" !== s) -1 === i && (r = !1, i = o + 1), "." === s ? -1 === t ? t = o : 1 !== a && (a = 1) : -1 !== t && (a = -1);
				else if (!r) {
					n = o + 1;
					break;
				}
			}
			return -1 === t || -1 === i || 0 === a || 1 === a && t === i - 1 && t === n + 1 ? "" : e.slice(t, i);
		},
		format: kt.bind(null, "/"),
		parse(e) {
			bt(e, "path");
			const t = {
				root: "",
				dir: "",
				base: "",
				ext: "",
				name: ""
			};
			if (0 === e.length) return t;
			const n = e.charCodeAt(0) === mt;
			let i;
			n ? (t.root = "/", i = 1) : i = 0;
			let r = -1, a = 0, o = -1, s = !0, l = e.length - 1, c = 0;
			for (; l >= i; --l) {
				const t = e.charCodeAt(l);
				if (t !== mt) -1 === o && (s = !1, o = l + 1), t === ut ? -1 === r ? r = l : 1 !== c && (c = 1) : -1 !== r && (c = -1);
				else if (!s) {
					a = l + 1;
					break;
				}
			}
			if (-1 !== o) {
				const i = 0 === a && n ? 1 : a;
				-1 === r || 0 === c || 1 === c && r === o - 1 && r === a + 1 ? t.base = t.name = e.slice(i, o) : (t.name = e.slice(i, r), t.base = e.slice(i, o), t.ext = e.slice(r, o));
			}
			return a > 0 ? t.dir = e.slice(0, a - 1) : n && (t.dir = "/"), t;
		},
		sep: "/",
		delimiter: ":",
		win32: null,
		posix: null
	};
	xt.win32 = St.win32 = St, xt.posix = St.posix = xt;
	_t ? St.normalize : xt.normalize, _t ? St.resolve : xt.resolve, _t ? St.relative : xt.relative, _t ? St.dirname : xt.dirname, _t ? St.basename : xt.basename, _t ? St.extname : xt.extname, _t ? St.sep : xt.sep;
	const Ct = /^\w[\w\d+.-]*$/, Et = /^\//, At = /^\/\//;
	const Rt = "", Mt = "/", Nt = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
	var It = class e {
		static isUri(t) {
			return t instanceof e || !(!t || "object" != typeof t) && "string" == typeof t.authority && "string" == typeof t.fragment && "string" == typeof t.path && "string" == typeof t.query && "string" == typeof t.scheme && "string" == typeof t.fsPath && "function" == typeof t.with && "function" == typeof t.toString;
		}
		constructor(e, t, n, i, r, a = !1) {
			"object" == typeof e ? (this.scheme = e.scheme || Rt, this.authority = e.authority || Rt, this.path = e.path || Rt, this.query = e.query || Rt, this.fragment = e.fragment || Rt) : (this.scheme = function(e, t) {
				return e || t ? e : "file";
			}(e, a), this.authority = t || Rt, this.path = function(e, t) {
				switch (e) {
					case "https":
					case "http":
					case "file": t ? t[0] !== Mt && (t = Mt + t) : t = Mt;
				}
				return t;
			}(this.scheme, n || Rt), this.query = i || Rt, this.fragment = r || Rt, function(e, t) {
				if (!e.scheme && t) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${e.authority}", path: "${e.path}", query: "${e.query}", fragment: "${e.fragment}"}`);
				if (e.scheme && !Ct.test(e.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
				if (e.path) {
					if (e.authority) {
						if (!Et.test(e.path)) throw new Error("[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash (\"/\") character");
					} else if (At.test(e.path)) throw new Error("[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters (\"//\")");
				}
			}(this, a));
		}
		get fsPath() {
			return Wt(this, !1);
		}
		with(e) {
			if (!e) return this;
			let { scheme: t, authority: n, path: i, query: r, fragment: a } = e;
			return void 0 === t ? t = this.scheme : null === t && (t = Rt), void 0 === n ? n = this.authority : null === n && (n = Rt), void 0 === i ? i = this.path : null === i && (i = Rt), void 0 === r ? r = this.query : null === r && (r = Rt), void 0 === a ? a = this.fragment : null === a && (a = Rt), t === this.scheme && n === this.authority && i === this.path && r === this.query && a === this.fragment ? this : new Ot(t, n, i, r, a);
		}
		static parse(e, t = !1) {
			const n = Nt.exec(e);
			return n ? new Ot(n[2] || Rt, Vt(n[4] || Rt), Vt(n[5] || Rt), Vt(n[7] || Rt), Vt(n[9] || Rt), t) : new Ot(Rt, Rt, Rt, Rt, Rt);
		}
		static file(e) {
			let t = Rt;
			if (j && (e = e.replace(/\\/g, Mt)), e[0] === Mt && e[1] === Mt) {
				const n = e.indexOf(Mt, 2);
				-1 === n ? (t = e.substring(2), e = Mt) : (t = e.substring(2, n), e = e.substring(n) || Mt);
			}
			return new Ot("file", t, e, Rt, Rt);
		}
		static from(e, t) {
			return new Ot(e.scheme, e.authority, e.path, e.query, e.fragment, t);
		}
		static joinPath(t, ...n) {
			if (!t.path) throw new Error("[UriError]: cannot call joinPath on URI without path");
			let i;
			return i = j && "file" === t.scheme ? e.file(St.join(Wt(t, !0), ...n)).path : xt.join(t.path, ...n), t.with({ path: i });
		}
		toString(e = !1) {
			return Pt(this, e);
		}
		toJSON() {
			return this;
		}
		static revive(t) {
			if (t) {
				if (t instanceof e) return t;
				{
					const e = new Ot(t);
					return e._formatted = t.external ?? null, e._fsPath = t._sep === zt ? t.fsPath ?? null : null, e;
				}
			}
			return t;
		}
	};
	const zt = j ? 1 : void 0;
	var Ot = class extends It {
		constructor() {
			super(...arguments), this._formatted = null, this._fsPath = null;
		}
		get fsPath() {
			return this._fsPath || (this._fsPath = Wt(this, !1)), this._fsPath;
		}
		toString(e = !1) {
			return e ? Pt(this, !0) : (this._formatted || (this._formatted = Pt(this, !1)), this._formatted);
		}
		toJSON() {
			const e = { $mid: 1 };
			return this._fsPath && (e.fsPath = this._fsPath, e._sep = zt), this._formatted && (e.external = this._formatted), this.path && (e.path = this.path), this.scheme && (e.scheme = this.scheme), this.authority && (e.authority = this.authority), this.query && (e.query = this.query), this.fragment && (e.fragment = this.fragment), e;
		}
	};
	const Ut = {
		58: "%3A",
		47: "%2F",
		63: "%3F",
		35: "%23",
		91: "%5B",
		93: "%5D",
		64: "%40",
		33: "%21",
		36: "%24",
		38: "%26",
		39: "%27",
		40: "%28",
		41: "%29",
		42: "%2A",
		43: "%2B",
		44: "%2C",
		59: "%3B",
		61: "%3D",
		32: "%20"
	};
	function Ht(e, t, n) {
		let i, r = -1;
		for (let a = 0; a < e.length; a++) {
			const o = e.charCodeAt(a);
			if (o >= 97 && o <= 122 || o >= 65 && o <= 90 || o >= 48 && o <= 57 || 45 === o || 46 === o || 95 === o || 126 === o || t && 47 === o || n && 91 === o || n && 93 === o || n && 58 === o) -1 !== r && (i += encodeURIComponent(e.substring(r, a)), r = -1), void 0 !== i && (i += e.charAt(a));
			else {
				void 0 === i && (i = e.substr(0, a));
				const t = Ut[o];
				void 0 !== t ? (-1 !== r && (i += encodeURIComponent(e.substring(r, a)), r = -1), i += t) : -1 === r && (r = a);
			}
		}
		return -1 !== r && (i += encodeURIComponent(e.substring(r))), void 0 !== i ? i : e;
	}
	function Dt(e) {
		let t;
		for (let n = 0; n < e.length; n++) {
			const i = e.charCodeAt(n);
			35 === i || 63 === i ? (void 0 === t && (t = e.substr(0, n)), t += Ut[i]) : void 0 !== t && (t += e[n]);
		}
		return void 0 !== t ? t : e;
	}
	function Wt(e, t) {
		let n;
		return n = e.authority && e.path.length > 1 && "file" === e.scheme ? `//${e.authority}${e.path}` : 47 === e.path.charCodeAt(0) && (e.path.charCodeAt(1) >= 65 && e.path.charCodeAt(1) <= 90 || e.path.charCodeAt(1) >= 97 && e.path.charCodeAt(1) <= 122) && 58 === e.path.charCodeAt(2) ? t ? e.path.substr(1) : e.path[1].toLowerCase() + e.path.substr(2) : e.path, j && (n = n.replace(/\//g, "\\")), n;
	}
	function Pt(e, t) {
		const n = t ? Dt : Ht;
		let i = "", { scheme: r, authority: a, path: o, query: s, fragment: l } = e;
		if (r && (i += r, i += ":"), (a || "file" === r) && (i += Mt, i += Mt), a) {
			let e = a.indexOf("@");
			if (-1 !== e) {
				const t = a.substr(0, e);
				a = a.substr(e + 1), e = t.lastIndexOf(":"), -1 === e ? i += n(t, !1, !1) : (i += n(t.substr(0, e), !1, !1), i += ":", i += n(t.substr(e + 1), !1, !0)), i += "@";
			}
			a = a.toLowerCase(), e = a.lastIndexOf(":"), -1 === e ? i += n(a, !1, !0) : (i += n(a.substr(0, e), !1, !0), i += a.substr(e));
		}
		if (o) {
			if (o.length >= 3 && 47 === o.charCodeAt(0) && 58 === o.charCodeAt(2)) {
				const e = o.charCodeAt(1);
				e >= 65 && e <= 90 && (o = `/${String.fromCharCode(e + 32)}:${o.substr(3)}`);
			} else if (o.length >= 2 && 58 === o.charCodeAt(1)) {
				const e = o.charCodeAt(0);
				e >= 65 && e <= 90 && (o = `${String.fromCharCode(e + 32)}:${o.substr(2)}`);
			}
			i += n(o, !0, !1);
		}
		return s && (i += "?", i += n(s, !1, !1)), l && (i += "#", i += t ? l : Ht(l, !1, !1)), i;
	}
	function qt(e) {
		try {
			return decodeURIComponent(e);
		} catch {
			return e.length > 3 ? e.substr(0, 3) + qt(e.substr(3)) : e;
		}
	}
	const Ft = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
	function Vt(e) {
		return e.match(Ft) ? e.replace(Ft, (e) => qt(e)) : e;
	}
	var Bt = class e extends De {
		constructor(e, t, n, i) {
			super(e, t, n, i), this.selectionStartLineNumber = e, this.selectionStartColumn = t, this.positionLineNumber = n, this.positionColumn = i;
		}
		toString() {
			return "[" + this.selectionStartLineNumber + "," + this.selectionStartColumn + " -> " + this.positionLineNumber + "," + this.positionColumn + "]";
		}
		equalsSelection(t) {
			return e.selectionsEqual(this, t);
		}
		static selectionsEqual(e, t) {
			return e.selectionStartLineNumber === t.selectionStartLineNumber && e.selectionStartColumn === t.selectionStartColumn && e.positionLineNumber === t.positionLineNumber && e.positionColumn === t.positionColumn;
		}
		getDirection() {
			return this.selectionStartLineNumber === this.startLineNumber && this.selectionStartColumn === this.startColumn ? 0 : 1;
		}
		setEndPosition(t, n) {
			return 0 === this.getDirection() ? new e(this.startLineNumber, this.startColumn, t, n) : new e(t, n, this.startLineNumber, this.startColumn);
		}
		getPosition() {
			return new He(this.positionLineNumber, this.positionColumn);
		}
		getSelectionStart() {
			return new He(this.selectionStartLineNumber, this.selectionStartColumn);
		}
		setStartPosition(t, n) {
			return 0 === this.getDirection() ? new e(t, n, this.endLineNumber, this.endColumn) : new e(this.endLineNumber, this.endColumn, t, n);
		}
		static fromPositions(t, n = t) {
			return new e(t.lineNumber, t.column, n.lineNumber, n.column);
		}
		static fromRange(t, n) {
			return 0 === n ? new e(t.startLineNumber, t.startColumn, t.endLineNumber, t.endColumn) : new e(t.endLineNumber, t.endColumn, t.startLineNumber, t.startColumn);
		}
		static liftSelection(t) {
			return new e(t.selectionStartLineNumber, t.selectionStartColumn, t.positionLineNumber, t.positionColumn);
		}
		static selectionsArrEqual(e, t) {
			if (e && !t || !e && t) return !1;
			if (!e && !t) return !0;
			if (e.length !== t.length) return !1;
			for (let n = 0, i = e.length; n < i; n++) if (!this.selectionsEqual(e[n], t[n])) return !1;
			return !0;
		}
		static isISelection(e) {
			return !!e && "number" == typeof e.selectionStartLineNumber && "number" == typeof e.selectionStartColumn && "number" == typeof e.positionLineNumber && "number" == typeof e.positionColumn;
		}
		static createWithDirection(t, n, i, r, a) {
			return 0 === a ? new e(t, n, i, r) : new e(i, r, t, n);
		}
	};
	const Kt = Object.create(null);
	function jt(e, t) {
		if ("string" == typeof t) {
			const n = Kt[t];
			if (void 0 === n) throw new Error(`${e} references an unknown codicon: ${t}`);
			t = n;
		}
		return Kt[e] = t, { id: e };
	}
	const Gt = {
		add: jt("add", 6e4),
		plus: jt("plus", 6e4),
		gistNew: jt("gist-new", 6e4),
		repoCreate: jt("repo-create", 6e4),
		lightbulb: jt("lightbulb", 60001),
		lightBulb: jt("light-bulb", 60001),
		repo: jt("repo", 60002),
		repoDelete: jt("repo-delete", 60002),
		gistFork: jt("gist-fork", 60003),
		repoForked: jt("repo-forked", 60003),
		gitPullRequest: jt("git-pull-request", 60004),
		gitPullRequestAbandoned: jt("git-pull-request-abandoned", 60004),
		recordKeys: jt("record-keys", 60005),
		keyboard: jt("keyboard", 60005),
		tag: jt("tag", 60006),
		gitPullRequestLabel: jt("git-pull-request-label", 60006),
		tagAdd: jt("tag-add", 60006),
		tagRemove: jt("tag-remove", 60006),
		person: jt("person", 60007),
		personFollow: jt("person-follow", 60007),
		personOutline: jt("person-outline", 60007),
		personFilled: jt("person-filled", 60007),
		sourceControl: jt("source-control", 60008),
		mirror: jt("mirror", 60009),
		mirrorPublic: jt("mirror-public", 60009),
		star: jt("star", 60010),
		starAdd: jt("star-add", 60010),
		starDelete: jt("star-delete", 60010),
		starEmpty: jt("star-empty", 60010),
		comment: jt("comment", 60011),
		commentAdd: jt("comment-add", 60011),
		alert: jt("alert", 60012),
		warning: jt("warning", 60012),
		search: jt("search", 60013),
		searchSave: jt("search-save", 60013),
		logOut: jt("log-out", 60014),
		signOut: jt("sign-out", 60014),
		logIn: jt("log-in", 60015),
		signIn: jt("sign-in", 60015),
		eye: jt("eye", 60016),
		eyeUnwatch: jt("eye-unwatch", 60016),
		eyeWatch: jt("eye-watch", 60016),
		circleFilled: jt("circle-filled", 60017),
		primitiveDot: jt("primitive-dot", 60017),
		closeDirty: jt("close-dirty", 60017),
		debugBreakpoint: jt("debug-breakpoint", 60017),
		debugBreakpointDisabled: jt("debug-breakpoint-disabled", 60017),
		debugHint: jt("debug-hint", 60017),
		terminalDecorationSuccess: jt("terminal-decoration-success", 60017),
		primitiveSquare: jt("primitive-square", 60018),
		edit: jt("edit", 60019),
		pencil: jt("pencil", 60019),
		info: jt("info", 60020),
		issueOpened: jt("issue-opened", 60020),
		gistPrivate: jt("gist-private", 60021),
		gitForkPrivate: jt("git-fork-private", 60021),
		lock: jt("lock", 60021),
		mirrorPrivate: jt("mirror-private", 60021),
		close: jt("close", 60022),
		removeClose: jt("remove-close", 60022),
		x: jt("x", 60022),
		repoSync: jt("repo-sync", 60023),
		sync: jt("sync", 60023),
		clone: jt("clone", 60024),
		desktopDownload: jt("desktop-download", 60024),
		beaker: jt("beaker", 60025),
		microscope: jt("microscope", 60025),
		vm: jt("vm", 60026),
		deviceDesktop: jt("device-desktop", 60026),
		file: jt("file", 60027),
		more: jt("more", 60028),
		ellipsis: jt("ellipsis", 60028),
		kebabHorizontal: jt("kebab-horizontal", 60028),
		mailReply: jt("mail-reply", 60029),
		reply: jt("reply", 60029),
		organization: jt("organization", 60030),
		organizationFilled: jt("organization-filled", 60030),
		organizationOutline: jt("organization-outline", 60030),
		newFile: jt("new-file", 60031),
		fileAdd: jt("file-add", 60031),
		newFolder: jt("new-folder", 60032),
		fileDirectoryCreate: jt("file-directory-create", 60032),
		trash: jt("trash", 60033),
		trashcan: jt("trashcan", 60033),
		history: jt("history", 60034),
		clock: jt("clock", 60034),
		folder: jt("folder", 60035),
		fileDirectory: jt("file-directory", 60035),
		symbolFolder: jt("symbol-folder", 60035),
		logoGithub: jt("logo-github", 60036),
		markGithub: jt("mark-github", 60036),
		github: jt("github", 60036),
		terminal: jt("terminal", 60037),
		console: jt("console", 60037),
		repl: jt("repl", 60037),
		zap: jt("zap", 60038),
		symbolEvent: jt("symbol-event", 60038),
		error: jt("error", 60039),
		stop: jt("stop", 60039),
		variable: jt("variable", 60040),
		symbolVariable: jt("symbol-variable", 60040),
		array: jt("array", 60042),
		symbolArray: jt("symbol-array", 60042),
		symbolModule: jt("symbol-module", 60043),
		symbolPackage: jt("symbol-package", 60043),
		symbolNamespace: jt("symbol-namespace", 60043),
		symbolObject: jt("symbol-object", 60043),
		symbolMethod: jt("symbol-method", 60044),
		symbolFunction: jt("symbol-function", 60044),
		symbolConstructor: jt("symbol-constructor", 60044),
		symbolBoolean: jt("symbol-boolean", 60047),
		symbolNull: jt("symbol-null", 60047),
		symbolNumeric: jt("symbol-numeric", 60048),
		symbolNumber: jt("symbol-number", 60048),
		symbolStructure: jt("symbol-structure", 60049),
		symbolStruct: jt("symbol-struct", 60049),
		symbolParameter: jt("symbol-parameter", 60050),
		symbolTypeParameter: jt("symbol-type-parameter", 60050),
		symbolKey: jt("symbol-key", 60051),
		symbolText: jt("symbol-text", 60051),
		symbolReference: jt("symbol-reference", 60052),
		goToFile: jt("go-to-file", 60052),
		symbolEnum: jt("symbol-enum", 60053),
		symbolValue: jt("symbol-value", 60053),
		symbolRuler: jt("symbol-ruler", 60054),
		symbolUnit: jt("symbol-unit", 60054),
		activateBreakpoints: jt("activate-breakpoints", 60055),
		archive: jt("archive", 60056),
		arrowBoth: jt("arrow-both", 60057),
		arrowDown: jt("arrow-down", 60058),
		arrowLeft: jt("arrow-left", 60059),
		arrowRight: jt("arrow-right", 60060),
		arrowSmallDown: jt("arrow-small-down", 60061),
		arrowSmallLeft: jt("arrow-small-left", 60062),
		arrowSmallRight: jt("arrow-small-right", 60063),
		arrowSmallUp: jt("arrow-small-up", 60064),
		arrowUp: jt("arrow-up", 60065),
		bell: jt("bell", 60066),
		bold: jt("bold", 60067),
		book: jt("book", 60068),
		bookmark: jt("bookmark", 60069),
		debugBreakpointConditionalUnverified: jt("debug-breakpoint-conditional-unverified", 60070),
		debugBreakpointConditional: jt("debug-breakpoint-conditional", 60071),
		debugBreakpointConditionalDisabled: jt("debug-breakpoint-conditional-disabled", 60071),
		debugBreakpointDataUnverified: jt("debug-breakpoint-data-unverified", 60072),
		debugBreakpointData: jt("debug-breakpoint-data", 60073),
		debugBreakpointDataDisabled: jt("debug-breakpoint-data-disabled", 60073),
		debugBreakpointLogUnverified: jt("debug-breakpoint-log-unverified", 60074),
		debugBreakpointLog: jt("debug-breakpoint-log", 60075),
		debugBreakpointLogDisabled: jt("debug-breakpoint-log-disabled", 60075),
		briefcase: jt("briefcase", 60076),
		broadcast: jt("broadcast", 60077),
		browser: jt("browser", 60078),
		bug: jt("bug", 60079),
		calendar: jt("calendar", 60080),
		caseSensitive: jt("case-sensitive", 60081),
		check: jt("check", 60082),
		checklist: jt("checklist", 60083),
		chevronDown: jt("chevron-down", 60084),
		chevronLeft: jt("chevron-left", 60085),
		chevronRight: jt("chevron-right", 60086),
		chevronUp: jt("chevron-up", 60087),
		chromeClose: jt("chrome-close", 60088),
		chromeMaximize: jt("chrome-maximize", 60089),
		chromeMinimize: jt("chrome-minimize", 60090),
		chromeRestore: jt("chrome-restore", 60091),
		circleOutline: jt("circle-outline", 60092),
		circle: jt("circle", 60092),
		debugBreakpointUnverified: jt("debug-breakpoint-unverified", 60092),
		terminalDecorationIncomplete: jt("terminal-decoration-incomplete", 60092),
		circleSlash: jt("circle-slash", 60093),
		circuitBoard: jt("circuit-board", 60094),
		clearAll: jt("clear-all", 60095),
		clippy: jt("clippy", 60096),
		closeAll: jt("close-all", 60097),
		cloudDownload: jt("cloud-download", 60098),
		cloudUpload: jt("cloud-upload", 60099),
		code: jt("code", 60100),
		collapseAll: jt("collapse-all", 60101),
		colorMode: jt("color-mode", 60102),
		commentDiscussion: jt("comment-discussion", 60103),
		creditCard: jt("credit-card", 60105),
		dash: jt("dash", 60108),
		dashboard: jt("dashboard", 60109),
		database: jt("database", 60110),
		debugContinue: jt("debug-continue", 60111),
		debugDisconnect: jt("debug-disconnect", 60112),
		debugPause: jt("debug-pause", 60113),
		debugRestart: jt("debug-restart", 60114),
		debugStart: jt("debug-start", 60115),
		debugStepInto: jt("debug-step-into", 60116),
		debugStepOut: jt("debug-step-out", 60117),
		debugStepOver: jt("debug-step-over", 60118),
		debugStop: jt("debug-stop", 60119),
		debug: jt("debug", 60120),
		deviceCameraVideo: jt("device-camera-video", 60121),
		deviceCamera: jt("device-camera", 60122),
		deviceMobile: jt("device-mobile", 60123),
		diffAdded: jt("diff-added", 60124),
		diffIgnored: jt("diff-ignored", 60125),
		diffModified: jt("diff-modified", 60126),
		diffRemoved: jt("diff-removed", 60127),
		diffRenamed: jt("diff-renamed", 60128),
		diff: jt("diff", 60129),
		diffSidebyside: jt("diff-sidebyside", 60129),
		discard: jt("discard", 60130),
		editorLayout: jt("editor-layout", 60131),
		emptyWindow: jt("empty-window", 60132),
		exclude: jt("exclude", 60133),
		extensions: jt("extensions", 60134),
		eyeClosed: jt("eye-closed", 60135),
		fileBinary: jt("file-binary", 60136),
		fileCode: jt("file-code", 60137),
		fileMedia: jt("file-media", 60138),
		filePdf: jt("file-pdf", 60139),
		fileSubmodule: jt("file-submodule", 60140),
		fileSymlinkDirectory: jt("file-symlink-directory", 60141),
		fileSymlinkFile: jt("file-symlink-file", 60142),
		fileZip: jt("file-zip", 60143),
		files: jt("files", 60144),
		filter: jt("filter", 60145),
		flame: jt("flame", 60146),
		foldDown: jt("fold-down", 60147),
		foldUp: jt("fold-up", 60148),
		fold: jt("fold", 60149),
		folderActive: jt("folder-active", 60150),
		folderOpened: jt("folder-opened", 60151),
		gear: jt("gear", 60152),
		gift: jt("gift", 60153),
		gistSecret: jt("gist-secret", 60154),
		gist: jt("gist", 60155),
		gitCommit: jt("git-commit", 60156),
		gitCompare: jt("git-compare", 60157),
		compareChanges: jt("compare-changes", 60157),
		gitMerge: jt("git-merge", 60158),
		githubAction: jt("github-action", 60159),
		githubAlt: jt("github-alt", 60160),
		globe: jt("globe", 60161),
		grabber: jt("grabber", 60162),
		graph: jt("graph", 60163),
		gripper: jt("gripper", 60164),
		heart: jt("heart", 60165),
		home: jt("home", 60166),
		horizontalRule: jt("horizontal-rule", 60167),
		hubot: jt("hubot", 60168),
		inbox: jt("inbox", 60169),
		issueReopened: jt("issue-reopened", 60171),
		issues: jt("issues", 60172),
		italic: jt("italic", 60173),
		jersey: jt("jersey", 60174),
		json: jt("json", 60175),
		kebabVertical: jt("kebab-vertical", 60176),
		key: jt("key", 60177),
		law: jt("law", 60178),
		lightbulbAutofix: jt("lightbulb-autofix", 60179),
		linkExternal: jt("link-external", 60180),
		link: jt("link", 60181),
		listOrdered: jt("list-ordered", 60182),
		listUnordered: jt("list-unordered", 60183),
		liveShare: jt("live-share", 60184),
		loading: jt("loading", 60185),
		location: jt("location", 60186),
		mailRead: jt("mail-read", 60187),
		mail: jt("mail", 60188),
		markdown: jt("markdown", 60189),
		megaphone: jt("megaphone", 60190),
		mention: jt("mention", 60191),
		milestone: jt("milestone", 60192),
		gitPullRequestMilestone: jt("git-pull-request-milestone", 60192),
		mortarBoard: jt("mortar-board", 60193),
		move: jt("move", 60194),
		multipleWindows: jt("multiple-windows", 60195),
		mute: jt("mute", 60196),
		noNewline: jt("no-newline", 60197),
		note: jt("note", 60198),
		octoface: jt("octoface", 60199),
		openPreview: jt("open-preview", 60200),
		package: jt("package", 60201),
		paintcan: jt("paintcan", 60202),
		pin: jt("pin", 60203),
		play: jt("play", 60204),
		run: jt("run", 60204),
		plug: jt("plug", 60205),
		preserveCase: jt("preserve-case", 60206),
		preview: jt("preview", 60207),
		project: jt("project", 60208),
		pulse: jt("pulse", 60209),
		question: jt("question", 60210),
		quote: jt("quote", 60211),
		radioTower: jt("radio-tower", 60212),
		reactions: jt("reactions", 60213),
		references: jt("references", 60214),
		refresh: jt("refresh", 60215),
		regex: jt("regex", 60216),
		remoteExplorer: jt("remote-explorer", 60217),
		remote: jt("remote", 60218),
		remove: jt("remove", 60219),
		replaceAll: jt("replace-all", 60220),
		replace: jt("replace", 60221),
		repoClone: jt("repo-clone", 60222),
		repoForcePush: jt("repo-force-push", 60223),
		repoPull: jt("repo-pull", 60224),
		repoPush: jt("repo-push", 60225),
		report: jt("report", 60226),
		requestChanges: jt("request-changes", 60227),
		rocket: jt("rocket", 60228),
		rootFolderOpened: jt("root-folder-opened", 60229),
		rootFolder: jt("root-folder", 60230),
		rss: jt("rss", 60231),
		ruby: jt("ruby", 60232),
		saveAll: jt("save-all", 60233),
		saveAs: jt("save-as", 60234),
		save: jt("save", 60235),
		screenFull: jt("screen-full", 60236),
		screenNormal: jt("screen-normal", 60237),
		searchStop: jt("search-stop", 60238),
		server: jt("server", 60240),
		settingsGear: jt("settings-gear", 60241),
		settings: jt("settings", 60242),
		shield: jt("shield", 60243),
		smiley: jt("smiley", 60244),
		sortPrecedence: jt("sort-precedence", 60245),
		splitHorizontal: jt("split-horizontal", 60246),
		splitVertical: jt("split-vertical", 60247),
		squirrel: jt("squirrel", 60248),
		starFull: jt("star-full", 60249),
		starHalf: jt("star-half", 60250),
		symbolClass: jt("symbol-class", 60251),
		symbolColor: jt("symbol-color", 60252),
		symbolConstant: jt("symbol-constant", 60253),
		symbolEnumMember: jt("symbol-enum-member", 60254),
		symbolField: jt("symbol-field", 60255),
		symbolFile: jt("symbol-file", 60256),
		symbolInterface: jt("symbol-interface", 60257),
		symbolKeyword: jt("symbol-keyword", 60258),
		symbolMisc: jt("symbol-misc", 60259),
		symbolOperator: jt("symbol-operator", 60260),
		symbolProperty: jt("symbol-property", 60261),
		wrench: jt("wrench", 60261),
		wrenchSubaction: jt("wrench-subaction", 60261),
		symbolSnippet: jt("symbol-snippet", 60262),
		tasklist: jt("tasklist", 60263),
		telescope: jt("telescope", 60264),
		textSize: jt("text-size", 60265),
		threeBars: jt("three-bars", 60266),
		thumbsdown: jt("thumbsdown", 60267),
		thumbsup: jt("thumbsup", 60268),
		tools: jt("tools", 60269),
		triangleDown: jt("triangle-down", 60270),
		triangleLeft: jt("triangle-left", 60271),
		triangleRight: jt("triangle-right", 60272),
		triangleUp: jt("triangle-up", 60273),
		twitter: jt("twitter", 60274),
		unfold: jt("unfold", 60275),
		unlock: jt("unlock", 60276),
		unmute: jt("unmute", 60277),
		unverified: jt("unverified", 60278),
		verified: jt("verified", 60279),
		versions: jt("versions", 60280),
		vmActive: jt("vm-active", 60281),
		vmOutline: jt("vm-outline", 60282),
		vmRunning: jt("vm-running", 60283),
		watch: jt("watch", 60284),
		whitespace: jt("whitespace", 60285),
		wholeWord: jt("whole-word", 60286),
		window: jt("window", 60287),
		wordWrap: jt("word-wrap", 60288),
		zoomIn: jt("zoom-in", 60289),
		zoomOut: jt("zoom-out", 60290),
		listFilter: jt("list-filter", 60291),
		listFlat: jt("list-flat", 60292),
		listSelection: jt("list-selection", 60293),
		selection: jt("selection", 60293),
		listTree: jt("list-tree", 60294),
		debugBreakpointFunctionUnverified: jt("debug-breakpoint-function-unverified", 60295),
		debugBreakpointFunction: jt("debug-breakpoint-function", 60296),
		debugBreakpointFunctionDisabled: jt("debug-breakpoint-function-disabled", 60296),
		debugStackframeActive: jt("debug-stackframe-active", 60297),
		circleSmallFilled: jt("circle-small-filled", 60298),
		debugStackframeDot: jt("debug-stackframe-dot", 60298),
		terminalDecorationMark: jt("terminal-decoration-mark", 60298),
		debugStackframe: jt("debug-stackframe", 60299),
		debugStackframeFocused: jt("debug-stackframe-focused", 60299),
		debugBreakpointUnsupported: jt("debug-breakpoint-unsupported", 60300),
		symbolString: jt("symbol-string", 60301),
		debugReverseContinue: jt("debug-reverse-continue", 60302),
		debugStepBack: jt("debug-step-back", 60303),
		debugRestartFrame: jt("debug-restart-frame", 60304),
		debugAlt: jt("debug-alt", 60305),
		callIncoming: jt("call-incoming", 60306),
		callOutgoing: jt("call-outgoing", 60307),
		menu: jt("menu", 60308),
		expandAll: jt("expand-all", 60309),
		feedback: jt("feedback", 60310),
		gitPullRequestReviewer: jt("git-pull-request-reviewer", 60310),
		groupByRefType: jt("group-by-ref-type", 60311),
		ungroupByRefType: jt("ungroup-by-ref-type", 60312),
		account: jt("account", 60313),
		gitPullRequestAssignee: jt("git-pull-request-assignee", 60313),
		bellDot: jt("bell-dot", 60314),
		debugConsole: jt("debug-console", 60315),
		library: jt("library", 60316),
		output: jt("output", 60317),
		runAll: jt("run-all", 60318),
		syncIgnored: jt("sync-ignored", 60319),
		pinned: jt("pinned", 60320),
		githubInverted: jt("github-inverted", 60321),
		serverProcess: jt("server-process", 60322),
		serverEnvironment: jt("server-environment", 60323),
		pass: jt("pass", 60324),
		issueClosed: jt("issue-closed", 60324),
		stopCircle: jt("stop-circle", 60325),
		playCircle: jt("play-circle", 60326),
		record: jt("record", 60327),
		debugAltSmall: jt("debug-alt-small", 60328),
		vmConnect: jt("vm-connect", 60329),
		cloud: jt("cloud", 60330),
		merge: jt("merge", 60331),
		export: jt("export", 60332),
		graphLeft: jt("graph-left", 60333),
		magnet: jt("magnet", 60334),
		notebook: jt("notebook", 60335),
		redo: jt("redo", 60336),
		checkAll: jt("check-all", 60337),
		pinnedDirty: jt("pinned-dirty", 60338),
		passFilled: jt("pass-filled", 60339),
		circleLargeFilled: jt("circle-large-filled", 60340),
		circleLarge: jt("circle-large", 60341),
		circleLargeOutline: jt("circle-large-outline", 60341),
		combine: jt("combine", 60342),
		gather: jt("gather", 60342),
		table: jt("table", 60343),
		variableGroup: jt("variable-group", 60344),
		typeHierarchy: jt("type-hierarchy", 60345),
		typeHierarchySub: jt("type-hierarchy-sub", 60346),
		typeHierarchySuper: jt("type-hierarchy-super", 60347),
		gitPullRequestCreate: jt("git-pull-request-create", 60348),
		runAbove: jt("run-above", 60349),
		runBelow: jt("run-below", 60350),
		notebookTemplate: jt("notebook-template", 60351),
		debugRerun: jt("debug-rerun", 60352),
		workspaceTrusted: jt("workspace-trusted", 60353),
		workspaceUntrusted: jt("workspace-untrusted", 60354),
		workspaceUnknown: jt("workspace-unknown", 60355),
		terminalCmd: jt("terminal-cmd", 60356),
		terminalDebian: jt("terminal-debian", 60357),
		terminalLinux: jt("terminal-linux", 60358),
		terminalPowershell: jt("terminal-powershell", 60359),
		terminalTmux: jt("terminal-tmux", 60360),
		terminalUbuntu: jt("terminal-ubuntu", 60361),
		terminalBash: jt("terminal-bash", 60362),
		arrowSwap: jt("arrow-swap", 60363),
		copy: jt("copy", 60364),
		personAdd: jt("person-add", 60365),
		filterFilled: jt("filter-filled", 60366),
		wand: jt("wand", 60367),
		debugLineByLine: jt("debug-line-by-line", 60368),
		inspect: jt("inspect", 60369),
		layers: jt("layers", 60370),
		layersDot: jt("layers-dot", 60371),
		layersActive: jt("layers-active", 60372),
		compass: jt("compass", 60373),
		compassDot: jt("compass-dot", 60374),
		compassActive: jt("compass-active", 60375),
		azure: jt("azure", 60376),
		issueDraft: jt("issue-draft", 60377),
		gitPullRequestClosed: jt("git-pull-request-closed", 60378),
		gitPullRequestDraft: jt("git-pull-request-draft", 60379),
		debugAll: jt("debug-all", 60380),
		debugCoverage: jt("debug-coverage", 60381),
		runErrors: jt("run-errors", 60382),
		folderLibrary: jt("folder-library", 60383),
		debugContinueSmall: jt("debug-continue-small", 60384),
		beakerStop: jt("beaker-stop", 60385),
		graphLine: jt("graph-line", 60386),
		graphScatter: jt("graph-scatter", 60387),
		pieChart: jt("pie-chart", 60388),
		bracket: jt("bracket", 60175),
		bracketDot: jt("bracket-dot", 60389),
		bracketError: jt("bracket-error", 60390),
		lockSmall: jt("lock-small", 60391),
		azureDevops: jt("azure-devops", 60392),
		verifiedFilled: jt("verified-filled", 60393),
		newline: jt("newline", 60394),
		layout: jt("layout", 60395),
		layoutActivitybarLeft: jt("layout-activitybar-left", 60396),
		layoutActivitybarRight: jt("layout-activitybar-right", 60397),
		layoutPanelLeft: jt("layout-panel-left", 60398),
		layoutPanelCenter: jt("layout-panel-center", 60399),
		layoutPanelJustify: jt("layout-panel-justify", 60400),
		layoutPanelRight: jt("layout-panel-right", 60401),
		layoutPanel: jt("layout-panel", 60402),
		layoutSidebarLeft: jt("layout-sidebar-left", 60403),
		layoutSidebarRight: jt("layout-sidebar-right", 60404),
		layoutStatusbar: jt("layout-statusbar", 60405),
		layoutMenubar: jt("layout-menubar", 60406),
		layoutCentered: jt("layout-centered", 60407),
		target: jt("target", 60408),
		indent: jt("indent", 60409),
		recordSmall: jt("record-small", 60410),
		errorSmall: jt("error-small", 60411),
		terminalDecorationError: jt("terminal-decoration-error", 60411),
		arrowCircleDown: jt("arrow-circle-down", 60412),
		arrowCircleLeft: jt("arrow-circle-left", 60413),
		arrowCircleRight: jt("arrow-circle-right", 60414),
		arrowCircleUp: jt("arrow-circle-up", 60415),
		layoutSidebarRightOff: jt("layout-sidebar-right-off", 60416),
		layoutPanelOff: jt("layout-panel-off", 60417),
		layoutSidebarLeftOff: jt("layout-sidebar-left-off", 60418),
		blank: jt("blank", 60419),
		heartFilled: jt("heart-filled", 60420),
		map: jt("map", 60421),
		mapHorizontal: jt("map-horizontal", 60421),
		foldHorizontal: jt("fold-horizontal", 60421),
		mapFilled: jt("map-filled", 60422),
		mapHorizontalFilled: jt("map-horizontal-filled", 60422),
		foldHorizontalFilled: jt("fold-horizontal-filled", 60422),
		circleSmall: jt("circle-small", 60423),
		bellSlash: jt("bell-slash", 60424),
		bellSlashDot: jt("bell-slash-dot", 60425),
		commentUnresolved: jt("comment-unresolved", 60426),
		gitPullRequestGoToChanges: jt("git-pull-request-go-to-changes", 60427),
		gitPullRequestNewChanges: jt("git-pull-request-new-changes", 60428),
		searchFuzzy: jt("search-fuzzy", 60429),
		commentDraft: jt("comment-draft", 60430),
		send: jt("send", 60431),
		sparkle: jt("sparkle", 60432),
		insert: jt("insert", 60433),
		mic: jt("mic", 60434),
		thumbsdownFilled: jt("thumbsdown-filled", 60435),
		thumbsupFilled: jt("thumbsup-filled", 60436),
		coffee: jt("coffee", 60437),
		snake: jt("snake", 60438),
		game: jt("game", 60439),
		vr: jt("vr", 60440),
		chip: jt("chip", 60441),
		piano: jt("piano", 60442),
		music: jt("music", 60443),
		micFilled: jt("mic-filled", 60444),
		repoFetch: jt("repo-fetch", 60445),
		copilot: jt("copilot", 60446),
		lightbulbSparkle: jt("lightbulb-sparkle", 60447),
		robot: jt("robot", 60448),
		sparkleFilled: jt("sparkle-filled", 60449),
		diffSingle: jt("diff-single", 60450),
		diffMultiple: jt("diff-multiple", 60451),
		surroundWith: jt("surround-with", 60452),
		share: jt("share", 60453),
		gitStash: jt("git-stash", 60454),
		gitStashApply: jt("git-stash-apply", 60455),
		gitStashPop: jt("git-stash-pop", 60456),
		vscode: jt("vscode", 60457),
		vscodeInsiders: jt("vscode-insiders", 60458),
		codeOss: jt("code-oss", 60459),
		runCoverage: jt("run-coverage", 60460),
		runAllCoverage: jt("run-all-coverage", 60461),
		coverage: jt("coverage", 60462),
		githubProject: jt("github-project", 60463),
		mapVertical: jt("map-vertical", 60464),
		foldVertical: jt("fold-vertical", 60464),
		mapVerticalFilled: jt("map-vertical-filled", 60465),
		foldVerticalFilled: jt("fold-vertical-filled", 60465),
		goToSearch: jt("go-to-search", 60466),
		percentage: jt("percentage", 60467),
		sortPercentage: jt("sort-percentage", 60467),
		attach: jt("attach", 60468),
		goToEditingSession: jt("go-to-editing-session", 60469),
		editSession: jt("edit-session", 60470),
		codeReview: jt("code-review", 60471),
		copilotWarning: jt("copilot-warning", 60472),
		python: jt("python", 60473),
		copilotLarge: jt("copilot-large", 60474),
		copilotWarningLarge: jt("copilot-warning-large", 60475),
		keyboardTab: jt("keyboard-tab", 60476),
		copilotBlocked: jt("copilot-blocked", 60477),
		copilotNotConnected: jt("copilot-not-connected", 60478),
		flag: jt("flag", 60479),
		lightbulbEmpty: jt("lightbulb-empty", 60480),
		symbolMethodArrow: jt("symbol-method-arrow", 60481),
		copilotUnavailable: jt("copilot-unavailable", 60482),
		repoPinned: jt("repo-pinned", 60483),
		keyboardTabAbove: jt("keyboard-tab-above", 60484),
		keyboardTabBelow: jt("keyboard-tab-below", 60485),
		gitPullRequestDone: jt("git-pull-request-done", 60486),
		mcp: jt("mcp", 60487),
		extensionsLarge: jt("extensions-large", 60488),
		layoutPanelDock: jt("layout-panel-dock", 60489),
		layoutSidebarLeftDock: jt("layout-sidebar-left-dock", 60490),
		layoutSidebarRightDock: jt("layout-sidebar-right-dock", 60491),
		copilotInProgress: jt("copilot-in-progress", 60492),
		copilotError: jt("copilot-error", 60493),
		copilotSuccess: jt("copilot-success", 60494),
		chatSparkle: jt("chat-sparkle", 60495),
		searchSparkle: jt("search-sparkle", 60496),
		editSparkle: jt("edit-sparkle", 60497),
		copilotSnooze: jt("copilot-snooze", 60498),
		sendToRemoteAgent: jt("send-to-remote-agent", 60499),
		commentDiscussionSparkle: jt("comment-discussion-sparkle", 60500),
		chatSparkleWarning: jt("chat-sparkle-warning", 60501),
		chatSparkleError: jt("chat-sparkle-error", 60502),
		collection: jt("collection", 60503),
		newCollection: jt("new-collection", 60504),
		thinking: jt("thinking", 60505),
		build: jt("build", 60506),
		commentDiscussionQuote: jt("comment-discussion-quote", 60507),
		cursor: jt("cursor", 60508),
		eraser: jt("eraser", 60509),
		fileText: jt("file-text", 60510),
		gitLens: jt("git-lens", 60511),
		quotes: jt("quotes", 60512),
		rename: jt("rename", 60513),
		runWithDeps: jt("run-with-deps", 60514),
		debugConnected: jt("debug-connected", 60515),
		strikethrough: jt("strikethrough", 60516),
		openInProduct: jt("open-in-product", 60517),
		indexZero: jt("index-zero", 60518),
		agent: jt("agent", 60519),
		editCode: jt("edit-code", 60520),
		repoSelected: jt("repo-selected", 60521),
		skip: jt("skip", 60522),
		mergeInto: jt("merge-into", 60523),
		gitBranchChanges: jt("git-branch-changes", 60524),
		gitBranchStagedChanges: jt("git-branch-staged-changes", 60525),
		gitBranchConflicts: jt("git-branch-conflicts", 60526),
		gitBranch: jt("git-branch", 60527),
		gitBranchCreate: jt("git-branch-create", 60527),
		gitBranchDelete: jt("git-branch-delete", 60527),
		searchLarge: jt("search-large", 60528),
		terminalGitBash: jt("terminal-git-bash", 60529),
		dialogError: jt("dialog-error", "error"),
		dialogWarning: jt("dialog-warning", "warning"),
		dialogInfo: jt("dialog-info", "info"),
		dialogClose: jt("dialog-close", "close"),
		treeItemExpanded: jt("tree-item-expanded", "chevron-down"),
		treeFilterOnTypeOn: jt("tree-filter-on-type-on", "list-filter"),
		treeFilterOnTypeOff: jt("tree-filter-on-type-off", "list-selection"),
		treeFilterClear: jt("tree-filter-clear", "close"),
		treeItemLoading: jt("tree-item-loading", "loading"),
		menuSelection: jt("menu-selection", "check"),
		menuSubmenu: jt("menu-submenu", "chevron-right"),
		menuBarMore: jt("menubar-more", "more"),
		scrollbarButtonLeft: jt("scrollbar-button-left", "triangle-left"),
		scrollbarButtonRight: jt("scrollbar-button-right", "triangle-right"),
		scrollbarButtonUp: jt("scrollbar-button-up", "triangle-up"),
		scrollbarButtonDown: jt("scrollbar-button-down", "triangle-down"),
		toolBarMore: jt("toolbar-more", "more"),
		quickInputBack: jt("quick-input-back", "arrow-left"),
		dropDownButton: jt("drop-down-button", 60084),
		symbolCustomColor: jt("symbol-customcolor", 60252),
		exportIcon: jt("export", 60332),
		workspaceUnspecified: jt("workspace-unspecified", 60355),
		newLine: jt("newline", 60394),
		thumbsDownFilled: jt("thumbsdown-filled", 60435),
		thumbsUpFilled: jt("thumbsup-filled", 60436),
		gitFetch: jt("git-fetch", 60445),
		lightbulbSparkleAutofix: jt("lightbulb-sparkle-autofix", 60447),
		debugBreakpointPending: jt("debug-breakpoint-pending", 60377)
	};
	var $t, Xt, Jt, Yt, Qt, Zt, en, tn, nn = class extends g {
		get isResolved() {
			return this._isResolved;
		}
		constructor(e, t, n) {
			super(), this._registry = e, this._languageId = t, this._factory = n, this._isDisposed = !1, this._resolvePromise = null, this._isResolved = !1;
		}
		dispose() {
			this._isDisposed = !0, super.dispose();
		}
		async resolve() {
			return this._resolvePromise || (this._resolvePromise = this._create()), this._resolvePromise;
		}
		async _create() {
			const e = await this._factory.tokenizationSupport;
			this._isResolved = !0, e && !this._isDisposed && this._register(this._registry.register(this._languageId, e));
		}
	}, rn = class {
		constructor(e, t, n) {
			this.offset = e, this.type = t, this.language = n, this._tokenBrand = void 0;
		}
		toString() {
			return "(" + this.offset + ", " + this.type + ")";
		}
	};
	(function(e) {
		e[e.Increase = 0] = "Increase", e[e.Decrease = 1] = "Decrease";
	})($t || ($t = {})), function(e) {
		const t = /* @__PURE__ */ new Map();
		t.set(0, Gt.symbolMethod), t.set(1, Gt.symbolFunction), t.set(2, Gt.symbolConstructor), t.set(3, Gt.symbolField), t.set(4, Gt.symbolVariable), t.set(5, Gt.symbolClass), t.set(6, Gt.symbolStruct), t.set(7, Gt.symbolInterface), t.set(8, Gt.symbolModule), t.set(9, Gt.symbolProperty), t.set(10, Gt.symbolEvent), t.set(11, Gt.symbolOperator), t.set(12, Gt.symbolUnit), t.set(13, Gt.symbolValue), t.set(15, Gt.symbolEnum), t.set(14, Gt.symbolConstant), t.set(15, Gt.symbolEnum), t.set(16, Gt.symbolEnumMember), t.set(17, Gt.symbolKeyword), t.set(28, Gt.symbolSnippet), t.set(18, Gt.symbolText), t.set(19, Gt.symbolColor), t.set(20, Gt.symbolFile), t.set(21, Gt.symbolReference), t.set(22, Gt.symbolCustomColor), t.set(23, Gt.symbolFolder), t.set(24, Gt.symbolTypeParameter), t.set(25, Gt.account), t.set(26, Gt.issues), t.set(27, Gt.tools), e.toIcon = function(e) {
			let n = t.get(e);
			return n || (n = Gt.symbolProperty), n;
		}, e.toLabel = function(e) {
			switch (e) {
				case 0: return N(728, "Method");
				case 1: return N(729, "Function");
				case 2: return N(730, "Constructor");
				case 3: return N(731, "Field");
				case 4: return N(732, "Variable");
				case 5: return N(733, "Class");
				case 6: return N(734, "Struct");
				case 7: return N(735, "Interface");
				case 8: return N(736, "Module");
				case 9: return N(737, "Property");
				case 10: return N(738, "Event");
				case 11: return N(739, "Operator");
				case 12: return N(740, "Unit");
				case 13: return N(741, "Value");
				case 14: return N(742, "Constant");
				case 15: return N(743, "Enum");
				case 16: return N(744, "Enum Member");
				case 17: return N(745, "Keyword");
				case 18: return N(746, "Text");
				case 19: return N(747, "Color");
				case 20: return N(748, "File");
				case 21: return N(749, "Reference");
				case 22: return N(750, "Custom Color");
				case 23: return N(751, "Folder");
				case 24: return N(752, "Type Parameter");
				case 25: return N(753, "User");
				case 26: return N(754, "Issue");
				case 27: return N(755, "Tool");
				case 28: return N(756, "Snippet");
				default: return "";
			}
		};
		const n = /* @__PURE__ */ new Map();
		n.set("method", 0), n.set("function", 1), n.set("constructor", 2), n.set("field", 3), n.set("variable", 4), n.set("class", 5), n.set("struct", 6), n.set("interface", 7), n.set("module", 8), n.set("property", 9), n.set("event", 10), n.set("operator", 11), n.set("unit", 12), n.set("value", 13), n.set("constant", 14), n.set("enum", 15), n.set("enum-member", 16), n.set("enumMember", 16), n.set("keyword", 17), n.set("snippet", 28), n.set("text", 18), n.set("color", 19), n.set("file", 20), n.set("reference", 21), n.set("customcolor", 22), n.set("folder", 23), n.set("type-parameter", 24), n.set("typeParameter", 24), n.set("account", 25), n.set("issue", 26), n.set("tool", 27), e.fromString = function(e, t) {
			let i = n.get(e);
			return void 0 !== i || t || (i = 9), i;
		};
	}(Xt || (Xt = {})), function(e) {
		e[e.Automatic = 0] = "Automatic", e[e.Explicit = 1] = "Explicit";
	}(Jt || (Jt = {})), function(e) {
		e[e.Code = 1] = "Code", e[e.Label = 2] = "Label";
	}(Yt || (Yt = {})), function(e) {
		e[e.Accepted = 0] = "Accepted", e[e.Rejected = 1] = "Rejected", e[e.Ignored = 2] = "Ignored";
	}(Qt || (Qt = {})), function(e) {
		e[e.Automatic = 0] = "Automatic", e[e.PasteAs = 1] = "PasteAs";
	}(Zt || (Zt = {})), function(e) {
		e[e.Invoke = 1] = "Invoke", e[e.TriggerCharacter = 2] = "TriggerCharacter", e[e.ContentChange = 3] = "ContentChange";
	}(en || (en = {})), function(e) {
		e[e.Text = 0] = "Text", e[e.Read = 1] = "Read", e[e.Write = 2] = "Write";
	}(tn || (tn = {}));
	N(757, "array"), N(758, "boolean"), N(759, "class"), N(760, "constant"), N(761, "constructor"), N(762, "enumeration"), N(763, "enumeration member"), N(764, "event"), N(765, "field"), N(766, "file"), N(767, "function"), N(768, "interface"), N(769, "key"), N(770, "method"), N(771, "module"), N(772, "namespace"), N(773, "null"), N(774, "number"), N(775, "object"), N(776, "operator"), N(777, "package"), N(778, "property"), N(779, "string"), N(780, "struct"), N(781, "type parameter"), N(782, "variable");
	var an;
	(function(e) {
		const t = /* @__PURE__ */ new Map();
		t.set(0, Gt.symbolFile), t.set(1, Gt.symbolModule), t.set(2, Gt.symbolNamespace), t.set(3, Gt.symbolPackage), t.set(4, Gt.symbolClass), t.set(5, Gt.symbolMethod), t.set(6, Gt.symbolProperty), t.set(7, Gt.symbolField), t.set(8, Gt.symbolConstructor), t.set(9, Gt.symbolEnum), t.set(10, Gt.symbolInterface), t.set(11, Gt.symbolFunction), t.set(12, Gt.symbolVariable), t.set(13, Gt.symbolConstant), t.set(14, Gt.symbolString), t.set(15, Gt.symbolNumber), t.set(16, Gt.symbolBoolean), t.set(17, Gt.symbolArray), t.set(18, Gt.symbolObject), t.set(19, Gt.symbolKey), t.set(20, Gt.symbolNull), t.set(21, Gt.symbolEnumMember), t.set(22, Gt.symbolStruct), t.set(23, Gt.symbolEvent), t.set(24, Gt.symbolOperator), t.set(25, Gt.symbolTypeParameter), e.toIcon = function(e) {
			let n = t.get(e);
			return n || (n = Gt.symbolProperty), n;
		};
		const n = /* @__PURE__ */ new Map();
		n.set(0, 20), n.set(1, 8), n.set(2, 8), n.set(3, 8), n.set(4, 5), n.set(5, 0), n.set(6, 9), n.set(7, 3), n.set(8, 2), n.set(9, 15), n.set(10, 7), n.set(11, 1), n.set(12, 4), n.set(13, 14), n.set(14, 18), n.set(15, 13), n.set(16, 13), n.set(17, 13), n.set(18, 13), n.set(19, 17), n.set(20, 13), n.set(21, 16), n.set(22, 6), n.set(23, 10), n.set(24, 11), n.set(25, 24), e.toCompletionKind = function(e) {
			let t = n.get(e);
			return void 0 === t && (t = 20), t;
		};
	})(an || (an = {}));
	var on, sn, ln, cn;
	(class e {
		static {
			this.Comment = new e("comment");
		}
		static {
			this.Imports = new e("imports");
		}
		static {
			this.Region = new e("region");
		}
		static fromValue(t) {
			switch (t) {
				case "comment": return e.Comment;
				case "imports": return e.Imports;
				case "region": return e.Region;
			}
			return new e(t);
		}
		constructor(e) {
			this.value = e;
		}
	});
	(function(e) {
		e[e.AIGenerated = 1] = "AIGenerated";
	})(on || (on = {})), function(e) {
		e[e.Invoke = 0] = "Invoke", e[e.Automatic = 1] = "Automatic";
	}(sn || (sn = {})), function(e) {
		e.is = function(e) {
			return !(!e || "object" != typeof e) && "string" == typeof e.id && "string" == typeof e.title;
		};
	}(ln || (ln = {})), function(e) {
		e[e.Type = 1] = "Type", e[e.Parameter = 2] = "Parameter";
	}(cn || (cn = {}));
	new class {
		constructor() {
			this._tokenizationSupports = /* @__PURE__ */ new Map(), this._factories = /* @__PURE__ */ new Map(), this._onDidChange = new C(), this.onDidChange = this._onDidChange.event, this._colorMap = null;
		}
		handleChange(e) {
			this._onDidChange.fire({
				changedLanguages: e,
				changedColorMap: !1
			});
		}
		register(e, t) {
			return this._tokenizationSupports.set(e, t), this.handleChange([e]), m(() => {
				this._tokenizationSupports.get(e) === t && (this._tokenizationSupports.delete(e), this.handleChange([e]));
			});
		}
		get(e) {
			return this._tokenizationSupports.get(e) || null;
		}
		registerFactory(e, t) {
			this._factories.get(e)?.dispose();
			const n = new nn(this, e, t);
			return this._factories.set(e, n), m(() => {
				const t = this._factories.get(e);
				t && t === n && (this._factories.delete(e), t.dispose());
			});
		}
		async getOrCreate(e) {
			const t = this.get(e);
			if (t) return t;
			const n = this._factories.get(e);
			return !n || n.isResolved ? null : (await n.resolve(), this.get(e));
		}
		isResolved(e) {
			if (this.get(e)) return !0;
			const t = this._factories.get(e);
			return !(t && !t.isResolved);
		}
		setColorMap(e) {
			this._colorMap = e, this._onDidChange.fire({
				changedLanguages: Array.from(this._tokenizationSupports.keys()),
				changedColorMap: !0
			});
		}
		getColorMap() {
			return this._colorMap;
		}
		getDefaultBackground() {
			return this._colorMap && this._colorMap.length > 2 ? this._colorMap[2] : null;
		}
	}();
	var hn, dn, un, mn, pn, gn, fn, bn, _n, wn, vn, yn, Tn, kn, Sn, Ln, xn, Cn, En, An, Rn, Mn, Nn, In, zn, On, Un, Hn, Dn, Wn, Pn, qn, Fn, Vn, Bn, Kn, jn, Gn, $n, Xn, Jn, Yn, Qn, Zn, ei, ti, ni, ii;
	(function(e) {
		e[e.Unknown = 0] = "Unknown", e[e.Disabled = 1] = "Disabled", e[e.Enabled = 2] = "Enabled";
	})(hn || (hn = {})), function(e) {
		e[e.Invoke = 1] = "Invoke", e[e.Auto = 2] = "Auto";
	}(dn || (dn = {})), function(e) {
		e[e.None = 0] = "None", e[e.KeepWhitespace = 1] = "KeepWhitespace", e[e.InsertAsSnippet = 4] = "InsertAsSnippet";
	}(un || (un = {})), function(e) {
		e[e.Method = 0] = "Method", e[e.Function = 1] = "Function", e[e.Constructor = 2] = "Constructor", e[e.Field = 3] = "Field", e[e.Variable = 4] = "Variable", e[e.Class = 5] = "Class", e[e.Struct = 6] = "Struct", e[e.Interface = 7] = "Interface", e[e.Module = 8] = "Module", e[e.Property = 9] = "Property", e[e.Event = 10] = "Event", e[e.Operator = 11] = "Operator", e[e.Unit = 12] = "Unit", e[e.Value = 13] = "Value", e[e.Constant = 14] = "Constant", e[e.Enum = 15] = "Enum", e[e.EnumMember = 16] = "EnumMember", e[e.Keyword = 17] = "Keyword", e[e.Text = 18] = "Text", e[e.Color = 19] = "Color", e[e.File = 20] = "File", e[e.Reference = 21] = "Reference", e[e.Customcolor = 22] = "Customcolor", e[e.Folder = 23] = "Folder", e[e.TypeParameter = 24] = "TypeParameter", e[e.User = 25] = "User", e[e.Issue = 26] = "Issue", e[e.Tool = 27] = "Tool", e[e.Snippet = 28] = "Snippet";
	}(mn || (mn = {})), function(e) {
		e[e.Deprecated = 1] = "Deprecated";
	}(pn || (pn = {})), function(e) {
		e[e.Invoke = 0] = "Invoke", e[e.TriggerCharacter = 1] = "TriggerCharacter", e[e.TriggerForIncompleteCompletions = 2] = "TriggerForIncompleteCompletions";
	}(gn || (gn = {})), function(e) {
		e[e.EXACT = 0] = "EXACT", e[e.ABOVE = 1] = "ABOVE", e[e.BELOW = 2] = "BELOW";
	}(fn || (fn = {})), function(e) {
		e[e.NotSet = 0] = "NotSet", e[e.ContentFlush = 1] = "ContentFlush", e[e.RecoverFromMarkers = 2] = "RecoverFromMarkers", e[e.Explicit = 3] = "Explicit", e[e.Paste = 4] = "Paste", e[e.Undo = 5] = "Undo", e[e.Redo = 6] = "Redo";
	}(bn || (bn = {})), function(e) {
		e[e.LF = 1] = "LF", e[e.CRLF = 2] = "CRLF";
	}(_n || (_n = {})), function(e) {
		e[e.Text = 0] = "Text", e[e.Read = 1] = "Read", e[e.Write = 2] = "Write";
	}(wn || (wn = {})), function(e) {
		e[e.None = 0] = "None", e[e.Keep = 1] = "Keep", e[e.Brackets = 2] = "Brackets", e[e.Advanced = 3] = "Advanced", e[e.Full = 4] = "Full";
	}(vn || (vn = {})), function(e) {
		e[e.acceptSuggestionOnCommitCharacter = 0] = "acceptSuggestionOnCommitCharacter", e[e.acceptSuggestionOnEnter = 1] = "acceptSuggestionOnEnter", e[e.accessibilitySupport = 2] = "accessibilitySupport", e[e.accessibilityPageSize = 3] = "accessibilityPageSize", e[e.allowOverflow = 4] = "allowOverflow", e[e.allowVariableLineHeights = 5] = "allowVariableLineHeights", e[e.allowVariableFonts = 6] = "allowVariableFonts", e[e.allowVariableFontsInAccessibilityMode = 7] = "allowVariableFontsInAccessibilityMode", e[e.ariaLabel = 8] = "ariaLabel", e[e.ariaRequired = 9] = "ariaRequired", e[e.autoClosingBrackets = 10] = "autoClosingBrackets", e[e.autoClosingComments = 11] = "autoClosingComments", e[e.screenReaderAnnounceInlineSuggestion = 12] = "screenReaderAnnounceInlineSuggestion", e[e.autoClosingDelete = 13] = "autoClosingDelete", e[e.autoClosingOvertype = 14] = "autoClosingOvertype", e[e.autoClosingQuotes = 15] = "autoClosingQuotes", e[e.autoIndent = 16] = "autoIndent", e[e.autoIndentOnPaste = 17] = "autoIndentOnPaste", e[e.autoIndentOnPasteWithinString = 18] = "autoIndentOnPasteWithinString", e[e.automaticLayout = 19] = "automaticLayout", e[e.autoSurround = 20] = "autoSurround", e[e.bracketPairColorization = 21] = "bracketPairColorization", e[e.guides = 22] = "guides", e[e.codeLens = 23] = "codeLens", e[e.codeLensFontFamily = 24] = "codeLensFontFamily", e[e.codeLensFontSize = 25] = "codeLensFontSize", e[e.colorDecorators = 26] = "colorDecorators", e[e.colorDecoratorsLimit = 27] = "colorDecoratorsLimit", e[e.columnSelection = 28] = "columnSelection", e[e.comments = 29] = "comments", e[e.contextmenu = 30] = "contextmenu", e[e.copyWithSyntaxHighlighting = 31] = "copyWithSyntaxHighlighting", e[e.cursorBlinking = 32] = "cursorBlinking", e[e.cursorSmoothCaretAnimation = 33] = "cursorSmoothCaretAnimation", e[e.cursorStyle = 34] = "cursorStyle", e[e.cursorSurroundingLines = 35] = "cursorSurroundingLines", e[e.cursorSurroundingLinesStyle = 36] = "cursorSurroundingLinesStyle", e[e.cursorWidth = 37] = "cursorWidth", e[e.cursorHeight = 38] = "cursorHeight", e[e.disableLayerHinting = 39] = "disableLayerHinting", e[e.disableMonospaceOptimizations = 40] = "disableMonospaceOptimizations", e[e.domReadOnly = 41] = "domReadOnly", e[e.dragAndDrop = 42] = "dragAndDrop", e[e.dropIntoEditor = 43] = "dropIntoEditor", e[e.editContext = 44] = "editContext", e[e.emptySelectionClipboard = 45] = "emptySelectionClipboard", e[e.experimentalGpuAcceleration = 46] = "experimentalGpuAcceleration", e[e.experimentalWhitespaceRendering = 47] = "experimentalWhitespaceRendering", e[e.extraEditorClassName = 48] = "extraEditorClassName", e[e.fastScrollSensitivity = 49] = "fastScrollSensitivity", e[e.find = 50] = "find", e[e.fixedOverflowWidgets = 51] = "fixedOverflowWidgets", e[e.folding = 52] = "folding", e[e.foldingStrategy = 53] = "foldingStrategy", e[e.foldingHighlight = 54] = "foldingHighlight", e[e.foldingImportsByDefault = 55] = "foldingImportsByDefault", e[e.foldingMaximumRegions = 56] = "foldingMaximumRegions", e[e.unfoldOnClickAfterEndOfLine = 57] = "unfoldOnClickAfterEndOfLine", e[e.fontFamily = 58] = "fontFamily", e[e.fontInfo = 59] = "fontInfo", e[e.fontLigatures = 60] = "fontLigatures", e[e.fontSize = 61] = "fontSize", e[e.fontWeight = 62] = "fontWeight", e[e.fontVariations = 63] = "fontVariations", e[e.formatOnPaste = 64] = "formatOnPaste", e[e.formatOnType = 65] = "formatOnType", e[e.glyphMargin = 66] = "glyphMargin", e[e.gotoLocation = 67] = "gotoLocation", e[e.hideCursorInOverviewRuler = 68] = "hideCursorInOverviewRuler", e[e.hover = 69] = "hover", e[e.inDiffEditor = 70] = "inDiffEditor", e[e.inlineSuggest = 71] = "inlineSuggest", e[e.letterSpacing = 72] = "letterSpacing", e[e.lightbulb = 73] = "lightbulb", e[e.lineDecorationsWidth = 74] = "lineDecorationsWidth", e[e.lineHeight = 75] = "lineHeight", e[e.lineNumbers = 76] = "lineNumbers", e[e.lineNumbersMinChars = 77] = "lineNumbersMinChars", e[e.linkedEditing = 78] = "linkedEditing", e[e.links = 79] = "links", e[e.matchBrackets = 80] = "matchBrackets", e[e.minimap = 81] = "minimap", e[e.mouseStyle = 82] = "mouseStyle", e[e.mouseWheelScrollSensitivity = 83] = "mouseWheelScrollSensitivity", e[e.mouseWheelZoom = 84] = "mouseWheelZoom", e[e.multiCursorMergeOverlapping = 85] = "multiCursorMergeOverlapping", e[e.multiCursorModifier = 86] = "multiCursorModifier", e[e.mouseMiddleClickAction = 87] = "mouseMiddleClickAction", e[e.multiCursorPaste = 88] = "multiCursorPaste", e[e.multiCursorLimit = 89] = "multiCursorLimit", e[e.occurrencesHighlight = 90] = "occurrencesHighlight", e[e.occurrencesHighlightDelay = 91] = "occurrencesHighlightDelay", e[e.overtypeCursorStyle = 92] = "overtypeCursorStyle", e[e.overtypeOnPaste = 93] = "overtypeOnPaste", e[e.overviewRulerBorder = 94] = "overviewRulerBorder", e[e.overviewRulerLanes = 95] = "overviewRulerLanes", e[e.padding = 96] = "padding", e[e.pasteAs = 97] = "pasteAs", e[e.parameterHints = 98] = "parameterHints", e[e.peekWidgetDefaultFocus = 99] = "peekWidgetDefaultFocus", e[e.placeholder = 100] = "placeholder", e[e.definitionLinkOpensInPeek = 101] = "definitionLinkOpensInPeek", e[e.quickSuggestions = 102] = "quickSuggestions", e[e.quickSuggestionsDelay = 103] = "quickSuggestionsDelay", e[e.readOnly = 104] = "readOnly", e[e.readOnlyMessage = 105] = "readOnlyMessage", e[e.renameOnType = 106] = "renameOnType", e[e.renderRichScreenReaderContent = 107] = "renderRichScreenReaderContent", e[e.renderControlCharacters = 108] = "renderControlCharacters", e[e.renderFinalNewline = 109] = "renderFinalNewline", e[e.renderLineHighlight = 110] = "renderLineHighlight", e[e.renderLineHighlightOnlyWhenFocus = 111] = "renderLineHighlightOnlyWhenFocus", e[e.renderValidationDecorations = 112] = "renderValidationDecorations", e[e.renderWhitespace = 113] = "renderWhitespace", e[e.revealHorizontalRightPadding = 114] = "revealHorizontalRightPadding", e[e.roundedSelection = 115] = "roundedSelection", e[e.rulers = 116] = "rulers", e[e.scrollbar = 117] = "scrollbar", e[e.scrollBeyondLastColumn = 118] = "scrollBeyondLastColumn", e[e.scrollBeyondLastLine = 119] = "scrollBeyondLastLine", e[e.scrollPredominantAxis = 120] = "scrollPredominantAxis", e[e.selectionClipboard = 121] = "selectionClipboard", e[e.selectionHighlight = 122] = "selectionHighlight", e[e.selectionHighlightMaxLength = 123] = "selectionHighlightMaxLength", e[e.selectionHighlightMultiline = 124] = "selectionHighlightMultiline", e[e.selectOnLineNumbers = 125] = "selectOnLineNumbers", e[e.showFoldingControls = 126] = "showFoldingControls", e[e.showUnused = 127] = "showUnused", e[e.snippetSuggestions = 128] = "snippetSuggestions", e[e.smartSelect = 129] = "smartSelect", e[e.smoothScrolling = 130] = "smoothScrolling", e[e.stickyScroll = 131] = "stickyScroll", e[e.stickyTabStops = 132] = "stickyTabStops", e[e.stopRenderingLineAfter = 133] = "stopRenderingLineAfter", e[e.suggest = 134] = "suggest", e[e.suggestFontSize = 135] = "suggestFontSize", e[e.suggestLineHeight = 136] = "suggestLineHeight", e[e.suggestOnTriggerCharacters = 137] = "suggestOnTriggerCharacters", e[e.suggestSelection = 138] = "suggestSelection", e[e.tabCompletion = 139] = "tabCompletion", e[e.tabIndex = 140] = "tabIndex", e[e.trimWhitespaceOnDelete = 141] = "trimWhitespaceOnDelete", e[e.unicodeHighlighting = 142] = "unicodeHighlighting", e[e.unusualLineTerminators = 143] = "unusualLineTerminators", e[e.useShadowDOM = 144] = "useShadowDOM", e[e.useTabStops = 145] = "useTabStops", e[e.wordBreak = 146] = "wordBreak", e[e.wordSegmenterLocales = 147] = "wordSegmenterLocales", e[e.wordSeparators = 148] = "wordSeparators", e[e.wordWrap = 149] = "wordWrap", e[e.wordWrapBreakAfterCharacters = 150] = "wordWrapBreakAfterCharacters", e[e.wordWrapBreakBeforeCharacters = 151] = "wordWrapBreakBeforeCharacters", e[e.wordWrapColumn = 152] = "wordWrapColumn", e[e.wordWrapOverride1 = 153] = "wordWrapOverride1", e[e.wordWrapOverride2 = 154] = "wordWrapOverride2", e[e.wrappingIndent = 155] = "wrappingIndent", e[e.wrappingStrategy = 156] = "wrappingStrategy", e[e.showDeprecated = 157] = "showDeprecated", e[e.inertialScroll = 158] = "inertialScroll", e[e.inlayHints = 159] = "inlayHints", e[e.wrapOnEscapedLineFeeds = 160] = "wrapOnEscapedLineFeeds", e[e.effectiveCursorStyle = 161] = "effectiveCursorStyle", e[e.editorClassName = 162] = "editorClassName", e[e.pixelRatio = 163] = "pixelRatio", e[e.tabFocusMode = 164] = "tabFocusMode", e[e.layoutInfo = 165] = "layoutInfo", e[e.wrappingInfo = 166] = "wrappingInfo", e[e.defaultColorDecorators = 167] = "defaultColorDecorators", e[e.colorDecoratorsActivatedOn = 168] = "colorDecoratorsActivatedOn", e[e.inlineCompletionsAccessibilityVerbose = 169] = "inlineCompletionsAccessibilityVerbose", e[e.effectiveEditContext = 170] = "effectiveEditContext", e[e.scrollOnMiddleClick = 171] = "scrollOnMiddleClick", e[e.effectiveAllowVariableFonts = 172] = "effectiveAllowVariableFonts";
	}(yn || (yn = {})), function(e) {
		e[e.TextDefined = 0] = "TextDefined", e[e.LF = 1] = "LF", e[e.CRLF = 2] = "CRLF";
	}(Tn || (Tn = {})), function(e) {
		e[e.LF = 0] = "LF", e[e.CRLF = 1] = "CRLF";
	}(kn || (kn = {})), function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 3] = "Right";
	}(Sn || (Sn = {})), function(e) {
		e[e.Increase = 0] = "Increase", e[e.Decrease = 1] = "Decrease";
	}(Ln || (Ln = {})), function(e) {
		e[e.None = 0] = "None", e[e.Indent = 1] = "Indent", e[e.IndentOutdent = 2] = "IndentOutdent", e[e.Outdent = 3] = "Outdent";
	}(xn || (xn = {})), function(e) {
		e[e.Both = 0] = "Both", e[e.Right = 1] = "Right", e[e.Left = 2] = "Left", e[e.None = 3] = "None";
	}(Cn || (Cn = {})), function(e) {
		e[e.Type = 1] = "Type", e[e.Parameter = 2] = "Parameter";
	}(En || (En = {})), function(e) {
		e[e.Accepted = 0] = "Accepted", e[e.Rejected = 1] = "Rejected", e[e.Ignored = 2] = "Ignored";
	}(An || (An = {})), function(e) {
		e[e.Code = 1] = "Code", e[e.Label = 2] = "Label";
	}(Rn || (Rn = {})), function(e) {
		e[e.Automatic = 0] = "Automatic", e[e.Explicit = 1] = "Explicit";
	}(Mn || (Mn = {})), function(e) {
		e[e.DependsOnKbLayout = -1] = "DependsOnKbLayout", e[e.Unknown = 0] = "Unknown", e[e.Backspace = 1] = "Backspace", e[e.Tab = 2] = "Tab", e[e.Enter = 3] = "Enter", e[e.Shift = 4] = "Shift", e[e.Ctrl = 5] = "Ctrl", e[e.Alt = 6] = "Alt", e[e.PauseBreak = 7] = "PauseBreak", e[e.CapsLock = 8] = "CapsLock", e[e.Escape = 9] = "Escape", e[e.Space = 10] = "Space", e[e.PageUp = 11] = "PageUp", e[e.PageDown = 12] = "PageDown", e[e.End = 13] = "End", e[e.Home = 14] = "Home", e[e.LeftArrow = 15] = "LeftArrow", e[e.UpArrow = 16] = "UpArrow", e[e.RightArrow = 17] = "RightArrow", e[e.DownArrow = 18] = "DownArrow", e[e.Insert = 19] = "Insert", e[e.Delete = 20] = "Delete", e[e.Digit0 = 21] = "Digit0", e[e.Digit1 = 22] = "Digit1", e[e.Digit2 = 23] = "Digit2", e[e.Digit3 = 24] = "Digit3", e[e.Digit4 = 25] = "Digit4", e[e.Digit5 = 26] = "Digit5", e[e.Digit6 = 27] = "Digit6", e[e.Digit7 = 28] = "Digit7", e[e.Digit8 = 29] = "Digit8", e[e.Digit9 = 30] = "Digit9", e[e.KeyA = 31] = "KeyA", e[e.KeyB = 32] = "KeyB", e[e.KeyC = 33] = "KeyC", e[e.KeyD = 34] = "KeyD", e[e.KeyE = 35] = "KeyE", e[e.KeyF = 36] = "KeyF", e[e.KeyG = 37] = "KeyG", e[e.KeyH = 38] = "KeyH", e[e.KeyI = 39] = "KeyI", e[e.KeyJ = 40] = "KeyJ", e[e.KeyK = 41] = "KeyK", e[e.KeyL = 42] = "KeyL", e[e.KeyM = 43] = "KeyM", e[e.KeyN = 44] = "KeyN", e[e.KeyO = 45] = "KeyO", e[e.KeyP = 46] = "KeyP", e[e.KeyQ = 47] = "KeyQ", e[e.KeyR = 48] = "KeyR", e[e.KeyS = 49] = "KeyS", e[e.KeyT = 50] = "KeyT", e[e.KeyU = 51] = "KeyU", e[e.KeyV = 52] = "KeyV", e[e.KeyW = 53] = "KeyW", e[e.KeyX = 54] = "KeyX", e[e.KeyY = 55] = "KeyY", e[e.KeyZ = 56] = "KeyZ", e[e.Meta = 57] = "Meta", e[e.ContextMenu = 58] = "ContextMenu", e[e.F1 = 59] = "F1", e[e.F2 = 60] = "F2", e[e.F3 = 61] = "F3", e[e.F4 = 62] = "F4", e[e.F5 = 63] = "F5", e[e.F6 = 64] = "F6", e[e.F7 = 65] = "F7", e[e.F8 = 66] = "F8", e[e.F9 = 67] = "F9", e[e.F10 = 68] = "F10", e[e.F11 = 69] = "F11", e[e.F12 = 70] = "F12", e[e.F13 = 71] = "F13", e[e.F14 = 72] = "F14", e[e.F15 = 73] = "F15", e[e.F16 = 74] = "F16", e[e.F17 = 75] = "F17", e[e.F18 = 76] = "F18", e[e.F19 = 77] = "F19", e[e.F20 = 78] = "F20", e[e.F21 = 79] = "F21", e[e.F22 = 80] = "F22", e[e.F23 = 81] = "F23", e[e.F24 = 82] = "F24", e[e.NumLock = 83] = "NumLock", e[e.ScrollLock = 84] = "ScrollLock", e[e.Semicolon = 85] = "Semicolon", e[e.Equal = 86] = "Equal", e[e.Comma = 87] = "Comma", e[e.Minus = 88] = "Minus", e[e.Period = 89] = "Period", e[e.Slash = 90] = "Slash", e[e.Backquote = 91] = "Backquote", e[e.BracketLeft = 92] = "BracketLeft", e[e.Backslash = 93] = "Backslash", e[e.BracketRight = 94] = "BracketRight", e[e.Quote = 95] = "Quote", e[e.OEM_8 = 96] = "OEM_8", e[e.IntlBackslash = 97] = "IntlBackslash", e[e.Numpad0 = 98] = "Numpad0", e[e.Numpad1 = 99] = "Numpad1", e[e.Numpad2 = 100] = "Numpad2", e[e.Numpad3 = 101] = "Numpad3", e[e.Numpad4 = 102] = "Numpad4", e[e.Numpad5 = 103] = "Numpad5", e[e.Numpad6 = 104] = "Numpad6", e[e.Numpad7 = 105] = "Numpad7", e[e.Numpad8 = 106] = "Numpad8", e[e.Numpad9 = 107] = "Numpad9", e[e.NumpadMultiply = 108] = "NumpadMultiply", e[e.NumpadAdd = 109] = "NumpadAdd", e[e.NUMPAD_SEPARATOR = 110] = "NUMPAD_SEPARATOR", e[e.NumpadSubtract = 111] = "NumpadSubtract", e[e.NumpadDecimal = 112] = "NumpadDecimal", e[e.NumpadDivide = 113] = "NumpadDivide", e[e.KEY_IN_COMPOSITION = 114] = "KEY_IN_COMPOSITION", e[e.ABNT_C1 = 115] = "ABNT_C1", e[e.ABNT_C2 = 116] = "ABNT_C2", e[e.AudioVolumeMute = 117] = "AudioVolumeMute", e[e.AudioVolumeUp = 118] = "AudioVolumeUp", e[e.AudioVolumeDown = 119] = "AudioVolumeDown", e[e.BrowserSearch = 120] = "BrowserSearch", e[e.BrowserHome = 121] = "BrowserHome", e[e.BrowserBack = 122] = "BrowserBack", e[e.BrowserForward = 123] = "BrowserForward", e[e.MediaTrackNext = 124] = "MediaTrackNext", e[e.MediaTrackPrevious = 125] = "MediaTrackPrevious", e[e.MediaStop = 126] = "MediaStop", e[e.MediaPlayPause = 127] = "MediaPlayPause", e[e.LaunchMediaPlayer = 128] = "LaunchMediaPlayer", e[e.LaunchMail = 129] = "LaunchMail", e[e.LaunchApp2 = 130] = "LaunchApp2", e[e.Clear = 131] = "Clear", e[e.MAX_VALUE = 132] = "MAX_VALUE";
	}(Nn || (Nn = {})), function(e) {
		e[e.Hint = 1] = "Hint", e[e.Info = 2] = "Info", e[e.Warning = 4] = "Warning", e[e.Error = 8] = "Error";
	}(In || (In = {})), function(e) {
		e[e.Unnecessary = 1] = "Unnecessary", e[e.Deprecated = 2] = "Deprecated";
	}(zn || (zn = {})), function(e) {
		e[e.Inline = 1] = "Inline", e[e.Gutter = 2] = "Gutter";
	}(On || (On = {})), function(e) {
		e[e.Normal = 1] = "Normal", e[e.Underlined = 2] = "Underlined";
	}(Un || (Un = {})), function(e) {
		e[e.UNKNOWN = 0] = "UNKNOWN", e[e.TEXTAREA = 1] = "TEXTAREA", e[e.GUTTER_GLYPH_MARGIN = 2] = "GUTTER_GLYPH_MARGIN", e[e.GUTTER_LINE_NUMBERS = 3] = "GUTTER_LINE_NUMBERS", e[e.GUTTER_LINE_DECORATIONS = 4] = "GUTTER_LINE_DECORATIONS", e[e.GUTTER_VIEW_ZONE = 5] = "GUTTER_VIEW_ZONE", e[e.CONTENT_TEXT = 6] = "CONTENT_TEXT", e[e.CONTENT_EMPTY = 7] = "CONTENT_EMPTY", e[e.CONTENT_VIEW_ZONE = 8] = "CONTENT_VIEW_ZONE", e[e.CONTENT_WIDGET = 9] = "CONTENT_WIDGET", e[e.OVERVIEW_RULER = 10] = "OVERVIEW_RULER", e[e.SCROLLBAR = 11] = "SCROLLBAR", e[e.OVERLAY_WIDGET = 12] = "OVERLAY_WIDGET", e[e.OUTSIDE_EDITOR = 13] = "OUTSIDE_EDITOR";
	}(Hn || (Hn = {})), function(e) {
		e[e.AIGenerated = 1] = "AIGenerated";
	}(Dn || (Dn = {})), function(e) {
		e[e.Invoke = 0] = "Invoke", e[e.Automatic = 1] = "Automatic";
	}(Wn || (Wn = {})), function(e) {
		e[e.TOP_RIGHT_CORNER = 0] = "TOP_RIGHT_CORNER", e[e.BOTTOM_RIGHT_CORNER = 1] = "BOTTOM_RIGHT_CORNER", e[e.TOP_CENTER = 2] = "TOP_CENTER";
	}(Pn || (Pn = {})), function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 4] = "Right", e[e.Full = 7] = "Full";
	}(qn || (qn = {})), function(e) {
		e[e.Word = 0] = "Word", e[e.Line = 1] = "Line", e[e.Suggest = 2] = "Suggest";
	}(Fn || (Fn = {})), function(e) {
		e[e.Left = 0] = "Left", e[e.Right = 1] = "Right", e[e.None = 2] = "None", e[e.LeftOfInjectedText = 3] = "LeftOfInjectedText", e[e.RightOfInjectedText = 4] = "RightOfInjectedText";
	}(Vn || (Vn = {})), function(e) {
		e[e.Off = 0] = "Off", e[e.On = 1] = "On", e[e.Relative = 2] = "Relative", e[e.Interval = 3] = "Interval", e[e.Custom = 4] = "Custom";
	}(Bn || (Bn = {})), function(e) {
		e[e.None = 0] = "None", e[e.Text = 1] = "Text", e[e.Blocks = 2] = "Blocks";
	}(Kn || (Kn = {})), function(e) {
		e[e.Smooth = 0] = "Smooth", e[e.Immediate = 1] = "Immediate";
	}(jn || (jn = {})), function(e) {
		e[e.Auto = 1] = "Auto", e[e.Hidden = 2] = "Hidden", e[e.Visible = 3] = "Visible";
	}(Gn || (Gn = {})), function(e) {
		e[e.LTR = 0] = "LTR", e[e.RTL = 1] = "RTL";
	}($n || ($n = {})), function(e) {
		e.Off = "off", e.OnCode = "onCode", e.On = "on";
	}(Xn || (Xn = {})), function(e) {
		e[e.Invoke = 1] = "Invoke", e[e.TriggerCharacter = 2] = "TriggerCharacter", e[e.ContentChange = 3] = "ContentChange";
	}(Jn || (Jn = {})), function(e) {
		e[e.File = 0] = "File", e[e.Module = 1] = "Module", e[e.Namespace = 2] = "Namespace", e[e.Package = 3] = "Package", e[e.Class = 4] = "Class", e[e.Method = 5] = "Method", e[e.Property = 6] = "Property", e[e.Field = 7] = "Field", e[e.Constructor = 8] = "Constructor", e[e.Enum = 9] = "Enum", e[e.Interface = 10] = "Interface", e[e.Function = 11] = "Function", e[e.Variable = 12] = "Variable", e[e.Constant = 13] = "Constant", e[e.String = 14] = "String", e[e.Number = 15] = "Number", e[e.Boolean = 16] = "Boolean", e[e.Array = 17] = "Array", e[e.Object = 18] = "Object", e[e.Key = 19] = "Key", e[e.Null = 20] = "Null", e[e.EnumMember = 21] = "EnumMember", e[e.Struct = 22] = "Struct", e[e.Event = 23] = "Event", e[e.Operator = 24] = "Operator", e[e.TypeParameter = 25] = "TypeParameter";
	}(Yn || (Yn = {})), function(e) {
		e[e.Deprecated = 1] = "Deprecated";
	}(Qn || (Qn = {})), function(e) {
		e[e.LTR = 0] = "LTR", e[e.RTL = 1] = "RTL";
	}(Zn || (Zn = {})), function(e) {
		e[e.Hidden = 0] = "Hidden", e[e.Blink = 1] = "Blink", e[e.Smooth = 2] = "Smooth", e[e.Phase = 3] = "Phase", e[e.Expand = 4] = "Expand", e[e.Solid = 5] = "Solid";
	}(ei || (ei = {})), function(e) {
		e[e.Line = 1] = "Line", e[e.Block = 2] = "Block", e[e.Underline = 3] = "Underline", e[e.LineThin = 4] = "LineThin", e[e.BlockOutline = 5] = "BlockOutline", e[e.UnderlineThin = 6] = "UnderlineThin";
	}(ti || (ti = {})), function(e) {
		e[e.AlwaysGrowsWhenTypingAtEdges = 0] = "AlwaysGrowsWhenTypingAtEdges", e[e.NeverGrowsWhenTypingAtEdges = 1] = "NeverGrowsWhenTypingAtEdges", e[e.GrowsOnlyWhenTypingBefore = 2] = "GrowsOnlyWhenTypingBefore", e[e.GrowsOnlyWhenTypingAfter = 3] = "GrowsOnlyWhenTypingAfter";
	}(ni || (ni = {})), function(e) {
		e[e.None = 0] = "None", e[e.Same = 1] = "Same", e[e.Indent = 2] = "Indent", e[e.DeepIndent = 3] = "DeepIndent";
	}(ii || (ii = {}));
	var ri, oi, si = class {
		static {
			this.CtrlCmd = 2048;
		}
		static {
			this.Shift = 1024;
		}
		static {
			this.Alt = 512;
		}
		static {
			this.WinCtrl = 256;
		}
		static chord(e, t) {
			return function(e, t) {
				return (e | (65535 & t) << 16 >>> 0) >>> 0;
			}(e, t);
		}
	};
	var li = class {
		constructor(e, t) {
			this.uri = e, this.value = t;
		}
	};
	(class e {
		static {
			this.defaultToKey = (e) => e.toString();
		}
		constructor(t, n) {
			if (this[ri] = "ResourceMap", t instanceof e) this.map = new Map(t.map), this.toKey = n ?? e.defaultToKey;
			else if (function(e) {
				return Array.isArray(e);
			}(t)) {
				this.map = /* @__PURE__ */ new Map(), this.toKey = n ?? e.defaultToKey;
				for (const [e, n] of t) this.set(e, n);
			} else this.map = /* @__PURE__ */ new Map(), this.toKey = t ?? e.defaultToKey;
		}
		set(e, t) {
			return this.map.set(this.toKey(e), new li(e, t)), this;
		}
		get(e) {
			return this.map.get(this.toKey(e))?.value;
		}
		has(e) {
			return this.map.has(this.toKey(e));
		}
		get size() {
			return this.map.size;
		}
		clear() {
			this.map.clear();
		}
		delete(e) {
			return this.map.delete(this.toKey(e));
		}
		forEach(e, t) {
			void 0 !== t && (e = e.bind(t));
			for (const [n, i] of this.map) e(i.value, i.uri, this);
		}
		*values() {
			for (const e of this.map.values()) yield e.value;
		}
		*keys() {
			for (const e of this.map.values()) yield e.uri;
		}
		*entries() {
			for (const e of this.map.values()) yield [e.uri, e.value];
		}
		*[(ri = Symbol.toStringTag, Symbol.iterator)]() {
			for (const [, e] of this.map) yield [e.uri, e.value];
		}
	});
	var hi = class {
		constructor() {
			this[oi] = "LinkedMap", this._map = /* @__PURE__ */ new Map(), this._head = void 0, this._tail = void 0, this._size = 0, this._state = 0;
		}
		clear() {
			this._map.clear(), this._head = void 0, this._tail = void 0, this._size = 0, this._state++;
		}
		isEmpty() {
			return !this._head && !this._tail;
		}
		get size() {
			return this._size;
		}
		get first() {
			return this._head?.value;
		}
		get last() {
			return this._tail?.value;
		}
		has(e) {
			return this._map.has(e);
		}
		get(e, t = 0) {
			const n = this._map.get(e);
			if (n) return 0 !== t && this.touch(n, t), n.value;
		}
		set(e, t, n = 0) {
			let i = this._map.get(e);
			if (i) i.value = t, 0 !== n && this.touch(i, n);
			else {
				switch (i = {
					key: e,
					value: t,
					next: void 0,
					previous: void 0
				}, n) {
					case 0:
					case 2:
					default:
						this.addItemLast(i);
						break;
					case 1: this.addItemFirst(i);
				}
				this._map.set(e, i), this._size++;
			}
			return this;
		}
		delete(e) {
			return !!this.remove(e);
		}
		remove(e) {
			const t = this._map.get(e);
			if (t) return this._map.delete(e), this.removeItem(t), this._size--, t.value;
		}
		shift() {
			if (!this._head && !this._tail) return;
			if (!this._head || !this._tail) throw new Error("Invalid list");
			const e = this._head;
			return this._map.delete(e.key), this.removeItem(e), this._size--, e.value;
		}
		forEach(e, t) {
			const n = this._state;
			let i = this._head;
			for (; i;) {
				if (t ? e.bind(t)(i.value, i.key, this) : e(i.value, i.key, this), this._state !== n) throw new Error("LinkedMap got modified during iteration.");
				i = i.next;
			}
		}
		keys() {
			const e = this, t = this._state;
			let n = this._head;
			const i = {
				[Symbol.iterator]: () => i,
				next() {
					if (e._state !== t) throw new Error("LinkedMap got modified during iteration.");
					if (n) {
						const e = {
							value: n.key,
							done: !1
						};
						return n = n.next, e;
					}
					return {
						value: void 0,
						done: !0
					};
				}
			};
			return i;
		}
		values() {
			const e = this, t = this._state;
			let n = this._head;
			const i = {
				[Symbol.iterator]: () => i,
				next() {
					if (e._state !== t) throw new Error("LinkedMap got modified during iteration.");
					if (n) {
						const e = {
							value: n.value,
							done: !1
						};
						return n = n.next, e;
					}
					return {
						value: void 0,
						done: !0
					};
				}
			};
			return i;
		}
		entries() {
			const e = this, t = this._state;
			let n = this._head;
			const i = {
				[Symbol.iterator]: () => i,
				next() {
					if (e._state !== t) throw new Error("LinkedMap got modified during iteration.");
					if (n) {
						const e = {
							value: [n.key, n.value],
							done: !1
						};
						return n = n.next, e;
					}
					return {
						value: void 0,
						done: !0
					};
				}
			};
			return i;
		}
		[(oi = Symbol.toStringTag, Symbol.iterator)]() {
			return this.entries();
		}
		trimOld(e) {
			if (e >= this.size) return;
			if (0 === e) return void this.clear();
			let t = this._head, n = this.size;
			for (; t && n > e;) this._map.delete(t.key), t = t.next, n--;
			this._head = t, this._size = n, t && (t.previous = void 0), this._state++;
		}
		trimNew(e) {
			if (e >= this.size) return;
			if (0 === e) return void this.clear();
			let t = this._tail, n = this.size;
			for (; t && n > e;) this._map.delete(t.key), t = t.previous, n--;
			this._tail = t, this._size = n, t && (t.next = void 0), this._state++;
		}
		addItemFirst(e) {
			if (this._head || this._tail) {
				if (!this._head) throw new Error("Invalid list");
				e.next = this._head, this._head.previous = e;
			} else this._tail = e;
			this._head = e, this._state++;
		}
		addItemLast(e) {
			if (this._head || this._tail) {
				if (!this._tail) throw new Error("Invalid list");
				e.previous = this._tail, this._tail.next = e;
			} else this._head = e;
			this._tail = e, this._state++;
		}
		removeItem(e) {
			if (e === this._head && e === this._tail) this._head = void 0, this._tail = void 0;
			else if (e === this._head) {
				if (!e.next) throw new Error("Invalid list");
				e.next.previous = void 0, this._head = e.next;
			} else if (e === this._tail) {
				if (!e.previous) throw new Error("Invalid list");
				e.previous.next = void 0, this._tail = e.previous;
			} else {
				const t = e.next, n = e.previous;
				if (!t || !n) throw new Error("Invalid list");
				t.previous = n, n.next = t;
			}
			e.next = void 0, e.previous = void 0, this._state++;
		}
		touch(e, t) {
			if (!this._head || !this._tail) throw new Error("Invalid list");
			if (1 === t || 2 === t) {
				if (1 === t) {
					if (e === this._head) return;
					const t = e.next, n = e.previous;
					e === this._tail ? (n.next = void 0, this._tail = n) : (t.previous = n, n.next = t), e.previous = void 0, e.next = this._head, this._head.previous = e, this._head = e, this._state++;
				} else if (2 === t) {
					if (e === this._tail) return;
					const t = e.next, n = e.previous;
					e === this._head ? (t.previous = void 0, this._head = t) : (t.previous = n, n.next = t), e.next = void 0, e.previous = this._tail, this._tail.next = e, this._tail = e, this._state++;
				}
			}
		}
		toJSON() {
			const e = [];
			return this.forEach((t, n) => {
				e.push([n, t]);
			}), e;
		}
		fromJSON(e) {
			this.clear();
			for (const [t, n] of e) this.set(t, n);
		}
	}, di = class extends hi {
		constructor(e, t = 1) {
			super(), this._limit = e, this._ratio = Math.min(Math.max(0, t), 1);
		}
		get limit() {
			return this._limit;
		}
		set limit(e) {
			this._limit = e, this.checkTrim();
		}
		get(e, t = 2) {
			return super.get(e, t);
		}
		peek(e) {
			return super.get(e, 0);
		}
		set(e, t) {
			return super.set(e, t, 2), this;
		}
		checkTrim() {
			this.size > this._limit && this.trim(Math.round(this._limit * this._ratio));
		}
	}, ui = class {
		constructor() {
			this.map = /* @__PURE__ */ new Map();
		}
		add(e, t) {
			let n = this.map.get(e);
			n || (n = /* @__PURE__ */ new Set(), this.map.set(e, n)), n.add(t);
		}
		delete(e, t) {
			const n = this.map.get(e);
			n && (n.delete(t), 0 === n.size && this.map.delete(e));
		}
		forEach(e, t) {
			const n = this.map.get(e);
			n && n.forEach(t);
		}
	};
	new class extends di {
		constructor(e, t = 1) {
			super(e, t);
		}
		trim(e) {
			this.trimOld(e);
		}
		set(e, t) {
			return super.set(e, t), this.checkTrim(), this;
		}
	}(10);
	var mi, pi, gi, fi;
	function bi(e, t, n, i, r) {
		return function(e, t, n, i, r) {
			if (0 === i) return !0;
			const a = t.charCodeAt(i - 1);
			if (0 !== e.get(a)) return !0;
			if (13 === a || 10 === a) return !0;
			if (r > 0) {
				const n = t.charCodeAt(i);
				if (0 !== e.get(n)) return !0;
			}
			return !1;
		}(e, t, 0, i, r) && function(e, t, n, i, r) {
			if (i + r === n) return !0;
			const a = t.charCodeAt(i + r);
			if (0 !== e.get(a)) return !0;
			if (13 === a || 10 === a) return !0;
			if (r > 0) {
				const n = t.charCodeAt(i + r - 1);
				if (0 !== e.get(n)) return !0;
			}
			return !1;
		}(e, t, n, i, r);
	}
	(function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 4] = "Right", e[e.Full = 7] = "Full";
	})(mi || (mi = {})), function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 3] = "Right";
	}(pi || (pi = {})), function(e) {
		e[e.LTR = 0] = "LTR", e[e.RTL = 1] = "RTL";
	}(gi || (gi = {})), function(e) {
		e[e.Both = 0] = "Both", e[e.Right = 1] = "Right", e[e.Left = 2] = "Left", e[e.None = 3] = "None";
	}(fi || (fi = {}));
	var _i = class {
		constructor(e, t) {
			this._wordSeparators = e, this._searchRegex = t, this._prevMatchStartIndex = -1, this._prevMatchLength = 0;
		}
		reset(e) {
			this._searchRegex.lastIndex = e, this._prevMatchStartIndex = -1, this._prevMatchLength = 0;
		}
		next(e) {
			const t = e.length;
			let n;
			do {
				if (this._prevMatchStartIndex + this._prevMatchLength === t) return null;
				if (n = this._searchRegex.exec(e), !n) return null;
				const i = n.index, r = n[0].length;
				if (i === this._prevMatchStartIndex && r === this._prevMatchLength) {
					if (0 === r) {
						oe(e, t, this._searchRegex.lastIndex) > 65535 ? this._searchRegex.lastIndex += 2 : this._searchRegex.lastIndex += 1;
						continue;
					}
					return null;
				}
				if (this._prevMatchStartIndex = i, this._prevMatchLength = r, !this._wordSeparators || bi(this._wordSeparators, e, t, i, r)) return n;
			} while (n);
			return null;
		}
	};
	const wi = function(e = "") {
		let t = "(-?\\d*\\.\\d\\w*)|([^";
		for (const n of "`~!@#$%^&*()-=+[{]}\\|;:'\",.<>/?") e.indexOf(n) >= 0 || (t += "\\" + n);
		return t += "\\s]+)", new RegExp(t, "g");
	}();
	function vi(e) {
		let t = wi;
		if (e && e instanceof RegExp) if (e.global) t = e;
		else {
			let n = "g";
			e.ignoreCase && (n += "i"), e.multiline && (n += "m"), e.unicode && (n += "u"), t = new RegExp(e.source, n);
		}
		return t.lastIndex = 0, t;
	}
	const yi = new b();
	function Ti(e, t, n, r, a) {
		if (t = vi(t), a || (a = i.first(yi)), n.length > a.maxLen) {
			let i = e - a.maxLen / 2;
			return i < 0 ? i = 0 : r += i, Ti(e, t, n = n.substring(i, e + a.maxLen / 2), r, a);
		}
		const o = Date.now(), s = e - 1 - r;
		let l = -1, c = null;
		for (let i = 1; !(Date.now() - o >= a.timeBudget); i++) {
			const e = s - a.windowSize * i;
			t.lastIndex = Math.max(0, e);
			const r = ki(t, n, s, l);
			if (!r && c) break;
			if (c = r, e <= 0) break;
			l = e;
		}
		if (c) {
			const e = {
				word: c[0],
				startColumn: r + 1 + c.index,
				endColumn: r + 1 + c.index + c[0].length
			};
			return t.lastIndex = 0, e;
		}
		return null;
	}
	function ki(e, t, n, i) {
		let r;
		for (; r = e.exec(t);) {
			const t = r.index || 0;
			if (t <= n && e.lastIndex >= n) return r;
			if (i > 0 && t > i) return null;
		}
		return null;
	}
	yi.unshift({
		maxLen: 1e3,
		windowSize: 15,
		timeBudget: 150
	});
	var Si = class {
		static computeUnicodeHighlights(e, t, n) {
			const i = n ? n.startLineNumber : 1, r = n ? n.endLineNumber : e.getLineCount(), a = new Li(t), o = a.getCandidateCodePoints();
			let l;
			var c, h;
			l = "allNonBasicAscii" === o ? /* @__PURE__ */ new RegExp("[^\\t\\n\\r\\x20-\\x7E]", "g") : new RegExp((c = Array.from(o), `[${h = c.map((e) => String.fromCodePoint(e)).join(""), h.replace(/[\\\{\}\*\+\?\|\^\$\.\[\]\(\)]/g, "\\$&")}]`), "g");
			const d = new _i(null, l), u = [];
			let m, p = !1, g = 0, f = 0, b = 0;
			e: for (let _ = i, w = r; _ <= w; _++) {
				const t = e.getLineContent(_), n = t.length;
				d.reset(0);
				do
					if (m = d.next(t), m) {
						let e = m.index, i = m.index + m[0].length;
						e > 0 && ie(t.charCodeAt(e - 1)) && e--, i + 1 < n && ie(t.charCodeAt(i - 1)) && i++;
						const r = t.substring(e, i);
						let o = Ti(e + 1, wi, t, 0);
						o && o.endColumn <= e + 1 && (o = null);
						const l = a.shouldHighlightNonBasicASCII(r, o ? o.word : null);
						if (0 !== l) {
							if (3 === l ? g++ : 2 === l ? f++ : 1 === l ? b++ : s(), u.length >= 1e3) {
								p = !0;
								break e;
							}
							u.push(new De(_, e + 1, _, i + 1));
						}
					}
				while (m);
			}
			return {
				ranges: u,
				hasMore: p,
				ambiguousCharacterCount: g,
				invisibleCharacterCount: f,
				nonBasicAsciiCharacterCount: b
			};
		}
		static computeUnicodeHighlightReason(e, t) {
			const n = new Li(t);
			switch (n.shouldHighlightNonBasicASCII(e, null)) {
				case 0: return null;
				case 2: return { kind: 1 };
				case 3: {
					const i = e.codePointAt(0), r = n.ambiguousCharacters.getPrimaryConfusable(i), a = ce.getLocales().filter((e) => !ce.getInstance(new Set([...t.allowedLocales, e])).isAmbiguous(i));
					return {
						kind: 0,
						confusableWith: String.fromCodePoint(r),
						notAmbiguousInLocales: a
					};
				}
				case 1: return { kind: 2 };
			}
		}
	};
	var Li = class {
		constructor(e) {
			this.options = e, this.allowedCodePoints = new Set(e.allowedCodePoints), this.ambiguousCharacters = ce.getInstance(new Set(e.allowedLocales));
		}
		getCandidateCodePoints() {
			if (this.options.nonBasicASCII) return "allNonBasicAscii";
			const e = /* @__PURE__ */ new Set();
			if (this.options.invisibleCharacters) for (const t of he.codePoints) xi(String.fromCodePoint(t)) || e.add(t);
			if (this.options.ambiguousCharacters) for (const t of this.ambiguousCharacters.getConfusableCodePoints()) e.add(t);
			for (const t of this.allowedCodePoints) e.delete(t);
			return e;
		}
		shouldHighlightNonBasicASCII(e, t) {
			const n = e.codePointAt(0);
			if (this.allowedCodePoints.has(n)) return 0;
			if (this.options.nonBasicASCII) return 1;
			let i = !1, r = !1;
			if (t) for (const a of t) {
				const e = a.codePointAt(0), t = le(a);
				i = i || t, t || this.ambiguousCharacters.isAmbiguous(e) || he.isInvisibleCharacter(e) || (r = !0);
			}
			return !i && r ? 0 : this.options.invisibleCharacters && !xi(e) && he.isInvisibleCharacter(n) ? 2 : this.options.ambiguousCharacters && this.ambiguousCharacters.isAmbiguous(n) ? 3 : 0;
		}
	};
	function xi(e) {
		return " " === e || "\n" === e || "	" === e;
	}
	var Ci, Ei = class {
		constructor(e, t, n) {
			this.changes = e, this.moves = t, this.hitTimeout = n;
		}
	}, Ai = class {
		constructor(e, t) {
			this.lineRangeMapping = e, this.changes = t;
		}
	};
	function Ri(e, t) {
		return (n, i) => t(e(n), e(i));
	}
	(function(e) {
		e.isLessThan = function(e) {
			return e < 0;
		}, e.isLessThanOrEqual = function(e) {
			return e <= 0;
		}, e.isGreaterThan = function(e) {
			return e > 0;
		}, e.isNeitherLessOrGreaterThan = function(e) {
			return 0 === e;
		}, e.greaterThan = 1, e.lessThan = -1, e.neitherLessOrGreaterThan = 0;
	})(Ci || (Ci = {}));
	const Mi = (e, t) => e - t;
	(class e {
		static {
			this.empty = new e((e) => {});
		}
		constructor(e) {
			this.iterate = e;
		}
		toArray() {
			const e = [];
			return this.iterate((t) => (e.push(t), !0)), e;
		}
		filter(t) {
			return new e((e) => this.iterate((n) => !t(n) || e(n)));
		}
		map(t) {
			return new e((e) => this.iterate((n) => e(t(n))));
		}
		findLast(e) {
			let t;
			return this.iterate((n) => (e(n) && (t = n), !0)), t;
		}
		findLastMaxBy(e) {
			let t, n = !0;
			return this.iterate((i) => ((n || Ci.isGreaterThan(e(i, t))) && (n = !1, t = i), !0)), t;
		}
	});
	var Ni = class e {
		static fromTo(t, n) {
			return new e(t, n);
		}
		static addRange(t, n) {
			let i = 0;
			for (; i < n.length && n[i].endExclusive < t.start;) i++;
			let r = i;
			for (; r < n.length && n[r].start <= t.endExclusive;) r++;
			if (i === r) n.splice(i, 0, t);
			else {
				const a = Math.min(t.start, n[i].start), o = Math.max(t.endExclusive, n[r - 1].endExclusive);
				n.splice(i, r - i, new e(a, o));
			}
		}
		static tryCreate(t, n) {
			if (!(t > n)) return new e(t, n);
		}
		static ofLength(t) {
			return new e(0, t);
		}
		static ofStartAndLength(t, n) {
			return new e(t, t + n);
		}
		static emptyAt(t) {
			return new e(t, t);
		}
		constructor(e, t) {
			if (this.start = e, this.endExclusive = t, e > t) throw new o(`Invalid range: ${this.toString()}`);
		}
		get isEmpty() {
			return this.start === this.endExclusive;
		}
		delta(t) {
			return new e(this.start + t, this.endExclusive + t);
		}
		deltaStart(t) {
			return new e(this.start + t, this.endExclusive);
		}
		deltaEnd(t) {
			return new e(this.start, this.endExclusive + t);
		}
		get length() {
			return this.endExclusive - this.start;
		}
		toString() {
			return `[${this.start}, ${this.endExclusive})`;
		}
		equals(e) {
			return this.start === e.start && this.endExclusive === e.endExclusive;
		}
		contains(e) {
			return this.start <= e && e < this.endExclusive;
		}
		join(t) {
			return new e(Math.min(this.start, t.start), Math.max(this.endExclusive, t.endExclusive));
		}
		intersect(t) {
			const n = Math.max(this.start, t.start), i = Math.min(this.endExclusive, t.endExclusive);
			if (n <= i) return new e(n, i);
		}
		intersectionLength(e) {
			const t = Math.max(this.start, e.start), n = Math.min(this.endExclusive, e.endExclusive);
			return Math.max(0, n - t);
		}
		intersects(e) {
			return Math.max(this.start, e.start) < Math.min(this.endExclusive, e.endExclusive);
		}
		intersectsOrTouches(e) {
			return Math.max(this.start, e.start) <= Math.min(this.endExclusive, e.endExclusive);
		}
		isBefore(e) {
			return this.endExclusive <= e.start;
		}
		isAfter(e) {
			return this.start >= e.endExclusive;
		}
		slice(e) {
			return e.slice(this.start, this.endExclusive);
		}
		substring(e) {
			return e.substring(this.start, this.endExclusive);
		}
		clip(e) {
			if (this.isEmpty) throw new o(`Invalid clipping range: ${this.toString()}`);
			return Math.max(this.start, Math.min(this.endExclusive - 1, e));
		}
		clipCyclic(e) {
			if (this.isEmpty) throw new o(`Invalid clipping range: ${this.toString()}`);
			return e < this.start ? this.endExclusive - (this.start - e) % this.length : e >= this.endExclusive ? this.start + (e - this.start) % this.length : e;
		}
		forEach(e) {
			for (let t = this.start; t < this.endExclusive; t++) e(t);
		}
		joinRightTouching(t) {
			if (this.endExclusive !== t.start) throw new o(`Invalid join: ${this.toString()} and ${t.toString()}`);
			return new e(this.start, t.endExclusive);
		}
	};
	function Ii(e, t) {
		const n = zi(e, t);
		return -1 === n ? void 0 : e[n];
	}
	function zi(e, t, n = 0, i = e.length) {
		let r = n, a = i;
		for (; r < a;) {
			const n = Math.floor((r + a) / 2);
			t(e[n]) ? r = n + 1 : a = n;
		}
		return r - 1;
	}
	function Oi(e, t, n = 0, i = e.length) {
		let r = n, a = i;
		for (; r < a;) {
			const n = Math.floor((r + a) / 2);
			t(e[n]) ? a = n : r = n + 1;
		}
		return r;
	}
	var Ui = class e {
		static {
			this.assertInvariants = !1;
		}
		constructor(e) {
			this._array = e, this._findLastMonotonousLastIdx = 0;
		}
		findLastMonotonous(t) {
			if (e.assertInvariants) {
				if (this._prevFindLastPredicate) {
					for (const e of this._array) if (this._prevFindLastPredicate(e) && !t(e)) throw new Error("MonotonousArray: current predicate must be weaker than (or equal to) the previous predicate.");
				}
				this._prevFindLastPredicate = t;
			}
			const n = zi(this._array, t, this._findLastMonotonousLastIdx);
			return this._findLastMonotonousLastIdx = n + 1, -1 === n ? void 0 : this._array[n];
		}
	}, Hi = class e {
		static ofLength(t, n) {
			return new e(t, t + n);
		}
		static fromRange(t) {
			return new e(t.startLineNumber, t.endLineNumber);
		}
		static fromRangeInclusive(t) {
			return new e(t.startLineNumber, t.endLineNumber + 1);
		}
		static {
			this.compareByStart = Ri((e) => e.startLineNumber, Mi);
		}
		static joinMany(e) {
			if (0 === e.length) return [];
			let t = new Di(e[0].slice());
			for (let n = 1; n < e.length; n++) t = t.getUnion(new Di(e[n].slice()));
			return t.ranges;
		}
		static join(t) {
			if (0 === t.length) throw new o("lineRanges cannot be empty");
			let n = t[0].startLineNumber, i = t[0].endLineNumberExclusive;
			for (let e = 1; e < t.length; e++) n = Math.min(n, t[e].startLineNumber), i = Math.max(i, t[e].endLineNumberExclusive);
			return new e(n, i);
		}
		static deserialize(t) {
			return new e(t[0], t[1]);
		}
		constructor(e, t) {
			if (e > t) throw new o(`startLineNumber ${e} cannot be after endLineNumberExclusive ${t}`);
			this.startLineNumber = e, this.endLineNumberExclusive = t;
		}
		contains(e) {
			return this.startLineNumber <= e && e < this.endLineNumberExclusive;
		}
		get isEmpty() {
			return this.startLineNumber === this.endLineNumberExclusive;
		}
		delta(t) {
			return new e(this.startLineNumber + t, this.endLineNumberExclusive + t);
		}
		deltaLength(t) {
			return new e(this.startLineNumber, this.endLineNumberExclusive + t);
		}
		get length() {
			return this.endLineNumberExclusive - this.startLineNumber;
		}
		join(t) {
			return new e(Math.min(this.startLineNumber, t.startLineNumber), Math.max(this.endLineNumberExclusive, t.endLineNumberExclusive));
		}
		toString() {
			return `[${this.startLineNumber},${this.endLineNumberExclusive})`;
		}
		intersect(t) {
			const n = Math.max(this.startLineNumber, t.startLineNumber), i = Math.min(this.endLineNumberExclusive, t.endLineNumberExclusive);
			if (n <= i) return new e(n, i);
		}
		intersectsStrict(e) {
			return this.startLineNumber < e.endLineNumberExclusive && e.startLineNumber < this.endLineNumberExclusive;
		}
		intersectsOrTouches(e) {
			return this.startLineNumber <= e.endLineNumberExclusive && e.startLineNumber <= this.endLineNumberExclusive;
		}
		equals(e) {
			return this.startLineNumber === e.startLineNumber && this.endLineNumberExclusive === e.endLineNumberExclusive;
		}
		toInclusiveRange() {
			return this.isEmpty ? null : new De(this.startLineNumber, 1, this.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER);
		}
		toExclusiveRange() {
			return new De(this.startLineNumber, 1, this.endLineNumberExclusive, 1);
		}
		mapToLineArray(e) {
			const t = [];
			for (let n = this.startLineNumber; n < this.endLineNumberExclusive; n++) t.push(e(n));
			return t;
		}
		forEach(e) {
			for (let t = this.startLineNumber; t < this.endLineNumberExclusive; t++) e(t);
		}
		serialize() {
			return [this.startLineNumber, this.endLineNumberExclusive];
		}
		toOffsetRange() {
			return new Ni(this.startLineNumber - 1, this.endLineNumberExclusive - 1);
		}
		addMargin(t, n) {
			return new e(this.startLineNumber - t, this.endLineNumberExclusive + n);
		}
	}, Di = class e {
		constructor(e = []) {
			this._normalizedRanges = e;
		}
		get ranges() {
			return this._normalizedRanges;
		}
		addRange(e) {
			if (0 === e.length) return;
			const t = Oi(this._normalizedRanges, (t) => t.endLineNumberExclusive >= e.startLineNumber), n = zi(this._normalizedRanges, (t) => t.startLineNumber <= e.endLineNumberExclusive) + 1;
			if (t === n) this._normalizedRanges.splice(t, 0, e);
			else if (t === n - 1) {
				const n = this._normalizedRanges[t];
				this._normalizedRanges[t] = n.join(e);
			} else {
				const i = this._normalizedRanges[t].join(this._normalizedRanges[n - 1]).join(e);
				this._normalizedRanges.splice(t, n - t, i);
			}
		}
		contains(e) {
			const t = Ii(this._normalizedRanges, (t) => t.startLineNumber <= e);
			return !!t && t.endLineNumberExclusive > e;
		}
		intersects(e) {
			const t = Ii(this._normalizedRanges, (t) => t.startLineNumber < e.endLineNumberExclusive);
			return !!t && t.endLineNumberExclusive > e.startLineNumber;
		}
		getUnion(t) {
			if (0 === this._normalizedRanges.length) return t;
			if (0 === t._normalizedRanges.length) return this;
			const n = [];
			let i = 0, r = 0, a = null;
			for (; i < this._normalizedRanges.length || r < t._normalizedRanges.length;) {
				let e = null;
				if (i < this._normalizedRanges.length && r < t._normalizedRanges.length) {
					const n = this._normalizedRanges[i], a = t._normalizedRanges[r];
					n.startLineNumber < a.startLineNumber ? (e = n, i++) : (e = a, r++);
				} else i < this._normalizedRanges.length ? (e = this._normalizedRanges[i], i++) : (e = t._normalizedRanges[r], r++);
				null === a ? a = e : a.endLineNumberExclusive >= e.startLineNumber ? a = new Hi(a.startLineNumber, Math.max(a.endLineNumberExclusive, e.endLineNumberExclusive)) : (n.push(a), a = e);
			}
			return null !== a && n.push(a), new e(n);
		}
		subtractFrom(t) {
			const n = Oi(this._normalizedRanges, (e) => e.endLineNumberExclusive >= t.startLineNumber), i = zi(this._normalizedRanges, (e) => e.startLineNumber <= t.endLineNumberExclusive) + 1;
			if (n === i) return new e([t]);
			const r = [];
			let a = t.startLineNumber;
			for (let e = n; e < i; e++) {
				const t = this._normalizedRanges[e];
				t.startLineNumber > a && r.push(new Hi(a, t.startLineNumber)), a = t.endLineNumberExclusive;
			}
			return a < t.endLineNumberExclusive && r.push(new Hi(a, t.endLineNumberExclusive)), new e(r);
		}
		toString() {
			return this._normalizedRanges.map((e) => e.toString()).join(", ");
		}
		getIntersection(t) {
			const n = [];
			let i = 0, r = 0;
			for (; i < this._normalizedRanges.length && r < t._normalizedRanges.length;) {
				const e = this._normalizedRanges[i], a = t._normalizedRanges[r], o = e.intersect(a);
				o && !o.isEmpty && n.push(o), e.endLineNumberExclusive < a.endLineNumberExclusive ? i++ : r++;
			}
			return new e(n);
		}
		getWithDelta(t) {
			return new e(this._normalizedRanges.map((e) => e.delta(t)));
		}
	}, Wi = class e {
		static {
			this.zero = new e(0, 0);
		}
		static betweenPositions(t, n) {
			return t.lineNumber === n.lineNumber ? new e(0, n.column - t.column) : new e(n.lineNumber - t.lineNumber, n.column - 1);
		}
		static fromPosition(t) {
			return new e(t.lineNumber - 1, t.column - 1);
		}
		static ofRange(t) {
			return e.betweenPositions(t.getStartPosition(), t.getEndPosition());
		}
		static ofText(t) {
			let n = 0, i = 0;
			for (const e of t) "\n" === e ? (n++, i = 0) : i++;
			return new e(n, i);
		}
		constructor(e, t) {
			this.lineCount = e, this.columnCount = t;
		}
		isGreaterThanOrEqualTo(e) {
			return this.lineCount !== e.lineCount ? this.lineCount > e.lineCount : this.columnCount >= e.columnCount;
		}
		add(t) {
			return 0 === t.lineCount ? new e(this.lineCount, this.columnCount + t.columnCount) : new e(this.lineCount + t.lineCount, t.columnCount);
		}
		createRange(e) {
			return 0 === this.lineCount ? new De(e.lineNumber, e.column, e.lineNumber, e.column + this.columnCount) : new De(e.lineNumber, e.column, e.lineNumber + this.lineCount, this.columnCount + 1);
		}
		toRange() {
			return new De(1, 1, this.lineCount + 1, this.columnCount + 1);
		}
		toLineRange() {
			return Hi.ofLength(1, this.lineCount + 1);
		}
		addToPosition(e) {
			return 0 === this.lineCount ? new He(e.lineNumber, e.column + this.columnCount) : new He(e.lineNumber + this.lineCount, this.columnCount + 1);
		}
		toString() {
			return `${this.lineCount},${this.columnCount}`;
		}
	}, Pi = class {
		getOffsetRange(e) {
			return new Ni(this.getOffset(e.getStartPosition()), this.getOffset(e.getEndPosition()));
		}
		getRange(e) {
			return De.fromPositions(this.getPosition(e.start), this.getPosition(e.endExclusive));
		}
		getStringReplacement(e) {
			return new qi.deps.StringReplacement(this.getOffsetRange(e.range), e.text);
		}
		getTextReplacement(e) {
			return new qi.deps.TextReplacement(this.getRange(e.replaceRange), e.newText);
		}
		getTextEdit(e) {
			const t = e.replacements.map((e) => this.getTextReplacement(e));
			return new qi.deps.TextEdit(t);
		}
	}, qi = class {
		static {
			this._deps = void 0;
		}
		static get deps() {
			if (!this._deps) throw new Error("Dependencies not set. Call _setDependencies first.");
			return this._deps;
		}
	}, Fi = class extends Pi {
		constructor(e) {
			super(), this.text = e, this.lineStartOffsetByLineIdx = [], this.lineEndOffsetByLineIdx = [], this.lineStartOffsetByLineIdx.push(0);
			for (let t = 0; t < e.length; t++) "\n" === e.charAt(t) && (this.lineStartOffsetByLineIdx.push(t + 1), t > 0 && "\r" === e.charAt(t - 1) ? this.lineEndOffsetByLineIdx.push(t - 1) : this.lineEndOffsetByLineIdx.push(t));
			this.lineEndOffsetByLineIdx.push(e.length);
		}
		getOffset(e) {
			const t = this._validatePosition(e);
			return this.lineStartOffsetByLineIdx[t.lineNumber - 1] + t.column - 1;
		}
		_validatePosition(e) {
			if (e.lineNumber < 1) return new He(1, 1);
			const t = this.textLength.lineCount + 1;
			if (e.lineNumber > t) return new He(t, this.getLineLength(t) + 1);
			if (e.column < 1) return new He(e.lineNumber, 1);
			const n = this.getLineLength(e.lineNumber);
			return e.column - 1 > n ? new He(e.lineNumber, n + 1) : e;
		}
		getPosition(e) {
			const t = zi(this.lineStartOffsetByLineIdx, (t) => t <= e);
			return new He(t + 1, e - this.lineStartOffsetByLineIdx[t] + 1);
		}
		get textLength() {
			const e = this.lineStartOffsetByLineIdx.length - 1;
			return new qi.deps.TextLength(e, this.text.length - this.lineStartOffsetByLineIdx[e]);
		}
		getLineLength(e) {
			return this.lineEndOffsetByLineIdx[e - 1] - this.lineStartOffsetByLineIdx[e - 1];
		}
	}, Vi = class {
		constructor() {
			this._transformer = void 0;
		}
		get endPositionExclusive() {
			return this.length.addToPosition(new He(1, 1));
		}
		get lineRange() {
			return this.length.toLineRange();
		}
		getValue() {
			return this.getValueOfRange(this.length.toRange());
		}
		getValueOfOffsetRange(e) {
			return this.getValueOfRange(this.getTransformer().getRange(e));
		}
		getLineLength(e) {
			return this.getValueOfRange(new De(e, 1, e, Number.MAX_SAFE_INTEGER)).length;
		}
		getTransformer() {
			return this._transformer || (this._transformer = new Fi(this.getValue())), this._transformer;
		}
		getLineAt(e) {
			return this.getValueOfRange(new De(e, 1, e, Number.MAX_SAFE_INTEGER));
		}
	}, Bi = class extends Vi {
		constructor(e, t) {
			(function(e, t = "unexpected state") {
				if (!e) throw "string" == typeof t ? new o(`Assertion Failed: ${t}`) : t;
			})(t >= 1), super(), this._getLineContent = e, this._lineCount = t;
		}
		getValueOfRange(e) {
			if (e.startLineNumber === e.endLineNumber) return this._getLineContent(e.startLineNumber).substring(e.startColumn - 1, e.endColumn - 1);
			let t = this._getLineContent(e.startLineNumber).substring(e.startColumn - 1);
			for (let n = e.startLineNumber + 1; n < e.endLineNumber; n++) t += "\n" + this._getLineContent(n);
			return t += "\n" + this._getLineContent(e.endLineNumber).substring(0, e.endColumn - 1), t;
		}
		getLineLength(e) {
			return this._getLineContent(e).length;
		}
		get length() {
			const e = this._getLineContent(this._lineCount);
			return new Wi(this._lineCount - 1, e.length);
		}
	}, Ki = class extends Bi {
		constructor(e) {
			super((t) => e[t - 1], e.length);
		}
	}, ji = class e {
		static joinReplacements(t, n) {
			if (0 === t.length) throw new o();
			if (1 === t.length) return t[0];
			const i = t[0].range.getStartPosition(), r = t[t.length - 1].range.getEndPosition();
			let a = "";
			for (let e = 0; e < t.length; e++) {
				const i = t[e];
				if (a += i.text, e < t.length - 1) {
					const r = t[e + 1], o = De.fromPositions(i.range.getEndPosition(), r.range.getStartPosition());
					a += n.getValueOfRange(o);
				}
			}
			return new e(De.fromPositions(i, r), a);
		}
		static fromStringReplacement(t, n) {
			return new e(n.getTransformer().getRange(t.replaceRange), t.newText);
		}
		static delete(t) {
			return new e(t, "");
		}
		constructor(e, t) {
			this.range = e, this.text = t;
		}
		get isEmpty() {
			return this.range.isEmpty() && 0 === this.text.length;
		}
		static equals(e, t) {
			return e.range.equalsRange(t.range) && e.text === t.text;
		}
		equals(t) {
			return e.equals(this, t);
		}
		removeCommonPrefixAndSuffix(e) {
			return this.removeCommonPrefix(e).removeCommonSuffix(e);
		}
		removeCommonPrefix(t) {
			const n = t.getValueOfRange(this.range).replaceAll("\r\n", "\n"), i = this.text.replaceAll("\r\n", "\n"), r = function(e, t) {
				const n = Math.min(e.length, t.length);
				let i;
				for (i = 0; i < n; i++) if (e.charCodeAt(i) !== t.charCodeAt(i)) return i;
				return n;
			}(n, i), a = Wi.ofText(n.substring(0, r)).addToPosition(this.range.getStartPosition()), o = i.substring(r);
			return new e(De.fromPositions(a, this.range.getEndPosition()), o);
		}
		removeCommonSuffix(t) {
			const n = t.getValueOfRange(this.range).replaceAll("\r\n", "\n"), i = this.text.replaceAll("\r\n", "\n"), r = function(e, t) {
				const n = Math.min(e.length, t.length);
				let i;
				const r = e.length - 1, a = t.length - 1;
				for (i = 0; i < n; i++) if (e.charCodeAt(r - i) !== t.charCodeAt(a - i)) return i;
				return n;
			}(n, i), a = Wi.ofText(n.substring(0, n.length - r)).addToPosition(this.range.getStartPosition()), o = i.substring(0, i.length - r);
			return new e(De.fromPositions(this.range.getStartPosition(), a), o);
		}
		toString() {
			const e = this.range.getStartPosition(), t = this.range.getEndPosition();
			return `(${e.lineNumber},${e.column} -> ${t.lineNumber},${t.column}): "${this.text}"`;
		}
	}, Gi = class e {
		static inverse(t, n, i) {
			const r = [];
			let a = 1, o = 1;
			for (const l of t) {
				const t = new e(new Hi(a, l.original.startLineNumber), new Hi(o, l.modified.startLineNumber));
				t.modified.isEmpty || r.push(t), a = l.original.endLineNumberExclusive, o = l.modified.endLineNumberExclusive;
			}
			const s = new e(new Hi(a, n + 1), new Hi(o, i + 1));
			return s.modified.isEmpty || r.push(s), r;
		}
		static clip(t, n, i) {
			const r = [];
			for (const a of t) {
				const t = a.original.intersect(n), o = a.modified.intersect(i);
				t && !t.isEmpty && o && !o.isEmpty && r.push(new e(t, o));
			}
			return r;
		}
		constructor(e, t) {
			this.original = e, this.modified = t;
		}
		toString() {
			return `{${this.original.toString()}->${this.modified.toString()}}`;
		}
		flip() {
			return new e(this.modified, this.original);
		}
		join(t) {
			return new e(this.original.join(t.original), this.modified.join(t.modified));
		}
		toRangeMapping() {
			const e = this.original.toInclusiveRange(), t = this.modified.toInclusiveRange();
			if (e && t) return new Yi(e, t);
			if (1 === this.original.startLineNumber || 1 === this.modified.startLineNumber) {
				if (1 !== this.modified.startLineNumber || 1 !== this.original.startLineNumber) throw new o("not a valid diff");
				return new Yi(new De(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new De(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1));
			}
			return new Yi(new De(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), new De(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER));
		}
		toRangeMapping2(e, t) {
			if (Xi(this.original.endLineNumberExclusive, e) && Xi(this.modified.endLineNumberExclusive, t)) return new Yi(new De(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new De(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1));
			if (!this.original.isEmpty && !this.modified.isEmpty) return new Yi(De.fromPositions(new He(this.original.startLineNumber, 1), $i(new He(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), De.fromPositions(new He(this.modified.startLineNumber, 1), $i(new He(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), t)));
			if (this.original.startLineNumber > 1 && this.modified.startLineNumber > 1) return new Yi(De.fromPositions($i(new He(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER), e), $i(new He(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), De.fromPositions($i(new He(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER), t), $i(new He(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), t)));
			throw new o();
		}
	};
	function $i(e, t) {
		if (e.lineNumber < 1) return new He(1, 1);
		if (e.lineNumber > t.length) return new He(t.length, t[t.length - 1].length + 1);
		const n = t[e.lineNumber - 1];
		return e.column > n.length + 1 ? new He(e.lineNumber, n.length + 1) : e;
	}
	function Xi(e, t) {
		return e >= 1 && e <= t.length;
	}
	var Ji = class e extends Gi {
		static fromRangeMappings(t) {
			return new e(Hi.join(t.map((e) => Hi.fromRangeInclusive(e.originalRange))), Hi.join(t.map((e) => Hi.fromRangeInclusive(e.modifiedRange))), t);
		}
		constructor(e, t, n) {
			super(e, t), this.innerChanges = n;
		}
		flip() {
			return new e(this.modified, this.original, this.innerChanges?.map((e) => e.flip()));
		}
		withInnerChangesFromLineRanges() {
			return new e(this.original, this.modified, [this.toRangeMapping()]);
		}
	}, Yi = class e {
		static fromEdit(t) {
			const n = t.getNewRanges();
			return t.replacements.map((t, i) => new e(t.range, n[i]));
		}
		static assertSorted(e) {
			for (let t = 1; t < e.length; t++) {
				const n = e[t - 1], i = e[t];
				if (!n.originalRange.getEndPosition().isBeforeOrEqual(i.originalRange.getStartPosition()) || !n.modifiedRange.getEndPosition().isBeforeOrEqual(i.modifiedRange.getStartPosition())) throw new o("Range mappings must be sorted");
			}
		}
		constructor(e, t) {
			this.originalRange = e, this.modifiedRange = t;
		}
		toString() {
			return `{${this.originalRange.toString()}->${this.modifiedRange.toString()}}`;
		}
		flip() {
			return new e(this.modifiedRange, this.originalRange);
		}
		toTextEdit(e) {
			const t = e.getValueOfRange(this.modifiedRange);
			return new ji(this.originalRange, t);
		}
	};
	function Qi(e, t, n, i = !1) {
		const r = [];
		for (const a of function* (e, t) {
			let n, i;
			for (const r of e) void 0 !== i && t(i, r) ? n.push(r) : (n && (yield n), n = [r]), i = r;
			n && (yield n);
		}(e.map((e) => function(e, t, n) {
			let i = 0, r = 0;
			1 === e.modifiedRange.endColumn && 1 === e.originalRange.endColumn && e.originalRange.startLineNumber + i <= e.originalRange.endLineNumber && e.modifiedRange.startLineNumber + i <= e.modifiedRange.endLineNumber && (r = -1);
			e.modifiedRange.startColumn - 1 >= n.getLineLength(e.modifiedRange.startLineNumber) && e.originalRange.startColumn - 1 >= t.getLineLength(e.originalRange.startLineNumber) && e.originalRange.startLineNumber <= e.originalRange.endLineNumber + r && e.modifiedRange.startLineNumber <= e.modifiedRange.endLineNumber + r && (i = 1);
			return new Ji(new Hi(e.originalRange.startLineNumber + i, e.originalRange.endLineNumber + 1 + r), new Hi(e.modifiedRange.startLineNumber + i, e.modifiedRange.endLineNumber + 1 + r), [e]);
		}(e, t, n)), (e, t) => e.original.intersectsOrTouches(t.original) || e.modified.intersectsOrTouches(t.modified))) {
			const e = a[0], t = a[a.length - 1];
			r.push(new Ji(e.original.join(t.original), e.modified.join(t.modified), a.map((e) => e.innerChanges[0])));
		}
		return l(() => {
			if (!i && r.length > 0) {
				if (r[0].modified.startLineNumber !== r[0].original.startLineNumber) return !1;
				if (n.length.lineCount - r[r.length - 1].modified.endLineNumberExclusive !== t.length.lineCount - r[r.length - 1].original.endLineNumberExclusive) return !1;
			}
			return c(r, (e, t) => t.original.startLineNumber - e.original.endLineNumberExclusive === t.modified.startLineNumber - e.modified.endLineNumberExclusive && e.original.endLineNumberExclusive < t.original.startLineNumber && e.modified.endLineNumberExclusive < t.modified.startLineNumber);
		}), r;
	}
	var Zi = class {
		computeDiff(e, t, n) {
			const i = new ar(e, t, {
				maxComputationTime: n.maxComputationTimeMs,
				shouldIgnoreTrimWhitespace: n.ignoreTrimWhitespace,
				shouldComputeCharChanges: !0,
				shouldMakePrettyDiff: !0,
				shouldPostProcessCharChanges: !0
			}).computeDiff(), r = [];
			let a = null;
			for (const o of i.changes) {
				let e, t;
				e = 0 === o.originalEndLineNumber ? new Hi(o.originalStartLineNumber + 1, o.originalStartLineNumber + 1) : new Hi(o.originalStartLineNumber, o.originalEndLineNumber + 1), t = 0 === o.modifiedEndLineNumber ? new Hi(o.modifiedStartLineNumber + 1, o.modifiedStartLineNumber + 1) : new Hi(o.modifiedStartLineNumber, o.modifiedEndLineNumber + 1);
				let n = new Ji(e, t, o.charChanges?.map((e) => new Yi(new De(e.originalStartLineNumber, e.originalStartColumn, e.originalEndLineNumber, e.originalEndColumn), new De(e.modifiedStartLineNumber, e.modifiedStartColumn, e.modifiedEndLineNumber, e.modifiedEndColumn))));
				a && (a.modified.endLineNumberExclusive !== n.modified.startLineNumber && a.original.endLineNumberExclusive !== n.original.startLineNumber || (n = new Ji(a.original.join(n.original), a.modified.join(n.modified), a.innerChanges && n.innerChanges ? a.innerChanges.concat(n.innerChanges) : void 0), r.pop())), r.push(n), a = n;
			}
			return l(() => c(r, (e, t) => t.original.startLineNumber - e.original.endLineNumberExclusive === t.modified.startLineNumber - e.modified.endLineNumberExclusive && e.original.endLineNumberExclusive < t.original.startLineNumber && e.modified.endLineNumberExclusive < t.modified.startLineNumber)), new Ei(r, [], i.quitEarly);
		}
	};
	function er(e, t, n, i) {
		return new Ue(e, t, n).ComputeDiff(i);
	}
	var tr = class {
		constructor(e) {
			const t = [], n = [];
			for (let i = 0, r = e.length; i < r; i++) t[i] = or(e[i], 1), n[i] = sr(e[i], 1);
			this.lines = e, this._startColumns = t, this._endColumns = n;
		}
		getElements() {
			const e = [];
			for (let t = 0, n = this.lines.length; t < n; t++) e[t] = this.lines[t].substring(this._startColumns[t] - 1, this._endColumns[t] - 1);
			return e;
		}
		getStrictElement(e) {
			return this.lines[e];
		}
		getStartLineNumber(e) {
			return e + 1;
		}
		getEndLineNumber(e) {
			return e + 1;
		}
		createCharSequence(e, t, n) {
			const i = [], r = [], a = [];
			let o = 0;
			for (let s = t; s <= n; s++) {
				const t = this.lines[s], l = e ? this._startColumns[s] : 1, c = e ? this._endColumns[s] : t.length + 1;
				for (let e = l; e < c; e++) i[o] = t.charCodeAt(e - 1), r[o] = s + 1, a[o] = e, o++;
				!e && s < n && (i[o] = 10, r[o] = s + 1, a[o] = t.length + 1, o++);
			}
			return new nr(i, r, a);
		}
	}, nr = class {
		constructor(e, t, n) {
			this._charCodes = e, this._lineNumbers = t, this._columns = n;
		}
		toString() {
			return "[" + this._charCodes.map((e, t) => (10 === e ? "\\n" : String.fromCharCode(e)) + `-(${this._lineNumbers[t]},${this._columns[t]})`).join(", ") + "]";
		}
		_assertIndex(e, t) {
			if (e < 0 || e >= t.length) throw new Error("Illegal index");
		}
		getElements() {
			return this._charCodes;
		}
		getStartLineNumber(e) {
			return e > 0 && e === this._lineNumbers.length ? this.getEndLineNumber(e - 1) : (this._assertIndex(e, this._lineNumbers), this._lineNumbers[e]);
		}
		getEndLineNumber(e) {
			return -1 === e ? this.getStartLineNumber(e + 1) : (this._assertIndex(e, this._lineNumbers), 10 === this._charCodes[e] ? this._lineNumbers[e] + 1 : this._lineNumbers[e]);
		}
		getStartColumn(e) {
			return e > 0 && e === this._columns.length ? this.getEndColumn(e - 1) : (this._assertIndex(e, this._columns), this._columns[e]);
		}
		getEndColumn(e) {
			return -1 === e ? this.getStartColumn(e + 1) : (this._assertIndex(e, this._columns), 10 === this._charCodes[e] ? 1 : this._columns[e] + 1);
		}
	}, ir = class e {
		constructor(e, t, n, i, r, a, o, s) {
			this.originalStartLineNumber = e, this.originalStartColumn = t, this.originalEndLineNumber = n, this.originalEndColumn = i, this.modifiedStartLineNumber = r, this.modifiedStartColumn = a, this.modifiedEndLineNumber = o, this.modifiedEndColumn = s;
		}
		static createFromDiffChange(t, n, i) {
			return new e(n.getStartLineNumber(t.originalStart), n.getStartColumn(t.originalStart), n.getEndLineNumber(t.originalStart + t.originalLength - 1), n.getEndColumn(t.originalStart + t.originalLength - 1), i.getStartLineNumber(t.modifiedStart), i.getStartColumn(t.modifiedStart), i.getEndLineNumber(t.modifiedStart + t.modifiedLength - 1), i.getEndColumn(t.modifiedStart + t.modifiedLength - 1));
		}
	};
	var rr = class e {
		constructor(e, t, n, i, r) {
			this.originalStartLineNumber = e, this.originalEndLineNumber = t, this.modifiedStartLineNumber = n, this.modifiedEndLineNumber = i, this.charChanges = r;
		}
		static createFromDiffResult(t, n, i, r, a, o, s) {
			let l, c, h, d, u;
			if (0 === n.originalLength ? (l = i.getStartLineNumber(n.originalStart) - 1, c = 0) : (l = i.getStartLineNumber(n.originalStart), c = i.getEndLineNumber(n.originalStart + n.originalLength - 1)), 0 === n.modifiedLength ? (h = r.getStartLineNumber(n.modifiedStart) - 1, d = 0) : (h = r.getStartLineNumber(n.modifiedStart), d = r.getEndLineNumber(n.modifiedStart + n.modifiedLength - 1)), o && n.originalLength > 0 && n.originalLength < 20 && n.modifiedLength > 0 && n.modifiedLength < 20 && a()) {
				const e = i.createCharSequence(t, n.originalStart, n.originalStart + n.originalLength - 1), o = r.createCharSequence(t, n.modifiedStart, n.modifiedStart + n.modifiedLength - 1);
				if (e.getElements().length > 0 && o.getElements().length > 0) {
					let t = er(e, o, a, !0).changes;
					s && (t = function(e) {
						if (e.length <= 1) return e;
						const t = [e[0]];
						let n = t[0];
						for (let i = 1, r = e.length; i < r; i++) {
							const r = e[i], a = r.originalStart - (n.originalStart + n.originalLength), o = r.modifiedStart - (n.modifiedStart + n.modifiedLength);
							Math.min(a, o) < 3 ? (n.originalLength = r.originalStart + r.originalLength - n.originalStart, n.modifiedLength = r.modifiedStart + r.modifiedLength - n.modifiedStart) : (t.push(r), n = r);
						}
						return t;
					}(t)), u = [];
					for (let n = 0, i = t.length; n < i; n++) u.push(ir.createFromDiffChange(t[n], e, o));
				}
			}
			return new e(l, c, h, d, u);
		}
	}, ar = class {
		constructor(e, t, n) {
			this.shouldComputeCharChanges = n.shouldComputeCharChanges, this.shouldPostProcessCharChanges = n.shouldPostProcessCharChanges, this.shouldIgnoreTrimWhitespace = n.shouldIgnoreTrimWhitespace, this.shouldMakePrettyDiff = n.shouldMakePrettyDiff, this.originalLines = e, this.modifiedLines = t, this.original = new tr(e), this.modified = new tr(t), this.continueLineDiff = lr(n.maxComputationTime), this.continueCharDiff = lr(0 === n.maxComputationTime ? 0 : Math.min(n.maxComputationTime, 5e3));
		}
		computeDiff() {
			if (1 === this.original.lines.length && 0 === this.original.lines[0].length) return 1 === this.modified.lines.length && 0 === this.modified.lines[0].length ? {
				quitEarly: !1,
				changes: []
			} : {
				quitEarly: !1,
				changes: [{
					originalStartLineNumber: 1,
					originalEndLineNumber: 1,
					modifiedStartLineNumber: 1,
					modifiedEndLineNumber: this.modified.lines.length,
					charChanges: void 0
				}]
			};
			if (1 === this.modified.lines.length && 0 === this.modified.lines[0].length) return {
				quitEarly: !1,
				changes: [{
					originalStartLineNumber: 1,
					originalEndLineNumber: this.original.lines.length,
					modifiedStartLineNumber: 1,
					modifiedEndLineNumber: 1,
					charChanges: void 0
				}]
			};
			const e = er(this.original, this.modified, this.continueLineDiff, this.shouldMakePrettyDiff), t = e.changes, n = e.quitEarly;
			if (this.shouldIgnoreTrimWhitespace) {
				const e = [];
				for (let n = 0, i = t.length; n < i; n++) e.push(rr.createFromDiffResult(this.shouldIgnoreTrimWhitespace, t[n], this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges));
				return {
					quitEarly: n,
					changes: e
				};
			}
			const i = [];
			let r = 0, a = 0;
			for (let o = -1, s = t.length; o < s; o++) {
				const e = o + 1 < s ? t[o + 1] : null, n = e ? e.originalStart : this.originalLines.length, l = e ? e.modifiedStart : this.modifiedLines.length;
				for (; r < n && a < l;) {
					const e = this.originalLines[r], t = this.modifiedLines[a];
					if (e !== t) {
						{
							let n = or(e, 1), o = or(t, 1);
							for (; n > 1 && o > 1 && e.charCodeAt(n - 2) === t.charCodeAt(o - 2);) n--, o--;
							(n > 1 || o > 1) && this._pushTrimWhitespaceCharChange(i, r + 1, 1, n, a + 1, 1, o);
						}
						{
							let n = sr(e, 1), o = sr(t, 1);
							const s = e.length + 1, l = t.length + 1;
							for (; n < s && o < l && e.charCodeAt(n - 1) === e.charCodeAt(o - 1);) n++, o++;
							(n < s || o < l) && this._pushTrimWhitespaceCharChange(i, r + 1, n, s, a + 1, o, l);
						}
					}
					r++, a++;
				}
				e && (i.push(rr.createFromDiffResult(this.shouldIgnoreTrimWhitespace, e, this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges)), r += e.originalLength, a += e.modifiedLength);
			}
			return {
				quitEarly: n,
				changes: i
			};
		}
		_pushTrimWhitespaceCharChange(e, t, n, i, r, a, o) {
			if (this._mergeTrimWhitespaceCharChange(e, t, n, i, r, a, o)) return;
			let s;
			this.shouldComputeCharChanges && (s = [new ir(t, n, t, i, r, a, r, o)]), e.push(new rr(t, t, r, r, s));
		}
		_mergeTrimWhitespaceCharChange(e, t, n, i, r, a, o) {
			const s = e.length;
			if (0 === s) return !1;
			const l = e[s - 1];
			return 0 !== l.originalEndLineNumber && 0 !== l.modifiedEndLineNumber && (l.originalEndLineNumber === t && l.modifiedEndLineNumber === r ? (this.shouldComputeCharChanges && l.charChanges && l.charChanges.push(new ir(t, n, t, i, r, a, r, o)), !0) : l.originalEndLineNumber + 1 === t && l.modifiedEndLineNumber + 1 === r && (l.originalEndLineNumber = t, l.modifiedEndLineNumber = r, this.shouldComputeCharChanges && l.charChanges && l.charChanges.push(new ir(t, n, t, i, r, a, r, o)), !0));
		}
	};
	function or(e, t) {
		const n = function(e) {
			for (let t = 0, n = e.length; t < n; t++) {
				const n = e.charCodeAt(t);
				if (32 !== n && 9 !== n) return t;
			}
			return -1;
		}(e);
		return -1 === n ? t : n + 1;
	}
	function sr(e, t) {
		const n = function(e, t = e.length - 1) {
			for (let n = t; n >= 0; n--) {
				const t = e.charCodeAt(n);
				if (32 !== t && 9 !== t) return n;
			}
			return -1;
		}(e);
		return -1 === n ? t : n + 2;
	}
	function lr(e) {
		if (0 === e) return () => !0;
		const t = Date.now();
		return () => Date.now() - t < e;
	}
	var cr = class e {
		static trivial(t, n) {
			return new e([new hr(Ni.ofLength(t.length), Ni.ofLength(n.length))], !1);
		}
		static trivialTimedOut(t, n) {
			return new e([new hr(Ni.ofLength(t.length), Ni.ofLength(n.length))], !0);
		}
		constructor(e, t) {
			this.diffs = e, this.hitTimeout = t;
		}
	}, hr = class e {
		static invert(t, n) {
			const i = [];
			return function(e, t) {
				for (let n = 0; n <= e.length; n++) t(0 === n ? void 0 : e[n - 1], n === e.length ? void 0 : e[n]);
			}(t, (t, r) => {
				i.push(e.fromOffsetPairs(t ? t.getEndExclusives() : dr.zero, r ? r.getStarts() : new dr(n, (t ? t.seq2Range.endExclusive - t.seq1Range.endExclusive : 0) + n)));
			}), i;
		}
		static fromOffsetPairs(t, n) {
			return new e(new Ni(t.offset1, n.offset1), new Ni(t.offset2, n.offset2));
		}
		static assertSorted(e) {
			let t;
			for (const n of e) {
				if (t && !(t.seq1Range.endExclusive <= n.seq1Range.start && t.seq2Range.endExclusive <= n.seq2Range.start)) throw new o("Sequence diffs must be sorted");
				t = n;
			}
		}
		constructor(e, t) {
			this.seq1Range = e, this.seq2Range = t;
		}
		swap() {
			return new e(this.seq2Range, this.seq1Range);
		}
		toString() {
			return `${this.seq1Range} <-> ${this.seq2Range}`;
		}
		join(t) {
			return new e(this.seq1Range.join(t.seq1Range), this.seq2Range.join(t.seq2Range));
		}
		delta(t) {
			return 0 === t ? this : new e(this.seq1Range.delta(t), this.seq2Range.delta(t));
		}
		deltaStart(t) {
			return 0 === t ? this : new e(this.seq1Range.deltaStart(t), this.seq2Range.deltaStart(t));
		}
		deltaEnd(t) {
			return 0 === t ? this : new e(this.seq1Range.deltaEnd(t), this.seq2Range.deltaEnd(t));
		}
		intersect(t) {
			const n = this.seq1Range.intersect(t.seq1Range), i = this.seq2Range.intersect(t.seq2Range);
			if (n && i) return new e(n, i);
		}
		getStarts() {
			return new dr(this.seq1Range.start, this.seq2Range.start);
		}
		getEndExclusives() {
			return new dr(this.seq1Range.endExclusive, this.seq2Range.endExclusive);
		}
	}, dr = class e {
		static {
			this.zero = new e(0, 0);
		}
		static {
			this.max = new e(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
		}
		constructor(e, t) {
			this.offset1 = e, this.offset2 = t;
		}
		toString() {
			return `${this.offset1} <-> ${this.offset2}`;
		}
		delta(t) {
			return 0 === t ? this : new e(this.offset1 + t, this.offset2 + t);
		}
		equals(e) {
			return this.offset1 === e.offset1 && this.offset2 === e.offset2;
		}
	}, ur = class e {
		static {
			this.instance = new e();
		}
		isValid() {
			return !0;
		}
	}, mr = class {
		constructor(e) {
			if (this.timeout = e, this.startTime = Date.now(), this.valid = !0, e <= 0) throw new o("timeout must be positive");
		}
		isValid() {
			return Date.now() - this.startTime < this.timeout || !this.valid || (this.valid = !1), this.valid;
		}
	}, pr = class {
		constructor(e, t) {
			this.width = e, this.height = t, this.array = [], this.array = new Array(e * t);
		}
		get(e, t) {
			return this.array[e + t * this.width];
		}
		set(e, t, n) {
			this.array[e + t * this.width] = n;
		}
	};
	function gr(e) {
		return 32 === e || 9 === e;
	}
	var fr = class e {
		static {
			this.chrKeys = /* @__PURE__ */ new Map();
		}
		static getKey(e) {
			let t = this.chrKeys.get(e);
			return void 0 === t && (t = this.chrKeys.size, this.chrKeys.set(e, t)), t;
		}
		constructor(t, n, i) {
			this.range = t, this.lines = n, this.source = i, this.histogram = [];
			let r = 0;
			for (let a = t.startLineNumber - 1; a < t.endLineNumberExclusive - 1; a++) {
				const t = n[a];
				for (let n = 0; n < t.length; n++) {
					r++;
					const i = t[n], a = e.getKey(i);
					this.histogram[a] = (this.histogram[a] || 0) + 1;
				}
				r++;
				const i = e.getKey("\n");
				this.histogram[i] = (this.histogram[i] || 0) + 1;
			}
			this.totalCount = r;
		}
		computeSimilarity(e) {
			let t = 0;
			const n = Math.max(this.histogram.length, e.histogram.length);
			for (let i = 0; i < n; i++) t += Math.abs((this.histogram[i] ?? 0) - (e.histogram[i] ?? 0));
			return 1 - t / (this.totalCount + e.totalCount);
		}
	}, br = class {
		compute(e, t, n = ur.instance, i) {
			if (0 === e.length || 0 === t.length) return cr.trivial(e, t);
			const r = new pr(e.length, t.length), a = new pr(e.length, t.length), o = new pr(e.length, t.length);
			for (let m = 0; m < e.length; m++) for (let s = 0; s < t.length; s++) {
				if (!n.isValid()) return cr.trivialTimedOut(e, t);
				const l = 0 === m ? 0 : r.get(m - 1, s), c = 0 === s ? 0 : r.get(m, s - 1);
				let h;
				e.getElement(m) === t.getElement(s) ? (h = 0 === m || 0 === s ? 0 : r.get(m - 1, s - 1), m > 0 && s > 0 && 3 === a.get(m - 1, s - 1) && (h += o.get(m - 1, s - 1)), h += i ? i(m, s) : 1) : h = -1;
				const d = Math.max(l, c, h);
				if (d === h) {
					const e = m > 0 && s > 0 ? o.get(m - 1, s - 1) : 0;
					o.set(m, s, e + 1), a.set(m, s, 3);
				} else d === l ? (o.set(m, s, 0), a.set(m, s, 1)) : d === c && (o.set(m, s, 0), a.set(m, s, 2));
				r.set(m, s, d);
			}
			const s = [];
			let l = e.length, c = t.length;
			function h(e, t) {
				e + 1 === l && t + 1 === c || s.push(new hr(new Ni(e + 1, l), new Ni(t + 1, c))), l = e, c = t;
			}
			let d = e.length - 1, u = t.length - 1;
			for (; d >= 0 && u >= 0;) 3 === a.get(d, u) ? (h(d, u), d--, u--) : 1 === a.get(d, u) ? d-- : u--;
			return h(-1, -1), s.reverse(), new cr(s, !1);
		}
	}, _r = class {
		compute(e, t, n = ur.instance) {
			if (0 === e.length || 0 === t.length) return cr.trivial(e, t);
			const i = e, r = t;
			function a(e, t) {
				for (; e < i.length && t < r.length && i.getElement(e) === r.getElement(t);) e++, t++;
				return e;
			}
			let o = 0;
			const s = new vr();
			s.set(0, a(0, 0));
			const l = new yr();
			l.set(0, 0 === s.get(0) ? null : new wr(null, 0, 0, s.get(0)));
			let c = 0;
			e: for (;;) {
				if (o++, !n.isValid()) return cr.trivialTimedOut(i, r);
				const e = -Math.min(o, r.length + o % 2), t = Math.min(o, i.length + o % 2);
				for (c = e; c <= t; c += 2) {
					const n = c === t ? -1 : s.get(c + 1), o = c === e ? -1 : s.get(c - 1) + 1, h = Math.min(Math.max(n, o), i.length), d = h - c;
					if (h > i.length || d > r.length) continue;
					const u = a(h, d);
					s.set(c, u);
					const m = h === n ? l.get(c + 1) : l.get(c - 1);
					if (l.set(c, u !== h ? new wr(m, h, d, u - h) : m), s.get(c) === i.length && s.get(c) - c === r.length) break e;
				}
			}
			let h = l.get(c);
			const d = [];
			let u = i.length, m = r.length;
			for (;;) {
				const e = h ? h.x + h.length : 0, t = h ? h.y + h.length : 0;
				if (e === u && t === m || d.push(new hr(new Ni(e, u), new Ni(t, m))), !h) break;
				u = h.x, m = h.y, h = h.prev;
			}
			return d.reverse(), new cr(d, !1);
		}
	}, wr = class {
		constructor(e, t, n, i) {
			this.prev = e, this.x = t, this.y = n, this.length = i;
		}
	}, vr = class {
		constructor() {
			this.positiveArr = new Int32Array(10), this.negativeArr = new Int32Array(10);
		}
		get(e) {
			return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e];
		}
		set(e, t) {
			if (e < 0) {
				if ((e = -e - 1) >= this.negativeArr.length) {
					const e = this.negativeArr;
					this.negativeArr = new Int32Array(2 * e.length), this.negativeArr.set(e);
				}
				this.negativeArr[e] = t;
			} else {
				if (e >= this.positiveArr.length) {
					const e = this.positiveArr;
					this.positiveArr = new Int32Array(2 * e.length), this.positiveArr.set(e);
				}
				this.positiveArr[e] = t;
			}
		}
	}, yr = class {
		constructor() {
			this.positiveArr = [], this.negativeArr = [];
		}
		get(e) {
			return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e];
		}
		set(e, t) {
			e < 0 ? (e = -e - 1, this.negativeArr[e] = t) : this.positiveArr[e] = t;
		}
	}, Tr = class {
		constructor(e, t, n) {
			this.lines = e, this.range = t, this.considerWhitespaceChanges = n, this.elements = [], this.firstElementOffsetByLineIdx = [], this.lineStartOffsets = [], this.trimmedWsLengthsByLineIdx = [], this.firstElementOffsetByLineIdx.push(0);
			for (let i = this.range.startLineNumber; i <= this.range.endLineNumber; i++) {
				let t = e[i - 1], r = 0;
				i === this.range.startLineNumber && this.range.startColumn > 1 && (r = this.range.startColumn - 1, t = t.substring(r)), this.lineStartOffsets.push(r);
				let a = 0;
				if (!n) {
					const e = t.trimStart();
					a = t.length - e.length, t = e.trimEnd();
				}
				this.trimmedWsLengthsByLineIdx.push(a);
				const o = i === this.range.endLineNumber ? Math.min(this.range.endColumn - 1 - r - a, t.length) : t.length;
				for (let e = 0; e < o; e++) this.elements.push(t.charCodeAt(e));
				i < this.range.endLineNumber && (this.elements.push("\n".charCodeAt(0)), this.firstElementOffsetByLineIdx.push(this.elements.length));
			}
		}
		toString() {
			return `Slice: "${this.text}"`;
		}
		get text() {
			return this.getText(new Ni(0, this.length));
		}
		getText(e) {
			return this.elements.slice(e.start, e.endExclusive).map((e) => String.fromCharCode(e)).join("");
		}
		getElement(e) {
			return this.elements[e];
		}
		get length() {
			return this.elements.length;
		}
		getBoundaryScore(e) {
			const t = Cr(e > 0 ? this.elements[e - 1] : -1), n = Cr(e < this.elements.length ? this.elements[e] : -1);
			if (7 === t && 8 === n) return 0;
			if (8 === t) return 150;
			let i = 0;
			return t !== n && (i += 10, 0 === t && 1 === n && (i += 1)), i += xr(t), i += xr(n), i;
		}
		translateOffset(e, t = "right") {
			const n = zi(this.firstElementOffsetByLineIdx, (t) => t <= e), i = e - this.firstElementOffsetByLineIdx[n];
			return new He(this.range.startLineNumber + n, 1 + this.lineStartOffsets[n] + i + (0 === i && "left" === t ? 0 : this.trimmedWsLengthsByLineIdx[n]));
		}
		translateRange(e) {
			const t = this.translateOffset(e.start, "right"), n = this.translateOffset(e.endExclusive, "left");
			return n.isBefore(t) ? De.fromPositions(n, n) : De.fromPositions(t, n);
		}
		findWordContaining(e) {
			if (e < 0 || e >= this.elements.length) return;
			if (!kr(this.elements[e])) return;
			let t = e;
			for (; t > 0 && kr(this.elements[t - 1]);) t--;
			let n = e;
			for (; n < this.elements.length && kr(this.elements[n]);) n++;
			return new Ni(t, n);
		}
		findSubWordContaining(e) {
			if (e < 0 || e >= this.elements.length) return;
			if (!kr(this.elements[e])) return;
			let t = e;
			for (; t > 0 && kr(this.elements[t - 1]) && !Sr(this.elements[t]);) t--;
			let n = e;
			for (; n < this.elements.length && kr(this.elements[n]) && !Sr(this.elements[n]);) n++;
			return new Ni(t, n);
		}
		countLinesIn(e) {
			return this.translateOffset(e.endExclusive).lineNumber - this.translateOffset(e.start).lineNumber;
		}
		isStronglyEqual(e, t) {
			return this.elements[e] === this.elements[t];
		}
		extendToFullLines(e) {
			return new Ni(Ii(this.firstElementOffsetByLineIdx, (t) => t <= e.start) ?? 0, function(e, t) {
				const n = Oi(e, t);
				return n === e.length ? void 0 : e[n];
			}(this.firstElementOffsetByLineIdx, (t) => e.endExclusive <= t) ?? this.elements.length);
		}
	};
	function kr(e) {
		return e >= 97 && e <= 122 || e >= 65 && e <= 90 || e >= 48 && e <= 57;
	}
	function Sr(e) {
		return e >= 65 && e <= 90;
	}
	const Lr = {
		0: 0,
		1: 0,
		2: 0,
		3: 10,
		4: 2,
		5: 30,
		6: 3,
		7: 10,
		8: 10
	};
	function xr(e) {
		return Lr[e];
	}
	function Cr(e) {
		return 10 === e ? 8 : 13 === e ? 7 : gr(e) ? 6 : e >= 97 && e <= 122 ? 0 : e >= 65 && e <= 90 ? 1 : e >= 48 && e <= 57 ? 2 : -1 === e ? 3 : 44 === e || 59 === e ? 5 : 4;
	}
	function Er(e, t, n, i, r, a) {
		let { moves: o, excludedChanges: s } = function(e, t, n, i) {
			const r = [], a = e.filter((e) => e.modified.isEmpty && e.original.length >= 3).map((e) => new fr(e.original, t, e)), o = new Set(e.filter((e) => e.original.isEmpty && e.modified.length >= 3).map((e) => new fr(e.modified, n, e))), s = /* @__PURE__ */ new Set();
			for (const l of a) {
				let e, t = -1;
				for (const n of o) {
					const i = l.computeSimilarity(n);
					i > t && (t = i, e = n);
				}
				if (t > .9 && e && (o.delete(e), r.push(new Gi(l.range, e.range)), s.add(l.source), s.add(e.source)), !i.isValid()) return {
					moves: r,
					excludedChanges: s
				};
			}
			return {
				moves: r,
				excludedChanges: s
			};
		}(e, t, n, a);
		if (!a.isValid()) return [];
		const l = function(e, t, n, i, r, a) {
			const o = [], s = new ui();
			for (const m of e) for (let e = m.original.startLineNumber; e < m.original.endLineNumberExclusive - 2; e++) {
				const n = `${t[e - 1]}:${t[e + 1 - 1]}:${t[e + 2 - 1]}`;
				s.add(n, { range: new Hi(e, e + 3) });
			}
			const l = [];
			e.sort(Ri((e) => e.modified.startLineNumber, Mi));
			for (const m of e) {
				let e = [];
				for (let t = m.modified.startLineNumber; t < m.modified.endLineNumberExclusive - 2; t++) {
					const i = `${n[t - 1]}:${n[t + 1 - 1]}:${n[t + 2 - 1]}`, r = new Hi(t, t + 3), a = [];
					s.forEach(i, ({ range: t }) => {
						for (const i of e) if (i.originalLineRange.endLineNumberExclusive + 1 === t.endLineNumberExclusive && i.modifiedLineRange.endLineNumberExclusive + 1 === r.endLineNumberExclusive) return i.originalLineRange = new Hi(i.originalLineRange.startLineNumber, t.endLineNumberExclusive), i.modifiedLineRange = new Hi(i.modifiedLineRange.startLineNumber, r.endLineNumberExclusive), void a.push(i);
						const n = {
							modifiedLineRange: r,
							originalLineRange: t
						};
						l.push(n), a.push(n);
					}), e = a;
				}
				if (!a.isValid()) return [];
			}
			l.sort((c = Ri((e) => e.modifiedLineRange.length, Mi), (e, t) => -c(e, t)));
			var c;
			const h = new Di(), d = new Di();
			for (const m of l) {
				const e = m.modifiedLineRange.startLineNumber - m.originalLineRange.startLineNumber, t = h.subtractFrom(m.modifiedLineRange), n = d.subtractFrom(m.originalLineRange).getWithDelta(e), i = t.getIntersection(n);
				for (const r of i.ranges) {
					if (r.length < 3) continue;
					const t = r, n = r.delta(-e);
					o.push(new Gi(n, t)), h.addRange(t), d.addRange(n);
				}
			}
			o.sort(Ri((e) => e.original.startLineNumber, Mi));
			const u = new Ui(e);
			for (let m = 0; m < o.length; m++) {
				const t = o[m], n = u.findLastMonotonous((e) => e.original.startLineNumber <= t.original.startLineNumber), s = Ii(e, (e) => e.modified.startLineNumber <= t.modified.startLineNumber), l = Math.max(t.original.startLineNumber - n.original.startLineNumber, t.modified.startLineNumber - s.modified.startLineNumber), c = u.findLastMonotonous((e) => e.original.startLineNumber < t.original.endLineNumberExclusive), p = Ii(e, (e) => e.modified.startLineNumber < t.modified.endLineNumberExclusive), g = Math.max(c.original.endLineNumberExclusive - t.original.endLineNumberExclusive, p.modified.endLineNumberExclusive - t.modified.endLineNumberExclusive);
				let f, b;
				for (f = 0; f < l; f++) {
					const e = t.original.startLineNumber - f - 1, n = t.modified.startLineNumber - f - 1;
					if (e > i.length || n > r.length) break;
					if (h.contains(n) || d.contains(e)) break;
					if (!Ar(i[e - 1], r[n - 1], a)) break;
				}
				for (f > 0 && (d.addRange(new Hi(t.original.startLineNumber - f, t.original.startLineNumber)), h.addRange(new Hi(t.modified.startLineNumber - f, t.modified.startLineNumber))), b = 0; b < g; b++) {
					const e = t.original.endLineNumberExclusive + b, n = t.modified.endLineNumberExclusive + b;
					if (e > i.length || n > r.length) break;
					if (h.contains(n) || d.contains(e)) break;
					if (!Ar(i[e - 1], r[n - 1], a)) break;
				}
				b > 0 && (d.addRange(new Hi(t.original.endLineNumberExclusive, t.original.endLineNumberExclusive + b)), h.addRange(new Hi(t.modified.endLineNumberExclusive, t.modified.endLineNumberExclusive + b))), (f > 0 || b > 0) && (o[m] = new Gi(new Hi(t.original.startLineNumber - f, t.original.endLineNumberExclusive + b), new Hi(t.modified.startLineNumber - f, t.modified.endLineNumberExclusive + b)));
			}
			return o;
		}(e.filter((e) => !s.has(e)), i, r, t, n, a);
		return function(e, t) {
			for (const n of t) e.push(n);
		}(o, l), o = function(e) {
			if (0 === e.length) return e;
			e.sort(Ri((e) => e.original.startLineNumber, Mi));
			const t = [e[0]];
			for (let n = 1; n < e.length; n++) {
				const i = t[t.length - 1], r = e[n], a = r.original.startLineNumber - i.original.endLineNumberExclusive, o = r.modified.startLineNumber - i.modified.endLineNumberExclusive;
				a >= 0 && o >= 0 && a + o <= 2 ? t[t.length - 1] = i.join(r) : t.push(r);
			}
			return t;
		}(o), o = o.filter((e) => {
			const n = e.original.toOffsetRange().slice(t).map((e) => e.trim());
			return n.join("\n").length >= 15 && function(e, t) {
				let n = 0;
				for (const i of e) t(i) && n++;
				return n;
			}(n, (e) => e.length >= 2) >= 2;
		}), o = function(e, t) {
			const n = new Ui(e);
			return t = t.filter((t) => (n.findLastMonotonous((e) => e.original.startLineNumber < t.original.endLineNumberExclusive) || new Gi(new Hi(1, 1), new Hi(1, 1))) !== Ii(e, (e) => e.modified.startLineNumber < t.modified.endLineNumberExclusive)), t;
		}(e, o), o;
	}
	function Ar(e, t, n) {
		if (e.trim() === t.trim()) return !0;
		if (e.length > 300 && t.length > 300) return !1;
		const i = new _r().compute(new Tr([e], new De(1, 1, 1, e.length), !1), new Tr([t], new De(1, 1, 1, t.length), !1), n);
		let r = 0;
		const a = hr.invert(i.diffs, e.length);
		for (const s of a) s.seq1Range.forEach((t) => {
			gr(e.charCodeAt(t)) || r++;
		});
		const o = function(t) {
			let n = 0;
			for (let i = 0; i < e.length; i++) gr(t.charCodeAt(i)) || n++;
			return n;
		}(e.length > t.length ? e : t);
		return r / o > .6 && o > 10;
	}
	function Rr(e, t, n) {
		let i = n;
		return i = Mr(e, t, i), i = Mr(e, t, i), i = function(e, t, n) {
			if (!e.getBoundaryScore || !t.getBoundaryScore) return n;
			for (let i = 0; i < n.length; i++) {
				const r = i > 0 ? n[i - 1] : void 0, a = n[i], o = i + 1 < n.length ? n[i + 1] : void 0, s = new Ni(r ? r.seq1Range.endExclusive + 1 : 0, o ? o.seq1Range.start - 1 : e.length), l = new Ni(r ? r.seq2Range.endExclusive + 1 : 0, o ? o.seq2Range.start - 1 : t.length);
				a.seq1Range.isEmpty ? n[i] = Nr(a, e, t, s, l) : a.seq2Range.isEmpty && (n[i] = Nr(a.swap(), t, e, l, s).swap());
			}
			return n;
		}(e, t, i), i;
	}
	function Mr(e, t, n) {
		if (0 === n.length) return n;
		const i = [];
		i.push(n[0]);
		for (let a = 1; a < n.length; a++) {
			const r = i[i.length - 1];
			let o = n[a];
			if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
				const n = o.seq1Range.start - r.seq1Range.endExclusive;
				let a;
				for (a = 1; a <= n && e.getElement(o.seq1Range.start - a) === e.getElement(o.seq1Range.endExclusive - a) && t.getElement(o.seq2Range.start - a) === t.getElement(o.seq2Range.endExclusive - a); a++);
				if (a--, a === n) {
					i[i.length - 1] = new hr(new Ni(r.seq1Range.start, o.seq1Range.endExclusive - n), new Ni(r.seq2Range.start, o.seq2Range.endExclusive - n));
					continue;
				}
				o = o.delta(-a);
			}
			i.push(o);
		}
		const r = [];
		for (let a = 0; a < i.length - 1; a++) {
			const n = i[a + 1];
			let o = i[a];
			if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
				const r = n.seq1Range.start - o.seq1Range.endExclusive;
				let s;
				for (s = 0; s < r && e.isStronglyEqual(o.seq1Range.start + s, o.seq1Range.endExclusive + s) && t.isStronglyEqual(o.seq2Range.start + s, o.seq2Range.endExclusive + s); s++);
				if (s === r) {
					i[a + 1] = new hr(new Ni(o.seq1Range.start + r, n.seq1Range.endExclusive), new Ni(o.seq2Range.start + r, n.seq2Range.endExclusive));
					continue;
				}
				s > 0 && (o = o.delta(s));
			}
			r.push(o);
		}
		return i.length > 0 && r.push(i[i.length - 1]), r;
	}
	function Nr(e, t, n, i, r) {
		let a = 1;
		for (; e.seq1Range.start - a >= i.start && e.seq2Range.start - a >= r.start && n.isStronglyEqual(e.seq2Range.start - a, e.seq2Range.endExclusive - a) && a < 100;) a++;
		a--;
		let o = 0;
		for (; e.seq1Range.start + o < i.endExclusive && e.seq2Range.endExclusive + o < r.endExclusive && n.isStronglyEqual(e.seq2Range.start + o, e.seq2Range.endExclusive + o) && o < 100;) o++;
		if (0 === a && 0 === o) return e;
		let s = 0, l = -1;
		for (let c = -a; c <= o; c++) {
			const i = e.seq2Range.start + c, r = e.seq2Range.endExclusive + c, a = e.seq1Range.start + c, o = t.getBoundaryScore(a) + n.getBoundaryScore(i) + n.getBoundaryScore(r);
			o > l && (l = o, s = c);
		}
		return e.delta(s);
	}
	function Ir(e, t, n, i, r = !1) {
		const a = hr.invert(n, e.length), o = [];
		let s = new dr(0, 0);
		function l(n, l) {
			if (n.offset1 < s.offset1 || n.offset2 < s.offset2) return;
			const c = i(e, n.offset1), h = i(t, n.offset2);
			if (!c || !h) return;
			let d = new hr(c, h);
			const u = d.intersect(l);
			let m = u.seq1Range.length, p = u.seq2Range.length;
			for (; a.length > 0;) {
				const n = a[0];
				if (!n.seq1Range.intersects(d.seq1Range) && !n.seq2Range.intersects(d.seq2Range)) break;
				const r = new hr(i(e, n.seq1Range.start), i(t, n.seq2Range.start)), o = r.intersect(n);
				if (m += o.seq1Range.length, p += o.seq2Range.length, d = d.join(r), !(d.seq1Range.endExclusive >= n.seq1Range.endExclusive)) break;
				a.shift();
			}
			(r && m + p < d.seq1Range.length + d.seq2Range.length || m + p < 2 * (d.seq1Range.length + d.seq2Range.length) / 3) && o.push(d), s = d.getEndExclusives();
		}
		for (; a.length > 0;) {
			const e = a.shift();
			e.seq1Range.isEmpty || (l(e.getStarts(), e), l(e.getEndExclusives().delta(-1), e));
		}
		return function(e, t) {
			const n = [];
			for (; e.length > 0 || t.length > 0;) {
				const i = e[0], r = t[0];
				let a;
				a = i && (!r || i.seq1Range.start < r.seq1Range.start) ? e.shift() : t.shift(), n.length > 0 && n[n.length - 1].seq1Range.endExclusive >= a.seq1Range.start ? n[n.length - 1] = n[n.length - 1].join(a) : n.push(a);
			}
			return n;
		}(n, o);
	}
	var zr = class {
		constructor(e, t) {
			this.trimmedHash = e, this.lines = t;
		}
		getElement(e) {
			return this.trimmedHash[e];
		}
		get length() {
			return this.trimmedHash.length;
		}
		getBoundaryScore(e) {
			return 1e3 - ((0 === e ? 0 : Or(this.lines[e - 1])) + (e === this.lines.length ? 0 : Or(this.lines[e])));
		}
		getText(e) {
			return this.lines.slice(e.start, e.endExclusive).join("\n");
		}
		isStronglyEqual(e, t) {
			return this.lines[e] === this.lines[t];
		}
	};
	function Or(e) {
		let t = 0;
		for (; t < e.length && (32 === e.charCodeAt(t) || 9 === e.charCodeAt(t));) t++;
		return t;
	}
	var Ur = class {
		constructor() {
			this.dynamicProgrammingDiffing = new br(), this.myersDiffingAlgorithm = new _r();
		}
		computeDiff(e, t, n) {
			if (e.length <= 1 && function(e, t, n = (e, t) => e === t) {
				if (e === t) return !0;
				if (!e || !t) return !1;
				if (e.length !== t.length) return !1;
				for (let i = 0, r = e.length; i < r; i++) if (!n(e[i], t[i])) return !1;
				return !0;
			}(e, t, (e, t) => e === t)) return new Ei([], [], !1);
			if (1 === e.length && 0 === e[0].length || 1 === t.length && 0 === t[0].length) return new Ei([new Ji(new Hi(1, e.length + 1), new Hi(1, t.length + 1), [new Yi(new De(1, 1, e.length, e[e.length - 1].length + 1), new De(1, 1, t.length, t[t.length - 1].length + 1))])], [], !1);
			const i = 0 === n.maxComputationTimeMs ? ur.instance : new mr(n.maxComputationTimeMs), r = !n.ignoreTrimWhitespace, a = /* @__PURE__ */ new Map();
			function o(e) {
				let t = a.get(e);
				return void 0 === t && (t = a.size, a.set(e, t)), t;
			}
			const s = e.map((e) => o(e.trim())), c = t.map((e) => o(e.trim())), h = new zr(s, e), d = new zr(c, t), u = h.length + d.length < 1700 ? this.dynamicProgrammingDiffing.compute(h, d, i, (n, i) => e[n] === t[i] ? 0 === t[i].length ? .1 : 1 + Math.log(1 + t[i].length) : .99) : this.myersDiffingAlgorithm.compute(h, d, i);
			let m = u.diffs, p = u.hitTimeout;
			m = Rr(h, d, m), m = function(e, t, n) {
				let i = n;
				if (0 === i.length) return i;
				let r, a = 0;
				do {
					r = !1;
					const o = [i[0]];
					for (let s = 1; s < i.length; s++) {
						const l = i[s], c = o[o.length - 1];
						function h(t, n) {
							const i = new Ni(c.seq1Range.endExclusive, l.seq1Range.start);
							return e.getText(i).replace(/\s/g, "").length <= 4 && (t.seq1Range.length + t.seq2Range.length > 5 || n.seq1Range.length + n.seq2Range.length > 5);
						}
						h(c, l) ? (r = !0, o[o.length - 1] = o[o.length - 1].join(l)) : o.push(l);
					}
					i = o;
				} while (a++ < 10 && r);
				return i;
			}(h, 0, m);
			const g = [], f = (a) => {
				if (r) for (let o = 0; o < a; o++) {
					const a = b + o, s = _ + o;
					if (e[a] !== t[s]) {
						const o = this.refineDiff(e, t, new hr(new Ni(a, a + 1), new Ni(s, s + 1)), i, r, n);
						for (const e of o.mappings) g.push(e);
						o.hitTimeout && (p = !0);
					}
				}
			};
			let b = 0, _ = 0;
			for (const y of m) {
				l(() => y.seq1Range.start - b === y.seq2Range.start - _), f(y.seq1Range.start - b), b = y.seq1Range.endExclusive, _ = y.seq2Range.endExclusive;
				const a = this.refineDiff(e, t, y, i, r, n);
				a.hitTimeout && (p = !0);
				for (const e of a.mappings) g.push(e);
			}
			f(e.length - b);
			const w = Qi(g, new Ki(e), new Ki(t));
			let v = [];
			return n.computeMoves && (v = this.computeMoves(w, e, t, s, c, i, r, n)), l(() => {
				function n(e, t) {
					if (e.lineNumber < 1 || e.lineNumber > t.length) return !1;
					const n = t[e.lineNumber - 1];
					return !(e.column < 1 || e.column > n.length + 1);
				}
				function i(e, t) {
					return !(e.startLineNumber < 1 || e.startLineNumber > t.length + 1) && !(e.endLineNumberExclusive < 1 || e.endLineNumberExclusive > t.length + 1);
				}
				for (const r of w) {
					if (!r.innerChanges) return !1;
					for (const i of r.innerChanges) if (!(n(i.modifiedRange.getStartPosition(), t) && n(i.modifiedRange.getEndPosition(), t) && n(i.originalRange.getStartPosition(), e) && n(i.originalRange.getEndPosition(), e))) return !1;
					if (!i(r.modified, t) || !i(r.original, e)) return !1;
				}
				return !0;
			}), new Ei(w, v, p);
		}
		computeMoves(e, t, n, i, r, a, o, s) {
			return Er(e, t, n, i, r, a).map((e) => new Ai(e, Qi(this.refineDiff(t, n, new hr(e.original.toOffsetRange(), e.modified.toOffsetRange()), a, o, s).mappings, new Ki(t), new Ki(n), !0)));
		}
		refineDiff(e, t, n, i, r, a) {
			const o = (s = n, new Gi(new Hi(s.seq1Range.start + 1, s.seq1Range.endExclusive + 1), new Hi(s.seq2Range.start + 1, s.seq2Range.endExclusive + 1))).toRangeMapping2(e, t);
			var s;
			const l = new Tr(e, o.originalRange, r), c = new Tr(t, o.modifiedRange, r), h = l.length + c.length < 500 ? this.dynamicProgrammingDiffing.compute(l, c, i) : this.myersDiffingAlgorithm.compute(l, c, i);
			let d = h.diffs;
			return d = Rr(l, c, d), d = Ir(l, c, d, (e, t) => e.findWordContaining(t)), a.extendToSubwords && (d = Ir(l, c, d, (e, t) => e.findSubWordContaining(t), !0)), d = function(e, t, n) {
				const i = [];
				for (const r of n) {
					const e = i[i.length - 1];
					e && (r.seq1Range.start - e.seq1Range.endExclusive <= 2 || r.seq2Range.start - e.seq2Range.endExclusive <= 2) ? i[i.length - 1] = new hr(e.seq1Range.join(r.seq1Range), e.seq2Range.join(r.seq2Range)) : i.push(r);
				}
				return i;
			}(0, 0, d), d = function(e, t, n) {
				let i = n;
				if (0 === i.length) return i;
				let r, a = 0;
				do {
					r = !1;
					const s = [i[0]];
					for (let l = 1; l < i.length; l++) {
						const c = i[l], h = s[s.length - 1];
						function d(n, i) {
							const r = new Ni(h.seq1Range.endExclusive, c.seq1Range.start);
							if (e.countLinesIn(r) > 5 || r.length > 500) return !1;
							const a = e.getText(r).trim();
							if (a.length > 20 || a.split(/\r\n|\r|\n/).length > 1) return !1;
							const o = e.countLinesIn(n.seq1Range), s = n.seq1Range.length, l = t.countLinesIn(n.seq2Range), d = n.seq2Range.length, u = e.countLinesIn(i.seq1Range), m = i.seq1Range.length, p = t.countLinesIn(i.seq2Range), g = i.seq2Range.length;
							function f(e) {
								return Math.min(e, 130);
							}
							return Math.pow(Math.pow(f(40 * o + s), 1.5) + Math.pow(f(40 * l + d), 1.5), 1.5) + Math.pow(Math.pow(f(40 * u + m), 1.5) + Math.pow(f(40 * p + g), 1.5), 1.5) > 74184.96480721243;
						}
						d(h, c) ? (r = !0, s[s.length - 1] = s[s.length - 1].join(c)) : s.push(c);
					}
					i = s;
				} while (a++ < 10 && r);
				const o = [];
				return function(e, t) {
					for (let n = 0; n < e.length; n++) t(0 === n ? void 0 : e[n - 1], e[n], n + 1 === e.length ? void 0 : e[n + 1]);
				}(i, (t, n, i) => {
					let r = n;
					function a(e) {
						return e.length > 0 && e.trim().length <= 3 && n.seq1Range.length + n.seq2Range.length > 100;
					}
					const s = e.extendToFullLines(n.seq1Range), l = e.getText(new Ni(s.start, n.seq1Range.start));
					a(l) && (r = r.deltaStart(-l.length));
					const c = e.getText(new Ni(n.seq1Range.endExclusive, s.endExclusive));
					a(c) && (r = r.deltaEnd(c.length));
					const h = hr.fromOffsetPairs(t ? t.getEndExclusives() : dr.zero, i ? i.getStarts() : dr.max), d = r.intersect(h);
					o.length > 0 && d.getStarts().equals(o[o.length - 1].getEndExclusives()) ? o[o.length - 1] = o[o.length - 1].join(d) : o.push(d);
				}), o;
			}(l, c, d), {
				mappings: d.map((e) => new Yi(l.translateRange(e.seq1Range), c.translateRange(e.seq2Range))),
				hitTimeout: h.hitTimeout
			};
		}
	};
	const Hr = () => new Zi(), Dr = () => new Ur();
	function Wr(e, t) {
		const n = Math.pow(10, t);
		return Math.round(e * n) / n;
	}
	var Pr = class {
		constructor(e, t, n, i = 1) {
			this._rgbaBrand = void 0, this.r = 0 | Math.min(255, Math.max(0, e)), this.g = 0 | Math.min(255, Math.max(0, t)), this.b = 0 | Math.min(255, Math.max(0, n)), this.a = Wr(Math.max(Math.min(1, i), 0), 3);
		}
		static equals(e, t) {
			return e.r === t.r && e.g === t.g && e.b === t.b && e.a === t.a;
		}
	}, qr = class e {
		constructor(e, t, n, i) {
			this._hslaBrand = void 0, this.h = 0 | Math.max(Math.min(360, e), 0), this.s = Wr(Math.max(Math.min(1, t), 0), 3), this.l = Wr(Math.max(Math.min(1, n), 0), 3), this.a = Wr(Math.max(Math.min(1, i), 0), 3);
		}
		static equals(e, t) {
			return e.h === t.h && e.s === t.s && e.l === t.l && e.a === t.a;
		}
		static fromRGBA(t) {
			const n = t.r / 255, i = t.g / 255, r = t.b / 255, a = t.a, o = Math.max(n, i, r), s = Math.min(n, i, r);
			let l = 0, c = 0;
			const h = (s + o) / 2, d = o - s;
			if (d > 0) {
				switch (c = Math.min(h <= .5 ? d / (2 * h) : d / (2 - 2 * h), 1), o) {
					case n:
						l = (i - r) / d + (i < r ? 6 : 0);
						break;
					case i:
						l = (r - n) / d + 2;
						break;
					case r: l = (n - i) / d + 4;
				}
				l *= 60, l = Math.round(l);
			}
			return new e(l, c, h, a);
		}
		static _hue2rgb(e, t, n) {
			return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + 6 * (t - e) * n : n < .5 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
		}
		static toRGBA(t) {
			const n = t.h / 360, { s: i, l: r, a } = t;
			let o, s, l;
			if (0 === i) o = s = l = r;
			else {
				const t = r < .5 ? r * (1 + i) : r + i - r * i, a = 2 * r - t;
				o = e._hue2rgb(a, t, n + 1 / 3), s = e._hue2rgb(a, t, n), l = e._hue2rgb(a, t, n - 1 / 3);
			}
			return new Pr(Math.round(255 * o), Math.round(255 * s), Math.round(255 * l), a);
		}
	}, Fr = class e {
		constructor(e, t, n, i) {
			this._hsvaBrand = void 0, this.h = 0 | Math.max(Math.min(360, e), 0), this.s = Wr(Math.max(Math.min(1, t), 0), 3), this.v = Wr(Math.max(Math.min(1, n), 0), 3), this.a = Wr(Math.max(Math.min(1, i), 0), 3);
		}
		static equals(e, t) {
			return e.h === t.h && e.s === t.s && e.v === t.v && e.a === t.a;
		}
		static fromRGBA(t) {
			const n = t.r / 255, i = t.g / 255, r = t.b / 255, a = Math.max(n, i, r), o = a - Math.min(n, i, r), s = 0 === a ? 0 : o / a;
			let l;
			return l = 0 === o ? 0 : a === n ? ((i - r) / o % 6 + 6) % 6 : a === i ? (r - n) / o + 2 : (n - i) / o + 4, new e(Math.round(60 * l), s, a, t.a);
		}
		static toRGBA(e) {
			const { h: t, s: n, v: i, a: r } = e, a = i * n, o = a * (1 - Math.abs(t / 60 % 2 - 1)), s = i - a;
			let [l, c, h] = [
				0,
				0,
				0
			];
			return t < 60 ? (l = a, c = o) : t < 120 ? (l = o, c = a) : t < 180 ? (c = a, h = o) : t < 240 ? (c = o, h = a) : t < 300 ? (l = o, h = a) : t <= 360 && (l = a, h = o), l = Math.round(255 * (l + s)), c = Math.round(255 * (c + s)), h = Math.round(255 * (h + s)), new Pr(l, c, h, r);
		}
	}, Vr = class e {
		static fromHex(t) {
			return e.Format.CSS.parseHex(t) || e.red;
		}
		static equals(e, t) {
			return !e && !t || !(!e || !t) && e.equals(t);
		}
		get hsla() {
			return this._hsla ? this._hsla : qr.fromRGBA(this.rgba);
		}
		get hsva() {
			return this._hsva ? this._hsva : Fr.fromRGBA(this.rgba);
		}
		constructor(e) {
			if (!e) throw new Error("Color needs a value");
			if (e instanceof Pr) this.rgba = e;
			else if (e instanceof qr) this._hsla = e, this.rgba = qr.toRGBA(e);
			else {
				if (!(e instanceof Fr)) throw new Error("Invalid color ctor argument");
				this._hsva = e, this.rgba = Fr.toRGBA(e);
			}
		}
		equals(e) {
			return !!e && Pr.equals(this.rgba, e.rgba) && qr.equals(this.hsla, e.hsla) && Fr.equals(this.hsva, e.hsva);
		}
		getRelativeLuminance() {
			return Wr(.2126 * e._relativeLuminanceForComponent(this.rgba.r) + .7152 * e._relativeLuminanceForComponent(this.rgba.g) + .0722 * e._relativeLuminanceForComponent(this.rgba.b), 4);
		}
		static _relativeLuminanceForComponent(e) {
			const t = e / 255;
			return t <= .03928 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4);
		}
		isLighter() {
			return (299 * this.rgba.r + 587 * this.rgba.g + 114 * this.rgba.b) / 1e3 >= 128;
		}
		isLighterThan(e) {
			return this.getRelativeLuminance() > e.getRelativeLuminance();
		}
		isDarkerThan(e) {
			return this.getRelativeLuminance() < e.getRelativeLuminance();
		}
		lighten(t) {
			return new e(new qr(this.hsla.h, this.hsla.s, this.hsla.l + this.hsla.l * t, this.hsla.a));
		}
		darken(t) {
			return new e(new qr(this.hsla.h, this.hsla.s, this.hsla.l - this.hsla.l * t, this.hsla.a));
		}
		transparent(t) {
			const { r: n, g: i, b: r, a } = this.rgba;
			return new e(new Pr(n, i, r, a * t));
		}
		isTransparent() {
			return 0 === this.rgba.a;
		}
		isOpaque() {
			return 1 === this.rgba.a;
		}
		opposite() {
			return new e(new Pr(255 - this.rgba.r, 255 - this.rgba.g, 255 - this.rgba.b, this.rgba.a));
		}
		mix(t, n = .5) {
			const i = Math.min(Math.max(n, 0), 1), r = this.rgba, a = t.rgba;
			return new e(new Pr(r.r + (a.r - r.r) * i, r.g + (a.g - r.g) * i, r.b + (a.b - r.b) * i, r.a + (a.a - r.a) * i));
		}
		makeOpaque(t) {
			if (this.isOpaque() || 1 !== t.rgba.a) return this;
			const { r: n, g: i, b: r, a } = this.rgba;
			return new e(new Pr(t.rgba.r - a * (t.rgba.r - n), t.rgba.g - a * (t.rgba.g - i), t.rgba.b - a * (t.rgba.b - r), 1));
		}
		toString() {
			return this._toString || (this._toString = e.Format.CSS.format(this)), this._toString;
		}
		toNumber32Bit() {
			return this._toNumber32Bit || (this._toNumber32Bit = (this.rgba.r << 24 | this.rgba.g << 16 | this.rgba.b << 8 | 255 * this.rgba.a) >>> 0), this._toNumber32Bit;
		}
		static getLighterColor(e, t, n) {
			if (e.isLighterThan(t)) return e;
			n = n || .5;
			const i = e.getRelativeLuminance(), r = t.getRelativeLuminance();
			return n = n * (r - i) / r, e.lighten(n);
		}
		static getDarkerColor(e, t, n) {
			if (e.isDarkerThan(t)) return e;
			n = n || .5;
			const i = e.getRelativeLuminance();
			return n = n * (i - t.getRelativeLuminance()) / i, e.darken(n);
		}
		static {
			this.white = new e(new Pr(255, 255, 255, 1));
		}
		static {
			this.black = new e(new Pr(0, 0, 0, 1));
		}
		static {
			this.red = new e(new Pr(255, 0, 0, 1));
		}
		static {
			this.blue = new e(new Pr(0, 0, 255, 1));
		}
		static {
			this.green = new e(new Pr(0, 255, 0, 1));
		}
		static {
			this.cyan = new e(new Pr(0, 255, 255, 1));
		}
		static {
			this.lightgrey = new e(new Pr(211, 211, 211, 1));
		}
		static {
			this.transparent = new e(new Pr(0, 0, 0, 0));
		}
	};
	function Br(e) {
		const t = [];
		for (const n of e) {
			const e = Number(n);
			(e || 0 === e && "" !== n.replace(/\s/g, "")) && t.push(e);
		}
		return t;
	}
	function Kr(e, t, n, i) {
		return {
			red: e / 255,
			blue: n / 255,
			green: t / 255,
			alpha: i
		};
	}
	function jr(e, t) {
		const n = t.index, i = t[0].length;
		if (void 0 === n) return;
		const r = e.positionAt(n);
		return {
			startLineNumber: r.lineNumber,
			startColumn: r.column,
			endLineNumber: r.lineNumber,
			endColumn: r.column + i
		};
	}
	function Gr(e, t) {
		if (!e) return;
		const n = Vr.Format.CSS.parseHex(t);
		return n ? {
			range: e,
			color: Kr(n.rgba.r, n.rgba.g, n.rgba.b, n.rgba.a)
		} : void 0;
	}
	function $r(e, t, n) {
		if (!e || 1 !== t.length) return;
		const i = Br(t[0].values());
		return {
			range: e,
			color: Kr(i[0], i[1], i[2], n ? i[3] : 1)
		};
	}
	function Xr(e, t, n) {
		if (!e || 1 !== t.length) return;
		const i = Br(t[0].values()), r = new Vr(new qr(i[0], i[1] / 100, i[2] / 100, n ? i[3] : 1));
		return {
			range: e,
			color: Kr(r.rgba.r, r.rgba.g, r.rgba.b, r.rgba.a)
		};
	}
	function Jr(e, t) {
		return "string" == typeof e ? [...e.matchAll(t)] : e.findMatches(t);
	}
	function Yr(e) {
		return e && "function" == typeof e.getValue && "function" == typeof e.positionAt ? function(e) {
			const t = [], n = Jr(e, /\b(rgb|rgba|hsl|hsla)(\([0-9\s,.\%]*\))|^(#)([A-Fa-f0-9]{3})\b|^(#)([A-Fa-f0-9]{4})\b|^(#)([A-Fa-f0-9]{6})\b|^(#)([A-Fa-f0-9]{8})\b|(?<=['"\s])(#)([A-Fa-f0-9]{3})\b|(?<=['"\s])(#)([A-Fa-f0-9]{4})\b|(?<=['"\s])(#)([A-Fa-f0-9]{6})\b|(?<=['"\s])(#)([A-Fa-f0-9]{8})\b/gm);
			if (n.length > 0) for (const i of n) {
				const n = i.filter((e) => void 0 !== e), r = n[1], a = n[2];
				if (!a) continue;
				let o;
				"rgb" === r ? o = $r(jr(e, i), Jr(a, /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*\)$/gm), !1) : "rgba" === r ? o = $r(jr(e, i), Jr(a, /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(0[.][0-9]+|[.][0-9]+|[01][.]|[01])\s*\)$/gm), !0) : "hsl" === r ? o = Xr(jr(e, i), Jr(a, /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*\)$/gm), !1) : "hsla" === r ? o = Xr(jr(e, i), Jr(a, /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(0[.][0-9]+|[.][0-9]+|[01][.]0*|[01])\s*\)$/gm), !0) : "#" === r && (o = Gr(jr(e, i), r + a)), o && t.push(o);
			}
			return t;
		}(e) : [];
	}
	(function(e) {
		var t;
		(function(t) {
			function n(e) {
				const t = e.toString(16);
				return 2 !== t.length ? "0" + t : t;
			}
			function i(t) {
				const n = t.length;
				if (0 === n) return null;
				if (35 !== t.charCodeAt(0)) return null;
				if (7 === n) return new e(new Pr(16 * r(t.charCodeAt(1)) + r(t.charCodeAt(2)), 16 * r(t.charCodeAt(3)) + r(t.charCodeAt(4)), 16 * r(t.charCodeAt(5)) + r(t.charCodeAt(6)), 1));
				if (9 === n) return new e(new Pr(16 * r(t.charCodeAt(1)) + r(t.charCodeAt(2)), 16 * r(t.charCodeAt(3)) + r(t.charCodeAt(4)), 16 * r(t.charCodeAt(5)) + r(t.charCodeAt(6)), (16 * r(t.charCodeAt(7)) + r(t.charCodeAt(8))) / 255));
				if (4 === n) {
					const n = r(t.charCodeAt(1)), i = r(t.charCodeAt(2)), a = r(t.charCodeAt(3));
					return new e(new Pr(16 * n + n, 16 * i + i, 16 * a + a));
				}
				if (5 === n) {
					const n = r(t.charCodeAt(1)), i = r(t.charCodeAt(2)), a = r(t.charCodeAt(3)), o = r(t.charCodeAt(4));
					return new e(new Pr(16 * n + n, 16 * i + i, 16 * a + a, (16 * o + o) / 255));
				}
				return null;
			}
			function r(e) {
				switch (e) {
					case 48: return 0;
					case 49: return 1;
					case 50: return 2;
					case 51: return 3;
					case 52: return 4;
					case 53: return 5;
					case 54: return 6;
					case 55: return 7;
					case 56: return 8;
					case 57: return 9;
					case 97:
					case 65: return 10;
					case 98:
					case 66: return 11;
					case 99:
					case 67: return 12;
					case 100:
					case 68: return 13;
					case 101:
					case 69: return 14;
					case 102:
					case 70: return 15;
				}
				return 0;
			}
			t.formatRGB = function(t) {
				return 1 === t.rgba.a ? `rgb(${t.rgba.r}, ${t.rgba.g}, ${t.rgba.b})` : e.Format.CSS.formatRGBA(t);
			}, t.formatRGBA = function(e) {
				return `rgba(${e.rgba.r}, ${e.rgba.g}, ${e.rgba.b}, ${+e.rgba.a.toFixed(2)})`;
			}, t.formatHSL = function(t) {
				return 1 === t.hsla.a ? `hsl(${t.hsla.h}, ${Math.round(100 * t.hsla.s)}%, ${Math.round(100 * t.hsla.l)}%)` : e.Format.CSS.formatHSLA(t);
			}, t.formatHSLA = function(e) {
				return `hsla(${e.hsla.h}, ${Math.round(100 * e.hsla.s)}%, ${Math.round(100 * e.hsla.l)}%, ${e.hsla.a.toFixed(2)})`;
			}, t.formatHex = function(e) {
				return `#${n(e.rgba.r)}${n(e.rgba.g)}${n(e.rgba.b)}`;
			}, t.formatHexA = function(t, i = !1) {
				return i && 1 === t.rgba.a ? e.Format.CSS.formatHex(t) : `#${n(t.rgba.r)}${n(t.rgba.g)}${n(t.rgba.b)}${n(Math.round(255 * t.rgba.a))}`;
			}, t.format = function(t) {
				return t.isOpaque() ? e.Format.CSS.formatHex(t) : e.Format.CSS.formatRGBA(t);
			}, t.parse = function(t) {
				if ("transparent" === t) return e.transparent;
				if (t.startsWith("#")) return i(t);
				if (t.startsWith("rgba(")) {
					const n = t.match(/rgba\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+), *(?<a>(?:\+|-)?\d+(\.\d+)?)\)/);
					if (!n) throw new Error("Invalid color format " + t);
					return new e(new Pr(parseInt(n.groups?.r ?? "0"), parseInt(n.groups?.g ?? "0"), parseInt(n.groups?.b ?? "0"), parseFloat(n.groups?.a ?? "0")));
				}
				if (t.startsWith("rgb(")) {
					const n = t.match(/rgb\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+)\)/);
					if (!n) throw new Error("Invalid color format " + t);
					return new e(new Pr(parseInt(n.groups?.r ?? "0"), parseInt(n.groups?.g ?? "0"), parseInt(n.groups?.b ?? "0")));
				}
				return function(t) {
					switch (t) {
						case "aliceblue": return new e(new Pr(240, 248, 255, 1));
						case "antiquewhite": return new e(new Pr(250, 235, 215, 1));
						case "aqua":
						case "cyan": return new e(new Pr(0, 255, 255, 1));
						case "aquamarine": return new e(new Pr(127, 255, 212, 1));
						case "azure": return new e(new Pr(240, 255, 255, 1));
						case "beige": return new e(new Pr(245, 245, 220, 1));
						case "bisque": return new e(new Pr(255, 228, 196, 1));
						case "black": return new e(new Pr(0, 0, 0, 1));
						case "blanchedalmond": return new e(new Pr(255, 235, 205, 1));
						case "blue": return new e(new Pr(0, 0, 255, 1));
						case "blueviolet": return new e(new Pr(138, 43, 226, 1));
						case "brown": return new e(new Pr(165, 42, 42, 1));
						case "burlywood": return new e(new Pr(222, 184, 135, 1));
						case "cadetblue": return new e(new Pr(95, 158, 160, 1));
						case "chartreuse": return new e(new Pr(127, 255, 0, 1));
						case "chocolate": return new e(new Pr(210, 105, 30, 1));
						case "coral": return new e(new Pr(255, 127, 80, 1));
						case "cornflowerblue": return new e(new Pr(100, 149, 237, 1));
						case "cornsilk": return new e(new Pr(255, 248, 220, 1));
						case "crimson": return new e(new Pr(220, 20, 60, 1));
						case "darkblue": return new e(new Pr(0, 0, 139, 1));
						case "darkcyan": return new e(new Pr(0, 139, 139, 1));
						case "darkgoldenrod": return new e(new Pr(184, 134, 11, 1));
						case "darkgray":
						case "darkgrey": return new e(new Pr(169, 169, 169, 1));
						case "darkgreen": return new e(new Pr(0, 100, 0, 1));
						case "darkkhaki": return new e(new Pr(189, 183, 107, 1));
						case "darkmagenta": return new e(new Pr(139, 0, 139, 1));
						case "darkolivegreen": return new e(new Pr(85, 107, 47, 1));
						case "darkorange": return new e(new Pr(255, 140, 0, 1));
						case "darkorchid": return new e(new Pr(153, 50, 204, 1));
						case "darkred": return new e(new Pr(139, 0, 0, 1));
						case "darksalmon": return new e(new Pr(233, 150, 122, 1));
						case "darkseagreen": return new e(new Pr(143, 188, 143, 1));
						case "darkslateblue": return new e(new Pr(72, 61, 139, 1));
						case "darkslategray":
						case "darkslategrey": return new e(new Pr(47, 79, 79, 1));
						case "darkturquoise": return new e(new Pr(0, 206, 209, 1));
						case "darkviolet": return new e(new Pr(148, 0, 211, 1));
						case "deeppink": return new e(new Pr(255, 20, 147, 1));
						case "deepskyblue": return new e(new Pr(0, 191, 255, 1));
						case "dimgray":
						case "dimgrey": return new e(new Pr(105, 105, 105, 1));
						case "dodgerblue": return new e(new Pr(30, 144, 255, 1));
						case "firebrick": return new e(new Pr(178, 34, 34, 1));
						case "floralwhite": return new e(new Pr(255, 250, 240, 1));
						case "forestgreen": return new e(new Pr(34, 139, 34, 1));
						case "fuchsia":
						case "magenta": return new e(new Pr(255, 0, 255, 1));
						case "gainsboro": return new e(new Pr(220, 220, 220, 1));
						case "ghostwhite": return new e(new Pr(248, 248, 255, 1));
						case "gold": return new e(new Pr(255, 215, 0, 1));
						case "goldenrod": return new e(new Pr(218, 165, 32, 1));
						case "gray":
						case "grey": return new e(new Pr(128, 128, 128, 1));
						case "green": return new e(new Pr(0, 128, 0, 1));
						case "greenyellow": return new e(new Pr(173, 255, 47, 1));
						case "honeydew": return new e(new Pr(240, 255, 240, 1));
						case "hotpink": return new e(new Pr(255, 105, 180, 1));
						case "indianred": return new e(new Pr(205, 92, 92, 1));
						case "indigo": return new e(new Pr(75, 0, 130, 1));
						case "ivory": return new e(new Pr(255, 255, 240, 1));
						case "khaki": return new e(new Pr(240, 230, 140, 1));
						case "lavender": return new e(new Pr(230, 230, 250, 1));
						case "lavenderblush": return new e(new Pr(255, 240, 245, 1));
						case "lawngreen": return new e(new Pr(124, 252, 0, 1));
						case "lemonchiffon": return new e(new Pr(255, 250, 205, 1));
						case "lightblue": return new e(new Pr(173, 216, 230, 1));
						case "lightcoral": return new e(new Pr(240, 128, 128, 1));
						case "lightcyan": return new e(new Pr(224, 255, 255, 1));
						case "lightgoldenrodyellow": return new e(new Pr(250, 250, 210, 1));
						case "lightgray":
						case "lightgrey": return new e(new Pr(211, 211, 211, 1));
						case "lightgreen": return new e(new Pr(144, 238, 144, 1));
						case "lightpink": return new e(new Pr(255, 182, 193, 1));
						case "lightsalmon": return new e(new Pr(255, 160, 122, 1));
						case "lightseagreen": return new e(new Pr(32, 178, 170, 1));
						case "lightskyblue": return new e(new Pr(135, 206, 250, 1));
						case "lightslategray":
						case "lightslategrey": return new e(new Pr(119, 136, 153, 1));
						case "lightsteelblue": return new e(new Pr(176, 196, 222, 1));
						case "lightyellow": return new e(new Pr(255, 255, 224, 1));
						case "lime": return new e(new Pr(0, 255, 0, 1));
						case "limegreen": return new e(new Pr(50, 205, 50, 1));
						case "linen": return new e(new Pr(250, 240, 230, 1));
						case "maroon": return new e(new Pr(128, 0, 0, 1));
						case "mediumaquamarine": return new e(new Pr(102, 205, 170, 1));
						case "mediumblue": return new e(new Pr(0, 0, 205, 1));
						case "mediumorchid": return new e(new Pr(186, 85, 211, 1));
						case "mediumpurple": return new e(new Pr(147, 112, 219, 1));
						case "mediumseagreen": return new e(new Pr(60, 179, 113, 1));
						case "mediumslateblue": return new e(new Pr(123, 104, 238, 1));
						case "mediumspringgreen": return new e(new Pr(0, 250, 154, 1));
						case "mediumturquoise": return new e(new Pr(72, 209, 204, 1));
						case "mediumvioletred": return new e(new Pr(199, 21, 133, 1));
						case "midnightblue": return new e(new Pr(25, 25, 112, 1));
						case "mintcream": return new e(new Pr(245, 255, 250, 1));
						case "mistyrose": return new e(new Pr(255, 228, 225, 1));
						case "moccasin": return new e(new Pr(255, 228, 181, 1));
						case "navajowhite": return new e(new Pr(255, 222, 173, 1));
						case "navy": return new e(new Pr(0, 0, 128, 1));
						case "oldlace": return new e(new Pr(253, 245, 230, 1));
						case "olive": return new e(new Pr(128, 128, 0, 1));
						case "olivedrab": return new e(new Pr(107, 142, 35, 1));
						case "orange": return new e(new Pr(255, 165, 0, 1));
						case "orangered": return new e(new Pr(255, 69, 0, 1));
						case "orchid": return new e(new Pr(218, 112, 214, 1));
						case "palegoldenrod": return new e(new Pr(238, 232, 170, 1));
						case "palegreen": return new e(new Pr(152, 251, 152, 1));
						case "paleturquoise": return new e(new Pr(175, 238, 238, 1));
						case "palevioletred": return new e(new Pr(219, 112, 147, 1));
						case "papayawhip": return new e(new Pr(255, 239, 213, 1));
						case "peachpuff": return new e(new Pr(255, 218, 185, 1));
						case "peru": return new e(new Pr(205, 133, 63, 1));
						case "pink": return new e(new Pr(255, 192, 203, 1));
						case "plum": return new e(new Pr(221, 160, 221, 1));
						case "powderblue": return new e(new Pr(176, 224, 230, 1));
						case "purple": return new e(new Pr(128, 0, 128, 1));
						case "rebeccapurple": return new e(new Pr(102, 51, 153, 1));
						case "red": return new e(new Pr(255, 0, 0, 1));
						case "rosybrown": return new e(new Pr(188, 143, 143, 1));
						case "royalblue": return new e(new Pr(65, 105, 225, 1));
						case "saddlebrown": return new e(new Pr(139, 69, 19, 1));
						case "salmon": return new e(new Pr(250, 128, 114, 1));
						case "sandybrown": return new e(new Pr(244, 164, 96, 1));
						case "seagreen": return new e(new Pr(46, 139, 87, 1));
						case "seashell": return new e(new Pr(255, 245, 238, 1));
						case "sienna": return new e(new Pr(160, 82, 45, 1));
						case "silver": return new e(new Pr(192, 192, 192, 1));
						case "skyblue": return new e(new Pr(135, 206, 235, 1));
						case "slateblue": return new e(new Pr(106, 90, 205, 1));
						case "slategray":
						case "slategrey": return new e(new Pr(112, 128, 144, 1));
						case "snow": return new e(new Pr(255, 250, 250, 1));
						case "springgreen": return new e(new Pr(0, 255, 127, 1));
						case "steelblue": return new e(new Pr(70, 130, 180, 1));
						case "tan": return new e(new Pr(210, 180, 140, 1));
						case "teal": return new e(new Pr(0, 128, 128, 1));
						case "thistle": return new e(new Pr(216, 191, 216, 1));
						case "tomato": return new e(new Pr(255, 99, 71, 1));
						case "turquoise": return new e(new Pr(64, 224, 208, 1));
						case "violet": return new e(new Pr(238, 130, 238, 1));
						case "wheat": return new e(new Pr(245, 222, 179, 1));
						case "white": return new e(new Pr(255, 255, 255, 1));
						case "whitesmoke": return new e(new Pr(245, 245, 245, 1));
						case "yellow": return new e(new Pr(255, 255, 0, 1));
						case "yellowgreen": return new e(new Pr(154, 205, 50, 1));
						default: return null;
					}
				}(t);
			}, t.parseHex = i;
		})((t = e.Format || (e.Format = {})).CSS || (t.CSS = {}));
	})(Vr || (Vr = {}));
	const Qr = /^-+|-+$/g, Zr = 100;
	function ea(e, t) {
		let n = [];
		if (t.findRegionSectionHeaders && t.foldingRules?.markers) {
			const i = function(e, t) {
				const n = [], i = e.getLineCount();
				for (let r = 1; r <= i; r++) {
					const i = e.getLineContent(r), a = i.match(t.foldingRules.markers.start);
					if (a) {
						const e = {
							startLineNumber: r,
							startColumn: a[0].length + 1,
							endLineNumber: r,
							endColumn: i.length + 1
						};
						if (e.endColumn > e.startColumn) {
							const t = {
								range: e,
								...ta(i.substring(a[0].length)),
								shouldBeInComments: !1
							};
							(t.text || t.hasSeparatorLine) && n.push(t);
						}
					}
				}
				return n;
			}(e, t);
			n = n.concat(i);
		}
		if (t.findMarkSectionHeaders) {
			const i = function(e, t) {
				const n = [], i = e.getLineCount();
				if (!t.markSectionHeaderRegex || "" === t.markSectionHeaderRegex.trim()) return n;
				const r = function(e) {
					if (!e || 0 === e.length) return !1;
					for (let t = 0, n = e.length; t < n; t++) {
						const i = e.charCodeAt(t);
						if (10 === i) return !0;
						if (92 === i) {
							if (t++, t >= n) break;
							const i = e.charCodeAt(t);
							if (110 === i || 114 === i || 87 === i) return !0;
						}
					}
					return !1;
				}(t.markSectionHeaderRegex), a = new RegExp(t.markSectionHeaderRegex, "gdm" + (r ? "s" : ""));
				if (o = a, "^" !== o.source && "^$" !== o.source && "$" !== o.source && "^\\s*$" !== o.source && o.exec("") && 0 === o.lastIndex) return n;
				var o;
				for (let s = 1; s <= i; s += 95) {
					const t = Math.min(s + Zr - 1, i), r = [];
					for (let n = s; n <= t; n++) r.push(e.getLineContent(n));
					const o = r.join("\n");
					let l;
					for (a.lastIndex = 0; null !== (l = a.exec(o));) {
						const e = o.substring(0, l.index), t = s + (e.match(/\n/g) || []).length, i = l[0].split("\n"), r = i.length, c = t + r - 1, h = e.lastIndexOf("\n") + 1, d = l.index - h + 1, u = i[i.length - 1], m = {
							range: {
								startLineNumber: t,
								startColumn: d,
								endLineNumber: c,
								endColumn: 1 === r ? d + l[0].length : u.length + 1
							},
							text: (l.groups ?? {}).label ?? "",
							hasSeparatorLine: "" !== ((l.groups ?? {}).separator ?? ""),
							shouldBeInComments: !0
						};
						(m.text || m.hasSeparatorLine) && (0 === n.length || n[n.length - 1].range.endLineNumber < m.range.startLineNumber) && n.push(m), a.lastIndex = l.index + l[0].length;
					}
				}
				return n;
			}(e, t);
			n = n.concat(i);
		}
		return n;
	}
	function ta(e) {
		const t = (e = e.trim()).startsWith("-");
		return {
			text: e = e.replace(Qr, ""),
			hasSeparatorLine: t
		};
	}
	(function() {
		const e = globalThis;
		"function" != typeof e.requestIdleCallback || e.cancelIdleCallback;
	})();
	var ra, aa = class {
		get isRejected() {
			return 1 === this.outcome?.outcome;
		}
		get isSettled() {
			return !!this.outcome;
		}
		constructor() {
			this.p = new Promise((e, t) => {
				this.completeCallback = e, this.errorCallback = t;
			});
		}
		complete(e) {
			return this.isSettled ? Promise.resolve() : new Promise((t) => {
				this.completeCallback(e), this.outcome = {
					outcome: 0,
					value: e
				}, t();
			});
		}
		error(e) {
			return this.isSettled ? Promise.resolve() : new Promise((t) => {
				this.errorCallback(e), this.outcome = {
					outcome: 1,
					value: e
				}, t();
			});
		}
		cancel() {
			return this.error(new r());
		}
	};
	(function(e) {
		e.settled = async function(e) {
			let t;
			const n = await Promise.all(e.map((e) => e.then((e) => e, (e) => {
				t || (t = e);
			})));
			if (void 0 !== t) throw t;
			return n;
		}, e.withAsyncBody = function(e) {
			return new Promise(async (t, n) => {
				try {
					await e(t, n);
				} catch (i) {
					n(i);
				}
			});
		};
	})(ra || (ra = {}));
	var oa = class {
		constructor() {
			this._unsatisfiedConsumers = [], this._unconsumedValues = [];
		}
		get hasFinalValue() {
			return !!this._finalValue;
		}
		produce(e) {
			if (this._ensureNoFinalValue(), this._unsatisfiedConsumers.length > 0) {
				const t = this._unsatisfiedConsumers.shift();
				this._resolveOrRejectDeferred(t, e);
			} else this._unconsumedValues.push(e);
		}
		produceFinal(e) {
			this._ensureNoFinalValue(), this._finalValue = e;
			for (const t of this._unsatisfiedConsumers) this._resolveOrRejectDeferred(t, e);
			this._unsatisfiedConsumers.length = 0;
		}
		_ensureNoFinalValue() {
			if (this._finalValue) throw new o("ProducerConsumer: cannot produce after final value has been set");
		}
		_resolveOrRejectDeferred(e, t) {
			t.ok ? e.complete(t.value) : e.error(t.error);
		}
		consume() {
			if (this._unconsumedValues.length > 0 || this._finalValue) {
				const e = this._unconsumedValues.length > 0 ? this._unconsumedValues.shift() : this._finalValue;
				return e.ok ? Promise.resolve(e.value) : Promise.reject(e.error);
			}
			{
				const e = new aa();
				return this._unsatisfiedConsumers.push(e), e.p;
			}
		}
	}, sa = (class e {
		constructor(e, t) {
			this._onReturn = t, this._producerConsumer = new oa(), this._iterator = {
				next: () => this._producerConsumer.consume(),
				return: () => (this._onReturn?.(), Promise.resolve({
					done: !0,
					value: void 0
				})),
				throw: async (e) => (this._finishError(e), {
					done: !0,
					value: void 0
				})
			}, queueMicrotask(async () => {
				const t = e({
					emitOne: (e) => this._producerConsumer.produce({
						ok: !0,
						value: {
							done: !1,
							value: e
						}
					}),
					emitMany: (e) => {
						for (const t of e) this._producerConsumer.produce({
							ok: !0,
							value: {
								done: !1,
								value: t
							}
						});
					},
					reject: (e) => this._finishError(e)
				});
				if (!this._producerConsumer.hasFinalValue) try {
					await t, this._finishOk();
				} catch (n) {
					this._finishError(n);
				}
			});
		}
		static fromArray(t) {
			return new e((e) => {
				e.emitMany(t);
			});
		}
		static fromPromise(t) {
			return new e(async (e) => {
				e.emitMany(await t);
			});
		}
		static fromPromisesResolveOrder(t) {
			return new e(async (e) => {
				await Promise.all(t.map(async (t) => e.emitOne(await t)));
			});
		}
		static merge(t) {
			return new e(async (e) => {
				await Promise.all(t.map(async (t) => {
					for await (const n of t) e.emitOne(n);
				}));
			});
		}
		static {
			this.EMPTY = e.fromArray([]);
		}
		static map(t, n) {
			return new e(async (e) => {
				for await (const i of t) e.emitOne(n(i));
			});
		}
		map(t) {
			return e.map(this, t);
		}
		static coalesce(t) {
			return e.filter(t, (e) => !!e);
		}
		coalesce() {
			return e.coalesce(this);
		}
		static filter(t, n) {
			return new e(async (e) => {
				for await (const i of t) n(i) && e.emitOne(i);
			});
		}
		filter(t) {
			return e.filter(this, t);
		}
		_finishOk() {
			this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
				ok: !0,
				value: {
					done: !0,
					value: void 0
				}
			});
		}
		_finishError(e) {
			this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
				ok: !1,
				error: e
			});
		}
		[Symbol.asyncIterator]() {
			return this._iterator;
		}
	}, class {
		constructor(e) {
			this.values = e, this.prefixSum = new Uint32Array(e.length), this.prefixSumValidIndex = new Int32Array(1), this.prefixSumValidIndex[0] = -1;
		}
		insertValues(e, t) {
			e = Pe(e);
			const n = this.values, i = this.prefixSum, r = t.length;
			return 0 !== r && (this.values = new Uint32Array(n.length + r), this.values.set(n.subarray(0, e), 0), this.values.set(n.subarray(e), e + r), this.values.set(t, e), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSum = new Uint32Array(this.values.length), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(i.subarray(0, this.prefixSumValidIndex[0] + 1)), !0);
		}
		setValue(e, t) {
			return e = Pe(e), t = Pe(t), this.values[e] !== t && (this.values[e] = t, e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), !0);
		}
		removeValues(e, t) {
			e = Pe(e), t = Pe(t);
			const n = this.values, i = this.prefixSum;
			if (e >= n.length) return !1;
			const r = n.length - e;
			return t >= r && (t = r), 0 !== t && (this.values = new Uint32Array(n.length - t), this.values.set(n.subarray(0, e), 0), this.values.set(n.subarray(e + t), e), this.prefixSum = new Uint32Array(this.values.length), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(i.subarray(0, this.prefixSumValidIndex[0] + 1)), !0);
		}
		getTotalSum() {
			return 0 === this.values.length ? 0 : this._getPrefixSum(this.values.length - 1);
		}
		getPrefixSum(e) {
			return e < 0 ? 0 : (e = Pe(e), this._getPrefixSum(e));
		}
		_getPrefixSum(e) {
			if (e <= this.prefixSumValidIndex[0]) return this.prefixSum[e];
			let t = this.prefixSumValidIndex[0] + 1;
			0 === t && (this.prefixSum[0] = this.values[0], t++), e >= this.values.length && (e = this.values.length - 1);
			for (let n = t; n <= e; n++) this.prefixSum[n] = this.prefixSum[n - 1] + this.values[n];
			return this.prefixSumValidIndex[0] = Math.max(this.prefixSumValidIndex[0], e), this.prefixSum[e];
		}
		getIndexOf(e) {
			e = Math.floor(e), this.getTotalSum();
			let t = 0, n = this.values.length - 1, i = 0, r = 0, a = 0;
			for (; t <= n;) if (i = t + (n - t) / 2 | 0, r = this.prefixSum[i], a = r - this.values[i], e < a) n = i - 1;
			else {
				if (!(e >= r)) break;
				t = i + 1;
			}
			return new la(i, e - a);
		}
	}), la = class {
		constructor(e, t) {
			this.index = e, this.remainder = t, this._prefixSumIndexOfResultBrand = void 0, this.index = e, this.remainder = t;
		}
	}, ca = class {
		constructor(e, t, n, i) {
			this._uri = e, this._lines = t, this._eol = n, this._versionId = i, this._lineStarts = null, this._cachedTextValue = null;
		}
		dispose() {
			this._lines.length = 0;
		}
		get version() {
			return this._versionId;
		}
		getText() {
			return null === this._cachedTextValue && (this._cachedTextValue = this._lines.join(this._eol)), this._cachedTextValue;
		}
		onEvents(e) {
			e.eol && e.eol !== this._eol && (this._eol = e.eol, this._lineStarts = null);
			const t = e.changes;
			for (const n of t) this._acceptDeleteRange(n.range), this._acceptInsertText(new He(n.range.startLineNumber, n.range.startColumn), n.text);
			this._versionId = e.versionId, this._cachedTextValue = null;
		}
		_ensureLineStarts() {
			if (!this._lineStarts) {
				const e = this._eol.length, t = this._lines.length, n = new Uint32Array(t);
				for (let i = 0; i < t; i++) n[i] = this._lines[i].length + e;
				this._lineStarts = new sa(n);
			}
		}
		_setLineText(e, t) {
			this._lines[e] = t, this._lineStarts && this._lineStarts.setValue(e, this._lines[e].length + this._eol.length);
		}
		_acceptDeleteRange(e) {
			if (e.startLineNumber !== e.endLineNumber) this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.endLineNumber - 1].substring(e.endColumn - 1)), this._lines.splice(e.startLineNumber, e.endLineNumber - e.startLineNumber), this._lineStarts && this._lineStarts.removeValues(e.startLineNumber, e.endLineNumber - e.startLineNumber);
			else {
				if (e.startColumn === e.endColumn) return;
				this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.startLineNumber - 1].substring(e.endColumn - 1));
			}
		}
		_acceptInsertText(e, t) {
			if (0 === t.length) return;
			const n = t.split(/\r\n|\r|\n/);
			if (1 === n.length) return void this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + n[0] + this._lines[e.lineNumber - 1].substring(e.column - 1));
			n[n.length - 1] += this._lines[e.lineNumber - 1].substring(e.column - 1), this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + n[0]);
			const i = new Uint32Array(n.length - 1);
			for (let r = 1; r < n.length; r++) this._lines.splice(e.lineNumber + r - 1, 0, n[r]), i[r - 1] = n[r].length + this._eol.length;
			this._lineStarts && this._lineStarts.insertValues(e.lineNumber, i);
		}
	}, ha = class {
		constructor() {
			this._models = Object.create(null);
		}
		getModel(e) {
			return this._models[e];
		}
		getModels() {
			const e = [];
			return Object.keys(this._models).forEach((t) => e.push(this._models[t])), e;
		}
		$acceptNewModel(e) {
			this._models[e.url] = new da(It.parse(e.url), e.lines, e.EOL, e.versionId);
		}
		$acceptModelChanged(e, t) {
			this._models[e] && this._models[e].onEvents(t);
		}
		$acceptRemovedModel(e) {
			this._models[e] && delete this._models[e];
		}
	}, da = class extends ca {
		get uri() {
			return this._uri;
		}
		get eol() {
			return this._eol;
		}
		getValue() {
			return this.getText();
		}
		findMatches(e) {
			const t = [];
			for (let n = 0; n < this._lines.length; n++) {
				const i = this._lines[n], r = this.offsetAt(new He(n + 1, 1)), a = i.matchAll(e);
				for (const e of a) (e.index || 0 === e.index) && (e.index = e.index + r), t.push(e);
			}
			return t;
		}
		getLinesContent() {
			return this._lines.slice(0);
		}
		getLineCount() {
			return this._lines.length;
		}
		getLineContent(e) {
			return this._lines[e - 1];
		}
		getWordAtPosition(e, t) {
			const n = Ti(e.column, vi(t), this._lines[e.lineNumber - 1], 0);
			return n ? new De(e.lineNumber, n.startColumn, e.lineNumber, n.endColumn) : null;
		}
		words(e) {
			const t = this._lines, n = this._wordenize.bind(this);
			let i = 0, r = "", a = 0, o = [];
			return { *[Symbol.iterator]() {
				for (;;) if (a < o.length) {
					const e = r.substring(o[a].start, o[a].end);
					a += 1, yield e;
				} else {
					if (!(i < t.length)) break;
					r = t[i], o = n(r, e), a = 0, i += 1;
				}
			} };
		}
		getLineWords(e, t) {
			const n = this._lines[e - 1], i = this._wordenize(n, t), r = [];
			for (const a of i) r.push({
				word: n.substring(a.start, a.end),
				startColumn: a.start + 1,
				endColumn: a.end + 1
			});
			return r;
		}
		_wordenize(e, t) {
			const n = [];
			let i;
			for (t.lastIndex = 0; (i = t.exec(e)) && 0 !== i[0].length;) n.push({
				start: i.index,
				end: i.index + i[0].length
			});
			return n;
		}
		getValueInRange(e) {
			if ((e = this._validateRange(e)).startLineNumber === e.endLineNumber) return this._lines[e.startLineNumber - 1].substring(e.startColumn - 1, e.endColumn - 1);
			const t = this._eol, n = e.startLineNumber - 1, i = e.endLineNumber - 1, r = [];
			r.push(this._lines[n].substring(e.startColumn - 1));
			for (let a = n + 1; a < i; a++) r.push(this._lines[a]);
			return r.push(this._lines[i].substring(0, e.endColumn - 1)), r.join(t);
		}
		offsetAt(e) {
			return e = this._validatePosition(e), this._ensureLineStarts(), this._lineStarts.getPrefixSum(e.lineNumber - 2) + (e.column - 1);
		}
		positionAt(e) {
			e = Math.floor(e), e = Math.max(0, e), this._ensureLineStarts();
			const t = this._lineStarts.getIndexOf(e), n = this._lines[t.index].length;
			return {
				lineNumber: 1 + t.index,
				column: 1 + Math.min(t.remainder, n)
			};
		}
		_validateRange(e) {
			const t = this._validatePosition({
				lineNumber: e.startLineNumber,
				column: e.startColumn
			}), n = this._validatePosition({
				lineNumber: e.endLineNumber,
				column: e.endColumn
			});
			return t.lineNumber !== e.startLineNumber || t.column !== e.startColumn || n.lineNumber !== e.endLineNumber || n.column !== e.endColumn ? {
				startLineNumber: t.lineNumber,
				startColumn: t.column,
				endLineNumber: n.lineNumber,
				endColumn: n.column
			} : e;
		}
		_validatePosition(e) {
			if (!He.isIPosition(e)) throw new Error("bad position");
			let { lineNumber: t, column: n } = e, i = !1;
			if (t < 1) t = 1, n = 1, i = !0;
			else if (t > this._lines.length) t = this._lines.length, n = this._lines[t - 1].length + 1, i = !0;
			else {
				const e = this._lines[t - 1].length + 1;
				n < 1 ? (n = 1, i = !0) : n > e && (n = e, i = !0);
			}
			return i ? {
				lineNumber: t,
				column: n
			} : e;
		}
	}, ua = class e {
		constructor(e = null) {
			this._foreignModule = e, this._requestHandlerBrand = void 0, this._workerTextModelSyncServer = new ha();
		}
		dispose() {}
		async $ping() {
			return "pong";
		}
		_getModel(e) {
			return this._workerTextModelSyncServer.getModel(e);
		}
		getModels() {
			return this._workerTextModelSyncServer.getModels();
		}
		$acceptNewModel(e) {
			this._workerTextModelSyncServer.$acceptNewModel(e);
		}
		$acceptModelChanged(e, t) {
			this._workerTextModelSyncServer.$acceptModelChanged(e, t);
		}
		$acceptRemovedModel(e) {
			this._workerTextModelSyncServer.$acceptRemovedModel(e);
		}
		async $computeUnicodeHighlights(e, t, n) {
			const i = this._getModel(e);
			return i ? Si.computeUnicodeHighlights(i, t, n) : {
				ranges: [],
				hasMore: !1,
				ambiguousCharacterCount: 0,
				invisibleCharacterCount: 0,
				nonBasicAsciiCharacterCount: 0
			};
		}
		async $findSectionHeaders(e, t) {
			const n = this._getModel(e);
			return n ? ea(n, t) : [];
		}
		async $computeDiff(t, n, i, r) {
			const a = this._getModel(t), o = this._getModel(n);
			return a && o ? e.computeDiff(a, o, i, r) : null;
		}
		static computeDiff(e, t, n, i) {
			const r = "advanced" === i ? Dr() : Hr(), a = e.getLinesContent(), o = t.getLinesContent(), s = r.computeDiff(a, o, n);
			function l(e) {
				return e.map((e) => [
					e.original.startLineNumber,
					e.original.endLineNumberExclusive,
					e.modified.startLineNumber,
					e.modified.endLineNumberExclusive,
					e.innerChanges?.map((e) => [
						e.originalRange.startLineNumber,
						e.originalRange.startColumn,
						e.originalRange.endLineNumber,
						e.originalRange.endColumn,
						e.modifiedRange.startLineNumber,
						e.modifiedRange.startColumn,
						e.modifiedRange.endLineNumber,
						e.modifiedRange.endColumn
					])
				]);
			}
			return {
				identical: !(s.changes.length > 0) && this._modelsAreIdentical(e, t),
				quitEarly: s.hitTimeout,
				changes: l(s.changes),
				moves: s.moves.map((e) => [
					e.lineRangeMapping.original.startLineNumber,
					e.lineRangeMapping.original.endLineNumberExclusive,
					e.lineRangeMapping.modified.startLineNumber,
					e.lineRangeMapping.modified.endLineNumberExclusive,
					l(e.changes)
				])
			};
		}
		static _modelsAreIdentical(e, t) {
			const n = e.getLineCount();
			if (n !== t.getLineCount()) return !1;
			for (let i = 1; i <= n; i++) if (e.getLineContent(i) !== t.getLineContent(i)) return !1;
			return !0;
		}
		static {
			this._diffLimit = 1e5;
		}
		async $computeMoreMinimalEdits(t, n, i) {
			const r = this._getModel(t);
			if (!r) return n;
			const a = [];
			let o;
			n = n.slice(0).sort((e, t) => e.range && t.range ? De.compareRangesUsingStarts(e.range, t.range) : (e.range ? 0 : 1) - (t.range ? 0 : 1));
			let s = 0;
			for (let e = 1; e < n.length; e++) De.getEndPosition(n[s].range).equals(De.getStartPosition(n[e].range)) ? (n[s].range = De.fromPositions(De.getStartPosition(n[s].range), De.getEndPosition(n[e].range)), n[s].text += n[e].text) : (s++, n[s] = n[e]);
			n.length = s + 1;
			for (let { range: l, text: c, eol: h } of n) {
				if ("number" == typeof h && (o = h), De.isEmpty(l) && !c) continue;
				const t = r.getValueInRange(l);
				if (c = c.replace(/\r\n|\n|\r/g, r.eol), t === c) continue;
				if (Math.max(c.length, t.length) > e._diffLimit) {
					a.push({
						range: l,
						text: c
					});
					continue;
				}
				const n = Ne(t, c, i), s = r.offsetAt(De.lift(l).getStartPosition());
				for (const e of n) {
					const t = r.positionAt(s + e.originalStart), n = r.positionAt(s + e.originalStart + e.originalLength), i = {
						text: c.substr(e.modifiedStart, e.modifiedLength),
						range: {
							startLineNumber: t.lineNumber,
							startColumn: t.column,
							endLineNumber: n.lineNumber,
							endColumn: n.column
						}
					};
					r.getValueInRange(i.range) !== i.text && a.push(i);
				}
			}
			return "number" == typeof o && a.push({
				eol: o,
				text: "",
				range: {
					startLineNumber: 0,
					startColumn: 0,
					endLineNumber: 0,
					endColumn: 0
				}
			}), a;
		}
		async $computeLinks(e) {
			const t = this._getModel(e);
			return t ? function(e) {
				return e && "function" == typeof e.getLineCount && "function" == typeof e.getLineContent ? je.computeLinks(e) : [];
			}(t) : null;
		}
		async $computeDefaultDocumentColors(e) {
			const t = this._getModel(e);
			return t ? Yr(t) : null;
		}
		static {
			this._suggestionsLimit = 1e4;
		}
		async $textualSuggest(t, n, i, r) {
			const a = new v(), o = new RegExp(i, r), s = /* @__PURE__ */ new Set();
			e: for (const l of t) {
				const t = this._getModel(l);
				if (t) {
					for (const i of t.words(o)) if (i !== n && isNaN(Number(i)) && (s.add(i), s.size > e._suggestionsLimit)) break e;
				}
			}
			return {
				words: Array.from(s),
				duration: a.elapsed()
			};
		}
		async $computeWordRanges(e, t, n, i) {
			const r = this._getModel(e);
			if (!r) return Object.create(null);
			const a = new RegExp(n, i), o = Object.create(null);
			for (let s = t.startLineNumber; s < t.endLineNumber; s++) {
				const e = r.getLineWords(s, a);
				for (const t of e) {
					if (!isNaN(Number(t.word))) continue;
					let e = o[t.word];
					e || (e = [], o[t.word] = e), e.push({
						startLineNumber: s,
						startColumn: t.startColumn,
						endLineNumber: s,
						endColumn: t.endColumn
					});
				}
			}
			return o;
		}
		async $navigateValueSet(e, t, n, i, r) {
			const a = this._getModel(e);
			if (!a) return null;
			const o = new RegExp(i, r);
			t.startColumn === t.endColumn && (t = {
				startLineNumber: t.startLineNumber,
				startColumn: t.startColumn,
				endLineNumber: t.endLineNumber,
				endColumn: t.endColumn + 1
			});
			const s = a.getValueInRange(t), l = a.getWordAtPosition({
				lineNumber: t.startLineNumber,
				column: t.startColumn
			}, o);
			if (!l) return null;
			const c = a.getValueInRange(l);
			return Ge.INSTANCE.navigateValueSet(t, s, l, c, n);
		}
		$fmr(e, t) {
			if (!this._foreignModule || "function" != typeof this._foreignModule[e]) return Promise.reject(/* @__PURE__ */ new Error("Missing requestHandler or method: " + e));
			try {
				return Promise.resolve(this._foreignModule[e].apply(this._foreignModule, t));
			} catch (El) {
				return Promise.reject(El);
			}
		}
	};
	"function" == typeof importScripts && (globalThis.monaco = {
		editor: void 0,
		languages: void 0,
		CancellationTokenSource: Ye,
		Emitter: C,
		KeyCode: Nn,
		KeyMod: si,
		Position: He,
		Range: De,
		Selection: Bt,
		SelectionDirection: $n,
		MarkerSeverity: In,
		MarkerTag: zn,
		Uri: It,
		Token: rn
	});
	var ma = class e {
		static {
			this.CHANNEL_NAME = "editorWorkerHost";
		}
		static getChannel(t) {
			return t.getChannel(e.CHANNEL_NAME);
		}
		static setChannel(t, n) {
			t.setChannel(e.CHANNEL_NAME, n);
		}
	};
	function pa(e) {
		let t;
		const n = function(e) {
			if (ye) throw new Error("WebWorker already initialized!");
			ye = !0;
			const t = new ve((e) => globalThis.postMessage(e), (t) => e(t));
			return globalThis.onmessage = (e) => {
				t.onmessage(e.data);
			}, t;
		}((i) => {
			const r = ma.getChannel(i);
			return t = e({
				host: new Proxy({}, { get(e, t, n) {
					if ("then" !== t) {
						if ("string" != typeof t) throw new Error("Not supported");
						return (...e) => r.$fhr(t, e);
					}
				} }),
				getMirrorModels: () => n.requestHandler.getModels()
			}), new ua(t);
		});
		return t;
	}
	function fa(...e) {
		const t = e[0];
		let n, i, r;
		if ("string" == typeof t) n = t, i = t, e.splice(0, 1), r = e && "object" == typeof e[0] ? e[0] : e;
		else {
			if (t instanceof Array) {
				const n = e.slice(1);
				if (t.length !== n.length + 1) throw new Error("expected a string as the first argument to l10n.t");
				let i = t[0];
				for (let e = 1; e < t.length; e++) i += `{${e - 1}}` + t[e];
				return fa(i, ...n);
			}
			i = t.message, n = i, t.comment && t.comment.length > 0 && (n += `/${Array.isArray(t.comment) ? t.comment.join("") : t.comment}`), r = t.args ?? {};
		}
		return a = i, o = r, 0 === Object.keys(o).length ? a : a.replace(Vo, (e, t) => o[t] ?? e);
		var a, o;
	}
	var ba, _a, wa, va, ya, Ta, ka, Sa, La, xa, Ca, Ea, Aa, Ra, Ma, Na, Ia, za, Oa, Ua, Ha, Da, Wa, Pa, qa, Fa, Va, Ba, Ka, ja, Ga, $a, Xa, Ja, Ya, Qa, Za, eo, to, no, io, ro, ao, oo, so, lo, co, ho, uo, mo, po, go, fo, bo, _o, wo, vo, yo, To, ko, So, Lo, xo, Co, Eo, Ao, Ro, Mo, No, Io, zo, Oo, Uo, Ho, Do, Wo, Po, qo, Fo, Vo = /{([^}]+)}/g;
	(function(e) {
		e.is = function(e) {
			return "string" == typeof e;
		};
	})(ba || (ba = {})), function(e) {
		e.is = function(e) {
			return "string" == typeof e;
		};
	}(_a || (_a = {})), function(e) {
		e.MIN_VALUE = -2147483648, e.MAX_VALUE = 2147483647, e.is = function(t) {
			return "number" == typeof t && e.MIN_VALUE <= t && t <= e.MAX_VALUE;
		};
	}(wa || (wa = {})), function(e) {
		e.MIN_VALUE = 0, e.MAX_VALUE = 2147483647, e.is = function(t) {
			return "number" == typeof t && e.MIN_VALUE <= t && t <= e.MAX_VALUE;
		};
	}(va || (va = {})), function(e) {
		e.create = function(e, t) {
			return e === Number.MAX_VALUE && (e = va.MAX_VALUE), t === Number.MAX_VALUE && (t = va.MAX_VALUE), {
				line: e,
				character: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.objectLiteral(t) && Bo.uinteger(t.line) && Bo.uinteger(t.character);
		};
	}(ya || (ya = {})), function(e) {
		e.create = function(e, t, n, i) {
			if (Bo.uinteger(e) && Bo.uinteger(t) && Bo.uinteger(n) && Bo.uinteger(i)) return {
				start: ya.create(e, t),
				end: ya.create(n, i)
			};
			if (ya.is(e) && ya.is(t)) return {
				start: e,
				end: t
			};
			throw new Error(`Range#create called with invalid arguments[${e}, ${t}, ${n}, ${i}]`);
		}, e.is = function(e) {
			let t = e;
			return Bo.objectLiteral(t) && ya.is(t.start) && ya.is(t.end);
		};
	}(Ta || (Ta = {})), function(e) {
		e.create = function(e, t) {
			return {
				uri: e,
				range: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.objectLiteral(t) && Ta.is(t.range) && (Bo.string(t.uri) || Bo.undefined(t.uri));
		};
	}(ka || (ka = {})), function(e) {
		e.create = function(e, t, n, i) {
			return {
				targetUri: e,
				targetRange: t,
				targetSelectionRange: n,
				originSelectionRange: i
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.objectLiteral(t) && Ta.is(t.targetRange) && Bo.string(t.targetUri) && Ta.is(t.targetSelectionRange) && (Ta.is(t.originSelectionRange) || Bo.undefined(t.originSelectionRange));
		};
	}(Sa || (Sa = {})), function(e) {
		e.create = function(e, t, n, i) {
			return {
				red: e,
				green: t,
				blue: n,
				alpha: i
			};
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Bo.numberRange(t.red, 0, 1) && Bo.numberRange(t.green, 0, 1) && Bo.numberRange(t.blue, 0, 1) && Bo.numberRange(t.alpha, 0, 1);
		};
	}(La || (La = {})), function(e) {
		e.create = function(e, t) {
			return {
				range: e,
				color: t
			};
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Ta.is(t.range) && La.is(t.color);
		};
	}(xa || (xa = {})), function(e) {
		e.create = function(e, t, n) {
			return {
				label: e,
				textEdit: t,
				additionalTextEdits: n
			};
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Bo.string(t.label) && (Bo.undefined(t.textEdit) || Ua.is(t)) && (Bo.undefined(t.additionalTextEdits) || Bo.typedArray(t.additionalTextEdits, Ua.is));
		};
	}(Ca || (Ca = {})), function(e) {
		e.Comment = "comment", e.Imports = "imports", e.Region = "region";
	}(Ea || (Ea = {})), function(e) {
		e.create = function(e, t, n, i, r, a) {
			const o = {
				startLine: e,
				endLine: t
			};
			return Bo.defined(n) && (o.startCharacter = n), Bo.defined(i) && (o.endCharacter = i), Bo.defined(r) && (o.kind = r), Bo.defined(a) && (o.collapsedText = a), o;
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Bo.uinteger(t.startLine) && Bo.uinteger(t.startLine) && (Bo.undefined(t.startCharacter) || Bo.uinteger(t.startCharacter)) && (Bo.undefined(t.endCharacter) || Bo.uinteger(t.endCharacter)) && (Bo.undefined(t.kind) || Bo.string(t.kind));
		};
	}(Aa || (Aa = {})), function(e) {
		e.create = function(e, t) {
			return {
				location: e,
				message: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && ka.is(t.location) && Bo.string(t.message);
		};
	}(Ra || (Ra = {})), function(e) {
		e.Error = 1, e.Warning = 2, e.Information = 3, e.Hint = 4;
	}(Ma || (Ma = {})), function(e) {
		e.Unnecessary = 1, e.Deprecated = 2;
	}(Na || (Na = {})), function(e) {
		e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Bo.string(t.href);
		};
	}(Ia || (Ia = {})), function(e) {
		e.create = function(e, t, n, i, r, a) {
			let o = {
				range: e,
				message: t
			};
			return Bo.defined(n) && (o.severity = n), Bo.defined(i) && (o.code = i), Bo.defined(r) && (o.source = r), Bo.defined(a) && (o.relatedInformation = a), o;
		}, e.is = function(e) {
			var t;
			let n = e;
			return Bo.defined(n) && Ta.is(n.range) && Bo.string(n.message) && (Bo.number(n.severity) || Bo.undefined(n.severity)) && (Bo.integer(n.code) || Bo.string(n.code) || Bo.undefined(n.code)) && (Bo.undefined(n.codeDescription) || Bo.string(null === (t = n.codeDescription) || void 0 === t ? void 0 : t.href)) && (Bo.string(n.source) || Bo.undefined(n.source)) && (Bo.undefined(n.relatedInformation) || Bo.typedArray(n.relatedInformation, Ra.is));
		};
	}(za || (za = {})), function(e) {
		e.create = function(e, t, ...n) {
			let i = {
				title: e,
				command: t
			};
			return Bo.defined(n) && n.length > 0 && (i.arguments = n), i;
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.string(t.title) && Bo.string(t.command);
		};
	}(Oa || (Oa = {})), function(e) {
		e.replace = function(e, t) {
			return {
				range: e,
				newText: t
			};
		}, e.insert = function(e, t) {
			return {
				range: {
					start: e,
					end: e
				},
				newText: t
			};
		}, e.del = function(e) {
			return {
				range: e,
				newText: ""
			};
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Bo.string(t.newText) && Ta.is(t.range);
		};
	}(Ua || (Ua = {})), function(e) {
		e.create = function(e, t, n) {
			const i = { label: e };
			return void 0 !== t && (i.needsConfirmation = t), void 0 !== n && (i.description = n), i;
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && Bo.string(t.label) && (Bo.boolean(t.needsConfirmation) || void 0 === t.needsConfirmation) && (Bo.string(t.description) || void 0 === t.description);
		};
	}(Ha || (Ha = {})), function(e) {
		e.is = function(e) {
			const t = e;
			return Bo.string(t);
		};
	}(Da || (Da = {})), function(e) {
		e.replace = function(e, t, n) {
			return {
				range: e,
				newText: t,
				annotationId: n
			};
		}, e.insert = function(e, t, n) {
			return {
				range: {
					start: e,
					end: e
				},
				newText: t,
				annotationId: n
			};
		}, e.del = function(e, t) {
			return {
				range: e,
				newText: "",
				annotationId: t
			};
		}, e.is = function(e) {
			const t = e;
			return Ua.is(t) && (Ha.is(t.annotationId) || Da.is(t.annotationId));
		};
	}(Wa || (Wa = {})), function(e) {
		e.create = function(e, t) {
			return {
				textDocument: e,
				edits: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Ga.is(t.textDocument) && Array.isArray(t.edits);
		};
	}(Pa || (Pa = {})), function(e) {
		e.create = function(e, t, n) {
			let i = {
				kind: "create",
				uri: e
			};
			return void 0 === t || void 0 === t.overwrite && void 0 === t.ignoreIfExists || (i.options = t), void 0 !== n && (i.annotationId = n), i;
		}, e.is = function(e) {
			let t = e;
			return t && "create" === t.kind && Bo.string(t.uri) && (void 0 === t.options || (void 0 === t.options.overwrite || Bo.boolean(t.options.overwrite)) && (void 0 === t.options.ignoreIfExists || Bo.boolean(t.options.ignoreIfExists))) && (void 0 === t.annotationId || Da.is(t.annotationId));
		};
	}(qa || (qa = {})), function(e) {
		e.create = function(e, t, n, i) {
			let r = {
				kind: "rename",
				oldUri: e,
				newUri: t
			};
			return void 0 === n || void 0 === n.overwrite && void 0 === n.ignoreIfExists || (r.options = n), void 0 !== i && (r.annotationId = i), r;
		}, e.is = function(e) {
			let t = e;
			return t && "rename" === t.kind && Bo.string(t.oldUri) && Bo.string(t.newUri) && (void 0 === t.options || (void 0 === t.options.overwrite || Bo.boolean(t.options.overwrite)) && (void 0 === t.options.ignoreIfExists || Bo.boolean(t.options.ignoreIfExists))) && (void 0 === t.annotationId || Da.is(t.annotationId));
		};
	}(Fa || (Fa = {})), function(e) {
		e.create = function(e, t, n) {
			let i = {
				kind: "delete",
				uri: e
			};
			return void 0 === t || void 0 === t.recursive && void 0 === t.ignoreIfNotExists || (i.options = t), void 0 !== n && (i.annotationId = n), i;
		}, e.is = function(e) {
			let t = e;
			return t && "delete" === t.kind && Bo.string(t.uri) && (void 0 === t.options || (void 0 === t.options.recursive || Bo.boolean(t.options.recursive)) && (void 0 === t.options.ignoreIfNotExists || Bo.boolean(t.options.ignoreIfNotExists))) && (void 0 === t.annotationId || Da.is(t.annotationId));
		};
	}(Va || (Va = {})), function(e) {
		e.is = function(e) {
			let t = e;
			return t && (void 0 !== t.changes || void 0 !== t.documentChanges) && (void 0 === t.documentChanges || t.documentChanges.every((e) => Bo.string(e.kind) ? qa.is(e) || Fa.is(e) || Va.is(e) : Pa.is(e)));
		};
	}(Ba || (Ba = {})), function(e) {
		e.create = function(e) {
			return { uri: e };
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.string(t.uri);
		};
	}(Ka || (Ka = {})), function(e) {
		e.create = function(e, t) {
			return {
				uri: e,
				version: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.string(t.uri) && Bo.integer(t.version);
		};
	}(ja || (ja = {})), function(e) {
		e.create = function(e, t) {
			return {
				uri: e,
				version: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.string(t.uri) && (null === t.version || Bo.integer(t.version));
		};
	}(Ga || (Ga = {})), function(e) {
		e.create = function(e, t, n, i) {
			return {
				uri: e,
				languageId: t,
				version: n,
				text: i
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.string(t.uri) && Bo.string(t.languageId) && Bo.integer(t.version) && Bo.string(t.text);
		};
	}($a || ($a = {})), function(e) {
		e.PlainText = "plaintext", e.Markdown = "markdown", e.is = function(t) {
			const n = t;
			return n === e.PlainText || n === e.Markdown;
		};
	}(Xa || (Xa = {})), function(e) {
		e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(e) && Xa.is(t.kind) && Bo.string(t.value);
		};
	}(Ja || (Ja = {})), function(e) {
		e.Text = 1, e.Method = 2, e.Function = 3, e.Constructor = 4, e.Field = 5, e.Variable = 6, e.Class = 7, e.Interface = 8, e.Module = 9, e.Property = 10, e.Unit = 11, e.Value = 12, e.Enum = 13, e.Keyword = 14, e.Snippet = 15, e.Color = 16, e.File = 17, e.Reference = 18, e.Folder = 19, e.EnumMember = 20, e.Constant = 21, e.Struct = 22, e.Event = 23, e.Operator = 24, e.TypeParameter = 25;
	}(Ya || (Ya = {})), function(e) {
		e.PlainText = 1, e.Snippet = 2;
	}(Qa || (Qa = {})), function(e) {
		e.Deprecated = 1;
	}(Za || (Za = {})), function(e) {
		e.create = function(e, t, n) {
			return {
				newText: e,
				insert: t,
				replace: n
			};
		}, e.is = function(e) {
			const t = e;
			return t && Bo.string(t.newText) && Ta.is(t.insert) && Ta.is(t.replace);
		};
	}(eo || (eo = {})), function(e) {
		e.asIs = 1, e.adjustIndentation = 2;
	}(to || (to = {})), function(e) {
		e.is = function(e) {
			const t = e;
			return t && (Bo.string(t.detail) || void 0 === t.detail) && (Bo.string(t.description) || void 0 === t.description);
		};
	}(no || (no = {})), function(e) {
		e.create = function(e) {
			return { label: e };
		};
	}(io || (io = {})), function(e) {
		e.create = function(e, t) {
			return {
				items: e || [],
				isIncomplete: !!t
			};
		};
	}(ro || (ro = {})), function(e) {
		e.fromPlainText = function(e) {
			return e.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&");
		}, e.is = function(e) {
			const t = e;
			return Bo.string(t) || Bo.objectLiteral(t) && Bo.string(t.language) && Bo.string(t.value);
		};
	}(ao || (ao = {})), function(e) {
		e.is = function(e) {
			let t = e;
			return !!t && Bo.objectLiteral(t) && (Ja.is(t.contents) || ao.is(t.contents) || Bo.typedArray(t.contents, ao.is)) && (void 0 === e.range || Ta.is(e.range));
		};
	}(oo || (oo = {})), function(e) {
		e.create = function(e, t) {
			return t ? {
				label: e,
				documentation: t
			} : { label: e };
		};
	}(so || (so = {})), function(e) {
		e.create = function(e, t, ...n) {
			let i = { label: e };
			return Bo.defined(t) && (i.documentation = t), Bo.defined(n) ? i.parameters = n : i.parameters = [], i;
		};
	}(lo || (lo = {})), function(e) {
		e.Text = 1, e.Read = 2, e.Write = 3;
	}(co || (co = {})), function(e) {
		e.create = function(e, t) {
			let n = { range: e };
			return Bo.number(t) && (n.kind = t), n;
		};
	}(ho || (ho = {})), function(e) {
		e.File = 1, e.Module = 2, e.Namespace = 3, e.Package = 4, e.Class = 5, e.Method = 6, e.Property = 7, e.Field = 8, e.Constructor = 9, e.Enum = 10, e.Interface = 11, e.Function = 12, e.Variable = 13, e.Constant = 14, e.String = 15, e.Number = 16, e.Boolean = 17, e.Array = 18, e.Object = 19, e.Key = 20, e.Null = 21, e.EnumMember = 22, e.Struct = 23, e.Event = 24, e.Operator = 25, e.TypeParameter = 26;
	}(uo || (uo = {})), function(e) {
		e.Deprecated = 1;
	}(mo || (mo = {})), function(e) {
		e.create = function(e, t, n, i, r) {
			let a = {
				name: e,
				kind: t,
				location: {
					uri: i,
					range: n
				}
			};
			return r && (a.containerName = r), a;
		};
	}(po || (po = {})), function(e) {
		e.create = function(e, t, n, i) {
			return void 0 !== i ? {
				name: e,
				kind: t,
				location: {
					uri: n,
					range: i
				}
			} : {
				name: e,
				kind: t,
				location: { uri: n }
			};
		};
	}(go || (go = {})), function(e) {
		e.create = function(e, t, n, i, r, a) {
			let o = {
				name: e,
				detail: t,
				kind: n,
				range: i,
				selectionRange: r
			};
			return void 0 !== a && (o.children = a), o;
		}, e.is = function(e) {
			let t = e;
			return t && Bo.string(t.name) && Bo.number(t.kind) && Ta.is(t.range) && Ta.is(t.selectionRange) && (void 0 === t.detail || Bo.string(t.detail)) && (void 0 === t.deprecated || Bo.boolean(t.deprecated)) && (void 0 === t.children || Array.isArray(t.children)) && (void 0 === t.tags || Array.isArray(t.tags));
		};
	}(fo || (fo = {})), function(e) {
		e.Empty = "", e.QuickFix = "quickfix", e.Refactor = "refactor", e.RefactorExtract = "refactor.extract", e.RefactorInline = "refactor.inline", e.RefactorRewrite = "refactor.rewrite", e.Source = "source", e.SourceOrganizeImports = "source.organizeImports", e.SourceFixAll = "source.fixAll";
	}(bo || (bo = {})), function(e) {
		e.Invoked = 1, e.Automatic = 2;
	}(_o || (_o = {})), function(e) {
		e.create = function(e, t, n) {
			let i = { diagnostics: e };
			return null != t && (i.only = t), null != n && (i.triggerKind = n), i;
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.typedArray(t.diagnostics, za.is) && (void 0 === t.only || Bo.typedArray(t.only, Bo.string)) && (void 0 === t.triggerKind || t.triggerKind === _o.Invoked || t.triggerKind === _o.Automatic);
		};
	}(wo || (wo = {})), function(e) {
		e.create = function(e, t, n) {
			let i = { title: e }, r = !0;
			return "string" == typeof t ? (r = !1, i.kind = t) : Oa.is(t) ? i.command = t : i.edit = t, r && void 0 !== n && (i.kind = n), i;
		}, e.is = function(e) {
			let t = e;
			return t && Bo.string(t.title) && (void 0 === t.diagnostics || Bo.typedArray(t.diagnostics, za.is)) && (void 0 === t.kind || Bo.string(t.kind)) && (void 0 !== t.edit || void 0 !== t.command) && (void 0 === t.command || Oa.is(t.command)) && (void 0 === t.isPreferred || Bo.boolean(t.isPreferred)) && (void 0 === t.edit || Ba.is(t.edit));
		};
	}(vo || (vo = {})), function(e) {
		e.create = function(e, t) {
			let n = { range: e };
			return Bo.defined(t) && (n.data = t), n;
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Ta.is(t.range) && (Bo.undefined(t.command) || Oa.is(t.command));
		};
	}(yo || (yo = {})), function(e) {
		e.create = function(e, t) {
			return {
				tabSize: e,
				insertSpaces: t
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Bo.uinteger(t.tabSize) && Bo.boolean(t.insertSpaces);
		};
	}(To || (To = {})), function(e) {
		e.create = function(e, t, n) {
			return {
				range: e,
				target: t,
				data: n
			};
		}, e.is = function(e) {
			let t = e;
			return Bo.defined(t) && Ta.is(t.range) && (Bo.undefined(t.target) || Bo.string(t.target));
		};
	}(ko || (ko = {})), function(e) {
		e.create = function(e, t) {
			return {
				range: e,
				parent: t
			};
		}, e.is = function(t) {
			let n = t;
			return Bo.objectLiteral(n) && Ta.is(n.range) && (void 0 === n.parent || e.is(n.parent));
		};
	}(So || (So = {})), function(e) {
		e.namespace = "namespace", e.type = "type", e.class = "class", e.enum = "enum", e.interface = "interface", e.struct = "struct", e.typeParameter = "typeParameter", e.parameter = "parameter", e.variable = "variable", e.property = "property", e.enumMember = "enumMember", e.event = "event", e.function = "function", e.method = "method", e.macro = "macro", e.keyword = "keyword", e.modifier = "modifier", e.comment = "comment", e.string = "string", e.number = "number", e.regexp = "regexp", e.operator = "operator", e.decorator = "decorator";
	}(Lo || (Lo = {})), function(e) {
		e.declaration = "declaration", e.definition = "definition", e.readonly = "readonly", e.static = "static", e.deprecated = "deprecated", e.abstract = "abstract", e.async = "async", e.modification = "modification", e.documentation = "documentation", e.defaultLibrary = "defaultLibrary";
	}(xo || (xo = {})), function(e) {
		e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && (void 0 === t.resultId || "string" == typeof t.resultId) && Array.isArray(t.data) && (0 === t.data.length || "number" == typeof t.data[0]);
		};
	}(Co || (Co = {})), function(e) {
		e.create = function(e, t) {
			return {
				range: e,
				text: t
			};
		}, e.is = function(e) {
			const t = e;
			return null != t && Ta.is(t.range) && Bo.string(t.text);
		};
	}(Eo || (Eo = {})), function(e) {
		e.create = function(e, t, n) {
			return {
				range: e,
				variableName: t,
				caseSensitiveLookup: n
			};
		}, e.is = function(e) {
			const t = e;
			return null != t && Ta.is(t.range) && Bo.boolean(t.caseSensitiveLookup) && (Bo.string(t.variableName) || void 0 === t.variableName);
		};
	}(Ao || (Ao = {})), function(e) {
		e.create = function(e, t) {
			return {
				range: e,
				expression: t
			};
		}, e.is = function(e) {
			const t = e;
			return null != t && Ta.is(t.range) && (Bo.string(t.expression) || void 0 === t.expression);
		};
	}(Ro || (Ro = {})), function(e) {
		e.create = function(e, t) {
			return {
				frameId: e,
				stoppedLocation: t
			};
		}, e.is = function(e) {
			const t = e;
			return Bo.defined(t) && Ta.is(e.stoppedLocation);
		};
	}(Mo || (Mo = {})), function(e) {
		e.Type = 1, e.Parameter = 2, e.is = function(e) {
			return 1 === e || 2 === e;
		};
	}(No || (No = {})), function(e) {
		e.create = function(e) {
			return { value: e };
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && (void 0 === t.tooltip || Bo.string(t.tooltip) || Ja.is(t.tooltip)) && (void 0 === t.location || ka.is(t.location)) && (void 0 === t.command || Oa.is(t.command));
		};
	}(Io || (Io = {})), function(e) {
		e.create = function(e, t, n) {
			const i = {
				position: e,
				label: t
			};
			return void 0 !== n && (i.kind = n), i;
		}, e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && ya.is(t.position) && (Bo.string(t.label) || Bo.typedArray(t.label, Io.is)) && (void 0 === t.kind || No.is(t.kind)) && void 0 === t.textEdits || Bo.typedArray(t.textEdits, Ua.is) && (void 0 === t.tooltip || Bo.string(t.tooltip) || Ja.is(t.tooltip)) && (void 0 === t.paddingLeft || Bo.boolean(t.paddingLeft)) && (void 0 === t.paddingRight || Bo.boolean(t.paddingRight));
		};
	}(zo || (zo = {})), function(e) {
		e.createSnippet = function(e) {
			return {
				kind: "snippet",
				value: e
			};
		};
	}(Oo || (Oo = {})), function(e) {
		e.create = function(e, t, n, i) {
			return {
				insertText: e,
				filterText: t,
				range: n,
				command: i
			};
		};
	}(Uo || (Uo = {})), function(e) {
		e.create = function(e) {
			return { items: e };
		};
	}(Ho || (Ho = {})), function(e) {
		e.Invoked = 0, e.Automatic = 1;
	}(Do || (Do = {})), function(e) {
		e.create = function(e, t) {
			return {
				range: e,
				text: t
			};
		};
	}(Wo || (Wo = {})), function(e) {
		e.create = function(e, t) {
			return {
				triggerKind: e,
				selectedCompletionInfo: t
			};
		};
	}(Po || (Po = {})), function(e) {
		e.is = function(e) {
			const t = e;
			return Bo.objectLiteral(t) && _a.is(t.uri) && Bo.string(t.name);
		};
	}(qo || (qo = {})), function(e) {
		function t(e, n) {
			if (e.length <= 1) return e;
			const i = e.length / 2 | 0, r = e.slice(0, i), a = e.slice(i);
			t(r, n), t(a, n);
			let o = 0, s = 0, l = 0;
			for (; o < r.length && s < a.length;) n(r[o], a[s]) <= 0 ? e[l++] = r[o++] : e[l++] = a[s++];
			for (; o < r.length;) e[l++] = r[o++];
			for (; s < a.length;) e[l++] = a[s++];
			return e;
		}
		e.create = function(e, t, n, i) {
			return new Ko(e, t, n, i);
		}, e.is = function(e) {
			let t = e;
			return !!(Bo.defined(t) && Bo.string(t.uri) && (Bo.undefined(t.languageId) || Bo.string(t.languageId)) && Bo.uinteger(t.lineCount) && Bo.func(t.getText) && Bo.func(t.positionAt) && Bo.func(t.offsetAt));
		}, e.applyEdits = function(e, n) {
			let i = e.getText(), r = t(n, (e, t) => {
				let n = e.range.start.line - t.range.start.line;
				return 0 === n ? e.range.start.character - t.range.start.character : n;
			}), a = i.length;
			for (let t = r.length - 1; t >= 0; t--) {
				let n = r[t], o = e.offsetAt(n.range.start), s = e.offsetAt(n.range.end);
				if (!(s <= a)) throw new Error("Overlapping edit");
				i = i.substring(0, o) + n.newText + i.substring(s, i.length), a = o;
			}
			return i;
		};
	}(Fo || (Fo = {}));
	var Bo, Ko = class {
		constructor(e, t, n, i) {
			this._uri = e, this._languageId = t, this._version = n, this._content = i, this._lineOffsets = void 0;
		}
		get uri() {
			return this._uri;
		}
		get languageId() {
			return this._languageId;
		}
		get version() {
			return this._version;
		}
		getText(e) {
			if (e) {
				let t = this.offsetAt(e.start), n = this.offsetAt(e.end);
				return this._content.substring(t, n);
			}
			return this._content;
		}
		update(e, t) {
			this._content = e.text, this._version = t, this._lineOffsets = void 0;
		}
		getLineOffsets() {
			if (void 0 === this._lineOffsets) {
				let e = [], t = this._content, n = !0;
				for (let i = 0; i < t.length; i++) {
					n && (e.push(i), n = !1);
					let r = t.charAt(i);
					n = "\r" === r || "\n" === r, "\r" === r && i + 1 < t.length && "\n" === t.charAt(i + 1) && i++;
				}
				n && t.length > 0 && e.push(t.length), this._lineOffsets = e;
			}
			return this._lineOffsets;
		}
		positionAt(e) {
			e = Math.max(Math.min(e, this._content.length), 0);
			let t = this.getLineOffsets(), n = 0, i = t.length;
			if (0 === i) return ya.create(0, e);
			for (; n < i;) {
				let r = Math.floor((n + i) / 2);
				t[r] > e ? i = r : n = r + 1;
			}
			let r = n - 1;
			return ya.create(r, e - t[r]);
		}
		offsetAt(e) {
			let t = this.getLineOffsets();
			if (e.line >= t.length) return this._content.length;
			if (e.line < 0) return 0;
			let n = t[e.line], i = e.line + 1 < t.length ? t[e.line + 1] : this._content.length;
			return Math.max(Math.min(n + e.character, i), n);
		}
		get lineCount() {
			return this.getLineOffsets().length;
		}
	};
	(function(e) {
		const t = Object.prototype.toString;
		e.defined = function(e) {
			return void 0 !== e;
		}, e.undefined = function(e) {
			return void 0 === e;
		}, e.boolean = function(e) {
			return !0 === e || !1 === e;
		}, e.string = function(e) {
			return "[object String]" === t.call(e);
		}, e.number = function(e) {
			return "[object Number]" === t.call(e);
		}, e.numberRange = function(e, n, i) {
			return "[object Number]" === t.call(e) && n <= e && e <= i;
		}, e.integer = function(e) {
			return "[object Number]" === t.call(e) && -2147483648 <= e && e <= 2147483647;
		}, e.uinteger = function(e) {
			return "[object Number]" === t.call(e) && 0 <= e && e <= 2147483647;
		}, e.func = function(e) {
			return "[object Function]" === t.call(e);
		}, e.objectLiteral = function(e) {
			return null !== e && "object" == typeof e;
		}, e.typedArray = function(e, t) {
			return Array.isArray(e) && e.every(t);
		};
	})(Bo || (Bo = {}));
	var jo, Go, $o, Xo, Jo, Yo = class e {
		constructor(e, t, n, i) {
			this._uri = e, this._languageId = t, this._version = n, this._content = i, this._lineOffsets = void 0;
		}
		get uri() {
			return this._uri;
		}
		get languageId() {
			return this._languageId;
		}
		get version() {
			return this._version;
		}
		getText(e) {
			if (e) {
				const t = this.offsetAt(e.start), n = this.offsetAt(e.end);
				return this._content.substring(t, n);
			}
			return this._content;
		}
		update(t, n) {
			for (let i of t) if (e.isIncremental(i)) {
				const e = es(i.range), t = this.offsetAt(e.start), n = this.offsetAt(e.end);
				this._content = this._content.substring(0, t) + i.text + this._content.substring(n, this._content.length);
				const r = Math.max(e.start.line, 0), a = Math.max(e.end.line, 0);
				let o = this._lineOffsets;
				const s = Zo(i.text, !1, t);
				if (a - r === s.length) for (let i = 0, c = s.length; i < c; i++) o[i + r + 1] = s[i];
				else s.length < 1e4 ? o.splice(r + 1, a - r, ...s) : this._lineOffsets = o = o.slice(0, r + 1).concat(s, o.slice(a + 1));
				const l = i.text.length - (n - t);
				if (0 !== l) for (let i = r + 1 + s.length, c = o.length; i < c; i++) o[i] = o[i] + l;
			} else {
				if (!e.isFull(i)) throw new Error("Unknown change event received");
				this._content = i.text, this._lineOffsets = void 0;
			}
			this._version = n;
		}
		getLineOffsets() {
			return void 0 === this._lineOffsets && (this._lineOffsets = Zo(this._content, !0)), this._lineOffsets;
		}
		positionAt(e) {
			e = Math.max(Math.min(e, this._content.length), 0);
			let t = this.getLineOffsets(), n = 0, i = t.length;
			if (0 === i) return {
				line: 0,
				character: e
			};
			for (; n < i;) {
				let r = Math.floor((n + i) / 2);
				t[r] > e ? i = r : n = r + 1;
			}
			let r = n - 1;
			return {
				line: r,
				character: e - t[r]
			};
		}
		offsetAt(e) {
			let t = this.getLineOffsets();
			if (e.line >= t.length) return this._content.length;
			if (e.line < 0) return 0;
			let n = t[e.line], i = e.line + 1 < t.length ? t[e.line + 1] : this._content.length;
			return Math.max(Math.min(n + e.character, i), n);
		}
		get lineCount() {
			return this.getLineOffsets().length;
		}
		static isIncremental(e) {
			let t = e;
			return null != t && "string" == typeof t.text && void 0 !== t.range && (void 0 === t.rangeLength || "number" == typeof t.rangeLength);
		}
		static isFull(e) {
			let t = e;
			return null != t && "string" == typeof t.text && void 0 === t.range && void 0 === t.rangeLength;
		}
	};
	function Qo(e, t) {
		if (e.length <= 1) return e;
		const n = e.length / 2 | 0, i = e.slice(0, n), r = e.slice(n);
		Qo(i, t), Qo(r, t);
		let a = 0, o = 0, s = 0;
		for (; a < i.length && o < r.length;) t(i[a], r[o]) <= 0 ? e[s++] = i[a++] : e[s++] = r[o++];
		for (; a < i.length;) e[s++] = i[a++];
		for (; o < r.length;) e[s++] = r[o++];
		return e;
	}
	function Zo(e, t, n = 0) {
		const i = t ? [n] : [];
		for (let r = 0; r < e.length; r++) {
			let t = e.charCodeAt(r);
			13 !== t && 10 !== t || (13 === t && r + 1 < e.length && 10 === e.charCodeAt(r + 1) && r++, i.push(n + r + 1));
		}
		return i;
	}
	function es(e) {
		const t = e.start, n = e.end;
		return t.line > n.line || t.line === n.line && t.character > n.character ? {
			start: n,
			end: t
		} : e;
	}
	function ts(e) {
		const t = es(e.range);
		return t !== e.range ? {
			newText: e.newText,
			range: t
		} : e;
	}
	(function(e) {
		e.create = function(e, t, n, i) {
			return new Yo(e, t, n, i);
		}, e.update = function(e, t, n) {
			if (e instanceof Yo) return e.update(t, n), e;
			throw new Error("TextDocument.update: document must be created by TextDocument.create");
		}, e.applyEdits = function(e, t) {
			let n = e.getText(), i = Qo(t.map(ts), (e, t) => {
				let n = e.range.start.line - t.range.start.line;
				return 0 === n ? e.range.start.character - t.range.start.character : n;
			}), r = 0;
			const a = [];
			for (const o of i) {
				let t = e.offsetAt(o.range.start);
				if (t < r) throw new Error("Overlapping edit");
				t > r && a.push(n.substring(r, t)), o.newText.length && a.push(o.newText), r = e.offsetAt(o.range.end);
			}
			return a.push(n.substr(r)), a.join("");
		};
	})(jo || (jo = {})), function(e) {
		e[e.StartCommentTag = 0] = "StartCommentTag", e[e.Comment = 1] = "Comment", e[e.EndCommentTag = 2] = "EndCommentTag", e[e.StartTagOpen = 3] = "StartTagOpen", e[e.StartTagClose = 4] = "StartTagClose", e[e.StartTagSelfClose = 5] = "StartTagSelfClose", e[e.StartTag = 6] = "StartTag", e[e.EndTagOpen = 7] = "EndTagOpen", e[e.EndTagClose = 8] = "EndTagClose", e[e.EndTag = 9] = "EndTag", e[e.DelimiterAssign = 10] = "DelimiterAssign", e[e.AttributeName = 11] = "AttributeName", e[e.AttributeValue = 12] = "AttributeValue", e[e.StartDoctypeTag = 13] = "StartDoctypeTag", e[e.Doctype = 14] = "Doctype", e[e.EndDoctypeTag = 15] = "EndDoctypeTag", e[e.Content = 16] = "Content", e[e.Whitespace = 17] = "Whitespace", e[e.Unknown = 18] = "Unknown", e[e.Script = 19] = "Script", e[e.Styles = 20] = "Styles", e[e.EOS = 21] = "EOS";
	}(Go || (Go = {})), function(e) {
		e[e.WithinContent = 0] = "WithinContent", e[e.AfterOpeningStartTag = 1] = "AfterOpeningStartTag", e[e.AfterOpeningEndTag = 2] = "AfterOpeningEndTag", e[e.WithinDoctype = 3] = "WithinDoctype", e[e.WithinTag = 4] = "WithinTag", e[e.WithinEndTag = 5] = "WithinEndTag", e[e.WithinComment = 6] = "WithinComment", e[e.WithinScriptContent = 7] = "WithinScriptContent", e[e.WithinStyleContent = 8] = "WithinStyleContent", e[e.AfterAttributeName = 9] = "AfterAttributeName", e[e.BeforeAttributeValue = 10] = "BeforeAttributeValue";
	}($o || ($o = {})), function(e) {
		e.LATEST = { textDocument: {
			completion: { completionItem: { documentationFormat: [Xa.Markdown, Xa.PlainText] } },
			hover: { contentFormat: [Xa.Markdown, Xa.PlainText] }
		} };
	}(Xo || (Xo = {})), function(e) {
		e[e.Unknown = 0] = "Unknown", e[e.File = 1] = "File", e[e.Directory = 2] = "Directory", e[e.SymbolicLink = 64] = "SymbolicLink";
	}(Jo || (Jo = {}));
	var ns = class {
		constructor(e, t) {
			this.source = e, this.len = e.length, this.position = t;
		}
		eos() {
			return this.len <= this.position;
		}
		getSource() {
			return this.source;
		}
		pos() {
			return this.position;
		}
		goBackTo(e) {
			this.position = e;
		}
		goBack(e) {
			this.position -= e;
		}
		advance(e) {
			this.position += e;
		}
		goToEnd() {
			this.position = this.source.length;
		}
		nextChar() {
			return this.source.charCodeAt(this.position++) || 0;
		}
		peekChar(e = 0) {
			return this.source.charCodeAt(this.position + e) || 0;
		}
		advanceIfChar(e) {
			return e === this.source.charCodeAt(this.position) && (this.position++, !0);
		}
		advanceIfChars(e) {
			let t;
			if (this.position + e.length > this.source.length) return !1;
			for (t = 0; t < e.length; t++) if (this.source.charCodeAt(this.position + t) !== e[t]) return !1;
			return this.advance(t), !0;
		}
		advanceIfRegExp(e) {
			const t = this.source.substr(this.position).match(e);
			return t ? (this.position = this.position + t.index + t[0].length, t[0]) : "";
		}
		advanceUntilRegExp(e) {
			const t = this.source.substr(this.position).match(e);
			return t ? (this.position = this.position + t.index, t[0]) : (this.goToEnd(), "");
		}
		advanceUntilChar(e) {
			for (; this.position < this.source.length;) {
				if (this.source.charCodeAt(this.position) === e) return !0;
				this.advance(1);
			}
			return !1;
		}
		advanceUntilChars(e) {
			for (; this.position + e.length <= this.source.length;) {
				let t = 0;
				for (; t < e.length && this.source.charCodeAt(this.position + t) === e[t]; t++);
				if (t === e.length) return !0;
				this.advance(1);
			}
			return this.goToEnd(), !1;
		}
		skipWhitespace() {
			return this.advanceWhileChar((e) => e === ps || e === gs || e === ds || e === ms || e === us) > 0;
		}
		advanceWhileChar(e) {
			const t = this.position;
			for (; this.position < this.len && e(this.source.charCodeAt(this.position));) this.position++;
			return this.position - t;
		}
	};
	const is = "!".charCodeAt(0), rs = "-".charCodeAt(0), as = "<".charCodeAt(0), os = ">".charCodeAt(0), ss = "/".charCodeAt(0), ls = "=".charCodeAt(0), cs = "\"".charCodeAt(0), hs = "'".charCodeAt(0), ds = "\n".charCodeAt(0), us = "\r".charCodeAt(0), ms = "\f".charCodeAt(0), ps = " ".charCodeAt(0), gs = "	".charCodeAt(0), fs = {
		"text/x-handlebars-template": !0,
		"text/html": !0
	};
	function bs(e, t = 0, n = $o.WithinContent, i = !1) {
		const r = new ns(e, t);
		let a, o, s, l, c, h = n, d = 0, u = Go.Unknown;
		function m() {
			return r.advanceIfRegExp(/^[_:\w][_:\w-.\d]*/).toLowerCase();
		}
		function p(e, t, n) {
			return u = t, d = e, a = n, t;
		}
		function g() {
			const e = r.pos();
			if (r.eos()) return p(e, Go.EOS);
			let t;
			switch (h) {
				case $o.WithinComment: return r.advanceIfChars([
					rs,
					rs,
					os
				]) ? (h = $o.WithinContent, p(e, Go.EndCommentTag)) : (r.advanceUntilChars([
					rs,
					rs,
					os
				]), p(e, Go.Comment));
				case $o.WithinDoctype: return r.advanceIfChar(os) ? (h = $o.WithinContent, p(e, Go.EndDoctypeTag)) : (r.advanceUntilChar(os), p(e, Go.Doctype));
				case $o.WithinContent:
					if (r.advanceIfChar(as)) {
						if (!r.eos() && r.peekChar() === is) {
							if (r.advanceIfChars([
								is,
								rs,
								rs
							])) return h = $o.WithinComment, p(e, Go.StartCommentTag);
							if (r.advanceIfRegExp(/^!doctype/i)) return h = $o.WithinDoctype, p(e, Go.StartDoctypeTag);
						}
						return r.advanceIfChar(ss) ? (h = $o.AfterOpeningEndTag, p(e, Go.EndTagOpen)) : (h = $o.AfterOpeningStartTag, p(e, Go.StartTagOpen));
					}
					return r.advanceUntilChar(as), p(e, Go.Content);
				case $o.AfterOpeningEndTag: return m().length > 0 ? (h = $o.WithinEndTag, p(e, Go.EndTag)) : r.skipWhitespace() ? p(e, Go.Whitespace, fa("Tag name must directly follow the open bracket.")) : (h = $o.WithinEndTag, r.advanceUntilChar(os), e < r.pos() ? p(e, Go.Unknown, fa("End tag name expected.")) : g());
				case $o.WithinEndTag:
					if (r.skipWhitespace()) return p(e, Go.Whitespace);
					if (r.advanceIfChar(os)) return h = $o.WithinContent, p(e, Go.EndTagClose);
					if (i && r.peekChar() === as) return h = $o.WithinContent, p(e, Go.EndTagClose, fa("Closing bracket missing."));
					t = fa("Closing bracket expected.");
					break;
				case $o.AfterOpeningStartTag: return s = m(), c = void 0, l = void 0, s.length > 0 ? (o = !1, h = $o.WithinTag, p(e, Go.StartTag)) : r.skipWhitespace() ? p(e, Go.Whitespace, fa("Tag name must directly follow the open bracket.")) : (h = $o.WithinTag, r.advanceUntilChar(os), e < r.pos() ? p(e, Go.Unknown, fa("Start tag name expected.")) : g());
				case $o.WithinTag: return r.skipWhitespace() ? (o = !0, p(e, Go.Whitespace)) : o && (l = r.advanceIfRegExp(/^[^\s"'></=\x00-\x0F\x7F\x80-\x9F]*/).toLowerCase(), l.length > 0) ? (h = $o.AfterAttributeName, o = !1, p(e, Go.AttributeName)) : r.advanceIfChars([ss, os]) ? (h = $o.WithinContent, p(e, Go.StartTagSelfClose)) : r.advanceIfChar(os) ? (h = "script" === s ? c && fs[c] ? $o.WithinContent : $o.WithinScriptContent : "style" === s ? $o.WithinStyleContent : $o.WithinContent, p(e, Go.StartTagClose)) : i && r.peekChar() === as ? (h = $o.WithinContent, p(e, Go.StartTagClose, fa("Closing bracket missing."))) : (r.advance(1), p(e, Go.Unknown, fa("Unexpected character in tag.")));
				case $o.AfterAttributeName: return r.skipWhitespace() ? (o = !0, p(e, Go.Whitespace)) : r.advanceIfChar(ls) ? (h = $o.BeforeAttributeValue, p(e, Go.DelimiterAssign)) : (h = $o.WithinTag, g());
				case $o.BeforeAttributeValue:
					if (r.skipWhitespace()) return p(e, Go.Whitespace);
					let n = r.advanceIfRegExp(/^[^\s"'`=<>]+/);
					if (n.length > 0 && (r.peekChar() === os && r.peekChar(-1) === ss && (r.goBack(1), n = n.substring(0, n.length - 1)), "type" === l && (c = n), n.length > 0)) return h = $o.WithinTag, o = !1, p(e, Go.AttributeValue);
					const a = r.peekChar();
					return a === hs || a === cs ? (r.advance(1), r.advanceUntilChar(a) && r.advance(1), "type" === l && (c = r.getSource().substring(e + 1, r.pos() - 1)), h = $o.WithinTag, o = !1, p(e, Go.AttributeValue)) : (h = $o.WithinTag, o = !1, g());
				case $o.WithinScriptContent:
					let d = 1;
					for (; !r.eos();) {
						const t = r.advanceIfRegExp(/<!--|-->|<\/?script\s*\/?>?/i);
						if (0 === t.length) return r.goToEnd(), p(e, Go.Script);
						if ("<!--" === t) 1 === d && (d = 2);
						else if ("-->" === t) d = 1;
						else if ("/" !== t[1]) 2 === d && (d = 3);
						else {
							if (3 !== d) {
								r.goBack(t.length);
								break;
							}
							d = 2;
						}
					}
					return h = $o.WithinContent, e < r.pos() ? p(e, Go.Script) : g();
				case $o.WithinStyleContent: return r.advanceUntilRegExp(/<\/style/i), h = $o.WithinContent, e < r.pos() ? p(e, Go.Styles) : g();
			}
			return r.advance(1), h = $o.WithinContent, p(e, Go.Unknown, t);
		}
		return {
			scan: function() {
				const e = r.pos(), t = g();
				return t === Go.EOS || e !== r.pos() || i && (t === Go.StartTagClose || t === Go.EndTagClose) ? t : (r.advance(1), p(e, Go.Unknown));
			},
			getTokenType: () => u,
			getTokenOffset: () => d,
			getTokenLength: () => r.pos() - d,
			getTokenEnd: () => r.pos(),
			getTokenText: () => r.getSource().substring(d, r.pos()),
			getScannerState: () => h,
			getTokenError: () => a
		};
	}
	function _s(e, t) {
		let n = 0, i = e.length;
		if (0 === i) return 0;
		for (; n < i;) {
			let r = Math.floor((n + i) / 2);
			t(e[r]) ? i = r : n = r + 1;
		}
		return n;
	}
	var ws = class {
		get attributeNames() {
			return this.attributes ? Object.keys(this.attributes) : [];
		}
		constructor(e, t, n, i) {
			this.start = e, this.end = t, this.children = n, this.parent = i, this.closed = !1;
		}
		isSameTag(e) {
			return void 0 === this.tag ? void 0 === e : void 0 !== e && this.tag.length === e.length && this.tag.toLowerCase() === e;
		}
		get firstChild() {
			return this.children[0];
		}
		get lastChild() {
			return this.children.length ? this.children[this.children.length - 1] : void 0;
		}
		findNodeBefore(e) {
			const t = _s(this.children, (t) => e <= t.start) - 1;
			if (t >= 0) {
				const n = this.children[t];
				if (e > n.start) {
					if (e < n.end) return n.findNodeBefore(e);
					const t = n.lastChild;
					return t && t.end === n.end ? n.findNodeBefore(e) : n;
				}
			}
			return this;
		}
		findNodeAt(e) {
			const t = _s(this.children, (t) => e <= t.start) - 1;
			if (t >= 0) {
				const n = this.children[t];
				if (e > n.start && e <= n.end) return n.findNodeAt(e);
			}
			return this;
		}
	}, vs = class {
		constructor(e) {
			this.dataManager = e;
		}
		parseDocument(e) {
			return this.parse(e.getText(), this.dataManager.getVoidElements(e.languageId));
		}
		parse(e, t) {
			const n = bs(e, void 0, void 0, !0), i = new ws(0, e.length, [], void 0);
			let r, a = i, o = -1, s = null, l = n.scan();
			for (; l !== Go.EOS;) {
				switch (l) {
					case Go.StartTagOpen:
						const i = new ws(n.getTokenOffset(), e.length, [], a);
						a.children.push(i), a = i;
						break;
					case Go.StartTag:
						a.tag = n.getTokenText();
						break;
					case Go.StartTagClose:
						a.parent && (a.end = n.getTokenEnd(), n.getTokenLength() ? (a.startTagEnd = n.getTokenEnd(), a.tag && this.dataManager.isVoidElement(a.tag, t) && (a.closed = !0, a = a.parent)) : a = a.parent);
						break;
					case Go.StartTagSelfClose:
						a.parent && (a.closed = !0, a.end = n.getTokenEnd(), a.startTagEnd = n.getTokenEnd(), a = a.parent);
						break;
					case Go.EndTagOpen:
						o = n.getTokenOffset(), r = void 0;
						break;
					case Go.EndTag:
						r = n.getTokenText().toLowerCase();
						break;
					case Go.EndTagClose:
						let l = a;
						for (; !l.isSameTag(r) && l.parent;) l = l.parent;
						if (l.parent) {
							for (; a !== l;) a.end = o, a.closed = !1, a = a.parent;
							a.closed = !0, a.endTagStart = o, a.end = n.getTokenEnd(), a = a.parent;
						}
						break;
					case Go.AttributeName: {
						s = n.getTokenText();
						let e = a.attributes;
						e || (a.attributes = e = {}), e[s] = null;
						break;
					}
					case Go.AttributeValue: {
						const e = n.getTokenText(), t = a.attributes;
						t && s && (t[s] = e, s = null);
						break;
					}
				}
				l = n.scan();
			}
			for (; a.parent;) a.end = e.length, a.closed = !1, a = a.parent;
			return {
				roots: i.children,
				findNodeBefore: i.findNodeBefore.bind(i),
				findNodeAt: i.findNodeAt.bind(i)
			};
		}
	};
	const ys = {
		"Aacute;": "Á",
		Aacute: "Á",
		"aacute;": "á",
		aacute: "á",
		"Abreve;": "Ă",
		"abreve;": "ă",
		"ac;": "∾",
		"acd;": "∿",
		"acE;": "∾̳",
		"Acirc;": "Â",
		Acirc: "Â",
		"acirc;": "â",
		acirc: "â",
		"acute;": "´",
		acute: "´",
		"Acy;": "А",
		"acy;": "а",
		"AElig;": "Æ",
		AElig: "Æ",
		"aelig;": "æ",
		aelig: "æ",
		"af;": "⁡",
		"Afr;": "𝔄",
		"afr;": "𝔞",
		"Agrave;": "À",
		Agrave: "À",
		"agrave;": "à",
		agrave: "à",
		"alefsym;": "ℵ",
		"aleph;": "ℵ",
		"Alpha;": "Α",
		"alpha;": "α",
		"Amacr;": "Ā",
		"amacr;": "ā",
		"amalg;": "⨿",
		"AMP;": "&",
		AMP: "&",
		"amp;": "&",
		amp: "&",
		"And;": "⩓",
		"and;": "∧",
		"andand;": "⩕",
		"andd;": "⩜",
		"andslope;": "⩘",
		"andv;": "⩚",
		"ang;": "∠",
		"ange;": "⦤",
		"angle;": "∠",
		"angmsd;": "∡",
		"angmsdaa;": "⦨",
		"angmsdab;": "⦩",
		"angmsdac;": "⦪",
		"angmsdad;": "⦫",
		"angmsdae;": "⦬",
		"angmsdaf;": "⦭",
		"angmsdag;": "⦮",
		"angmsdah;": "⦯",
		"angrt;": "∟",
		"angrtvb;": "⊾",
		"angrtvbd;": "⦝",
		"angsph;": "∢",
		"angst;": "Å",
		"angzarr;": "⍼",
		"Aogon;": "Ą",
		"aogon;": "ą",
		"Aopf;": "𝔸",
		"aopf;": "𝕒",
		"ap;": "≈",
		"apacir;": "⩯",
		"apE;": "⩰",
		"ape;": "≊",
		"apid;": "≋",
		"apos;": "'",
		"ApplyFunction;": "⁡",
		"approx;": "≈",
		"approxeq;": "≊",
		"Aring;": "Å",
		Aring: "Å",
		"aring;": "å",
		aring: "å",
		"Ascr;": "𝒜",
		"ascr;": "𝒶",
		"Assign;": "≔",
		"ast;": "*",
		"asymp;": "≈",
		"asympeq;": "≍",
		"Atilde;": "Ã",
		Atilde: "Ã",
		"atilde;": "ã",
		atilde: "ã",
		"Auml;": "Ä",
		Auml: "Ä",
		"auml;": "ä",
		auml: "ä",
		"awconint;": "∳",
		"awint;": "⨑",
		"backcong;": "≌",
		"backepsilon;": "϶",
		"backprime;": "‵",
		"backsim;": "∽",
		"backsimeq;": "⋍",
		"Backslash;": "∖",
		"Barv;": "⫧",
		"barvee;": "⊽",
		"Barwed;": "⌆",
		"barwed;": "⌅",
		"barwedge;": "⌅",
		"bbrk;": "⎵",
		"bbrktbrk;": "⎶",
		"bcong;": "≌",
		"Bcy;": "Б",
		"bcy;": "б",
		"bdquo;": "„",
		"becaus;": "∵",
		"Because;": "∵",
		"because;": "∵",
		"bemptyv;": "⦰",
		"bepsi;": "϶",
		"bernou;": "ℬ",
		"Bernoullis;": "ℬ",
		"Beta;": "Β",
		"beta;": "β",
		"beth;": "ℶ",
		"between;": "≬",
		"Bfr;": "𝔅",
		"bfr;": "𝔟",
		"bigcap;": "⋂",
		"bigcirc;": "◯",
		"bigcup;": "⋃",
		"bigodot;": "⨀",
		"bigoplus;": "⨁",
		"bigotimes;": "⨂",
		"bigsqcup;": "⨆",
		"bigstar;": "★",
		"bigtriangledown;": "▽",
		"bigtriangleup;": "△",
		"biguplus;": "⨄",
		"bigvee;": "⋁",
		"bigwedge;": "⋀",
		"bkarow;": "⤍",
		"blacklozenge;": "⧫",
		"blacksquare;": "▪",
		"blacktriangle;": "▴",
		"blacktriangledown;": "▾",
		"blacktriangleleft;": "◂",
		"blacktriangleright;": "▸",
		"blank;": "␣",
		"blk12;": "▒",
		"blk14;": "░",
		"blk34;": "▓",
		"block;": "█",
		"bne;": "=⃥",
		"bnequiv;": "≡⃥",
		"bNot;": "⫭",
		"bnot;": "⌐",
		"Bopf;": "𝔹",
		"bopf;": "𝕓",
		"bot;": "⊥",
		"bottom;": "⊥",
		"bowtie;": "⋈",
		"boxbox;": "⧉",
		"boxDL;": "╗",
		"boxDl;": "╖",
		"boxdL;": "╕",
		"boxdl;": "┐",
		"boxDR;": "╔",
		"boxDr;": "╓",
		"boxdR;": "╒",
		"boxdr;": "┌",
		"boxH;": "═",
		"boxh;": "─",
		"boxHD;": "╦",
		"boxHd;": "╤",
		"boxhD;": "╥",
		"boxhd;": "┬",
		"boxHU;": "╩",
		"boxHu;": "╧",
		"boxhU;": "╨",
		"boxhu;": "┴",
		"boxminus;": "⊟",
		"boxplus;": "⊞",
		"boxtimes;": "⊠",
		"boxUL;": "╝",
		"boxUl;": "╜",
		"boxuL;": "╛",
		"boxul;": "┘",
		"boxUR;": "╚",
		"boxUr;": "╙",
		"boxuR;": "╘",
		"boxur;": "└",
		"boxV;": "║",
		"boxv;": "│",
		"boxVH;": "╬",
		"boxVh;": "╫",
		"boxvH;": "╪",
		"boxvh;": "┼",
		"boxVL;": "╣",
		"boxVl;": "╢",
		"boxvL;": "╡",
		"boxvl;": "┤",
		"boxVR;": "╠",
		"boxVr;": "╟",
		"boxvR;": "╞",
		"boxvr;": "├",
		"bprime;": "‵",
		"Breve;": "˘",
		"breve;": "˘",
		"brvbar;": "¦",
		brvbar: "¦",
		"Bscr;": "ℬ",
		"bscr;": "𝒷",
		"bsemi;": "⁏",
		"bsim;": "∽",
		"bsime;": "⋍",
		"bsol;": "\\",
		"bsolb;": "⧅",
		"bsolhsub;": "⟈",
		"bull;": "•",
		"bullet;": "•",
		"bump;": "≎",
		"bumpE;": "⪮",
		"bumpe;": "≏",
		"Bumpeq;": "≎",
		"bumpeq;": "≏",
		"Cacute;": "Ć",
		"cacute;": "ć",
		"Cap;": "⋒",
		"cap;": "∩",
		"capand;": "⩄",
		"capbrcup;": "⩉",
		"capcap;": "⩋",
		"capcup;": "⩇",
		"capdot;": "⩀",
		"CapitalDifferentialD;": "ⅅ",
		"caps;": "∩︀",
		"caret;": "⁁",
		"caron;": "ˇ",
		"Cayleys;": "ℭ",
		"ccaps;": "⩍",
		"Ccaron;": "Č",
		"ccaron;": "č",
		"Ccedil;": "Ç",
		Ccedil: "Ç",
		"ccedil;": "ç",
		ccedil: "ç",
		"Ccirc;": "Ĉ",
		"ccirc;": "ĉ",
		"Cconint;": "∰",
		"ccups;": "⩌",
		"ccupssm;": "⩐",
		"Cdot;": "Ċ",
		"cdot;": "ċ",
		"cedil;": "¸",
		cedil: "¸",
		"Cedilla;": "¸",
		"cemptyv;": "⦲",
		"cent;": "¢",
		cent: "¢",
		"CenterDot;": "·",
		"centerdot;": "·",
		"Cfr;": "ℭ",
		"cfr;": "𝔠",
		"CHcy;": "Ч",
		"chcy;": "ч",
		"check;": "✓",
		"checkmark;": "✓",
		"Chi;": "Χ",
		"chi;": "χ",
		"cir;": "○",
		"circ;": "ˆ",
		"circeq;": "≗",
		"circlearrowleft;": "↺",
		"circlearrowright;": "↻",
		"circledast;": "⊛",
		"circledcirc;": "⊚",
		"circleddash;": "⊝",
		"CircleDot;": "⊙",
		"circledR;": "®",
		"circledS;": "Ⓢ",
		"CircleMinus;": "⊖",
		"CirclePlus;": "⊕",
		"CircleTimes;": "⊗",
		"cirE;": "⧃",
		"cire;": "≗",
		"cirfnint;": "⨐",
		"cirmid;": "⫯",
		"cirscir;": "⧂",
		"ClockwiseContourIntegral;": "∲",
		"CloseCurlyDoubleQuote;": "”",
		"CloseCurlyQuote;": "’",
		"clubs;": "♣",
		"clubsuit;": "♣",
		"Colon;": "∷",
		"colon;": ":",
		"Colone;": "⩴",
		"colone;": "≔",
		"coloneq;": "≔",
		"comma;": ",",
		"commat;": "@",
		"comp;": "∁",
		"compfn;": "∘",
		"complement;": "∁",
		"complexes;": "ℂ",
		"cong;": "≅",
		"congdot;": "⩭",
		"Congruent;": "≡",
		"Conint;": "∯",
		"conint;": "∮",
		"ContourIntegral;": "∮",
		"Copf;": "ℂ",
		"copf;": "𝕔",
		"coprod;": "∐",
		"Coproduct;": "∐",
		"COPY;": "©",
		COPY: "©",
		"copy;": "©",
		copy: "©",
		"copysr;": "℗",
		"CounterClockwiseContourIntegral;": "∳",
		"crarr;": "↵",
		"Cross;": "⨯",
		"cross;": "✗",
		"Cscr;": "𝒞",
		"cscr;": "𝒸",
		"csub;": "⫏",
		"csube;": "⫑",
		"csup;": "⫐",
		"csupe;": "⫒",
		"ctdot;": "⋯",
		"cudarrl;": "⤸",
		"cudarrr;": "⤵",
		"cuepr;": "⋞",
		"cuesc;": "⋟",
		"cularr;": "↶",
		"cularrp;": "⤽",
		"Cup;": "⋓",
		"cup;": "∪",
		"cupbrcap;": "⩈",
		"CupCap;": "≍",
		"cupcap;": "⩆",
		"cupcup;": "⩊",
		"cupdot;": "⊍",
		"cupor;": "⩅",
		"cups;": "∪︀",
		"curarr;": "↷",
		"curarrm;": "⤼",
		"curlyeqprec;": "⋞",
		"curlyeqsucc;": "⋟",
		"curlyvee;": "⋎",
		"curlywedge;": "⋏",
		"curren;": "¤",
		curren: "¤",
		"curvearrowleft;": "↶",
		"curvearrowright;": "↷",
		"cuvee;": "⋎",
		"cuwed;": "⋏",
		"cwconint;": "∲",
		"cwint;": "∱",
		"cylcty;": "⌭",
		"Dagger;": "‡",
		"dagger;": "†",
		"daleth;": "ℸ",
		"Darr;": "↡",
		"dArr;": "⇓",
		"darr;": "↓",
		"dash;": "‐",
		"Dashv;": "⫤",
		"dashv;": "⊣",
		"dbkarow;": "⤏",
		"dblac;": "˝",
		"Dcaron;": "Ď",
		"dcaron;": "ď",
		"Dcy;": "Д",
		"dcy;": "д",
		"DD;": "ⅅ",
		"dd;": "ⅆ",
		"ddagger;": "‡",
		"ddarr;": "⇊",
		"DDotrahd;": "⤑",
		"ddotseq;": "⩷",
		"deg;": "°",
		deg: "°",
		"Del;": "∇",
		"Delta;": "Δ",
		"delta;": "δ",
		"demptyv;": "⦱",
		"dfisht;": "⥿",
		"Dfr;": "𝔇",
		"dfr;": "𝔡",
		"dHar;": "⥥",
		"dharl;": "⇃",
		"dharr;": "⇂",
		"DiacriticalAcute;": "´",
		"DiacriticalDot;": "˙",
		"DiacriticalDoubleAcute;": "˝",
		"DiacriticalGrave;": "`",
		"DiacriticalTilde;": "˜",
		"diam;": "⋄",
		"Diamond;": "⋄",
		"diamond;": "⋄",
		"diamondsuit;": "♦",
		"diams;": "♦",
		"die;": "¨",
		"DifferentialD;": "ⅆ",
		"digamma;": "ϝ",
		"disin;": "⋲",
		"div;": "÷",
		"divide;": "÷",
		divide: "÷",
		"divideontimes;": "⋇",
		"divonx;": "⋇",
		"DJcy;": "Ђ",
		"djcy;": "ђ",
		"dlcorn;": "⌞",
		"dlcrop;": "⌍",
		"dollar;": "$",
		"Dopf;": "𝔻",
		"dopf;": "𝕕",
		"Dot;": "¨",
		"dot;": "˙",
		"DotDot;": "⃜",
		"doteq;": "≐",
		"doteqdot;": "≑",
		"DotEqual;": "≐",
		"dotminus;": "∸",
		"dotplus;": "∔",
		"dotsquare;": "⊡",
		"doublebarwedge;": "⌆",
		"DoubleContourIntegral;": "∯",
		"DoubleDot;": "¨",
		"DoubleDownArrow;": "⇓",
		"DoubleLeftArrow;": "⇐",
		"DoubleLeftRightArrow;": "⇔",
		"DoubleLeftTee;": "⫤",
		"DoubleLongLeftArrow;": "⟸",
		"DoubleLongLeftRightArrow;": "⟺",
		"DoubleLongRightArrow;": "⟹",
		"DoubleRightArrow;": "⇒",
		"DoubleRightTee;": "⊨",
		"DoubleUpArrow;": "⇑",
		"DoubleUpDownArrow;": "⇕",
		"DoubleVerticalBar;": "∥",
		"DownArrow;": "↓",
		"Downarrow;": "⇓",
		"downarrow;": "↓",
		"DownArrowBar;": "⤓",
		"DownArrowUpArrow;": "⇵",
		"DownBreve;": "̑",
		"downdownarrows;": "⇊",
		"downharpoonleft;": "⇃",
		"downharpoonright;": "⇂",
		"DownLeftRightVector;": "⥐",
		"DownLeftTeeVector;": "⥞",
		"DownLeftVector;": "↽",
		"DownLeftVectorBar;": "⥖",
		"DownRightTeeVector;": "⥟",
		"DownRightVector;": "⇁",
		"DownRightVectorBar;": "⥗",
		"DownTee;": "⊤",
		"DownTeeArrow;": "↧",
		"drbkarow;": "⤐",
		"drcorn;": "⌟",
		"drcrop;": "⌌",
		"Dscr;": "𝒟",
		"dscr;": "𝒹",
		"DScy;": "Ѕ",
		"dscy;": "ѕ",
		"dsol;": "⧶",
		"Dstrok;": "Đ",
		"dstrok;": "đ",
		"dtdot;": "⋱",
		"dtri;": "▿",
		"dtrif;": "▾",
		"duarr;": "⇵",
		"duhar;": "⥯",
		"dwangle;": "⦦",
		"DZcy;": "Џ",
		"dzcy;": "џ",
		"dzigrarr;": "⟿",
		"Eacute;": "É",
		Eacute: "É",
		"eacute;": "é",
		eacute: "é",
		"easter;": "⩮",
		"Ecaron;": "Ě",
		"ecaron;": "ě",
		"ecir;": "≖",
		"Ecirc;": "Ê",
		Ecirc: "Ê",
		"ecirc;": "ê",
		ecirc: "ê",
		"ecolon;": "≕",
		"Ecy;": "Э",
		"ecy;": "э",
		"eDDot;": "⩷",
		"Edot;": "Ė",
		"eDot;": "≑",
		"edot;": "ė",
		"ee;": "ⅇ",
		"efDot;": "≒",
		"Efr;": "𝔈",
		"efr;": "𝔢",
		"eg;": "⪚",
		"Egrave;": "È",
		Egrave: "È",
		"egrave;": "è",
		egrave: "è",
		"egs;": "⪖",
		"egsdot;": "⪘",
		"el;": "⪙",
		"Element;": "∈",
		"elinters;": "⏧",
		"ell;": "ℓ",
		"els;": "⪕",
		"elsdot;": "⪗",
		"Emacr;": "Ē",
		"emacr;": "ē",
		"empty;": "∅",
		"emptyset;": "∅",
		"EmptySmallSquare;": "◻",
		"emptyv;": "∅",
		"EmptyVerySmallSquare;": "▫",
		"emsp;": " ",
		"emsp13;": " ",
		"emsp14;": " ",
		"ENG;": "Ŋ",
		"eng;": "ŋ",
		"ensp;": " ",
		"Eogon;": "Ę",
		"eogon;": "ę",
		"Eopf;": "𝔼",
		"eopf;": "𝕖",
		"epar;": "⋕",
		"eparsl;": "⧣",
		"eplus;": "⩱",
		"epsi;": "ε",
		"Epsilon;": "Ε",
		"epsilon;": "ε",
		"epsiv;": "ϵ",
		"eqcirc;": "≖",
		"eqcolon;": "≕",
		"eqsim;": "≂",
		"eqslantgtr;": "⪖",
		"eqslantless;": "⪕",
		"Equal;": "⩵",
		"equals;": "=",
		"EqualTilde;": "≂",
		"equest;": "≟",
		"Equilibrium;": "⇌",
		"equiv;": "≡",
		"equivDD;": "⩸",
		"eqvparsl;": "⧥",
		"erarr;": "⥱",
		"erDot;": "≓",
		"Escr;": "ℰ",
		"escr;": "ℯ",
		"esdot;": "≐",
		"Esim;": "⩳",
		"esim;": "≂",
		"Eta;": "Η",
		"eta;": "η",
		"ETH;": "Ð",
		ETH: "Ð",
		"eth;": "ð",
		eth: "ð",
		"Euml;": "Ë",
		Euml: "Ë",
		"euml;": "ë",
		euml: "ë",
		"euro;": "€",
		"excl;": "!",
		"exist;": "∃",
		"Exists;": "∃",
		"expectation;": "ℰ",
		"ExponentialE;": "ⅇ",
		"exponentiale;": "ⅇ",
		"fallingdotseq;": "≒",
		"Fcy;": "Ф",
		"fcy;": "ф",
		"female;": "♀",
		"ffilig;": "ﬃ",
		"fflig;": "ﬀ",
		"ffllig;": "ﬄ",
		"Ffr;": "𝔉",
		"ffr;": "𝔣",
		"filig;": "ﬁ",
		"FilledSmallSquare;": "◼",
		"FilledVerySmallSquare;": "▪",
		"fjlig;": "fj",
		"flat;": "♭",
		"fllig;": "ﬂ",
		"fltns;": "▱",
		"fnof;": "ƒ",
		"Fopf;": "𝔽",
		"fopf;": "𝕗",
		"ForAll;": "∀",
		"forall;": "∀",
		"fork;": "⋔",
		"forkv;": "⫙",
		"Fouriertrf;": "ℱ",
		"fpartint;": "⨍",
		"frac12;": "½",
		frac12: "½",
		"frac13;": "⅓",
		"frac14;": "¼",
		frac14: "¼",
		"frac15;": "⅕",
		"frac16;": "⅙",
		"frac18;": "⅛",
		"frac23;": "⅔",
		"frac25;": "⅖",
		"frac34;": "¾",
		frac34: "¾",
		"frac35;": "⅗",
		"frac38;": "⅜",
		"frac45;": "⅘",
		"frac56;": "⅚",
		"frac58;": "⅝",
		"frac78;": "⅞",
		"frasl;": "⁄",
		"frown;": "⌢",
		"Fscr;": "ℱ",
		"fscr;": "𝒻",
		"gacute;": "ǵ",
		"Gamma;": "Γ",
		"gamma;": "γ",
		"Gammad;": "Ϝ",
		"gammad;": "ϝ",
		"gap;": "⪆",
		"Gbreve;": "Ğ",
		"gbreve;": "ğ",
		"Gcedil;": "Ģ",
		"Gcirc;": "Ĝ",
		"gcirc;": "ĝ",
		"Gcy;": "Г",
		"gcy;": "г",
		"Gdot;": "Ġ",
		"gdot;": "ġ",
		"gE;": "≧",
		"ge;": "≥",
		"gEl;": "⪌",
		"gel;": "⋛",
		"geq;": "≥",
		"geqq;": "≧",
		"geqslant;": "⩾",
		"ges;": "⩾",
		"gescc;": "⪩",
		"gesdot;": "⪀",
		"gesdoto;": "⪂",
		"gesdotol;": "⪄",
		"gesl;": "⋛︀",
		"gesles;": "⪔",
		"Gfr;": "𝔊",
		"gfr;": "𝔤",
		"Gg;": "⋙",
		"gg;": "≫",
		"ggg;": "⋙",
		"gimel;": "ℷ",
		"GJcy;": "Ѓ",
		"gjcy;": "ѓ",
		"gl;": "≷",
		"gla;": "⪥",
		"glE;": "⪒",
		"glj;": "⪤",
		"gnap;": "⪊",
		"gnapprox;": "⪊",
		"gnE;": "≩",
		"gne;": "⪈",
		"gneq;": "⪈",
		"gneqq;": "≩",
		"gnsim;": "⋧",
		"Gopf;": "𝔾",
		"gopf;": "𝕘",
		"grave;": "`",
		"GreaterEqual;": "≥",
		"GreaterEqualLess;": "⋛",
		"GreaterFullEqual;": "≧",
		"GreaterGreater;": "⪢",
		"GreaterLess;": "≷",
		"GreaterSlantEqual;": "⩾",
		"GreaterTilde;": "≳",
		"Gscr;": "𝒢",
		"gscr;": "ℊ",
		"gsim;": "≳",
		"gsime;": "⪎",
		"gsiml;": "⪐",
		"GT;": ">",
		GT: ">",
		"Gt;": "≫",
		"gt;": ">",
		gt: ">",
		"gtcc;": "⪧",
		"gtcir;": "⩺",
		"gtdot;": "⋗",
		"gtlPar;": "⦕",
		"gtquest;": "⩼",
		"gtrapprox;": "⪆",
		"gtrarr;": "⥸",
		"gtrdot;": "⋗",
		"gtreqless;": "⋛",
		"gtreqqless;": "⪌",
		"gtrless;": "≷",
		"gtrsim;": "≳",
		"gvertneqq;": "≩︀",
		"gvnE;": "≩︀",
		"Hacek;": "ˇ",
		"hairsp;": " ",
		"half;": "½",
		"hamilt;": "ℋ",
		"HARDcy;": "Ъ",
		"hardcy;": "ъ",
		"hArr;": "⇔",
		"harr;": "↔",
		"harrcir;": "⥈",
		"harrw;": "↭",
		"Hat;": "^",
		"hbar;": "ℏ",
		"Hcirc;": "Ĥ",
		"hcirc;": "ĥ",
		"hearts;": "♥",
		"heartsuit;": "♥",
		"hellip;": "…",
		"hercon;": "⊹",
		"Hfr;": "ℌ",
		"hfr;": "𝔥",
		"HilbertSpace;": "ℋ",
		"hksearow;": "⤥",
		"hkswarow;": "⤦",
		"hoarr;": "⇿",
		"homtht;": "∻",
		"hookleftarrow;": "↩",
		"hookrightarrow;": "↪",
		"Hopf;": "ℍ",
		"hopf;": "𝕙",
		"horbar;": "―",
		"HorizontalLine;": "─",
		"Hscr;": "ℋ",
		"hscr;": "𝒽",
		"hslash;": "ℏ",
		"Hstrok;": "Ħ",
		"hstrok;": "ħ",
		"HumpDownHump;": "≎",
		"HumpEqual;": "≏",
		"hybull;": "⁃",
		"hyphen;": "‐",
		"Iacute;": "Í",
		Iacute: "Í",
		"iacute;": "í",
		iacute: "í",
		"ic;": "⁣",
		"Icirc;": "Î",
		Icirc: "Î",
		"icirc;": "î",
		icirc: "î",
		"Icy;": "И",
		"icy;": "и",
		"Idot;": "İ",
		"IEcy;": "Е",
		"iecy;": "е",
		"iexcl;": "¡",
		iexcl: "¡",
		"iff;": "⇔",
		"Ifr;": "ℑ",
		"ifr;": "𝔦",
		"Igrave;": "Ì",
		Igrave: "Ì",
		"igrave;": "ì",
		igrave: "ì",
		"ii;": "ⅈ",
		"iiiint;": "⨌",
		"iiint;": "∭",
		"iinfin;": "⧜",
		"iiota;": "℩",
		"IJlig;": "Ĳ",
		"ijlig;": "ĳ",
		"Im;": "ℑ",
		"Imacr;": "Ī",
		"imacr;": "ī",
		"image;": "ℑ",
		"ImaginaryI;": "ⅈ",
		"imagline;": "ℐ",
		"imagpart;": "ℑ",
		"imath;": "ı",
		"imof;": "⊷",
		"imped;": "Ƶ",
		"Implies;": "⇒",
		"in;": "∈",
		"incare;": "℅",
		"infin;": "∞",
		"infintie;": "⧝",
		"inodot;": "ı",
		"Int;": "∬",
		"int;": "∫",
		"intcal;": "⊺",
		"integers;": "ℤ",
		"Integral;": "∫",
		"intercal;": "⊺",
		"Intersection;": "⋂",
		"intlarhk;": "⨗",
		"intprod;": "⨼",
		"InvisibleComma;": "⁣",
		"InvisibleTimes;": "⁢",
		"IOcy;": "Ё",
		"iocy;": "ё",
		"Iogon;": "Į",
		"iogon;": "į",
		"Iopf;": "𝕀",
		"iopf;": "𝕚",
		"Iota;": "Ι",
		"iota;": "ι",
		"iprod;": "⨼",
		"iquest;": "¿",
		iquest: "¿",
		"Iscr;": "ℐ",
		"iscr;": "𝒾",
		"isin;": "∈",
		"isindot;": "⋵",
		"isinE;": "⋹",
		"isins;": "⋴",
		"isinsv;": "⋳",
		"isinv;": "∈",
		"it;": "⁢",
		"Itilde;": "Ĩ",
		"itilde;": "ĩ",
		"Iukcy;": "І",
		"iukcy;": "і",
		"Iuml;": "Ï",
		Iuml: "Ï",
		"iuml;": "ï",
		iuml: "ï",
		"Jcirc;": "Ĵ",
		"jcirc;": "ĵ",
		"Jcy;": "Й",
		"jcy;": "й",
		"Jfr;": "𝔍",
		"jfr;": "𝔧",
		"jmath;": "ȷ",
		"Jopf;": "𝕁",
		"jopf;": "𝕛",
		"Jscr;": "𝒥",
		"jscr;": "𝒿",
		"Jsercy;": "Ј",
		"jsercy;": "ј",
		"Jukcy;": "Є",
		"jukcy;": "є",
		"Kappa;": "Κ",
		"kappa;": "κ",
		"kappav;": "ϰ",
		"Kcedil;": "Ķ",
		"kcedil;": "ķ",
		"Kcy;": "К",
		"kcy;": "к",
		"Kfr;": "𝔎",
		"kfr;": "𝔨",
		"kgreen;": "ĸ",
		"KHcy;": "Х",
		"khcy;": "х",
		"KJcy;": "Ќ",
		"kjcy;": "ќ",
		"Kopf;": "𝕂",
		"kopf;": "𝕜",
		"Kscr;": "𝒦",
		"kscr;": "𝓀",
		"lAarr;": "⇚",
		"Lacute;": "Ĺ",
		"lacute;": "ĺ",
		"laemptyv;": "⦴",
		"lagran;": "ℒ",
		"Lambda;": "Λ",
		"lambda;": "λ",
		"Lang;": "⟪",
		"lang;": "⟨",
		"langd;": "⦑",
		"langle;": "⟨",
		"lap;": "⪅",
		"Laplacetrf;": "ℒ",
		"laquo;": "«",
		laquo: "«",
		"Larr;": "↞",
		"lArr;": "⇐",
		"larr;": "←",
		"larrb;": "⇤",
		"larrbfs;": "⤟",
		"larrfs;": "⤝",
		"larrhk;": "↩",
		"larrlp;": "↫",
		"larrpl;": "⤹",
		"larrsim;": "⥳",
		"larrtl;": "↢",
		"lat;": "⪫",
		"lAtail;": "⤛",
		"latail;": "⤙",
		"late;": "⪭",
		"lates;": "⪭︀",
		"lBarr;": "⤎",
		"lbarr;": "⤌",
		"lbbrk;": "❲",
		"lbrace;": "{",
		"lbrack;": "[",
		"lbrke;": "⦋",
		"lbrksld;": "⦏",
		"lbrkslu;": "⦍",
		"Lcaron;": "Ľ",
		"lcaron;": "ľ",
		"Lcedil;": "Ļ",
		"lcedil;": "ļ",
		"lceil;": "⌈",
		"lcub;": "{",
		"Lcy;": "Л",
		"lcy;": "л",
		"ldca;": "⤶",
		"ldquo;": "“",
		"ldquor;": "„",
		"ldrdhar;": "⥧",
		"ldrushar;": "⥋",
		"ldsh;": "↲",
		"lE;": "≦",
		"le;": "≤",
		"LeftAngleBracket;": "⟨",
		"LeftArrow;": "←",
		"Leftarrow;": "⇐",
		"leftarrow;": "←",
		"LeftArrowBar;": "⇤",
		"LeftArrowRightArrow;": "⇆",
		"leftarrowtail;": "↢",
		"LeftCeiling;": "⌈",
		"LeftDoubleBracket;": "⟦",
		"LeftDownTeeVector;": "⥡",
		"LeftDownVector;": "⇃",
		"LeftDownVectorBar;": "⥙",
		"LeftFloor;": "⌊",
		"leftharpoondown;": "↽",
		"leftharpoonup;": "↼",
		"leftleftarrows;": "⇇",
		"LeftRightArrow;": "↔",
		"Leftrightarrow;": "⇔",
		"leftrightarrow;": "↔",
		"leftrightarrows;": "⇆",
		"leftrightharpoons;": "⇋",
		"leftrightsquigarrow;": "↭",
		"LeftRightVector;": "⥎",
		"LeftTee;": "⊣",
		"LeftTeeArrow;": "↤",
		"LeftTeeVector;": "⥚",
		"leftthreetimes;": "⋋",
		"LeftTriangle;": "⊲",
		"LeftTriangleBar;": "⧏",
		"LeftTriangleEqual;": "⊴",
		"LeftUpDownVector;": "⥑",
		"LeftUpTeeVector;": "⥠",
		"LeftUpVector;": "↿",
		"LeftUpVectorBar;": "⥘",
		"LeftVector;": "↼",
		"LeftVectorBar;": "⥒",
		"lEg;": "⪋",
		"leg;": "⋚",
		"leq;": "≤",
		"leqq;": "≦",
		"leqslant;": "⩽",
		"les;": "⩽",
		"lescc;": "⪨",
		"lesdot;": "⩿",
		"lesdoto;": "⪁",
		"lesdotor;": "⪃",
		"lesg;": "⋚︀",
		"lesges;": "⪓",
		"lessapprox;": "⪅",
		"lessdot;": "⋖",
		"lesseqgtr;": "⋚",
		"lesseqqgtr;": "⪋",
		"LessEqualGreater;": "⋚",
		"LessFullEqual;": "≦",
		"LessGreater;": "≶",
		"lessgtr;": "≶",
		"LessLess;": "⪡",
		"lesssim;": "≲",
		"LessSlantEqual;": "⩽",
		"LessTilde;": "≲",
		"lfisht;": "⥼",
		"lfloor;": "⌊",
		"Lfr;": "𝔏",
		"lfr;": "𝔩",
		"lg;": "≶",
		"lgE;": "⪑",
		"lHar;": "⥢",
		"lhard;": "↽",
		"lharu;": "↼",
		"lharul;": "⥪",
		"lhblk;": "▄",
		"LJcy;": "Љ",
		"ljcy;": "љ",
		"Ll;": "⋘",
		"ll;": "≪",
		"llarr;": "⇇",
		"llcorner;": "⌞",
		"Lleftarrow;": "⇚",
		"llhard;": "⥫",
		"lltri;": "◺",
		"Lmidot;": "Ŀ",
		"lmidot;": "ŀ",
		"lmoust;": "⎰",
		"lmoustache;": "⎰",
		"lnap;": "⪉",
		"lnapprox;": "⪉",
		"lnE;": "≨",
		"lne;": "⪇",
		"lneq;": "⪇",
		"lneqq;": "≨",
		"lnsim;": "⋦",
		"loang;": "⟬",
		"loarr;": "⇽",
		"lobrk;": "⟦",
		"LongLeftArrow;": "⟵",
		"Longleftarrow;": "⟸",
		"longleftarrow;": "⟵",
		"LongLeftRightArrow;": "⟷",
		"Longleftrightarrow;": "⟺",
		"longleftrightarrow;": "⟷",
		"longmapsto;": "⟼",
		"LongRightArrow;": "⟶",
		"Longrightarrow;": "⟹",
		"longrightarrow;": "⟶",
		"looparrowleft;": "↫",
		"looparrowright;": "↬",
		"lopar;": "⦅",
		"Lopf;": "𝕃",
		"lopf;": "𝕝",
		"loplus;": "⨭",
		"lotimes;": "⨴",
		"lowast;": "∗",
		"lowbar;": "_",
		"LowerLeftArrow;": "↙",
		"LowerRightArrow;": "↘",
		"loz;": "◊",
		"lozenge;": "◊",
		"lozf;": "⧫",
		"lpar;": "(",
		"lparlt;": "⦓",
		"lrarr;": "⇆",
		"lrcorner;": "⌟",
		"lrhar;": "⇋",
		"lrhard;": "⥭",
		"lrm;": "‎",
		"lrtri;": "⊿",
		"lsaquo;": "‹",
		"Lscr;": "ℒ",
		"lscr;": "𝓁",
		"Lsh;": "↰",
		"lsh;": "↰",
		"lsim;": "≲",
		"lsime;": "⪍",
		"lsimg;": "⪏",
		"lsqb;": "[",
		"lsquo;": "‘",
		"lsquor;": "‚",
		"Lstrok;": "Ł",
		"lstrok;": "ł",
		"LT;": "<",
		LT: "<",
		"Lt;": "≪",
		"lt;": "<",
		lt: "<",
		"ltcc;": "⪦",
		"ltcir;": "⩹",
		"ltdot;": "⋖",
		"lthree;": "⋋",
		"ltimes;": "⋉",
		"ltlarr;": "⥶",
		"ltquest;": "⩻",
		"ltri;": "◃",
		"ltrie;": "⊴",
		"ltrif;": "◂",
		"ltrPar;": "⦖",
		"lurdshar;": "⥊",
		"luruhar;": "⥦",
		"lvertneqq;": "≨︀",
		"lvnE;": "≨︀",
		"macr;": "¯",
		macr: "¯",
		"male;": "♂",
		"malt;": "✠",
		"maltese;": "✠",
		"Map;": "⤅",
		"map;": "↦",
		"mapsto;": "↦",
		"mapstodown;": "↧",
		"mapstoleft;": "↤",
		"mapstoup;": "↥",
		"marker;": "▮",
		"mcomma;": "⨩",
		"Mcy;": "М",
		"mcy;": "м",
		"mdash;": "—",
		"mDDot;": "∺",
		"measuredangle;": "∡",
		"MediumSpace;": " ",
		"Mellintrf;": "ℳ",
		"Mfr;": "𝔐",
		"mfr;": "𝔪",
		"mho;": "℧",
		"micro;": "µ",
		micro: "µ",
		"mid;": "∣",
		"midast;": "*",
		"midcir;": "⫰",
		"middot;": "·",
		middot: "·",
		"minus;": "−",
		"minusb;": "⊟",
		"minusd;": "∸",
		"minusdu;": "⨪",
		"MinusPlus;": "∓",
		"mlcp;": "⫛",
		"mldr;": "…",
		"mnplus;": "∓",
		"models;": "⊧",
		"Mopf;": "𝕄",
		"mopf;": "𝕞",
		"mp;": "∓",
		"Mscr;": "ℳ",
		"mscr;": "𝓂",
		"mstpos;": "∾",
		"Mu;": "Μ",
		"mu;": "μ",
		"multimap;": "⊸",
		"mumap;": "⊸",
		"nabla;": "∇",
		"Nacute;": "Ń",
		"nacute;": "ń",
		"nang;": "∠⃒",
		"nap;": "≉",
		"napE;": "⩰̸",
		"napid;": "≋̸",
		"napos;": "ŉ",
		"napprox;": "≉",
		"natur;": "♮",
		"natural;": "♮",
		"naturals;": "ℕ",
		"nbsp;": "\xA0",
		nbsp: "\xA0",
		"nbump;": "≎̸",
		"nbumpe;": "≏̸",
		"ncap;": "⩃",
		"Ncaron;": "Ň",
		"ncaron;": "ň",
		"Ncedil;": "Ņ",
		"ncedil;": "ņ",
		"ncong;": "≇",
		"ncongdot;": "⩭̸",
		"ncup;": "⩂",
		"Ncy;": "Н",
		"ncy;": "н",
		"ndash;": "–",
		"ne;": "≠",
		"nearhk;": "⤤",
		"neArr;": "⇗",
		"nearr;": "↗",
		"nearrow;": "↗",
		"nedot;": "≐̸",
		"NegativeMediumSpace;": "​",
		"NegativeThickSpace;": "​",
		"NegativeThinSpace;": "​",
		"NegativeVeryThinSpace;": "​",
		"nequiv;": "≢",
		"nesear;": "⤨",
		"nesim;": "≂̸",
		"NestedGreaterGreater;": "≫",
		"NestedLessLess;": "≪",
		"NewLine;": "\n",
		"nexist;": "∄",
		"nexists;": "∄",
		"Nfr;": "𝔑",
		"nfr;": "𝔫",
		"ngE;": "≧̸",
		"nge;": "≱",
		"ngeq;": "≱",
		"ngeqq;": "≧̸",
		"ngeqslant;": "⩾̸",
		"nges;": "⩾̸",
		"nGg;": "⋙̸",
		"ngsim;": "≵",
		"nGt;": "≫⃒",
		"ngt;": "≯",
		"ngtr;": "≯",
		"nGtv;": "≫̸",
		"nhArr;": "⇎",
		"nharr;": "↮",
		"nhpar;": "⫲",
		"ni;": "∋",
		"nis;": "⋼",
		"nisd;": "⋺",
		"niv;": "∋",
		"NJcy;": "Њ",
		"njcy;": "њ",
		"nlArr;": "⇍",
		"nlarr;": "↚",
		"nldr;": "‥",
		"nlE;": "≦̸",
		"nle;": "≰",
		"nLeftarrow;": "⇍",
		"nleftarrow;": "↚",
		"nLeftrightarrow;": "⇎",
		"nleftrightarrow;": "↮",
		"nleq;": "≰",
		"nleqq;": "≦̸",
		"nleqslant;": "⩽̸",
		"nles;": "⩽̸",
		"nless;": "≮",
		"nLl;": "⋘̸",
		"nlsim;": "≴",
		"nLt;": "≪⃒",
		"nlt;": "≮",
		"nltri;": "⋪",
		"nltrie;": "⋬",
		"nLtv;": "≪̸",
		"nmid;": "∤",
		"NoBreak;": "⁠",
		"NonBreakingSpace;": "\xA0",
		"Nopf;": "ℕ",
		"nopf;": "𝕟",
		"Not;": "⫬",
		"not;": "¬",
		not: "¬",
		"NotCongruent;": "≢",
		"NotCupCap;": "≭",
		"NotDoubleVerticalBar;": "∦",
		"NotElement;": "∉",
		"NotEqual;": "≠",
		"NotEqualTilde;": "≂̸",
		"NotExists;": "∄",
		"NotGreater;": "≯",
		"NotGreaterEqual;": "≱",
		"NotGreaterFullEqual;": "≧̸",
		"NotGreaterGreater;": "≫̸",
		"NotGreaterLess;": "≹",
		"NotGreaterSlantEqual;": "⩾̸",
		"NotGreaterTilde;": "≵",
		"NotHumpDownHump;": "≎̸",
		"NotHumpEqual;": "≏̸",
		"notin;": "∉",
		"notindot;": "⋵̸",
		"notinE;": "⋹̸",
		"notinva;": "∉",
		"notinvb;": "⋷",
		"notinvc;": "⋶",
		"NotLeftTriangle;": "⋪",
		"NotLeftTriangleBar;": "⧏̸",
		"NotLeftTriangleEqual;": "⋬",
		"NotLess;": "≮",
		"NotLessEqual;": "≰",
		"NotLessGreater;": "≸",
		"NotLessLess;": "≪̸",
		"NotLessSlantEqual;": "⩽̸",
		"NotLessTilde;": "≴",
		"NotNestedGreaterGreater;": "⪢̸",
		"NotNestedLessLess;": "⪡̸",
		"notni;": "∌",
		"notniva;": "∌",
		"notnivb;": "⋾",
		"notnivc;": "⋽",
		"NotPrecedes;": "⊀",
		"NotPrecedesEqual;": "⪯̸",
		"NotPrecedesSlantEqual;": "⋠",
		"NotReverseElement;": "∌",
		"NotRightTriangle;": "⋫",
		"NotRightTriangleBar;": "⧐̸",
		"NotRightTriangleEqual;": "⋭",
		"NotSquareSubset;": "⊏̸",
		"NotSquareSubsetEqual;": "⋢",
		"NotSquareSuperset;": "⊐̸",
		"NotSquareSupersetEqual;": "⋣",
		"NotSubset;": "⊂⃒",
		"NotSubsetEqual;": "⊈",
		"NotSucceeds;": "⊁",
		"NotSucceedsEqual;": "⪰̸",
		"NotSucceedsSlantEqual;": "⋡",
		"NotSucceedsTilde;": "≿̸",
		"NotSuperset;": "⊃⃒",
		"NotSupersetEqual;": "⊉",
		"NotTilde;": "≁",
		"NotTildeEqual;": "≄",
		"NotTildeFullEqual;": "≇",
		"NotTildeTilde;": "≉",
		"NotVerticalBar;": "∤",
		"npar;": "∦",
		"nparallel;": "∦",
		"nparsl;": "⫽⃥",
		"npart;": "∂̸",
		"npolint;": "⨔",
		"npr;": "⊀",
		"nprcue;": "⋠",
		"npre;": "⪯̸",
		"nprec;": "⊀",
		"npreceq;": "⪯̸",
		"nrArr;": "⇏",
		"nrarr;": "↛",
		"nrarrc;": "⤳̸",
		"nrarrw;": "↝̸",
		"nRightarrow;": "⇏",
		"nrightarrow;": "↛",
		"nrtri;": "⋫",
		"nrtrie;": "⋭",
		"nsc;": "⊁",
		"nsccue;": "⋡",
		"nsce;": "⪰̸",
		"Nscr;": "𝒩",
		"nscr;": "𝓃",
		"nshortmid;": "∤",
		"nshortparallel;": "∦",
		"nsim;": "≁",
		"nsime;": "≄",
		"nsimeq;": "≄",
		"nsmid;": "∤",
		"nspar;": "∦",
		"nsqsube;": "⋢",
		"nsqsupe;": "⋣",
		"nsub;": "⊄",
		"nsubE;": "⫅̸",
		"nsube;": "⊈",
		"nsubset;": "⊂⃒",
		"nsubseteq;": "⊈",
		"nsubseteqq;": "⫅̸",
		"nsucc;": "⊁",
		"nsucceq;": "⪰̸",
		"nsup;": "⊅",
		"nsupE;": "⫆̸",
		"nsupe;": "⊉",
		"nsupset;": "⊃⃒",
		"nsupseteq;": "⊉",
		"nsupseteqq;": "⫆̸",
		"ntgl;": "≹",
		"Ntilde;": "Ñ",
		Ntilde: "Ñ",
		"ntilde;": "ñ",
		ntilde: "ñ",
		"ntlg;": "≸",
		"ntriangleleft;": "⋪",
		"ntrianglelefteq;": "⋬",
		"ntriangleright;": "⋫",
		"ntrianglerighteq;": "⋭",
		"Nu;": "Ν",
		"nu;": "ν",
		"num;": "#",
		"numero;": "№",
		"numsp;": " ",
		"nvap;": "≍⃒",
		"nVDash;": "⊯",
		"nVdash;": "⊮",
		"nvDash;": "⊭",
		"nvdash;": "⊬",
		"nvge;": "≥⃒",
		"nvgt;": ">⃒",
		"nvHarr;": "⤄",
		"nvinfin;": "⧞",
		"nvlArr;": "⤂",
		"nvle;": "≤⃒",
		"nvlt;": "<⃒",
		"nvltrie;": "⊴⃒",
		"nvrArr;": "⤃",
		"nvrtrie;": "⊵⃒",
		"nvsim;": "∼⃒",
		"nwarhk;": "⤣",
		"nwArr;": "⇖",
		"nwarr;": "↖",
		"nwarrow;": "↖",
		"nwnear;": "⤧",
		"Oacute;": "Ó",
		Oacute: "Ó",
		"oacute;": "ó",
		oacute: "ó",
		"oast;": "⊛",
		"ocir;": "⊚",
		"Ocirc;": "Ô",
		Ocirc: "Ô",
		"ocirc;": "ô",
		ocirc: "ô",
		"Ocy;": "О",
		"ocy;": "о",
		"odash;": "⊝",
		"Odblac;": "Ő",
		"odblac;": "ő",
		"odiv;": "⨸",
		"odot;": "⊙",
		"odsold;": "⦼",
		"OElig;": "Œ",
		"oelig;": "œ",
		"ofcir;": "⦿",
		"Ofr;": "𝔒",
		"ofr;": "𝔬",
		"ogon;": "˛",
		"Ograve;": "Ò",
		Ograve: "Ò",
		"ograve;": "ò",
		ograve: "ò",
		"ogt;": "⧁",
		"ohbar;": "⦵",
		"ohm;": "Ω",
		"oint;": "∮",
		"olarr;": "↺",
		"olcir;": "⦾",
		"olcross;": "⦻",
		"oline;": "‾",
		"olt;": "⧀",
		"Omacr;": "Ō",
		"omacr;": "ō",
		"Omega;": "Ω",
		"omega;": "ω",
		"Omicron;": "Ο",
		"omicron;": "ο",
		"omid;": "⦶",
		"ominus;": "⊖",
		"Oopf;": "𝕆",
		"oopf;": "𝕠",
		"opar;": "⦷",
		"OpenCurlyDoubleQuote;": "“",
		"OpenCurlyQuote;": "‘",
		"operp;": "⦹",
		"oplus;": "⊕",
		"Or;": "⩔",
		"or;": "∨",
		"orarr;": "↻",
		"ord;": "⩝",
		"order;": "ℴ",
		"orderof;": "ℴ",
		"ordf;": "ª",
		ordf: "ª",
		"ordm;": "º",
		ordm: "º",
		"origof;": "⊶",
		"oror;": "⩖",
		"orslope;": "⩗",
		"orv;": "⩛",
		"oS;": "Ⓢ",
		"Oscr;": "𝒪",
		"oscr;": "ℴ",
		"Oslash;": "Ø",
		Oslash: "Ø",
		"oslash;": "ø",
		oslash: "ø",
		"osol;": "⊘",
		"Otilde;": "Õ",
		Otilde: "Õ",
		"otilde;": "õ",
		otilde: "õ",
		"Otimes;": "⨷",
		"otimes;": "⊗",
		"otimesas;": "⨶",
		"Ouml;": "Ö",
		Ouml: "Ö",
		"ouml;": "ö",
		ouml: "ö",
		"ovbar;": "⌽",
		"OverBar;": "‾",
		"OverBrace;": "⏞",
		"OverBracket;": "⎴",
		"OverParenthesis;": "⏜",
		"par;": "∥",
		"para;": "¶",
		para: "¶",
		"parallel;": "∥",
		"parsim;": "⫳",
		"parsl;": "⫽",
		"part;": "∂",
		"PartialD;": "∂",
		"Pcy;": "П",
		"pcy;": "п",
		"percnt;": "%",
		"period;": ".",
		"permil;": "‰",
		"perp;": "⊥",
		"pertenk;": "‱",
		"Pfr;": "𝔓",
		"pfr;": "𝔭",
		"Phi;": "Φ",
		"phi;": "φ",
		"phiv;": "ϕ",
		"phmmat;": "ℳ",
		"phone;": "☎",
		"Pi;": "Π",
		"pi;": "π",
		"pitchfork;": "⋔",
		"piv;": "ϖ",
		"planck;": "ℏ",
		"planckh;": "ℎ",
		"plankv;": "ℏ",
		"plus;": "+",
		"plusacir;": "⨣",
		"plusb;": "⊞",
		"pluscir;": "⨢",
		"plusdo;": "∔",
		"plusdu;": "⨥",
		"pluse;": "⩲",
		"PlusMinus;": "±",
		"plusmn;": "±",
		plusmn: "±",
		"plussim;": "⨦",
		"plustwo;": "⨧",
		"pm;": "±",
		"Poincareplane;": "ℌ",
		"pointint;": "⨕",
		"Popf;": "ℙ",
		"popf;": "𝕡",
		"pound;": "£",
		pound: "£",
		"Pr;": "⪻",
		"pr;": "≺",
		"prap;": "⪷",
		"prcue;": "≼",
		"prE;": "⪳",
		"pre;": "⪯",
		"prec;": "≺",
		"precapprox;": "⪷",
		"preccurlyeq;": "≼",
		"Precedes;": "≺",
		"PrecedesEqual;": "⪯",
		"PrecedesSlantEqual;": "≼",
		"PrecedesTilde;": "≾",
		"preceq;": "⪯",
		"precnapprox;": "⪹",
		"precneqq;": "⪵",
		"precnsim;": "⋨",
		"precsim;": "≾",
		"Prime;": "″",
		"prime;": "′",
		"primes;": "ℙ",
		"prnap;": "⪹",
		"prnE;": "⪵",
		"prnsim;": "⋨",
		"prod;": "∏",
		"Product;": "∏",
		"profalar;": "⌮",
		"profline;": "⌒",
		"profsurf;": "⌓",
		"prop;": "∝",
		"Proportion;": "∷",
		"Proportional;": "∝",
		"propto;": "∝",
		"prsim;": "≾",
		"prurel;": "⊰",
		"Pscr;": "𝒫",
		"pscr;": "𝓅",
		"Psi;": "Ψ",
		"psi;": "ψ",
		"puncsp;": " ",
		"Qfr;": "𝔔",
		"qfr;": "𝔮",
		"qint;": "⨌",
		"Qopf;": "ℚ",
		"qopf;": "𝕢",
		"qprime;": "⁗",
		"Qscr;": "𝒬",
		"qscr;": "𝓆",
		"quaternions;": "ℍ",
		"quatint;": "⨖",
		"quest;": "?",
		"questeq;": "≟",
		"QUOT;": "\"",
		QUOT: "\"",
		"quot;": "\"",
		quot: "\"",
		"rAarr;": "⇛",
		"race;": "∽̱",
		"Racute;": "Ŕ",
		"racute;": "ŕ",
		"radic;": "√",
		"raemptyv;": "⦳",
		"Rang;": "⟫",
		"rang;": "⟩",
		"rangd;": "⦒",
		"range;": "⦥",
		"rangle;": "⟩",
		"raquo;": "»",
		raquo: "»",
		"Rarr;": "↠",
		"rArr;": "⇒",
		"rarr;": "→",
		"rarrap;": "⥵",
		"rarrb;": "⇥",
		"rarrbfs;": "⤠",
		"rarrc;": "⤳",
		"rarrfs;": "⤞",
		"rarrhk;": "↪",
		"rarrlp;": "↬",
		"rarrpl;": "⥅",
		"rarrsim;": "⥴",
		"Rarrtl;": "⤖",
		"rarrtl;": "↣",
		"rarrw;": "↝",
		"rAtail;": "⤜",
		"ratail;": "⤚",
		"ratio;": "∶",
		"rationals;": "ℚ",
		"RBarr;": "⤐",
		"rBarr;": "⤏",
		"rbarr;": "⤍",
		"rbbrk;": "❳",
		"rbrace;": "}",
		"rbrack;": "]",
		"rbrke;": "⦌",
		"rbrksld;": "⦎",
		"rbrkslu;": "⦐",
		"Rcaron;": "Ř",
		"rcaron;": "ř",
		"Rcedil;": "Ŗ",
		"rcedil;": "ŗ",
		"rceil;": "⌉",
		"rcub;": "}",
		"Rcy;": "Р",
		"rcy;": "р",
		"rdca;": "⤷",
		"rdldhar;": "⥩",
		"rdquo;": "”",
		"rdquor;": "”",
		"rdsh;": "↳",
		"Re;": "ℜ",
		"real;": "ℜ",
		"realine;": "ℛ",
		"realpart;": "ℜ",
		"reals;": "ℝ",
		"rect;": "▭",
		"REG;": "®",
		REG: "®",
		"reg;": "®",
		reg: "®",
		"ReverseElement;": "∋",
		"ReverseEquilibrium;": "⇋",
		"ReverseUpEquilibrium;": "⥯",
		"rfisht;": "⥽",
		"rfloor;": "⌋",
		"Rfr;": "ℜ",
		"rfr;": "𝔯",
		"rHar;": "⥤",
		"rhard;": "⇁",
		"rharu;": "⇀",
		"rharul;": "⥬",
		"Rho;": "Ρ",
		"rho;": "ρ",
		"rhov;": "ϱ",
		"RightAngleBracket;": "⟩",
		"RightArrow;": "→",
		"Rightarrow;": "⇒",
		"rightarrow;": "→",
		"RightArrowBar;": "⇥",
		"RightArrowLeftArrow;": "⇄",
		"rightarrowtail;": "↣",
		"RightCeiling;": "⌉",
		"RightDoubleBracket;": "⟧",
		"RightDownTeeVector;": "⥝",
		"RightDownVector;": "⇂",
		"RightDownVectorBar;": "⥕",
		"RightFloor;": "⌋",
		"rightharpoondown;": "⇁",
		"rightharpoonup;": "⇀",
		"rightleftarrows;": "⇄",
		"rightleftharpoons;": "⇌",
		"rightrightarrows;": "⇉",
		"rightsquigarrow;": "↝",
		"RightTee;": "⊢",
		"RightTeeArrow;": "↦",
		"RightTeeVector;": "⥛",
		"rightthreetimes;": "⋌",
		"RightTriangle;": "⊳",
		"RightTriangleBar;": "⧐",
		"RightTriangleEqual;": "⊵",
		"RightUpDownVector;": "⥏",
		"RightUpTeeVector;": "⥜",
		"RightUpVector;": "↾",
		"RightUpVectorBar;": "⥔",
		"RightVector;": "⇀",
		"RightVectorBar;": "⥓",
		"ring;": "˚",
		"risingdotseq;": "≓",
		"rlarr;": "⇄",
		"rlhar;": "⇌",
		"rlm;": "‏",
		"rmoust;": "⎱",
		"rmoustache;": "⎱",
		"rnmid;": "⫮",
		"roang;": "⟭",
		"roarr;": "⇾",
		"robrk;": "⟧",
		"ropar;": "⦆",
		"Ropf;": "ℝ",
		"ropf;": "𝕣",
		"roplus;": "⨮",
		"rotimes;": "⨵",
		"RoundImplies;": "⥰",
		"rpar;": ")",
		"rpargt;": "⦔",
		"rppolint;": "⨒",
		"rrarr;": "⇉",
		"Rrightarrow;": "⇛",
		"rsaquo;": "›",
		"Rscr;": "ℛ",
		"rscr;": "𝓇",
		"Rsh;": "↱",
		"rsh;": "↱",
		"rsqb;": "]",
		"rsquo;": "’",
		"rsquor;": "’",
		"rthree;": "⋌",
		"rtimes;": "⋊",
		"rtri;": "▹",
		"rtrie;": "⊵",
		"rtrif;": "▸",
		"rtriltri;": "⧎",
		"RuleDelayed;": "⧴",
		"ruluhar;": "⥨",
		"rx;": "℞",
		"Sacute;": "Ś",
		"sacute;": "ś",
		"sbquo;": "‚",
		"Sc;": "⪼",
		"sc;": "≻",
		"scap;": "⪸",
		"Scaron;": "Š",
		"scaron;": "š",
		"sccue;": "≽",
		"scE;": "⪴",
		"sce;": "⪰",
		"Scedil;": "Ş",
		"scedil;": "ş",
		"Scirc;": "Ŝ",
		"scirc;": "ŝ",
		"scnap;": "⪺",
		"scnE;": "⪶",
		"scnsim;": "⋩",
		"scpolint;": "⨓",
		"scsim;": "≿",
		"Scy;": "С",
		"scy;": "с",
		"sdot;": "⋅",
		"sdotb;": "⊡",
		"sdote;": "⩦",
		"searhk;": "⤥",
		"seArr;": "⇘",
		"searr;": "↘",
		"searrow;": "↘",
		"sect;": "§",
		sect: "§",
		"semi;": ";",
		"seswar;": "⤩",
		"setminus;": "∖",
		"setmn;": "∖",
		"sext;": "✶",
		"Sfr;": "𝔖",
		"sfr;": "𝔰",
		"sfrown;": "⌢",
		"sharp;": "♯",
		"SHCHcy;": "Щ",
		"shchcy;": "щ",
		"SHcy;": "Ш",
		"shcy;": "ш",
		"ShortDownArrow;": "↓",
		"ShortLeftArrow;": "←",
		"shortmid;": "∣",
		"shortparallel;": "∥",
		"ShortRightArrow;": "→",
		"ShortUpArrow;": "↑",
		"shy;": "­",
		shy: "­",
		"Sigma;": "Σ",
		"sigma;": "σ",
		"sigmaf;": "ς",
		"sigmav;": "ς",
		"sim;": "∼",
		"simdot;": "⩪",
		"sime;": "≃",
		"simeq;": "≃",
		"simg;": "⪞",
		"simgE;": "⪠",
		"siml;": "⪝",
		"simlE;": "⪟",
		"simne;": "≆",
		"simplus;": "⨤",
		"simrarr;": "⥲",
		"slarr;": "←",
		"SmallCircle;": "∘",
		"smallsetminus;": "∖",
		"smashp;": "⨳",
		"smeparsl;": "⧤",
		"smid;": "∣",
		"smile;": "⌣",
		"smt;": "⪪",
		"smte;": "⪬",
		"smtes;": "⪬︀",
		"SOFTcy;": "Ь",
		"softcy;": "ь",
		"sol;": "/",
		"solb;": "⧄",
		"solbar;": "⌿",
		"Sopf;": "𝕊",
		"sopf;": "𝕤",
		"spades;": "♠",
		"spadesuit;": "♠",
		"spar;": "∥",
		"sqcap;": "⊓",
		"sqcaps;": "⊓︀",
		"sqcup;": "⊔",
		"sqcups;": "⊔︀",
		"Sqrt;": "√",
		"sqsub;": "⊏",
		"sqsube;": "⊑",
		"sqsubset;": "⊏",
		"sqsubseteq;": "⊑",
		"sqsup;": "⊐",
		"sqsupe;": "⊒",
		"sqsupset;": "⊐",
		"sqsupseteq;": "⊒",
		"squ;": "□",
		"Square;": "□",
		"square;": "□",
		"SquareIntersection;": "⊓",
		"SquareSubset;": "⊏",
		"SquareSubsetEqual;": "⊑",
		"SquareSuperset;": "⊐",
		"SquareSupersetEqual;": "⊒",
		"SquareUnion;": "⊔",
		"squarf;": "▪",
		"squf;": "▪",
		"srarr;": "→",
		"Sscr;": "𝒮",
		"sscr;": "𝓈",
		"ssetmn;": "∖",
		"ssmile;": "⌣",
		"sstarf;": "⋆",
		"Star;": "⋆",
		"star;": "☆",
		"starf;": "★",
		"straightepsilon;": "ϵ",
		"straightphi;": "ϕ",
		"strns;": "¯",
		"Sub;": "⋐",
		"sub;": "⊂",
		"subdot;": "⪽",
		"subE;": "⫅",
		"sube;": "⊆",
		"subedot;": "⫃",
		"submult;": "⫁",
		"subnE;": "⫋",
		"subne;": "⊊",
		"subplus;": "⪿",
		"subrarr;": "⥹",
		"Subset;": "⋐",
		"subset;": "⊂",
		"subseteq;": "⊆",
		"subseteqq;": "⫅",
		"SubsetEqual;": "⊆",
		"subsetneq;": "⊊",
		"subsetneqq;": "⫋",
		"subsim;": "⫇",
		"subsub;": "⫕",
		"subsup;": "⫓",
		"succ;": "≻",
		"succapprox;": "⪸",
		"succcurlyeq;": "≽",
		"Succeeds;": "≻",
		"SucceedsEqual;": "⪰",
		"SucceedsSlantEqual;": "≽",
		"SucceedsTilde;": "≿",
		"succeq;": "⪰",
		"succnapprox;": "⪺",
		"succneqq;": "⪶",
		"succnsim;": "⋩",
		"succsim;": "≿",
		"SuchThat;": "∋",
		"Sum;": "∑",
		"sum;": "∑",
		"sung;": "♪",
		"Sup;": "⋑",
		"sup;": "⊃",
		"sup1;": "¹",
		sup1: "¹",
		"sup2;": "²",
		sup2: "²",
		"sup3;": "³",
		sup3: "³",
		"supdot;": "⪾",
		"supdsub;": "⫘",
		"supE;": "⫆",
		"supe;": "⊇",
		"supedot;": "⫄",
		"Superset;": "⊃",
		"SupersetEqual;": "⊇",
		"suphsol;": "⟉",
		"suphsub;": "⫗",
		"suplarr;": "⥻",
		"supmult;": "⫂",
		"supnE;": "⫌",
		"supne;": "⊋",
		"supplus;": "⫀",
		"Supset;": "⋑",
		"supset;": "⊃",
		"supseteq;": "⊇",
		"supseteqq;": "⫆",
		"supsetneq;": "⊋",
		"supsetneqq;": "⫌",
		"supsim;": "⫈",
		"supsub;": "⫔",
		"supsup;": "⫖",
		"swarhk;": "⤦",
		"swArr;": "⇙",
		"swarr;": "↙",
		"swarrow;": "↙",
		"swnwar;": "⤪",
		"szlig;": "ß",
		szlig: "ß",
		"Tab;": "	",
		"target;": "⌖",
		"Tau;": "Τ",
		"tau;": "τ",
		"tbrk;": "⎴",
		"Tcaron;": "Ť",
		"tcaron;": "ť",
		"Tcedil;": "Ţ",
		"tcedil;": "ţ",
		"Tcy;": "Т",
		"tcy;": "т",
		"tdot;": "⃛",
		"telrec;": "⌕",
		"Tfr;": "𝔗",
		"tfr;": "𝔱",
		"there4;": "∴",
		"Therefore;": "∴",
		"therefore;": "∴",
		"Theta;": "Θ",
		"theta;": "θ",
		"thetasym;": "ϑ",
		"thetav;": "ϑ",
		"thickapprox;": "≈",
		"thicksim;": "∼",
		"ThickSpace;": "  ",
		"thinsp;": " ",
		"ThinSpace;": " ",
		"thkap;": "≈",
		"thksim;": "∼",
		"THORN;": "Þ",
		THORN: "Þ",
		"thorn;": "þ",
		thorn: "þ",
		"Tilde;": "∼",
		"tilde;": "˜",
		"TildeEqual;": "≃",
		"TildeFullEqual;": "≅",
		"TildeTilde;": "≈",
		"times;": "×",
		times: "×",
		"timesb;": "⊠",
		"timesbar;": "⨱",
		"timesd;": "⨰",
		"tint;": "∭",
		"toea;": "⤨",
		"top;": "⊤",
		"topbot;": "⌶",
		"topcir;": "⫱",
		"Topf;": "𝕋",
		"topf;": "𝕥",
		"topfork;": "⫚",
		"tosa;": "⤩",
		"tprime;": "‴",
		"TRADE;": "™",
		"trade;": "™",
		"triangle;": "▵",
		"triangledown;": "▿",
		"triangleleft;": "◃",
		"trianglelefteq;": "⊴",
		"triangleq;": "≜",
		"triangleright;": "▹",
		"trianglerighteq;": "⊵",
		"tridot;": "◬",
		"trie;": "≜",
		"triminus;": "⨺",
		"TripleDot;": "⃛",
		"triplus;": "⨹",
		"trisb;": "⧍",
		"tritime;": "⨻",
		"trpezium;": "⏢",
		"Tscr;": "𝒯",
		"tscr;": "𝓉",
		"TScy;": "Ц",
		"tscy;": "ц",
		"TSHcy;": "Ћ",
		"tshcy;": "ћ",
		"Tstrok;": "Ŧ",
		"tstrok;": "ŧ",
		"twixt;": "≬",
		"twoheadleftarrow;": "↞",
		"twoheadrightarrow;": "↠",
		"Uacute;": "Ú",
		Uacute: "Ú",
		"uacute;": "ú",
		uacute: "ú",
		"Uarr;": "↟",
		"uArr;": "⇑",
		"uarr;": "↑",
		"Uarrocir;": "⥉",
		"Ubrcy;": "Ў",
		"ubrcy;": "ў",
		"Ubreve;": "Ŭ",
		"ubreve;": "ŭ",
		"Ucirc;": "Û",
		Ucirc: "Û",
		"ucirc;": "û",
		ucirc: "û",
		"Ucy;": "У",
		"ucy;": "у",
		"udarr;": "⇅",
		"Udblac;": "Ű",
		"udblac;": "ű",
		"udhar;": "⥮",
		"ufisht;": "⥾",
		"Ufr;": "𝔘",
		"ufr;": "𝔲",
		"Ugrave;": "Ù",
		Ugrave: "Ù",
		"ugrave;": "ù",
		ugrave: "ù",
		"uHar;": "⥣",
		"uharl;": "↿",
		"uharr;": "↾",
		"uhblk;": "▀",
		"ulcorn;": "⌜",
		"ulcorner;": "⌜",
		"ulcrop;": "⌏",
		"ultri;": "◸",
		"Umacr;": "Ū",
		"umacr;": "ū",
		"uml;": "¨",
		uml: "¨",
		"UnderBar;": "_",
		"UnderBrace;": "⏟",
		"UnderBracket;": "⎵",
		"UnderParenthesis;": "⏝",
		"Union;": "⋃",
		"UnionPlus;": "⊎",
		"Uogon;": "Ų",
		"uogon;": "ų",
		"Uopf;": "𝕌",
		"uopf;": "𝕦",
		"UpArrow;": "↑",
		"Uparrow;": "⇑",
		"uparrow;": "↑",
		"UpArrowBar;": "⤒",
		"UpArrowDownArrow;": "⇅",
		"UpDownArrow;": "↕",
		"Updownarrow;": "⇕",
		"updownarrow;": "↕",
		"UpEquilibrium;": "⥮",
		"upharpoonleft;": "↿",
		"upharpoonright;": "↾",
		"uplus;": "⊎",
		"UpperLeftArrow;": "↖",
		"UpperRightArrow;": "↗",
		"Upsi;": "ϒ",
		"upsi;": "υ",
		"upsih;": "ϒ",
		"Upsilon;": "Υ",
		"upsilon;": "υ",
		"UpTee;": "⊥",
		"UpTeeArrow;": "↥",
		"upuparrows;": "⇈",
		"urcorn;": "⌝",
		"urcorner;": "⌝",
		"urcrop;": "⌎",
		"Uring;": "Ů",
		"uring;": "ů",
		"urtri;": "◹",
		"Uscr;": "𝒰",
		"uscr;": "𝓊",
		"utdot;": "⋰",
		"Utilde;": "Ũ",
		"utilde;": "ũ",
		"utri;": "▵",
		"utrif;": "▴",
		"uuarr;": "⇈",
		"Uuml;": "Ü",
		Uuml: "Ü",
		"uuml;": "ü",
		uuml: "ü",
		"uwangle;": "⦧",
		"vangrt;": "⦜",
		"varepsilon;": "ϵ",
		"varkappa;": "ϰ",
		"varnothing;": "∅",
		"varphi;": "ϕ",
		"varpi;": "ϖ",
		"varpropto;": "∝",
		"vArr;": "⇕",
		"varr;": "↕",
		"varrho;": "ϱ",
		"varsigma;": "ς",
		"varsubsetneq;": "⊊︀",
		"varsubsetneqq;": "⫋︀",
		"varsupsetneq;": "⊋︀",
		"varsupsetneqq;": "⫌︀",
		"vartheta;": "ϑ",
		"vartriangleleft;": "⊲",
		"vartriangleright;": "⊳",
		"Vbar;": "⫫",
		"vBar;": "⫨",
		"vBarv;": "⫩",
		"Vcy;": "В",
		"vcy;": "в",
		"VDash;": "⊫",
		"Vdash;": "⊩",
		"vDash;": "⊨",
		"vdash;": "⊢",
		"Vdashl;": "⫦",
		"Vee;": "⋁",
		"vee;": "∨",
		"veebar;": "⊻",
		"veeeq;": "≚",
		"vellip;": "⋮",
		"Verbar;": "‖",
		"verbar;": "|",
		"Vert;": "‖",
		"vert;": "|",
		"VerticalBar;": "∣",
		"VerticalLine;": "|",
		"VerticalSeparator;": "❘",
		"VerticalTilde;": "≀",
		"VeryThinSpace;": " ",
		"Vfr;": "𝔙",
		"vfr;": "𝔳",
		"vltri;": "⊲",
		"vnsub;": "⊂⃒",
		"vnsup;": "⊃⃒",
		"Vopf;": "𝕍",
		"vopf;": "𝕧",
		"vprop;": "∝",
		"vrtri;": "⊳",
		"Vscr;": "𝒱",
		"vscr;": "𝓋",
		"vsubnE;": "⫋︀",
		"vsubne;": "⊊︀",
		"vsupnE;": "⫌︀",
		"vsupne;": "⊋︀",
		"Vvdash;": "⊪",
		"vzigzag;": "⦚",
		"Wcirc;": "Ŵ",
		"wcirc;": "ŵ",
		"wedbar;": "⩟",
		"Wedge;": "⋀",
		"wedge;": "∧",
		"wedgeq;": "≙",
		"weierp;": "℘",
		"Wfr;": "𝔚",
		"wfr;": "𝔴",
		"Wopf;": "𝕎",
		"wopf;": "𝕨",
		"wp;": "℘",
		"wr;": "≀",
		"wreath;": "≀",
		"Wscr;": "𝒲",
		"wscr;": "𝓌",
		"xcap;": "⋂",
		"xcirc;": "◯",
		"xcup;": "⋃",
		"xdtri;": "▽",
		"Xfr;": "𝔛",
		"xfr;": "𝔵",
		"xhArr;": "⟺",
		"xharr;": "⟷",
		"Xi;": "Ξ",
		"xi;": "ξ",
		"xlArr;": "⟸",
		"xlarr;": "⟵",
		"xmap;": "⟼",
		"xnis;": "⋻",
		"xodot;": "⨀",
		"Xopf;": "𝕏",
		"xopf;": "𝕩",
		"xoplus;": "⨁",
		"xotime;": "⨂",
		"xrArr;": "⟹",
		"xrarr;": "⟶",
		"Xscr;": "𝒳",
		"xscr;": "𝓍",
		"xsqcup;": "⨆",
		"xuplus;": "⨄",
		"xutri;": "△",
		"xvee;": "⋁",
		"xwedge;": "⋀",
		"Yacute;": "Ý",
		Yacute: "Ý",
		"yacute;": "ý",
		yacute: "ý",
		"YAcy;": "Я",
		"yacy;": "я",
		"Ycirc;": "Ŷ",
		"ycirc;": "ŷ",
		"Ycy;": "Ы",
		"ycy;": "ы",
		"yen;": "¥",
		yen: "¥",
		"Yfr;": "𝔜",
		"yfr;": "𝔶",
		"YIcy;": "Ї",
		"yicy;": "ї",
		"Yopf;": "𝕐",
		"yopf;": "𝕪",
		"Yscr;": "𝒴",
		"yscr;": "𝓎",
		"YUcy;": "Ю",
		"yucy;": "ю",
		"Yuml;": "Ÿ",
		"yuml;": "ÿ",
		yuml: "ÿ",
		"Zacute;": "Ź",
		"zacute;": "ź",
		"Zcaron;": "Ž",
		"zcaron;": "ž",
		"Zcy;": "З",
		"zcy;": "з",
		"Zdot;": "Ż",
		"zdot;": "ż",
		"zeetrf;": "ℨ",
		"ZeroWidthSpace;": "​",
		"Zeta;": "Ζ",
		"zeta;": "ζ",
		"Zfr;": "ℨ",
		"zfr;": "𝔷",
		"ZHcy;": "Ж",
		"zhcy;": "ж",
		"zigrarr;": "⇝",
		"Zopf;": "ℤ",
		"zopf;": "𝕫",
		"Zscr;": "𝒵",
		"zscr;": "𝓏",
		"zwj;": "‍",
		"zwnj;": "‌"
	};
	function Ts(e, t) {
		if (e.length < t.length) return !1;
		for (let n = 0; n < t.length; n++) if (e[n] !== t[n]) return !1;
		return !0;
	}
	function ks(e, t) {
		const n = e.length - t.length;
		return n > 0 ? e.lastIndexOf(t) === n : 0 === n && e === t;
	}
	function Ss(e, t) {
		let n = "";
		for (; t > 0;) 1 & ~t || (n += e), e += e, t >>>= 1;
		return n;
	}
	const Ls = "a".charCodeAt(0), xs = "z".charCodeAt(0), Cs = "A".charCodeAt(0), Es = "Z".charCodeAt(0), As = "0".charCodeAt(0), Rs = "9".charCodeAt(0);
	function Ms(e, t) {
		const n = e.charCodeAt(t);
		return Ls <= n && n <= xs || Cs <= n && n <= Es || As <= n && n <= Rs;
	}
	function Ns(e) {
		return void 0 !== e;
	}
	var Is = class {
		isApplicable() {
			return !0;
		}
		constructor(e, t) {
			this.id = e, this._tags = [], this._tagMap = {}, this._valueSetMap = {}, this._tags = t.tags || [], this._globalAttributes = t.globalAttributes || [], this._tags.forEach((e) => {
				this._tagMap[e.name.toLowerCase()] = e;
			}), t.valueSets && t.valueSets.forEach((e) => {
				this._valueSetMap[e.name] = e.values;
			});
		}
		getId() {
			return this.id;
		}
		provideTags() {
			return this._tags;
		}
		provideAttributes(e) {
			const t = [], n = (e) => {
				t.push(e);
			}, i = this._tagMap[e.toLowerCase()];
			return i && i.attributes.forEach(n), this._globalAttributes.forEach(n), t;
		}
		provideValues(e, t) {
			const n = [];
			t = t.toLowerCase();
			const i = (e) => {
				e.forEach((e) => {
					e.name.toLowerCase() === t && (e.values && e.values.forEach((e) => {
						n.push(e);
					}), e.valueSet && this._valueSetMap[e.valueSet] && this._valueSetMap[e.valueSet].forEach((e) => {
						n.push(e);
					}));
				});
			}, r = this._tagMap[e.toLowerCase()];
			return r && i(r.attributes), i(this._globalAttributes), n;
		}
	};
	function zs(e, t = {}, n) {
		const i = {
			kind: n ? "markdown" : "plaintext",
			value: ""
		};
		if (e.description && !1 !== t.documentation) {
			const t = function(e) {
				if (e) return "string" == typeof e ? {
					kind: "markdown",
					value: e
				} : {
					kind: "markdown",
					value: e.value
				};
			}(e.description);
			t && (i.value += t.value);
		}
		if (e.references && e.references.length > 0 && !1 !== t.references && (i.value.length && (i.value += "\n\n"), i.value += n ? e.references.map((e) => `[${e.name}](${e.url})`).join(" | ") : e.references.map((e) => `${e.name}: ${e.url}`).join("\n")), "" !== i.value) return i;
	}
	var Os = class {
		constructor(e, t) {
			this.dataManager = e, this.readDirectory = t, this.atributeCompletions = [];
		}
		onHtmlAttributeValue(e) {
			this.dataManager.isPathAttribute(e.tag, e.attribute) && this.atributeCompletions.push(e);
		}
		async computeCompletions(e, t) {
			const n = {
				items: [],
				isIncomplete: !1
			};
			for (const i of this.atributeCompletions) {
				const r = Hs(e.getText(i.range));
				if (Ds(r)) if ("." === r || ".." === r) n.isIncomplete = !0;
				else {
					const a = Ws(i.value, r, i.range), o = await this.providePathSuggestions(i.value, a, e, t);
					for (const e of o) n.items.push(e);
				}
			}
			return n;
		}
		async providePathSuggestions(e, t, n, i) {
			const r = e.substring(0, e.lastIndexOf("/") + 1);
			let a = i.resolveReference(r || ".", n.uri);
			if (a) try {
				const e = [], n = await this.readDirectory(a);
				for (const [i, r] of n) i.charCodeAt(0) !== Us && e.push(Ps(i, r === Jo.Directory, t));
				return e;
			} catch (El) {}
			return [];
		}
	};
	const Us = ".".charCodeAt(0);
	function Hs(e) {
		return Ts(e, "'") || Ts(e, "\"") ? e.slice(1, -1) : e;
	}
	function Ds(e) {
		return !(Ts(e, "http") || Ts(e, "https") || Ts(e, "//"));
	}
	function Ws(e, t, n) {
		let i;
		const r = e.lastIndexOf("/");
		if (-1 === r) i = function(e, t, n) {
			const i = qs(e.start, t), r = qs(e.end, n);
			return Ta.create(i, r);
		}(n, 1, -1);
		else {
			const e = t.slice(r + 1), a = qs(n.end, -1 - e.length), o = e.indexOf(" ");
			let s;
			s = -1 !== o ? qs(a, o) : qs(n.end, -1), i = Ta.create(a, s);
		}
		return i;
	}
	function Ps(e, t, n) {
		return t ? {
			label: e += "/",
			kind: Ya.Folder,
			textEdit: Ua.replace(n, e),
			command: {
				title: "Suggest",
				command: "editor.action.triggerSuggest"
			}
		} : {
			label: e,
			kind: Ya.File,
			textEdit: Ua.replace(n, e)
		};
	}
	function qs(e, t) {
		return ya.create(e.line, e.character + t);
	}
	var Fs = class {
		constructor(e, t) {
			this.lsOptions = e, this.dataManager = t, this.completionParticipants = [];
		}
		setCompletionParticipants(e) {
			this.completionParticipants = e || [];
		}
		async doComplete2(e, t, n, i, r) {
			if (!this.lsOptions.fileSystemProvider || !this.lsOptions.fileSystemProvider.readDirectory) return this.doComplete(e, t, n, r);
			const a = new Os(this.dataManager, this.lsOptions.fileSystemProvider.readDirectory), o = this.completionParticipants;
			this.completionParticipants = [a].concat(o);
			const s = this.doComplete(e, t, n, r);
			try {
				const t = await a.computeCompletions(e, i);
				return {
					isIncomplete: s.isIncomplete || t.isIncomplete,
					items: t.items.concat(s.items)
				};
			} finally {
				this.completionParticipants = o;
			}
		}
		doComplete(e, t, n, i) {
			const r = this._doComplete(e, t, n, i);
			return this.convertCompletionList(r);
		}
		_doComplete(e, t, n, i) {
			const r = {
				isIncomplete: !1,
				items: []
			}, a = this.completionParticipants, o = this.dataManager.getDataProviders().filter((t) => t.isApplicable(e.languageId) && (!i || !1 !== i[t.getId()])), s = this.dataManager.getVoidElements(o), l = this.doesSupportMarkdown(), c = e.getText(), h = e.offsetAt(t), d = n.findNodeBefore(h);
			if (!d) return r;
			const u = bs(c, d.start);
			let m, p = "";
			function g(t, n = h) {
				return t > h && (t = h), {
					start: e.positionAt(t),
					end: e.positionAt(n)
				};
			}
			function f(e, t) {
				const n = g(e, t);
				return o.forEach((e) => {
					e.provideTags().forEach((e) => {
						r.items.push({
							label: e.name,
							kind: Ya.Property,
							documentation: zs(e, void 0, l),
							textEdit: Ua.replace(n, e.name),
							insertTextFormat: Qa.PlainText
						});
					});
				}), r;
			}
			function b(e) {
				let t = e;
				for (; t > 0;) {
					const n = c.charAt(t - 1);
					if ("\n\r".indexOf(n) >= 0) return c.substring(t, e);
					if (!Vs(n)) return null;
					t--;
				}
				return c.substring(0, e);
			}
			function _(e, t, n = h) {
				const i = g(e, n), a = Bs(c, n, $o.WithinEndTag, Go.EndTagClose) ? "" : ">";
				let s = d;
				for (t && (s = s.parent); s;) {
					const t = s.tag;
					if (t && (!s.closed || s.endTagStart && s.endTagStart > h)) {
						const n = {
							label: "/" + t,
							kind: Ya.Property,
							filterText: "/" + t,
							textEdit: Ua.replace(i, "/" + t + a),
							insertTextFormat: Qa.PlainText
						}, o = b(s.start), l = b(e - 1);
						if (null !== o && null !== l && o !== l) {
							const i = o + "</" + t + a;
							n.textEdit = Ua.replace(g(e - 1 - l.length), i), n.filterText = l + "</" + t;
						}
						return r.items.push(n), r;
					}
					s = s.parent;
				}
				return t || o.forEach((e) => {
					e.provideTags().forEach((e) => {
						r.items.push({
							label: "/" + e.name,
							kind: Ya.Property,
							documentation: zs(e, void 0, l),
							filterText: "/" + e.name + a,
							textEdit: Ua.replace(i, "/" + e.name + a),
							insertTextFormat: Qa.PlainText
						});
					});
				}), r;
			}
			const w = (t, n) => {
				if (i && i.hideAutoCompleteProposals) return r;
				if (!this.dataManager.isVoidElement(n, s)) {
					const i = e.positionAt(t);
					r.items.push({
						label: "</" + n + ">",
						kind: Ya.Property,
						filterText: "</" + n + ">",
						textEdit: Ua.insert(i, "$0</" + n + ">"),
						insertTextFormat: Qa.Snippet
					});
				}
				return r;
			};
			function v(e, t) {
				return f(e, t), _(e, !0, t), r;
			}
			function y(e, t = h) {
				let a = h;
				for (; a < t && "<" !== c[a];) a++;
				const s = c.substring(e, t), u = g(e, a);
				let m = "";
				if (!Bs(c, t, $o.AfterAttributeName, Go.DelimiterAssign)) {
					const e = i?.attributeDefaultValue ?? "doublequotes";
					m = "empty" === e ? "=$1" : "singlequotes" === e ? "='$1'" : "=\"$1\"";
				}
				const f = function() {
					const e = Object.create(null);
					return d.attributeNames.forEach((t) => {
						e[t] = !0;
					}), e;
				}();
				return f[s] = !1, o.forEach((e) => {
					e.provideAttributes(p).forEach((e) => {
						if (f[e.name]) return;
						f[e.name] = !0;
						let t, n = e.name;
						"v" !== e.valueSet && m.length && (n += m, (e.valueSet || "style" === e.name) && (t = {
							title: "Suggest",
							command: "editor.action.triggerSuggest"
						})), r.items.push({
							label: e.name,
							kind: "handler" === e.valueSet ? Ya.Function : Ya.Value,
							documentation: zs(e, void 0, l),
							textEdit: Ua.replace(u, n),
							insertTextFormat: Qa.Snippet,
							command: t
						});
					});
				}), function(e, t) {
					const i = "data-", a = {};
					function o(e) {
						e.attributeNames.forEach((e) => {
							!Ts(e, i) || a[e] || t[e] || (a[e] = e + "=\"$1\"");
						}), e.children.forEach((e) => o(e));
					}
					a[i] = `${i}$1="$2"`, n && n.roots.forEach((e) => o(e));
					Object.keys(a).forEach((t) => r.items.push({
						label: t,
						kind: Ya.Value,
						textEdit: Ua.replace(e, a[t]),
						insertTextFormat: Qa.Snippet
					}));
				}(u, f), r;
			}
			function T(n, i = h) {
				let s, d, u;
				if (h > n && h <= i && (f = c[n], /^["']*$/.test(f))) {
					const e = n + 1;
					let t = i;
					i > n && c[i - 1] === c[n] && t--, s = g(function(e, t, n) {
						for (; t > n && !Vs(e[t - 1]);) t--;
						return t;
					}(c, h, e), function(e, t, n) {
						for (; t < n && !Vs(e[t]);) t++;
						return t;
					}(c, h, t)), u = h >= e && h <= t ? c.substring(e, h) : "", d = !1;
				} else s = g(n, i), u = c.substring(n, h), d = !0;
				var f;
				if (a.length > 0) {
					const r = p.toLowerCase(), o = m.toLowerCase(), s = g(n, i);
					for (const n of a) n.onHtmlAttributeValue && n.onHtmlAttributeValue({
						document: e,
						position: t,
						tag: r,
						attribute: o,
						value: u,
						range: s
					});
				}
				return o.forEach((e) => {
					e.provideValues(p, m).forEach((e) => {
						const t = d ? "\"" + e.name + "\"" : e.name;
						r.items.push({
							label: e.name,
							filterText: t,
							kind: Ya.Unit,
							documentation: zs(e, void 0, l),
							textEdit: Ua.replace(s, t),
							insertTextFormat: Qa.PlainText
						});
					});
				}), L(), r;
			}
			function k(e) {
				return h === u.getTokenEnd() && (C = u.scan(), C === e && u.getTokenOffset() === h) ? u.getTokenEnd() : h;
			}
			function S() {
				for (const n of a) n.onHtmlContent && n.onHtmlContent({
					document: e,
					position: t
				});
				return L();
			}
			function L() {
				let e = h - 1, n = t.character;
				for (; e >= 0 && Ms(c, e);) e--, n--;
				if (e >= 0 && "&" === c[e]) {
					const e = Ta.create(ya.create(t.line, n - 1), t);
					for (const t in ys) if (ks(t, ";")) {
						const n = "&" + t;
						r.items.push({
							label: n,
							kind: Ya.Keyword,
							documentation: fa("Character entity representing '{0}'", ys[t]),
							textEdit: Ua.replace(e, n),
							insertTextFormat: Qa.PlainText
						});
					}
				}
				return r;
			}
			function x(e, t) {
				const n = g(e, t);
				r.items.push({
					label: "!DOCTYPE",
					kind: Ya.Property,
					documentation: "A preamble for an HTML document.",
					textEdit: Ua.replace(n, "!DOCTYPE html>"),
					insertTextFormat: Qa.PlainText
				});
			}
			let C = u.scan();
			for (; C !== Go.EOS && u.getTokenOffset() <= h;) {
				switch (C) {
					case Go.StartTagOpen:
						if (u.getTokenEnd() === h) {
							const e = k(Go.StartTag);
							return 0 === t.line && x(h, e), v(h, e);
						}
						break;
					case Go.StartTag:
						if (u.getTokenOffset() <= h && h <= u.getTokenEnd()) return f(u.getTokenOffset(), u.getTokenEnd());
						p = u.getTokenText();
						break;
					case Go.AttributeName:
						if (u.getTokenOffset() <= h && h <= u.getTokenEnd()) return y(u.getTokenOffset(), u.getTokenEnd());
						m = u.getTokenText();
						break;
					case Go.DelimiterAssign:
						if (u.getTokenEnd() === h) return T(h, k(Go.AttributeValue));
						break;
					case Go.AttributeValue:
						if (u.getTokenOffset() <= h && h <= u.getTokenEnd()) return T(u.getTokenOffset(), u.getTokenEnd());
						break;
					case Go.Whitespace:
						if (h <= u.getTokenEnd()) switch (u.getScannerState()) {
							case $o.AfterOpeningStartTag: return v(u.getTokenOffset(), k(Go.StartTag));
							case $o.WithinTag:
							case $o.AfterAttributeName: return y(u.getTokenEnd());
							case $o.BeforeAttributeValue: return T(u.getTokenEnd());
							case $o.AfterOpeningEndTag: return _(u.getTokenOffset() - 1, !1);
							case $o.WithinContent: return S();
						}
						break;
					case Go.EndTagOpen:
						if (h <= u.getTokenEnd()) return _(u.getTokenOffset() + 1, !1, k(Go.EndTag));
						break;
					case Go.EndTag:
						if (h <= u.getTokenEnd()) {
							let e = u.getTokenOffset() - 1;
							for (; e >= 0;) {
								const t = c.charAt(e);
								if ("/" === t) return _(e, !1, u.getTokenEnd());
								if (!Vs(t)) break;
								e--;
							}
						}
						break;
					case Go.StartTagClose:
						if (h <= u.getTokenEnd() && p) return w(u.getTokenEnd(), p);
						break;
					case Go.Content:
						if (h <= u.getTokenEnd()) return S();
						break;
					default: if (h <= u.getTokenEnd()) return r;
				}
				C = u.scan();
			}
			return r;
		}
		doQuoteComplete(e, t, n, i) {
			const r = e.offsetAt(t);
			if (r <= 0) return null;
			const a = i?.attributeDefaultValue ?? "doublequotes";
			if ("empty" === a) return null;
			if ("=" !== e.getText().charAt(r - 1)) return null;
			const o = "doublequotes" === a ? "\"$1\"" : "'$1'", s = n.findNodeBefore(r);
			if (s && s.attributes && s.start < r && (!s.endTagStart || s.endTagStart > r)) {
				const t = bs(e.getText(), s.start);
				let n = t.scan();
				for (; n !== Go.EOS && t.getTokenEnd() <= r;) {
					if (n === Go.AttributeName && t.getTokenEnd() === r - 1) return n = t.scan(), n !== Go.DelimiterAssign ? null : (n = t.scan(), n === Go.Unknown || n === Go.AttributeValue ? null : o);
					n = t.scan();
				}
			}
			return null;
		}
		doTagComplete(e, t, n) {
			const i = e.offsetAt(t);
			if (i <= 0) return null;
			const r = e.getText().charAt(i - 1);
			if (">" === r) {
				const t = this.dataManager.getVoidElements(e.languageId), r = n.findNodeBefore(i);
				if (r && r.tag && !this.dataManager.isVoidElement(r.tag, t) && r.start < i && (!r.endTagStart || r.endTagStart > i)) {
					const t = bs(e.getText(), r.start);
					let n = t.scan();
					for (; n !== Go.EOS && t.getTokenEnd() <= i;) {
						if (n === Go.StartTagClose && t.getTokenEnd() === i) return `$0</${r.tag}>`;
						n = t.scan();
					}
				}
			} else if ("/" === r) {
				let t = n.findNodeBefore(i);
				for (; t && t.closed && !(t.endTagStart && t.endTagStart > i);) t = t.parent;
				if (t && t.tag) {
					const n = bs(e.getText(), t.start);
					let r = n.scan();
					for (; r !== Go.EOS && n.getTokenEnd() <= i;) {
						if (r === Go.EndTagOpen && n.getTokenEnd() === i) return ">" !== e.getText().charAt(i) ? `${t.tag}>` : t.tag;
						r = n.scan();
					}
				}
			}
			return null;
		}
		convertCompletionList(e) {
			return this.doesSupportMarkdown() || e.items.forEach((e) => {
				e.documentation && "string" != typeof e.documentation && (e.documentation = {
					kind: "plaintext",
					value: e.documentation.value
				});
			}), e;
		}
		doesSupportMarkdown() {
			if (!Ns(this.supportsMarkdown)) {
				if (!Ns(this.lsOptions.clientCapabilities)) return this.supportsMarkdown = !0, this.supportsMarkdown;
				const e = this.lsOptions.clientCapabilities.textDocument?.completion?.completionItem?.documentationFormat;
				this.supportsMarkdown = Array.isArray(e) && -1 !== e.indexOf(Xa.Markdown);
			}
			return this.supportsMarkdown;
		}
	};
	function Vs(e) {
		return /^\s*$/.test(e);
	}
	function Bs(e, t, n, i) {
		const r = bs(e, t, n);
		let a = r.scan();
		for (; a === Go.Whitespace;) a = r.scan();
		return a === i;
	}
	var Ks, js, Gs = class {
		constructor(e, t) {
			this.lsOptions = e, this.dataManager = t;
		}
		doHover(e, t, n, i) {
			const r = this.convertContents.bind(this), a = this.doesSupportMarkdown(), o = e.offsetAt(t), s = n.findNodeAt(o), l = e.getText();
			if (!s || !s.tag) return null;
			const c = this.dataManager.getDataProviders().filter((t) => t.isApplicable(e.languageId));
			function h(e, t, n) {
				for (const o of c) {
					let n = null;
					if (o.provideTags().forEach((r) => {
						if (r.name.toLowerCase() === e.toLowerCase()) {
							let e = zs(r, i, a);
							e || (e = {
								kind: a ? "markdown" : "plaintext",
								value: ""
							}), n = {
								contents: e,
								range: t
							};
						}
					}), n) return n.contents = r(n.contents), n;
				}
				return null;
			}
			function d(t, n) {
				const i = bs(e.getText(), n);
				let r = i.scan();
				for (; r !== Go.EOS && (i.getTokenEnd() < o || i.getTokenEnd() === o && r !== t);) r = i.scan();
				return r === t && o <= i.getTokenEnd() ? {
					start: e.positionAt(i.getTokenOffset()),
					end: e.positionAt(i.getTokenEnd())
				} : null;
			}
			if (s.endTagStart && o >= s.endTagStart) {
				const e = d(Go.EndTag, s.endTagStart);
				return e ? h(s.tag, e) : null;
			}
			const u = d(Go.StartTag, s.start);
			if (u) return h(s.tag, u);
			const m = d(Go.AttributeName, s.start);
			if (m) return function(e, t, n) {
				for (const o of c) {
					let s = null;
					if (o.provideAttributes(e).forEach((e) => {
						if (t === e.name && e.description) {
							const t = zs(e, i, a);
							s = t ? {
								contents: t,
								range: n
							} : null;
						}
					}), s) return s.contents = r(s.contents), s;
				}
				return null;
			}(s.tag, e.getText(m), m);
			const p = function() {
				let e = o - 1, n = t.character;
				for (; e >= 0 && Ms(l, e);) e--, n--;
				let i = e + 1, r = n;
				for (; Ms(l, i);) i++, r++;
				if (e >= 0 && "&" === l[e]) {
					let e = null;
					return e = ";" === l[i] ? Ta.create(ya.create(t.line, n), ya.create(t.line, r + 1)) : Ta.create(ya.create(t.line, n), ya.create(t.line, r)), e;
				}
				return null;
			}();
			if (p) return function(e, t) {
				let n = function(e) {
					let t = o - 1, n = "&";
					for (; t >= 0 && Ms(e, t);) t--;
					t += 1;
					for (; Ms(e, t);) n += e[t], t += 1;
					return n += ";", n;
				}(e);
				for (const i in ys) {
					let e = null;
					if (n === "&" + i) {
						let n = ys[i].charCodeAt(0).toString(16).toUpperCase(), r = "U+";
						if (n.length < 4) {
							const e = 4 - n.length;
							let t = 0;
							for (; t < e;) r += "0", t += 1;
						}
						r += n;
						const a = fa("Character entity representing '{0}', unicode equivalent '{1}'", ys[i], r);
						e = a ? {
							contents: a,
							range: t
						} : null;
					}
					if (e) return e.contents = r(e.contents), e;
				}
				return null;
			}(l, p);
			const g = d(Go.AttributeValue, s.start);
			if (g) {
				const t = s.tag, n = function(e) {
					if (e.length <= 1) return e.replace(/['"]/, "");
					"'" !== e[0] && "\"" !== e[0] || (e = e.slice(1));
					"'" !== e[e.length - 1] && "\"" !== e[e.length - 1] || (e = e.slice(0, -1));
					return e;
				}(e.getText(g)), o = function(t, n) {
					const i = bs(e.getText(), t);
					let r, a = i.scan();
					for (; a !== Go.EOS && i.getTokenEnd() <= n;) a = i.scan(), a === Go.AttributeName && (r = i.getTokenText());
					return r;
				}(s.start, e.offsetAt(g.start));
				if (o) return function(e, t, n, o) {
					for (const s of c) {
						let l = null;
						if (s.provideValues(e, t).forEach((e) => {
							if (n === e.name && e.description) {
								const t = zs(e, i, a);
								l = t ? {
									contents: t,
									range: o
								} : null;
							}
						}), l) return l.contents = r(l.contents), l;
					}
					return null;
				}(t, o, n, g);
			}
			return null;
		}
		convertContents(e) {
			if (!this.doesSupportMarkdown()) {
				if ("string" == typeof e) return e;
				if ("kind" in e) return {
					kind: "plaintext",
					value: e.value
				};
				if (!Array.isArray(e)) return e.value;
				e.map((e) => "string" == typeof e ? e : e.value);
			}
			return e;
		}
		doesSupportMarkdown() {
			if (!Ns(this.supportsMarkdown)) {
				if (!Ns(this.lsOptions.clientCapabilities)) return this.supportsMarkdown = !0, this.supportsMarkdown;
				const e = this.lsOptions.clientCapabilities?.textDocument?.hover?.contentFormat;
				this.supportsMarkdown = Array.isArray(e) && -1 !== e.indexOf(Xa.Markdown);
			}
			return this.supportsMarkdown;
		}
	};
	function $s(e, t) {
		return e;
	}
	Ks = [
		,
		,
		function(e) {
			function t(e) {
				this.__parent = e, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = [];
			}
			function n(e, t) {
				this.__cache = [""], this.__indent_size = e.indent_size, this.__indent_string = e.indent_char, e.indent_with_tabs || (this.__indent_string = new Array(e.indent_size + 1).join(e.indent_char)), t = t || "", e.indent_level > 0 && (t = new Array(e.indent_level + 1).join(this.__indent_string)), this.__base_string = t, this.__base_string_length = t.length;
			}
			function i(e, i) {
				this.__indent_cache = new n(e, i), this.raw = !1, this._end_with_newline = e.end_with_newline, this.indent_size = e.indent_size, this.wrap_line_length = e.wrap_line_length, this.indent_empty_lines = e.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new t(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline();
			}
			t.prototype.clone_empty = function() {
				var e = new t(this.__parent);
				return e.set_indent(this.__indent_count, this.__alignment_count), e;
			}, t.prototype.item = function(e) {
				return e < 0 ? this.__items[this.__items.length + e] : this.__items[e];
			}, t.prototype.has_match = function(e) {
				for (var t = this.__items.length - 1; t >= 0; t--) if (this.__items[t].match(e)) return !0;
				return !1;
			}, t.prototype.set_indent = function(e, t) {
				this.is_empty() && (this.__indent_count = e || 0, this.__alignment_count = t || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count));
			}, t.prototype._set_wrap_point = function() {
				this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count);
			}, t.prototype._should_wrap = function() {
				return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count;
			}, t.prototype._allow_wrap = function() {
				if (this._should_wrap()) {
					this.__parent.add_new_line();
					var e = this.__parent.current_line;
					return e.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), e.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), e.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, " " === e.__items[0] && (e.__items.splice(0, 1), e.__character_count -= 1), !0;
				}
				return !1;
			}, t.prototype.is_empty = function() {
				return 0 === this.__items.length;
			}, t.prototype.last = function() {
				return this.is_empty() ? null : this.__items[this.__items.length - 1];
			}, t.prototype.push = function(e) {
				this.__items.push(e);
				var t = e.lastIndexOf("\n");
				-1 !== t ? this.__character_count = e.length - t : this.__character_count += e.length;
			}, t.prototype.pop = function() {
				var e = null;
				return this.is_empty() || (e = this.__items.pop(), this.__character_count -= e.length), e;
			}, t.prototype._remove_indent = function() {
				this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size);
			}, t.prototype._remove_wrap_indent = function() {
				this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1);
			}, t.prototype.trim = function() {
				for (; " " === this.last();) this.__items.pop(), this.__character_count -= 1;
			}, t.prototype.toString = function() {
				var e = "";
				return this.is_empty() ? this.__parent.indent_empty_lines && (e = this.__parent.get_indent_string(this.__indent_count)) : (e = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), e += this.__items.join("")), e;
			}, n.prototype.get_indent_size = function(e, t) {
				var n = this.__base_string_length;
				return t = t || 0, e < 0 && (n = 0), n += e * this.__indent_size, n += t;
			}, n.prototype.get_indent_string = function(e, t) {
				var n = this.__base_string;
				return t = t || 0, e < 0 && (e = 0, n = ""), t += e * this.__indent_size, this.__ensure_cache(t), n += this.__cache[t];
			}, n.prototype.__ensure_cache = function(e) {
				for (; e >= this.__cache.length;) this.__add_column();
			}, n.prototype.__add_column = function() {
				var e = this.__cache.length, t = 0, n = "";
				this.__indent_size && e >= this.__indent_size && (e -= (t = Math.floor(e / this.__indent_size)) * this.__indent_size, n = new Array(t + 1).join(this.__indent_string)), e && (n += new Array(e + 1).join(" ")), this.__cache.push(n);
			}, i.prototype.__add_outputline = function() {
				this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line);
			}, i.prototype.get_line_number = function() {
				return this.__lines.length;
			}, i.prototype.get_indent_string = function(e, t) {
				return this.__indent_cache.get_indent_string(e, t);
			}, i.prototype.get_indent_size = function(e, t) {
				return this.__indent_cache.get_indent_size(e, t);
			}, i.prototype.is_empty = function() {
				return !this.previous_line && this.current_line.is_empty();
			}, i.prototype.add_new_line = function(e) {
				return !(this.is_empty() || !e && this.just_added_newline() || (this.raw || this.__add_outputline(), 0));
			}, i.prototype.get_code = function(e) {
				this.trim(!0);
				var t = this.current_line.pop();
				t && ("\n" === t[t.length - 1] && (t = t.replace(/\n+$/g, "")), this.current_line.push(t)), this._end_with_newline && this.__add_outputline();
				var n = this.__lines.join("\n");
				return "\n" !== e && (n = n.replace(/[\n]/g, e)), n;
			}, i.prototype.set_wrap_point = function() {
				this.current_line._set_wrap_point();
			}, i.prototype.set_indent = function(e, t) {
				return e = e || 0, t = t || 0, this.next_line.set_indent(e, t), this.__lines.length > 1 ? (this.current_line.set_indent(e, t), !0) : (this.current_line.set_indent(), !1);
			}, i.prototype.add_raw_token = function(e) {
				for (var t = 0; t < e.newlines; t++) this.__add_outputline();
				this.current_line.set_indent(-1), this.current_line.push(e.whitespace_before), this.current_line.push(e.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1;
			}, i.prototype.add_token = function(e) {
				this.__add_space_before_token(), this.current_line.push(e), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap();
			}, i.prototype.__add_space_before_token = function() {
				this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "));
			}, i.prototype.remove_indent = function(e) {
				for (var t = this.__lines.length; e < t;) this.__lines[e]._remove_indent(), e++;
				this.current_line._remove_wrap_indent();
			}, i.prototype.trim = function(e) {
				for (e = void 0 !== e && e, this.current_line.trim(); e && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
				this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null;
			}, i.prototype.just_added_newline = function() {
				return this.current_line.is_empty();
			}, i.prototype.just_added_blankline = function() {
				return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty();
			}, i.prototype.ensure_empty_line_above = function(e, n) {
				for (var i = this.__lines.length - 2; i >= 0;) {
					var r = this.__lines[i];
					if (r.is_empty()) break;
					if (0 !== r.item(0).indexOf(e) && r.item(-1) !== n) {
						this.__lines.splice(i + 1, 0, new t(this)), this.previous_line = this.__lines[this.__lines.length - 2];
						break;
					}
					i--;
				}
			}, e.exports.Output = i;
		},
		,
		,
		,
		function(e) {
			function t(e, t) {
				this.raw_options = n(e, t), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", "	" === this.indent_char), this.indent_with_tabs && (this.indent_char = "	", 1 === this.indent_size && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", [
					"auto",
					"none",
					"angular",
					"django",
					"erb",
					"handlebars",
					"php",
					"smarty"
				], ["auto"]);
			}
			function n(e, t) {
				var n, r = {};
				for (n in e = i(e)) n !== t && (r[n] = e[n]);
				if (t && e[t]) for (n in e[t]) r[n] = e[t][n];
				return r;
			}
			function i(e) {
				var t, n = {};
				for (t in e) n[t.replace(/-/g, "_")] = e[t];
				return n;
			}
			t.prototype._get_array = function(e, t) {
				var n = this.raw_options[e], i = t || [];
				return "object" == typeof n ? null !== n && "function" == typeof n.concat && (i = n.concat()) : "string" == typeof n && (i = n.split(/[^a-zA-Z0-9_\/\-]+/)), i;
			}, t.prototype._get_boolean = function(e, t) {
				var n = this.raw_options[e];
				return void 0 === n ? !!t : !!n;
			}, t.prototype._get_characters = function(e, t) {
				var n = this.raw_options[e], i = t || "";
				return "string" == typeof n && (i = n.replace(/\\r/, "\r").replace(/\\n/, "\n").replace(/\\t/, "	")), i;
			}, t.prototype._get_number = function(e, t) {
				var n = this.raw_options[e];
				t = parseInt(t, 10), isNaN(t) && (t = 0);
				var i = parseInt(n, 10);
				return isNaN(i) && (i = t), i;
			}, t.prototype._get_selection = function(e, t, n) {
				var i = this._get_selection_list(e, t, n);
				if (1 !== i.length) throw new Error("Invalid Option Value: The option '" + e + "' can only be one of the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
				return i[0];
			}, t.prototype._get_selection_list = function(e, t, n) {
				if (!t || 0 === t.length) throw new Error("Selection list cannot be empty.");
				if (n = n || [t[0]], !this._is_valid_selection(n, t)) throw new Error("Invalid Default Value!");
				var i = this._get_array(e, n);
				if (!this._is_valid_selection(i, t)) throw new Error("Invalid Option Value: The option '" + e + "' can contain only the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
				return i;
			}, t.prototype._is_valid_selection = function(e, t) {
				return e.length && t.length && !e.some(function(e) {
					return -1 === t.indexOf(e);
				});
			}, e.exports.Options = t, e.exports.normalizeOpts = i, e.exports.mergeOpts = n;
		},
		,
		function(e) {
			var t = RegExp.prototype.hasOwnProperty("sticky");
			function n(e) {
				this.__input = e || "", this.__input_length = this.__input.length, this.__position = 0;
			}
			n.prototype.restart = function() {
				this.__position = 0;
			}, n.prototype.back = function() {
				this.__position > 0 && (this.__position -= 1);
			}, n.prototype.hasNext = function() {
				return this.__position < this.__input_length;
			}, n.prototype.next = function() {
				var e = null;
				return this.hasNext() && (e = this.__input.charAt(this.__position), this.__position += 1), e;
			}, n.prototype.peek = function(e) {
				var t = null;
				return e = e || 0, (e += this.__position) >= 0 && e < this.__input_length && (t = this.__input.charAt(e)), t;
			}, n.prototype.__match = function(e, n) {
				e.lastIndex = n;
				var i = e.exec(this.__input);
				return !i || t && e.sticky || i.index !== n && (i = null), i;
			}, n.prototype.test = function(e, t) {
				return t = t || 0, (t += this.__position) >= 0 && t < this.__input_length && !!this.__match(e, t);
			}, n.prototype.testChar = function(e, t) {
				var n = this.peek(t);
				return e.lastIndex = 0, null !== n && e.test(n);
			}, n.prototype.match = function(e) {
				var t = this.__match(e, this.__position);
				return t ? this.__position += t[0].length : t = null, t;
			}, n.prototype.read = function(e, t, n) {
				var i, r = "";
				return e && (i = this.match(e)) && (r += i[0]), !t || !i && e || (r += this.readUntil(t, n)), r;
			}, n.prototype.readUntil = function(e, t) {
				var n, i = this.__position;
				e.lastIndex = this.__position;
				var r = e.exec(this.__input);
				return r ? (i = r.index, t && (i += r[0].length)) : i = this.__input_length, n = this.__input.substring(this.__position, i), this.__position = i, n;
			}, n.prototype.readUntilAfter = function(e) {
				return this.readUntil(e, !0);
			}, n.prototype.get_regexp = function(e, n) {
				var i = null, r = "g";
				return n && t && (r = "y"), "string" == typeof e && "" !== e ? i = new RegExp(e, r) : e && (i = new RegExp(e.source, r)), i;
			}, n.prototype.get_literal_regexp = function(e) {
				return RegExp(e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"));
			}, n.prototype.peekUntilAfter = function(e) {
				var t = this.__position, n = this.readUntilAfter(e);
				return this.__position = t, n;
			}, n.prototype.lookBack = function(e) {
				var t = this.__position - 1;
				return t >= e.length && this.__input.substring(t - e.length, t).toLowerCase() === e;
			}, e.exports.InputScanner = n;
		},
		,
		,
		,
		,
		function(e) {
			function t(e, t) {
				e = "string" == typeof e ? e : e.source, t = "string" == typeof t ? t : t.source, this.__directives_block_pattern = new RegExp(e + / beautify( \w+[:]\w+)+ /.source + t, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(e + /\sbeautify\signore:end\s/.source + t, "g");
			}
			t.prototype.get_directives = function(e) {
				if (!e.match(this.__directives_block_pattern)) return null;
				var t = {};
				this.__directive_pattern.lastIndex = 0;
				for (var n = this.__directive_pattern.exec(e); n;) t[n[1]] = n[2], n = this.__directive_pattern.exec(e);
				return t;
			}, t.prototype.readIgnored = function(e) {
				return e.readUntilAfter(this.__directives_end_ignore_pattern);
			}, e.exports.Directives = t;
		},
		,
		function(e, t, n) {
			var i = n(16).Beautifier, r = n(17).Options;
			e.exports = function(e, t) {
				return new i(e, t).beautify();
			}, e.exports.defaultOptions = function() {
				return new r();
			};
		},
		function(e, t, n) {
			var i = n(17).Options, r = n(2).Output, a = n(8).InputScanner, o = new (n(13)).Directives(/\/\*/, /\*\//), s = /\r\n|[\r\n]/, l = /\r\n|[\r\n]/g, c = /\s/, h = /(?:\s|\n)+/g, d = /\/\*(?:[\s\S]*?)((?:\*\/)|$)/g, u = /\/\/(?:[^\n\r\u2028\u2029]*)/g;
			function m(e, t) {
				this._source_text = e || "", this._options = new i(t), this._ch = null, this._input = null, this.NESTED_AT_RULE = {
					page: !0,
					"font-face": !0,
					keyframes: !0,
					media: !0,
					supports: !0,
					document: !0
				}, this.CONDITIONAL_GROUP_RULE = {
					media: !0,
					supports: !0,
					document: !0
				}, this.NON_SEMICOLON_NEWLINE_PROPERTY = ["grid-template-areas", "grid-template"];
			}
			m.prototype.eatString = function(e) {
				var t = "";
				for (this._ch = this._input.next(); this._ch;) {
					if (t += this._ch, "\\" === this._ch) t += this._input.next();
					else if (-1 !== e.indexOf(this._ch) || "\n" === this._ch) break;
					this._ch = this._input.next();
				}
				return t;
			}, m.prototype.eatWhitespace = function(e) {
				for (var t = c.test(this._input.peek()), n = 0; c.test(this._input.peek());) this._ch = this._input.next(), e && "\n" === this._ch && (0 === n || n < this._options.max_preserve_newlines) && (n++, this._output.add_new_line(!0));
				return t;
			}, m.prototype.foundNestedPseudoClass = function() {
				for (var e = 0, t = 1, n = this._input.peek(t); n;) {
					if ("{" === n) return !0;
					if ("(" === n) e += 1;
					else if (")" === n) {
						if (0 === e) return !1;
						e -= 1;
					} else if (";" === n || "}" === n) return !1;
					t++, n = this._input.peek(t);
				}
				return !1;
			}, m.prototype.print_string = function(e) {
				this._output.set_indent(this._indentLevel), this._output.non_breaking_space = !0, this._output.add_token(e);
			}, m.prototype.preserveSingleSpace = function(e) {
				e && (this._output.space_before_token = !0);
			}, m.prototype.indent = function() {
				this._indentLevel++;
			}, m.prototype.outdent = function() {
				this._indentLevel > 0 && this._indentLevel--;
			}, m.prototype.beautify = function() {
				if (this._options.disabled) return this._source_text;
				var e = this._source_text, t = this._options.eol;
				"auto" === t && (t = "\n", e && s.test(e || "") && (t = e.match(s)[0]));
				var n = (e = e.replace(l, "\n")).match(/^[\t ]*/)[0];
				this._output = new r(this._options, n), this._input = new a(e), this._indentLevel = 0, this._nestedLevel = 0, this._ch = null;
				for (var i, m, p = 0, g = !1, f = !1, b = !1, _ = !1, w = !1, v = this._ch, y = !1; i = "" !== this._input.read(h), m = v, this._ch = this._input.next(), "\\" === this._ch && this._input.hasNext() && (this._ch += this._input.next()), v = this._ch, this._ch;) if ("/" === this._ch && "*" === this._input.peek()) {
					this._output.add_new_line(), this._input.back();
					var T = this._input.read(d), k = o.get_directives(T);
					k && "start" === k.ignore && (T += o.readIgnored(this._input)), this.print_string(T), this.eatWhitespace(!0), this._output.add_new_line();
				} else if ("/" === this._ch && "/" === this._input.peek()) this._output.space_before_token = !0, this._input.back(), this.print_string(this._input.read(u)), this.eatWhitespace(!0);
				else if ("$" === this._ch) {
					this.preserveSingleSpace(i), this.print_string(this._ch);
					var S = this._input.peekUntilAfter(/[: ,;{}()[\]\/='"]/g);
					S.match(/[ :]$/) && (S = this.eatString(": ").replace(/\s+$/, ""), this.print_string(S), this._output.space_before_token = !0), 0 === p && -1 !== S.indexOf(":") && (f = !0, this.indent());
				} else if ("@" === this._ch) if (this.preserveSingleSpace(i), "{" === this._input.peek()) this.print_string(this._ch + this.eatString("}"));
				else {
					this.print_string(this._ch);
					var L = this._input.peekUntilAfter(/[: ,;{}()[\]\/='"]/g);
					L.match(/[ :]$/) && (L = this.eatString(": ").replace(/\s+$/, ""), this.print_string(L), this._output.space_before_token = !0), 0 === p && -1 !== L.indexOf(":") ? (f = !0, this.indent()) : L in this.NESTED_AT_RULE ? (this._nestedLevel += 1, L in this.CONDITIONAL_GROUP_RULE && (b = !0)) : 0 !== p || f || (_ = !0);
				}
				else if ("#" === this._ch && "{" === this._input.peek()) this.preserveSingleSpace(i), this.print_string(this._ch + this.eatString("}"));
				else if ("{" === this._ch) f && (f = !1, this.outdent()), _ = !1, b ? (b = !1, g = this._indentLevel >= this._nestedLevel) : g = this._indentLevel >= this._nestedLevel - 1, this._options.newline_between_rules && g && this._output.previous_line && "{" !== this._output.previous_line.item(-1) && this._output.ensure_empty_line_above("/", ","), this._output.space_before_token = !0, "expand" === this._options.brace_style ? (this._output.add_new_line(), this.print_string(this._ch), this.indent(), this._output.set_indent(this._indentLevel)) : ("(" === m ? this._output.space_before_token = !1 : "," !== m && this.indent(), this.print_string(this._ch)), this.eatWhitespace(!0), this._output.add_new_line();
				else if ("}" === this._ch) this.outdent(), this._output.add_new_line(), "{" === m && this._output.trim(!0), f && (this.outdent(), f = !1), this.print_string(this._ch), g = !1, this._nestedLevel && this._nestedLevel--, this.eatWhitespace(!0), this._output.add_new_line(), this._options.newline_between_rules && !this._output.just_added_blankline() && "}" !== this._input.peek() && this._output.add_new_line(!0), ")" === this._input.peek() && (this._output.trim(!0), "expand" === this._options.brace_style && this._output.add_new_line(!0));
				else if (":" === this._ch) {
					for (var x = 0; x < this.NON_SEMICOLON_NEWLINE_PROPERTY.length; x++) if (this._input.lookBack(this.NON_SEMICOLON_NEWLINE_PROPERTY[x])) {
						y = !0;
						break;
					}
					!g && !b || this._input.lookBack("&") || this.foundNestedPseudoClass() || this._input.lookBack("(") || _ || 0 !== p ? (this._input.lookBack(" ") && (this._output.space_before_token = !0), ":" === this._input.peek() ? (this._ch = this._input.next(), this.print_string("::")) : this.print_string(":")) : (this.print_string(":"), f || (f = !0, this._output.space_before_token = !0, this.eatWhitespace(!0), this.indent()));
				} else if ("\"" === this._ch || "'" === this._ch) {
					var C = "\"" === m || "'" === m;
					this.preserveSingleSpace(C || i), this.print_string(this._ch + this.eatString(this._ch)), this.eatWhitespace(!0);
				} else if (";" === this._ch) y = !1, 0 === p ? (f && (this.outdent(), f = !1), _ = !1, this.print_string(this._ch), this.eatWhitespace(!0), "/" !== this._input.peek() && this._output.add_new_line()) : (this.print_string(this._ch), this.eatWhitespace(!0), this._output.space_before_token = !0);
				else if ("(" === this._ch) if (this._input.lookBack("url")) this.print_string(this._ch), this.eatWhitespace(), p++, this.indent(), this._ch = this._input.next(), ")" === this._ch || "\"" === this._ch || "'" === this._ch ? this._input.back() : this._ch && (this.print_string(this._ch + this.eatString(")")), p && (p--, this.outdent()));
				else {
					var E = !1;
					this._input.lookBack("with") && (E = !0), this.preserveSingleSpace(i || E), this.print_string(this._ch), f && "$" === m && this._options.selector_separator_newline ? (this._output.add_new_line(), w = !0) : (this.eatWhitespace(), p++, this.indent());
				}
				else if (")" === this._ch) p && (p--, this.outdent()), w && ";" === this._input.peek() && this._options.selector_separator_newline && (w = !1, this.outdent(), this._output.add_new_line()), this.print_string(this._ch);
				else if ("," === this._ch) this.print_string(this._ch), this.eatWhitespace(!0), !this._options.selector_separator_newline || f && !w || 0 !== p || _ ? this._output.space_before_token = !0 : this._output.add_new_line();
				else if (">" !== this._ch && "+" !== this._ch && "~" !== this._ch || f || 0 !== p) if ("]" === this._ch) this.print_string(this._ch);
				else if ("[" === this._ch) this.preserveSingleSpace(i), this.print_string(this._ch);
				else if ("=" === this._ch) this.eatWhitespace(), this.print_string("="), c.test(this._ch) && (this._ch = "");
				else if ("!" !== this._ch || this._input.lookBack("\\")) {
					var A = "\"" === m || "'" === m;
					this.preserveSingleSpace(A || i), this.print_string(this._ch), !this._output.just_added_newline() && "\n" === this._input.peek() && y && this._output.add_new_line();
				} else this._output.space_before_token = !0, this.print_string(this._ch);
				else this._options.space_around_combinator ? (this._output.space_before_token = !0, this.print_string(this._ch), this._output.space_before_token = !0) : (this.print_string(this._ch), this.eatWhitespace(), this._ch && c.test(this._ch) && (this._ch = ""));
				return this._output.get_code(t);
			}, e.exports.Beautifier = m;
		},
		function(e, t, n) {
			var i = n(6).Options;
			function r(e) {
				i.call(this, e, "css"), this.selector_separator_newline = this._get_boolean("selector_separator_newline", !0), this.newline_between_rules = this._get_boolean("newline_between_rules", !0);
				var t = this._get_boolean("space_around_selector_separator");
				this.space_around_combinator = this._get_boolean("space_around_combinator") || t;
				var n = this._get_selection_list("brace_style", [
					"collapse",
					"expand",
					"end-expand",
					"none",
					"preserve-inline"
				]);
				this.brace_style = "collapse";
				for (var r = 0; r < n.length; r++) "expand" !== n[r] ? this.brace_style = "collapse" : this.brace_style = n[r];
			}
			r.prototype = new i(), e.exports.Options = r;
		}
	], js = {};
	var Xs, Js, Ys = function e(t) {
		var n = js[t];
		if (void 0 !== n) return n.exports;
		var i = js[t] = { exports: {} };
		return Ks[t](i, i.exports, e), i.exports;
	}(15);
	function Qs(e, t, n) {
		let i = e.getText(), r = !0, a = 0;
		const o = n.tabSize || 4;
		if (t) {
			let o = e.offsetAt(t.start), s = o;
			for (; s > 0 && il(i, s - 1);) s--;
			0 === s || nl(i, s - 1) ? o = s : s < o && (o = s + 1);
			let l = e.offsetAt(t.end), c = l;
			for (; c < i.length && il(i, c);) c++;
			(c === i.length || nl(i, c)) && (l = c), t = Ta.create(e.positionAt(o), e.positionAt(l));
			const h = i.substring(0, o);
			if ((/* @__PURE__ */ new RegExp(/.*[<][^>]*$/)).test(h)) return i = i.substring(o, l), [{
				range: t,
				newText: i
			}];
			if (r = l === i.length, i = i.substring(o, l), 0 !== o) {
				const i = e.offsetAt(ya.create(t.start.line, 0));
				a = function(e, t, n) {
					let i = t, r = 0;
					const a = n.tabSize || 4;
					for (; i < e.length;) {
						const t = e.charAt(i);
						if (" " === t) r++;
						else {
							if ("	" !== t) break;
							r += a;
						}
						i++;
					}
					return Math.floor(r / a);
				}(e.getText(), i, n);
			}
		} else t = Ta.create(ya.create(0, 0), e.positionAt(i.length));
		const s = {
			indent_size: o,
			indent_char: n.insertSpaces ? " " : "	",
			indent_empty_lines: Zs(n, "indentEmptyLines", !1),
			wrap_line_length: Zs(n, "wrapLineLength", 120),
			unformatted: el(n, "unformatted", void 0),
			content_unformatted: el(n, "contentUnformatted", void 0),
			indent_inner_html: Zs(n, "indentInnerHtml", !1),
			preserve_newlines: Zs(n, "preserveNewLines", !0),
			max_preserve_newlines: Zs(n, "maxPreserveNewLines", 32786),
			indent_handlebars: Zs(n, "indentHandlebars", !1),
			end_with_newline: r && Zs(n, "endWithNewline", !1),
			extra_liners: el(n, "extraLiners", void 0),
			wrap_attributes: Zs(n, "wrapAttributes", "auto"),
			wrap_attributes_indent_size: Zs(n, "wrapAttributesIndentSize", void 0),
			eol: "\n",
			indent_scripts: Zs(n, "indentScripts", "normal"),
			templating: tl(n, "all"),
			unformatted_content_delimiter: Zs(n, "unformattedContentDelimiter", "")
		};
		let l = function(e, t) {
			return Xs(e, t, $s, Ys);
		}(i.replace(/^\s+/, ""), s);
		if (a > 0) {
			const e = n.insertSpaces ? Ss(" ", o * a) : Ss("	", a);
			l = l.split("\n").join("\n" + e), 0 === t.start.character && (l = e + l);
		}
		return [{
			range: t,
			newText: l
		}];
	}
	function Zs(e, t, n) {
		if (e && e.hasOwnProperty(t)) {
			const n = e[t];
			if (null !== n) return n;
		}
		return n;
	}
	function el(e, t, n) {
		const i = Zs(e, t, null);
		return "string" == typeof i ? i.length > 0 ? i.split(",").map((e) => e.trim().toLowerCase()) : [] : n;
	}
	function tl(e, t) {
		const n = Zs(e, "templating", t);
		return !0 === n ? ["auto"] : !1 === n || n === t || !1 === Array.isArray(n) ? ["none"] : n;
	}
	function nl(e, t) {
		return -1 !== "\r\n".indexOf(e.charAt(t));
	}
	function il(e, t) {
		return -1 !== " 	".indexOf(e.charAt(t));
	}
	(function() {
		var e = [
			,
			,
			function(e) {
				function t(e) {
					this.__parent = e, this.__character_count = 0, this.__indent_count = -1, this.__alignment_count = 0, this.__wrap_point_index = 0, this.__wrap_point_character_count = 0, this.__wrap_point_indent_count = -1, this.__wrap_point_alignment_count = 0, this.__items = [];
				}
				function n(e, t) {
					this.__cache = [""], this.__indent_size = e.indent_size, this.__indent_string = e.indent_char, e.indent_with_tabs || (this.__indent_string = new Array(e.indent_size + 1).join(e.indent_char)), t = t || "", e.indent_level > 0 && (t = new Array(e.indent_level + 1).join(this.__indent_string)), this.__base_string = t, this.__base_string_length = t.length;
				}
				function i(e, i) {
					this.__indent_cache = new n(e, i), this.raw = !1, this._end_with_newline = e.end_with_newline, this.indent_size = e.indent_size, this.wrap_line_length = e.wrap_line_length, this.indent_empty_lines = e.indent_empty_lines, this.__lines = [], this.previous_line = null, this.current_line = null, this.next_line = new t(this), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1, this.__add_outputline();
				}
				t.prototype.clone_empty = function() {
					var e = new t(this.__parent);
					return e.set_indent(this.__indent_count, this.__alignment_count), e;
				}, t.prototype.item = function(e) {
					return e < 0 ? this.__items[this.__items.length + e] : this.__items[e];
				}, t.prototype.has_match = function(e) {
					for (var t = this.__items.length - 1; t >= 0; t--) if (this.__items[t].match(e)) return !0;
					return !1;
				}, t.prototype.set_indent = function(e, t) {
					this.is_empty() && (this.__indent_count = e || 0, this.__alignment_count = t || 0, this.__character_count = this.__parent.get_indent_size(this.__indent_count, this.__alignment_count));
				}, t.prototype._set_wrap_point = function() {
					this.__parent.wrap_line_length && (this.__wrap_point_index = this.__items.length, this.__wrap_point_character_count = this.__character_count, this.__wrap_point_indent_count = this.__parent.next_line.__indent_count, this.__wrap_point_alignment_count = this.__parent.next_line.__alignment_count);
				}, t.prototype._should_wrap = function() {
					return this.__wrap_point_index && this.__character_count > this.__parent.wrap_line_length && this.__wrap_point_character_count > this.__parent.next_line.__character_count;
				}, t.prototype._allow_wrap = function() {
					if (this._should_wrap()) {
						this.__parent.add_new_line();
						var e = this.__parent.current_line;
						return e.set_indent(this.__wrap_point_indent_count, this.__wrap_point_alignment_count), e.__items = this.__items.slice(this.__wrap_point_index), this.__items = this.__items.slice(0, this.__wrap_point_index), e.__character_count += this.__character_count - this.__wrap_point_character_count, this.__character_count = this.__wrap_point_character_count, " " === e.__items[0] && (e.__items.splice(0, 1), e.__character_count -= 1), !0;
					}
					return !1;
				}, t.prototype.is_empty = function() {
					return 0 === this.__items.length;
				}, t.prototype.last = function() {
					return this.is_empty() ? null : this.__items[this.__items.length - 1];
				}, t.prototype.push = function(e) {
					this.__items.push(e);
					var t = e.lastIndexOf("\n");
					-1 !== t ? this.__character_count = e.length - t : this.__character_count += e.length;
				}, t.prototype.pop = function() {
					var e = null;
					return this.is_empty() || (e = this.__items.pop(), this.__character_count -= e.length), e;
				}, t.prototype._remove_indent = function() {
					this.__indent_count > 0 && (this.__indent_count -= 1, this.__character_count -= this.__parent.indent_size);
				}, t.prototype._remove_wrap_indent = function() {
					this.__wrap_point_indent_count > 0 && (this.__wrap_point_indent_count -= 1);
				}, t.prototype.trim = function() {
					for (; " " === this.last();) this.__items.pop(), this.__character_count -= 1;
				}, t.prototype.toString = function() {
					var e = "";
					return this.is_empty() ? this.__parent.indent_empty_lines && (e = this.__parent.get_indent_string(this.__indent_count)) : (e = this.__parent.get_indent_string(this.__indent_count, this.__alignment_count), e += this.__items.join("")), e;
				}, n.prototype.get_indent_size = function(e, t) {
					var n = this.__base_string_length;
					return t = t || 0, e < 0 && (n = 0), n += e * this.__indent_size, n += t;
				}, n.prototype.get_indent_string = function(e, t) {
					var n = this.__base_string;
					return t = t || 0, e < 0 && (e = 0, n = ""), t += e * this.__indent_size, this.__ensure_cache(t), n += this.__cache[t];
				}, n.prototype.__ensure_cache = function(e) {
					for (; e >= this.__cache.length;) this.__add_column();
				}, n.prototype.__add_column = function() {
					var e = this.__cache.length, t = 0, n = "";
					this.__indent_size && e >= this.__indent_size && (e -= (t = Math.floor(e / this.__indent_size)) * this.__indent_size, n = new Array(t + 1).join(this.__indent_string)), e && (n += new Array(e + 1).join(" ")), this.__cache.push(n);
				}, i.prototype.__add_outputline = function() {
					this.previous_line = this.current_line, this.current_line = this.next_line.clone_empty(), this.__lines.push(this.current_line);
				}, i.prototype.get_line_number = function() {
					return this.__lines.length;
				}, i.prototype.get_indent_string = function(e, t) {
					return this.__indent_cache.get_indent_string(e, t);
				}, i.prototype.get_indent_size = function(e, t) {
					return this.__indent_cache.get_indent_size(e, t);
				}, i.prototype.is_empty = function() {
					return !this.previous_line && this.current_line.is_empty();
				}, i.prototype.add_new_line = function(e) {
					return !(this.is_empty() || !e && this.just_added_newline()) && (this.raw || this.__add_outputline(), !0);
				}, i.prototype.get_code = function(e) {
					this.trim(!0);
					var t = this.current_line.pop();
					t && ("\n" === t[t.length - 1] && (t = t.replace(/\n+$/g, "")), this.current_line.push(t)), this._end_with_newline && this.__add_outputline();
					var n = this.__lines.join("\n");
					return "\n" !== e && (n = n.replace(/[\n]/g, e)), n;
				}, i.prototype.set_wrap_point = function() {
					this.current_line._set_wrap_point();
				}, i.prototype.set_indent = function(e, t) {
					return e = e || 0, t = t || 0, this.next_line.set_indent(e, t), this.__lines.length > 1 ? (this.current_line.set_indent(e, t), !0) : (this.current_line.set_indent(), !1);
				}, i.prototype.add_raw_token = function(e) {
					for (var t = 0; t < e.newlines; t++) this.__add_outputline();
					this.current_line.set_indent(-1), this.current_line.push(e.whitespace_before), this.current_line.push(e.text), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = !1;
				}, i.prototype.add_token = function(e) {
					this.__add_space_before_token(), this.current_line.push(e), this.space_before_token = !1, this.non_breaking_space = !1, this.previous_token_wrapped = this.current_line._allow_wrap();
				}, i.prototype.__add_space_before_token = function() {
					this.space_before_token && !this.just_added_newline() && (this.non_breaking_space || this.set_wrap_point(), this.current_line.push(" "));
				}, i.prototype.remove_indent = function(e) {
					for (var t = this.__lines.length; e < t;) this.__lines[e]._remove_indent(), e++;
					this.current_line._remove_wrap_indent();
				}, i.prototype.trim = function(e) {
					for (e = void 0 !== e && e, this.current_line.trim(); e && this.__lines.length > 1 && this.current_line.is_empty();) this.__lines.pop(), this.current_line = this.__lines[this.__lines.length - 1], this.current_line.trim();
					this.previous_line = this.__lines.length > 1 ? this.__lines[this.__lines.length - 2] : null;
				}, i.prototype.just_added_newline = function() {
					return this.current_line.is_empty();
				}, i.prototype.just_added_blankline = function() {
					return this.is_empty() || this.current_line.is_empty() && this.previous_line.is_empty();
				}, i.prototype.ensure_empty_line_above = function(e, n) {
					for (var i = this.__lines.length - 2; i >= 0;) {
						var r = this.__lines[i];
						if (r.is_empty()) break;
						if (0 !== r.item(0).indexOf(e) && r.item(-1) !== n) {
							this.__lines.splice(i + 1, 0, new t(this)), this.previous_line = this.__lines[this.__lines.length - 2];
							break;
						}
						i--;
					}
				}, e.exports.Output = i;
			},
			function(e) {
				e.exports.Token = function(e, t, n, i) {
					this.type = e, this.text = t, this.comments_before = null, this.newlines = n || 0, this.whitespace_before = i || "", this.parent = null, this.next = null, this.previous = null, this.opened = null, this.closed = null, this.directives = null;
				};
			},
			,
			,
			function(e) {
				function t(e, t) {
					this.raw_options = n(e, t), this.disabled = this._get_boolean("disabled"), this.eol = this._get_characters("eol", "auto"), this.end_with_newline = this._get_boolean("end_with_newline"), this.indent_size = this._get_number("indent_size", 4), this.indent_char = this._get_characters("indent_char", " "), this.indent_level = this._get_number("indent_level"), this.preserve_newlines = this._get_boolean("preserve_newlines", !0), this.max_preserve_newlines = this._get_number("max_preserve_newlines", 32786), this.preserve_newlines || (this.max_preserve_newlines = 0), this.indent_with_tabs = this._get_boolean("indent_with_tabs", "	" === this.indent_char), this.indent_with_tabs && (this.indent_char = "	", 1 === this.indent_size && (this.indent_size = 4)), this.wrap_line_length = this._get_number("wrap_line_length", this._get_number("max_char")), this.indent_empty_lines = this._get_boolean("indent_empty_lines"), this.templating = this._get_selection_list("templating", [
						"auto",
						"none",
						"angular",
						"django",
						"erb",
						"handlebars",
						"php",
						"smarty"
					], ["auto"]);
				}
				function n(e, t) {
					var n, r = {};
					for (n in e = i(e)) n !== t && (r[n] = e[n]);
					if (t && e[t]) for (n in e[t]) r[n] = e[t][n];
					return r;
				}
				function i(e) {
					var t, n = {};
					for (t in e) n[t.replace(/-/g, "_")] = e[t];
					return n;
				}
				t.prototype._get_array = function(e, t) {
					var n = this.raw_options[e], i = t || [];
					return "object" == typeof n ? null !== n && "function" == typeof n.concat && (i = n.concat()) : "string" == typeof n && (i = n.split(/[^a-zA-Z0-9_\/\-]+/)), i;
				}, t.prototype._get_boolean = function(e, t) {
					var n = this.raw_options[e];
					return void 0 === n ? !!t : !!n;
				}, t.prototype._get_characters = function(e, t) {
					var n = this.raw_options[e], i = t || "";
					return "string" == typeof n && (i = n.replace(/\\r/, "\r").replace(/\\n/, "\n").replace(/\\t/, "	")), i;
				}, t.prototype._get_number = function(e, t) {
					var n = this.raw_options[e];
					t = parseInt(t, 10), isNaN(t) && (t = 0);
					var i = parseInt(n, 10);
					return isNaN(i) && (i = t), i;
				}, t.prototype._get_selection = function(e, t, n) {
					var i = this._get_selection_list(e, t, n);
					if (1 !== i.length) throw new Error("Invalid Option Value: The option '" + e + "' can only be one of the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
					return i[0];
				}, t.prototype._get_selection_list = function(e, t, n) {
					if (!t || 0 === t.length) throw new Error("Selection list cannot be empty.");
					if (n = n || [t[0]], !this._is_valid_selection(n, t)) throw new Error("Invalid Default Value!");
					var i = this._get_array(e, n);
					if (!this._is_valid_selection(i, t)) throw new Error("Invalid Option Value: The option '" + e + "' can contain only the following values:\n" + t + "\nYou passed in: '" + this.raw_options[e] + "'");
					return i;
				}, t.prototype._is_valid_selection = function(e, t) {
					return e.length && t.length && !e.some(function(e) {
						return -1 === t.indexOf(e);
					});
				}, e.exports.Options = t, e.exports.normalizeOpts = i, e.exports.mergeOpts = n;
			},
			,
			function(e) {
				var t = RegExp.prototype.hasOwnProperty("sticky");
				function n(e) {
					this.__input = e || "", this.__input_length = this.__input.length, this.__position = 0;
				}
				n.prototype.restart = function() {
					this.__position = 0;
				}, n.prototype.back = function() {
					this.__position > 0 && (this.__position -= 1);
				}, n.prototype.hasNext = function() {
					return this.__position < this.__input_length;
				}, n.prototype.next = function() {
					var e = null;
					return this.hasNext() && (e = this.__input.charAt(this.__position), this.__position += 1), e;
				}, n.prototype.peek = function(e) {
					var t = null;
					return e = e || 0, (e += this.__position) >= 0 && e < this.__input_length && (t = this.__input.charAt(e)), t;
				}, n.prototype.__match = function(e, n) {
					e.lastIndex = n;
					var i = e.exec(this.__input);
					return !i || t && e.sticky || i.index !== n && (i = null), i;
				}, n.prototype.test = function(e, t) {
					return t = t || 0, (t += this.__position) >= 0 && t < this.__input_length && !!this.__match(e, t);
				}, n.prototype.testChar = function(e, t) {
					var n = this.peek(t);
					return e.lastIndex = 0, null !== n && e.test(n);
				}, n.prototype.match = function(e) {
					var t = this.__match(e, this.__position);
					return t ? this.__position += t[0].length : t = null, t;
				}, n.prototype.read = function(e, t, n) {
					var i, r = "";
					return e && (i = this.match(e)) && (r += i[0]), !t || !i && e || (r += this.readUntil(t, n)), r;
				}, n.prototype.readUntil = function(e, t) {
					var n, i = this.__position;
					e.lastIndex = this.__position;
					var r = e.exec(this.__input);
					return r ? (i = r.index, t && (i += r[0].length)) : i = this.__input_length, n = this.__input.substring(this.__position, i), this.__position = i, n;
				}, n.prototype.readUntilAfter = function(e) {
					return this.readUntil(e, !0);
				}, n.prototype.get_regexp = function(e, n) {
					var i = null, r = "g";
					return n && t && (r = "y"), "string" == typeof e && "" !== e ? i = new RegExp(e, r) : e && (i = new RegExp(e.source, r)), i;
				}, n.prototype.get_literal_regexp = function(e) {
					return RegExp(e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"));
				}, n.prototype.peekUntilAfter = function(e) {
					var t = this.__position, n = this.readUntilAfter(e);
					return this.__position = t, n;
				}, n.prototype.lookBack = function(e) {
					var t = this.__position - 1;
					return t >= e.length && this.__input.substring(t - e.length, t).toLowerCase() === e;
				}, e.exports.InputScanner = n;
			},
			function(e, t, n) {
				var i = n(8).InputScanner, r = n(3).Token, a = n(10).TokenStream, o = n(11).WhitespacePattern, s = {
					START: "TK_START",
					RAW: "TK_RAW",
					EOF: "TK_EOF"
				}, l = function(e, t) {
					this._input = new i(e), this._options = t || {}, this.__tokens = null, this._patterns = {}, this._patterns.whitespace = new o(this._input);
				};
				l.prototype.tokenize = function() {
					var e;
					this._input.restart(), this.__tokens = new a(), this._reset();
					for (var t = new r(s.START, ""), n = null, i = [], o = new a(); t.type !== s.EOF;) {
						for (e = this._get_next_token(t, n); this._is_comment(e);) o.add(e), e = this._get_next_token(t, n);
						o.isEmpty() || (e.comments_before = o, o = new a()), e.parent = n, this._is_opening(e) ? (i.push(n), n = e) : n && this._is_closing(e, n) && (e.opened = n, n.closed = e, n = i.pop(), e.parent = n), e.previous = t, t.next = e, this.__tokens.add(e), t = e;
					}
					return this.__tokens;
				}, l.prototype._is_first_token = function() {
					return this.__tokens.isEmpty();
				}, l.prototype._reset = function() {}, l.prototype._get_next_token = function(e, t) {
					this._readWhitespace();
					var n = this._input.read(/.+/g);
					return n ? this._create_token(s.RAW, n) : this._create_token(s.EOF, "");
				}, l.prototype._is_comment = function(e) {
					return !1;
				}, l.prototype._is_opening = function(e) {
					return !1;
				}, l.prototype._is_closing = function(e, t) {
					return !1;
				}, l.prototype._create_token = function(e, t) {
					return new r(e, t, this._patterns.whitespace.newline_count, this._patterns.whitespace.whitespace_before_token);
				}, l.prototype._readWhitespace = function() {
					return this._patterns.whitespace.read();
				}, e.exports.Tokenizer = l, e.exports.TOKEN = s;
			},
			function(e) {
				function t(e) {
					this.__tokens = [], this.__tokens_length = this.__tokens.length, this.__position = 0, this.__parent_token = e;
				}
				t.prototype.restart = function() {
					this.__position = 0;
				}, t.prototype.isEmpty = function() {
					return 0 === this.__tokens_length;
				}, t.prototype.hasNext = function() {
					return this.__position < this.__tokens_length;
				}, t.prototype.next = function() {
					var e = null;
					return this.hasNext() && (e = this.__tokens[this.__position], this.__position += 1), e;
				}, t.prototype.peek = function(e) {
					var t = null;
					return e = e || 0, (e += this.__position) >= 0 && e < this.__tokens_length && (t = this.__tokens[e]), t;
				}, t.prototype.add = function(e) {
					this.__parent_token && (e.parent = this.__parent_token), this.__tokens.push(e), this.__tokens_length += 1;
				}, e.exports.TokenStream = t;
			},
			function(e, t, n) {
				var i = n(12).Pattern;
				function r(e, t) {
					i.call(this, e, t), t ? this._line_regexp = this._input.get_regexp(t._line_regexp) : this.__set_whitespace_patterns("", ""), this.newline_count = 0, this.whitespace_before_token = "";
				}
				r.prototype = new i(), r.prototype.__set_whitespace_patterns = function(e, t) {
					e += "\\t ", t += "\\n\\r", this._match_pattern = this._input.get_regexp("[" + e + t + "]+", !0), this._newline_regexp = this._input.get_regexp("\\r\\n|[" + t + "]");
				}, r.prototype.read = function() {
					this.newline_count = 0, this.whitespace_before_token = "";
					var e = this._input.read(this._match_pattern);
					if (" " === e) this.whitespace_before_token = " ";
					else if (e) {
						var t = this.__split(this._newline_regexp, e);
						this.newline_count = t.length - 1, this.whitespace_before_token = t[this.newline_count];
					}
					return e;
				}, r.prototype.matching = function(e, t) {
					var n = this._create();
					return n.__set_whitespace_patterns(e, t), n._update(), n;
				}, r.prototype._create = function() {
					return new r(this._input, this);
				}, r.prototype.__split = function(e, t) {
					e.lastIndex = 0;
					for (var n = 0, i = [], r = e.exec(t); r;) i.push(t.substring(n, r.index)), n = r.index + r[0].length, r = e.exec(t);
					return n < t.length ? i.push(t.substring(n, t.length)) : i.push(""), i;
				}, e.exports.WhitespacePattern = r;
			},
			function(e) {
				function t(e, t) {
					this._input = e, this._starting_pattern = null, this._match_pattern = null, this._until_pattern = null, this._until_after = !1, t && (this._starting_pattern = this._input.get_regexp(t._starting_pattern, !0), this._match_pattern = this._input.get_regexp(t._match_pattern, !0), this._until_pattern = this._input.get_regexp(t._until_pattern), this._until_after = t._until_after);
				}
				t.prototype.read = function() {
					var e = this._input.read(this._starting_pattern);
					return this._starting_pattern && !e || (e += this._input.read(this._match_pattern, this._until_pattern, this._until_after)), e;
				}, t.prototype.read_match = function() {
					return this._input.match(this._match_pattern);
				}, t.prototype.until_after = function(e) {
					var t = this._create();
					return t._until_after = !0, t._until_pattern = this._input.get_regexp(e), t._update(), t;
				}, t.prototype.until = function(e) {
					var t = this._create();
					return t._until_after = !1, t._until_pattern = this._input.get_regexp(e), t._update(), t;
				}, t.prototype.starting_with = function(e) {
					var t = this._create();
					return t._starting_pattern = this._input.get_regexp(e, !0), t._update(), t;
				}, t.prototype.matching = function(e) {
					var t = this._create();
					return t._match_pattern = this._input.get_regexp(e, !0), t._update(), t;
				}, t.prototype._create = function() {
					return new t(this._input, this);
				}, t.prototype._update = function() {}, e.exports.Pattern = t;
			},
			function(e) {
				function t(e, t) {
					e = "string" == typeof e ? e : e.source, t = "string" == typeof t ? t : t.source, this.__directives_block_pattern = new RegExp(e + / beautify( \w+[:]\w+)+ /.source + t, "g"), this.__directive_pattern = / (\w+)[:](\w+)/g, this.__directives_end_ignore_pattern = new RegExp(e + /\sbeautify\signore:end\s/.source + t, "g");
				}
				t.prototype.get_directives = function(e) {
					if (!e.match(this.__directives_block_pattern)) return null;
					var t = {};
					this.__directive_pattern.lastIndex = 0;
					for (var n = this.__directive_pattern.exec(e); n;) t[n[1]] = n[2], n = this.__directive_pattern.exec(e);
					return t;
				}, t.prototype.readIgnored = function(e) {
					return e.readUntilAfter(this.__directives_end_ignore_pattern);
				}, e.exports.Directives = t;
			},
			function(e, t, n) {
				var i = n(12).Pattern, r = {
					django: !1,
					erb: !1,
					handlebars: !1,
					php: !1,
					smarty: !1,
					angular: !1
				};
				function a(e, t) {
					i.call(this, e, t), this.__template_pattern = null, this._disabled = Object.assign({}, r), this._excluded = Object.assign({}, r), t && (this.__template_pattern = this._input.get_regexp(t.__template_pattern), this._excluded = Object.assign(this._excluded, t._excluded), this._disabled = Object.assign(this._disabled, t._disabled));
					var n = new i(e);
					this.__patterns = {
						handlebars_comment: n.starting_with(/{{!--/).until_after(/--}}/),
						handlebars_unescaped: n.starting_with(/{{{/).until_after(/}}}/),
						handlebars: n.starting_with(/{{/).until_after(/}}/),
						php: n.starting_with(/<\?(?:[= ]|php)/).until_after(/\?>/),
						erb: n.starting_with(/<%[^%]/).until_after(/[^%]%>/),
						django: n.starting_with(/{%/).until_after(/%}/),
						django_value: n.starting_with(/{{/).until_after(/}}/),
						django_comment: n.starting_with(/{#/).until_after(/#}/),
						smarty: n.starting_with(/{(?=[^}{\s\n])/).until_after(/[^\s\n]}/),
						smarty_comment: n.starting_with(/{\*/).until_after(/\*}/),
						smarty_literal: n.starting_with(/{literal}/).until_after(/{\/literal}/)
					};
				}
				a.prototype = new i(), a.prototype._create = function() {
					return new a(this._input, this);
				}, a.prototype._update = function() {
					this.__set_templated_pattern();
				}, a.prototype.disable = function(e) {
					var t = this._create();
					return t._disabled[e] = !0, t._update(), t;
				}, a.prototype.read_options = function(e) {
					var t = this._create();
					for (var n in r) t._disabled[n] = -1 === e.templating.indexOf(n);
					return t._update(), t;
				}, a.prototype.exclude = function(e) {
					var t = this._create();
					return t._excluded[e] = !0, t._update(), t;
				}, a.prototype.read = function() {
					var e = "";
					e = this._match_pattern ? this._input.read(this._starting_pattern) : this._input.read(this._starting_pattern, this.__template_pattern);
					for (var t = this._read_template(); t;) this._match_pattern ? t += this._input.read(this._match_pattern) : t += this._input.readUntil(this.__template_pattern), e += t, t = this._read_template();
					return this._until_after && (e += this._input.readUntilAfter(this._until_pattern)), e;
				}, a.prototype.__set_templated_pattern = function() {
					var e = [];
					this._disabled.php || e.push(this.__patterns.php._starting_pattern.source), this._disabled.handlebars || e.push(this.__patterns.handlebars._starting_pattern.source), this._disabled.erb || e.push(this.__patterns.erb._starting_pattern.source), this._disabled.django || (e.push(this.__patterns.django._starting_pattern.source), e.push(this.__patterns.django_value._starting_pattern.source), e.push(this.__patterns.django_comment._starting_pattern.source)), this._disabled.smarty || e.push(this.__patterns.smarty._starting_pattern.source), this._until_pattern && e.push(this._until_pattern.source), this.__template_pattern = this._input.get_regexp("(?:" + e.join("|") + ")");
				}, a.prototype._read_template = function() {
					var e = "", t = this._input.peek();
					if ("<" === t) {
						var n = this._input.peek(1);
						this._disabled.php || this._excluded.php || "?" !== n || (e = e || this.__patterns.php.read()), this._disabled.erb || this._excluded.erb || "%" !== n || (e = e || this.__patterns.erb.read());
					} else "{" === t && (this._disabled.handlebars || this._excluded.handlebars || (e = (e = (e = e || this.__patterns.handlebars_comment.read()) || this.__patterns.handlebars_unescaped.read()) || this.__patterns.handlebars.read()), this._disabled.django || (this._excluded.django || this._excluded.handlebars || (e = e || this.__patterns.django_value.read()), this._excluded.django || (e = (e = e || this.__patterns.django_comment.read()) || this.__patterns.django.read())), this._disabled.smarty || this._disabled.django && this._disabled.handlebars && (e = (e = (e = e || this.__patterns.smarty_comment.read()) || this.__patterns.smarty_literal.read()) || this.__patterns.smarty.read()));
					return e;
				}, e.exports.TemplatablePattern = a;
			},
			,
			,
			,
			function(e, t, n) {
				var i = n(19).Beautifier, r = n(20).Options;
				e.exports = function(e, t, n, r) {
					return new i(e, t, n, r).beautify();
				}, e.exports.defaultOptions = function() {
					return new r();
				};
			},
			function(e, t, n) {
				var i = n(20).Options, r = n(2).Output, a = n(21).Tokenizer, o = n(21).TOKEN, s = /\r\n|[\r\n]/, l = /\r\n|[\r\n]/g, c = function(e, t) {
					this.indent_level = 0, this.alignment_size = 0, this.max_preserve_newlines = e.max_preserve_newlines, this.preserve_newlines = e.preserve_newlines, this._output = new r(e, t);
				};
				c.prototype.current_line_has_match = function(e) {
					return this._output.current_line.has_match(e);
				}, c.prototype.set_space_before_token = function(e, t) {
					this._output.space_before_token = e, this._output.non_breaking_space = t;
				}, c.prototype.set_wrap_point = function() {
					this._output.set_indent(this.indent_level, this.alignment_size), this._output.set_wrap_point();
				}, c.prototype.add_raw_token = function(e) {
					this._output.add_raw_token(e);
				}, c.prototype.print_preserved_newlines = function(e) {
					var t = 0;
					e.type !== o.TEXT && e.previous.type !== o.TEXT && (t = e.newlines ? 1 : 0), this.preserve_newlines && (t = e.newlines < this.max_preserve_newlines + 1 ? e.newlines : this.max_preserve_newlines + 1);
					for (var n = 0; n < t; n++) this.print_newline(n > 0);
					return 0 !== t;
				}, c.prototype.traverse_whitespace = function(e) {
					return !(!e.whitespace_before && !e.newlines) && (this.print_preserved_newlines(e) || (this._output.space_before_token = !0), !0);
				}, c.prototype.previous_token_wrapped = function() {
					return this._output.previous_token_wrapped;
				}, c.prototype.print_newline = function(e) {
					this._output.add_new_line(e);
				}, c.prototype.print_token = function(e) {
					e.text && (this._output.set_indent(this.indent_level, this.alignment_size), this._output.add_token(e.text));
				}, c.prototype.indent = function() {
					this.indent_level++;
				}, c.prototype.deindent = function() {
					this.indent_level > 0 && (this.indent_level--, this._output.set_indent(this.indent_level, this.alignment_size));
				}, c.prototype.get_full_indent = function(e) {
					return (e = this.indent_level + (e || 0)) < 1 ? "" : this._output.get_indent_string(e);
				};
				var h = function(e, t) {
					var n = null, i = null;
					return t.closed ? ("script" === e ? n = "text/javascript" : "style" === e && (n = "text/css"), n = function(e) {
						for (var t = null, n = e.next; n.type !== o.EOF && e.closed !== n;) {
							if (n.type === o.ATTRIBUTE && "type" === n.text) {
								n.next && n.next.type === o.EQUALS && n.next.next && n.next.next.type === o.VALUE && (t = n.next.next.text);
								break;
							}
							n = n.next;
						}
						return t;
					}(t) || n, n.search("text/css") > -1 ? i = "css" : n.search(/module|((text|application|dojo)\/(x-)?(javascript|ecmascript|jscript|livescript|(ld\+)?json|method|aspect))/) > -1 ? i = "javascript" : n.search(/(text|application|dojo)\/(x-)?(html)/) > -1 ? i = "html" : n.search(/test\/null/) > -1 && (i = "null"), i) : null;
				};
				function d(e, t) {
					return -1 !== t.indexOf(e);
				}
				function u(e, t, n) {
					this.parent = e || null, this.tag = t ? t.tag_name : "", this.indent_level = n || 0, this.parser_token = t || null;
				}
				function m(e) {
					this._printer = e, this._current_frame = null;
				}
				function p(e, t, n, r) {
					this._source_text = e || "", t = t || {}, this._js_beautify = n, this._css_beautify = r, this._tag_stack = null, this._options = new i(t, "html"), this._is_wrap_attributes_force = "force" === this._options.wrap_attributes.substr(0, 5), this._is_wrap_attributes_force_expand_multiline = "force-expand-multiline" === this._options.wrap_attributes, this._is_wrap_attributes_force_aligned = "force-aligned" === this._options.wrap_attributes, this._is_wrap_attributes_aligned_multiple = "aligned-multiple" === this._options.wrap_attributes, this._is_wrap_attributes_preserve = "preserve" === this._options.wrap_attributes.substr(0, 8), this._is_wrap_attributes_preserve_aligned = "preserve-aligned" === this._options.wrap_attributes;
				}
				m.prototype.get_parser_token = function() {
					return this._current_frame ? this._current_frame.parser_token : null;
				}, m.prototype.record_tag = function(e) {
					this._current_frame = new u(this._current_frame, e, this._printer.indent_level);
				}, m.prototype._try_pop_frame = function(e) {
					var t = null;
					return e && (t = e.parser_token, this._printer.indent_level = e.indent_level, this._current_frame = e.parent), t;
				}, m.prototype._get_frame = function(e, t) {
					for (var n = this._current_frame; n && -1 === e.indexOf(n.tag);) {
						if (t && -1 !== t.indexOf(n.tag)) {
							n = null;
							break;
						}
						n = n.parent;
					}
					return n;
				}, m.prototype.try_pop = function(e, t) {
					var n = this._get_frame([e], t);
					return this._try_pop_frame(n);
				}, m.prototype.indent_to_tag = function(e) {
					var t = this._get_frame(e);
					t && (this._printer.indent_level = t.indent_level);
				}, p.prototype.beautify = function() {
					if (this._options.disabled) return this._source_text;
					var e = this._source_text, t = this._options.eol;
					"auto" === this._options.eol && (t = "\n", e && s.test(e) && (t = e.match(s)[0]));
					var n = (e = e.replace(l, "\n")).match(/^[\t ]*/)[0], i = {
						text: "",
						type: ""
					}, r = new g(), h = new c(this._options, n), d = new a(e, this._options).tokenize();
					this._tag_stack = new m(h);
					for (var u = null, p = d.next(); p.type !== o.EOF;) p.type === o.TAG_OPEN || p.type === o.COMMENT ? r = u = this._handle_tag_open(h, p, r, i, d) : p.type === o.ATTRIBUTE || p.type === o.EQUALS || p.type === o.VALUE || p.type === o.TEXT && !r.tag_complete ? u = this._handle_inside_tag(h, p, r, i) : p.type === o.TAG_CLOSE ? u = this._handle_tag_close(h, p, r) : p.type === o.TEXT ? u = this._handle_text(h, p, r) : p.type === o.CONTROL_FLOW_OPEN ? u = this._handle_control_flow_open(h, p) : p.type === o.CONTROL_FLOW_CLOSE ? u = this._handle_control_flow_close(h, p) : h.add_raw_token(p), i = u, p = d.next();
					return h._output.get_code(t);
				}, p.prototype._handle_control_flow_open = function(e, t) {
					var n = {
						text: t.text,
						type: t.type
					};
					return e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), t.newlines ? e.print_preserved_newlines(t) : e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), e.print_token(t), e.indent(), n;
				}, p.prototype._handle_control_flow_close = function(e, t) {
					var n = {
						text: t.text,
						type: t.type
					};
					return e.deindent(), t.newlines ? e.print_preserved_newlines(t) : e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), e.print_token(t), n;
				}, p.prototype._handle_tag_close = function(e, t, n) {
					var i = {
						text: t.text,
						type: t.type
					};
					return e.alignment_size = 0, n.tag_complete = !0, e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), n.is_unformatted ? e.add_raw_token(t) : ("<" === n.tag_start_char && (e.set_space_before_token("/" === t.text[0], !0), this._is_wrap_attributes_force_expand_multiline && n.has_wrapped_attrs && e.print_newline(!1)), e.print_token(t)), !n.indent_content || n.is_unformatted || n.is_content_unformatted || (e.indent(), n.indent_content = !1), n.is_inline_element || n.is_unformatted || n.is_content_unformatted || e.set_wrap_point(), i;
				}, p.prototype._handle_inside_tag = function(e, t, n, i) {
					var r = n.has_wrapped_attrs, a = {
						text: t.text,
						type: t.type
					};
					return e.set_space_before_token(t.newlines || "" !== t.whitespace_before, !0), n.is_unformatted ? e.add_raw_token(t) : "{" === n.tag_start_char && t.type === o.TEXT ? e.print_preserved_newlines(t) ? (t.newlines = 0, e.add_raw_token(t)) : e.print_token(t) : (t.type === o.ATTRIBUTE ? e.set_space_before_token(!0) : (t.type === o.EQUALS || t.type === o.VALUE && t.previous.type === o.EQUALS) && e.set_space_before_token(!1), t.type === o.ATTRIBUTE && "<" === n.tag_start_char && ((this._is_wrap_attributes_preserve || this._is_wrap_attributes_preserve_aligned) && (e.traverse_whitespace(t), r = r || 0 !== t.newlines), this._is_wrap_attributes_force && n.attr_count >= this._options.wrap_attributes_min_attrs && (i.type !== o.TAG_OPEN || this._is_wrap_attributes_force_expand_multiline) && (e.print_newline(!1), r = !0)), e.print_token(t), r = r || e.previous_token_wrapped(), n.has_wrapped_attrs = r), a;
				}, p.prototype._handle_text = function(e, t, n) {
					var i = {
						text: t.text,
						type: "TK_CONTENT"
					};
					return n.custom_beautifier_name ? this._print_custom_beatifier_text(e, t, n) : n.is_unformatted || n.is_content_unformatted ? e.add_raw_token(t) : (e.traverse_whitespace(t), e.print_token(t)), i;
				}, p.prototype._print_custom_beatifier_text = function(e, t, n) {
					var i = this;
					if ("" !== t.text) {
						var r, a = t.text, o = 1, s = "", l = "";
						"javascript" === n.custom_beautifier_name && "function" == typeof this._js_beautify ? r = this._js_beautify : "css" === n.custom_beautifier_name && "function" == typeof this._css_beautify ? r = this._css_beautify : "html" === n.custom_beautifier_name && (r = function(e, t) {
							return new p(e, t, i._js_beautify, i._css_beautify).beautify();
						}), "keep" === this._options.indent_scripts ? o = 0 : "separate" === this._options.indent_scripts && (o = -e.indent_level);
						var c = e.get_full_indent(o);
						if (a = a.replace(/\n[ \t]*$/, ""), "html" !== n.custom_beautifier_name && "<" === a[0] && a.match(/^(<!--|<!\[CDATA\[)/)) {
							var h = /^(<!--[^\n]*|<!\[CDATA\[)(\n?)([ \t\n]*)([\s\S]*)(-->|]]>)$/.exec(a);
							if (!h) return void e.add_raw_token(t);
							s = c + h[1] + "\n", a = h[4], h[5] && (l = c + h[5]), a = a.replace(/\n[ \t]*$/, ""), (h[2] || -1 !== h[3].indexOf("\n")) && (h = h[3].match(/[ \t]+$/)) && (t.whitespace_before = h[0]);
						}
						if (a) if (r) {
							var d = function() {
								this.eol = "\n";
							};
							d.prototype = this._options.raw_options, a = r(c + a, new d());
						} else {
							var u = t.whitespace_before;
							u && (a = a.replace(new RegExp("\n(" + u + ")?", "g"), "\n")), a = c + a.replace(/\n/g, "\n" + c);
						}
						s && (a = a ? s + a + "\n" + l : s + l), e.print_newline(!1), a && (t.text = a, t.whitespace_before = "", t.newlines = 0, e.add_raw_token(t), e.print_newline(!0));
					}
				}, p.prototype._handle_tag_open = function(e, t, n, i, r) {
					var a = this._get_tag_open_token(t);
					if (!n.is_unformatted && !n.is_content_unformatted || n.is_empty_element || t.type !== o.TAG_OPEN || a.is_start_tag ? (e.traverse_whitespace(t), this._set_tag_position(e, t, a, n, i), a.is_inline_element || e.set_wrap_point(), e.print_token(t)) : (e.add_raw_token(t), a.start_tag_token = this._tag_stack.try_pop(a.tag_name)), a.is_start_tag && this._is_wrap_attributes_force) {
						var s, l = 0;
						do
							(s = r.peek(l)).type === o.ATTRIBUTE && (a.attr_count += 1), l += 1;
						while (s.type !== o.EOF && s.type !== o.TAG_CLOSE);
					}
					return (this._is_wrap_attributes_force_aligned || this._is_wrap_attributes_aligned_multiple || this._is_wrap_attributes_preserve_aligned) && (a.alignment_size = t.text.length + 1), a.tag_complete || a.is_unformatted || (e.alignment_size = a.alignment_size), a;
				};
				var g = function(e, t) {
					if (this.parent = e || null, this.text = "", this.type = "TK_TAG_OPEN", this.tag_name = "", this.is_inline_element = !1, this.is_unformatted = !1, this.is_content_unformatted = !1, this.is_empty_element = !1, this.is_start_tag = !1, this.is_end_tag = !1, this.indent_content = !1, this.multiline_content = !1, this.custom_beautifier_name = null, this.start_tag_token = null, this.attr_count = 0, this.has_wrapped_attrs = !1, this.alignment_size = 0, this.tag_complete = !1, this.tag_start_char = "", this.tag_check = "", t) {
						var n;
						this.tag_start_char = t.text[0], this.text = t.text, "<" === this.tag_start_char ? (n = t.text.match(/^<([^\s>]*)/), this.tag_check = n ? n[1] : "") : (n = t.text.match(/^{{~?(?:[\^]|#\*?)?([^\s}]+)/), this.tag_check = n ? n[1] : "", (t.text.startsWith("{{#>") || t.text.startsWith("{{~#>")) && ">" === this.tag_check[0] && (">" === this.tag_check && null !== t.next ? this.tag_check = t.next.text.split(" ")[0] : this.tag_check = t.text.split(">")[1])), this.tag_check = this.tag_check.toLowerCase(), t.type === o.COMMENT && (this.tag_complete = !0), this.is_start_tag = "/" !== this.tag_check.charAt(0), this.tag_name = this.is_start_tag ? this.tag_check : this.tag_check.substr(1), this.is_end_tag = !this.is_start_tag || t.closed && "/>" === t.closed.text;
						var i = 2;
						"{" === this.tag_start_char && this.text.length >= 3 && "~" === this.text.charAt(2) && (i = 3), this.is_end_tag = this.is_end_tag || "{" === this.tag_start_char && (this.text.length < 3 || /[^#\^]/.test(this.text.charAt(i)));
					} else this.tag_complete = !0;
				};
				p.prototype._get_tag_open_token = function(e) {
					var t = new g(this._tag_stack.get_parser_token(), e);
					return t.alignment_size = this._options.wrap_attributes_indent_size, t.is_end_tag = t.is_end_tag || d(t.tag_check, this._options.void_elements), t.is_empty_element = t.tag_complete || t.is_start_tag && t.is_end_tag, t.is_unformatted = !t.tag_complete && d(t.tag_check, this._options.unformatted), t.is_content_unformatted = !t.is_empty_element && d(t.tag_check, this._options.content_unformatted), t.is_inline_element = d(t.tag_name, this._options.inline) || this._options.inline_custom_elements && t.tag_name.includes("-") || "{" === t.tag_start_char, t;
				}, p.prototype._set_tag_position = function(e, t, n, i, r) {
					if (n.is_empty_element || (n.is_end_tag ? n.start_tag_token = this._tag_stack.try_pop(n.tag_name) : (this._do_optional_end_element(n) && (n.is_inline_element || e.print_newline(!1)), this._tag_stack.record_tag(n), "script" !== n.tag_name && "style" !== n.tag_name || n.is_unformatted || n.is_content_unformatted || (n.custom_beautifier_name = h(n.tag_check, t)))), d(n.tag_check, this._options.extra_liners) && (e.print_newline(!1), e._output.just_added_blankline() || e.print_newline(!0)), n.is_empty_element) "{" === n.tag_start_char && "else" === n.tag_check && (this._tag_stack.indent_to_tag([
						"if",
						"unless",
						"each"
					]), n.indent_content = !0, e.current_line_has_match(/{{#if/) || e.print_newline(!1)), "!--" === n.tag_name && r.type === o.TAG_CLOSE && i.is_end_tag && -1 === n.text.indexOf("\n") || (n.is_inline_element || n.is_unformatted || e.print_newline(!1), this._calcluate_parent_multiline(e, n));
					else if (n.is_end_tag) {
						var a = !1;
						a = (a = n.start_tag_token && n.start_tag_token.multiline_content) || !n.is_inline_element && !(i.is_inline_element || i.is_unformatted) && !(r.type === o.TAG_CLOSE && n.start_tag_token === i) && "TK_CONTENT" !== r.type, (n.is_content_unformatted || n.is_unformatted) && (a = !1), a && e.print_newline(!1);
					} else n.indent_content = !n.custom_beautifier_name, "<" === n.tag_start_char && ("html" === n.tag_name ? n.indent_content = this._options.indent_inner_html : "head" === n.tag_name ? n.indent_content = this._options.indent_head_inner_html : "body" === n.tag_name && (n.indent_content = this._options.indent_body_inner_html)), n.is_inline_element || n.is_unformatted || "TK_CONTENT" === r.type && !n.is_content_unformatted || e.print_newline(!1), this._calcluate_parent_multiline(e, n);
				}, p.prototype._calcluate_parent_multiline = function(e, t) {
					!t.parent || !e._output.just_added_newline() || (t.is_inline_element || t.is_unformatted) && t.parent.is_inline_element || (t.parent.multiline_content = !0);
				};
				var f = [
					"address",
					"article",
					"aside",
					"blockquote",
					"details",
					"div",
					"dl",
					"fieldset",
					"figcaption",
					"figure",
					"footer",
					"form",
					"h1",
					"h2",
					"h3",
					"h4",
					"h5",
					"h6",
					"header",
					"hr",
					"main",
					"menu",
					"nav",
					"ol",
					"p",
					"pre",
					"section",
					"table",
					"ul"
				], b = [
					"a",
					"audio",
					"del",
					"ins",
					"map",
					"noscript",
					"video"
				];
				p.prototype._do_optional_end_element = function(e) {
					var t = null;
					if (!e.is_empty_element && e.is_start_tag && e.parent) {
						if ("body" === e.tag_name) t = t || this._tag_stack.try_pop("head");
						else if ("li" === e.tag_name) t = t || this._tag_stack.try_pop("li", [
							"ol",
							"ul",
							"menu"
						]);
						else if ("dd" === e.tag_name || "dt" === e.tag_name) t = (t = t || this._tag_stack.try_pop("dt", ["dl"])) || this._tag_stack.try_pop("dd", ["dl"]);
						else if ("p" === e.parent.tag_name && -1 !== f.indexOf(e.tag_name)) {
							var n = e.parent.parent;
							n && -1 !== b.indexOf(n.tag_name) || (t = t || this._tag_stack.try_pop("p"));
						} else "rp" === e.tag_name || "rt" === e.tag_name ? t = (t = t || this._tag_stack.try_pop("rt", ["ruby", "rtc"])) || this._tag_stack.try_pop("rp", ["ruby", "rtc"]) : "optgroup" === e.tag_name ? t = t || this._tag_stack.try_pop("optgroup", ["select"]) : "option" === e.tag_name ? t = t || this._tag_stack.try_pop("option", [
							"select",
							"datalist",
							"optgroup"
						]) : "colgroup" === e.tag_name ? t = t || this._tag_stack.try_pop("caption", ["table"]) : "thead" === e.tag_name ? t = (t = t || this._tag_stack.try_pop("caption", ["table"])) || this._tag_stack.try_pop("colgroup", ["table"]) : "tbody" === e.tag_name || "tfoot" === e.tag_name ? t = (t = (t = (t = t || this._tag_stack.try_pop("caption", ["table"])) || this._tag_stack.try_pop("colgroup", ["table"])) || this._tag_stack.try_pop("thead", ["table"])) || this._tag_stack.try_pop("tbody", ["table"]) : "tr" === e.tag_name ? t = (t = (t = t || this._tag_stack.try_pop("caption", ["table"])) || this._tag_stack.try_pop("colgroup", ["table"])) || this._tag_stack.try_pop("tr", [
							"table",
							"thead",
							"tbody",
							"tfoot"
						]) : "th" !== e.tag_name && "td" !== e.tag_name || (t = (t = t || this._tag_stack.try_pop("td", [
							"table",
							"thead",
							"tbody",
							"tfoot",
							"tr"
						])) || this._tag_stack.try_pop("th", [
							"table",
							"thead",
							"tbody",
							"tfoot",
							"tr"
						]));
						return e.parent = this._tag_stack.get_parser_token(), t;
					}
				}, e.exports.Beautifier = p;
			},
			function(e, t, n) {
				var i = n(6).Options;
				function r(e) {
					i.call(this, e, "html"), 1 === this.templating.length && "auto" === this.templating[0] && (this.templating = [
						"django",
						"erb",
						"handlebars",
						"php"
					]), this.indent_inner_html = this._get_boolean("indent_inner_html"), this.indent_body_inner_html = this._get_boolean("indent_body_inner_html", !0), this.indent_head_inner_html = this._get_boolean("indent_head_inner_html", !0), this.indent_handlebars = this._get_boolean("indent_handlebars", !0), this.wrap_attributes = this._get_selection("wrap_attributes", [
						"auto",
						"force",
						"force-aligned",
						"force-expand-multiline",
						"aligned-multiple",
						"preserve",
						"preserve-aligned"
					]), this.wrap_attributes_min_attrs = this._get_number("wrap_attributes_min_attrs", 2), this.wrap_attributes_indent_size = this._get_number("wrap_attributes_indent_size", this.indent_size), this.extra_liners = this._get_array("extra_liners", [
						"head",
						"body",
						"/html"
					]), this.inline = this._get_array("inline", [
						"a",
						"abbr",
						"area",
						"audio",
						"b",
						"bdi",
						"bdo",
						"br",
						"button",
						"canvas",
						"cite",
						"code",
						"data",
						"datalist",
						"del",
						"dfn",
						"em",
						"embed",
						"i",
						"iframe",
						"img",
						"input",
						"ins",
						"kbd",
						"keygen",
						"label",
						"map",
						"mark",
						"math",
						"meter",
						"noscript",
						"object",
						"output",
						"progress",
						"q",
						"ruby",
						"s",
						"samp",
						"select",
						"small",
						"span",
						"strong",
						"sub",
						"sup",
						"svg",
						"template",
						"textarea",
						"time",
						"u",
						"var",
						"video",
						"wbr",
						"text",
						"acronym",
						"big",
						"strike",
						"tt"
					]), this.inline_custom_elements = this._get_boolean("inline_custom_elements", !0), this.void_elements = this._get_array("void_elements", [
						"area",
						"base",
						"br",
						"col",
						"embed",
						"hr",
						"img",
						"input",
						"keygen",
						"link",
						"menuitem",
						"meta",
						"param",
						"source",
						"track",
						"wbr",
						"!doctype",
						"?xml",
						"basefont",
						"isindex"
					]), this.unformatted = this._get_array("unformatted", []), this.content_unformatted = this._get_array("content_unformatted", ["pre", "textarea"]), this.unformatted_content_delimiter = this._get_characters("unformatted_content_delimiter"), this.indent_scripts = this._get_selection("indent_scripts", [
						"normal",
						"keep",
						"separate"
					]);
				}
				r.prototype = new i(), e.exports.Options = r;
			},
			function(e, t, n) {
				var i = n(9).Tokenizer, r = n(9).TOKEN, a = n(13).Directives, o = n(14).TemplatablePattern, s = n(12).Pattern, l = {
					TAG_OPEN: "TK_TAG_OPEN",
					TAG_CLOSE: "TK_TAG_CLOSE",
					CONTROL_FLOW_OPEN: "TK_CONTROL_FLOW_OPEN",
					CONTROL_FLOW_CLOSE: "TK_CONTROL_FLOW_CLOSE",
					ATTRIBUTE: "TK_ATTRIBUTE",
					EQUALS: "TK_EQUALS",
					VALUE: "TK_VALUE",
					COMMENT: "TK_COMMENT",
					TEXT: "TK_TEXT",
					UNKNOWN: "TK_UNKNOWN",
					START: r.START,
					RAW: r.RAW,
					EOF: r.EOF
				}, c = new a(/<\!--/, /-->/), h = function(e, t) {
					i.call(this, e, t), this._current_tag_name = "";
					var n = new o(this._input).read_options(this._options), r = new s(this._input);
					if (this.__patterns = {
						word: n.until(/[\n\r\t <]/),
						word_control_flow_close_excluded: n.until(/[\n\r\t <}]/),
						single_quote: n.until_after(/'/),
						double_quote: n.until_after(/"/),
						attribute: n.until(/[\n\r\t =>]|\/>/),
						element_name: n.until(/[\n\r\t >\/]/),
						angular_control_flow_start: r.matching(/\@[a-zA-Z]+[^({]*[({]/),
						handlebars_comment: r.starting_with(/{{!--/).until_after(/--}}/),
						handlebars: r.starting_with(/{{/).until_after(/}}/),
						handlebars_open: r.until(/[\n\r\t }]/),
						handlebars_raw_close: r.until(/}}/),
						comment: r.starting_with(/<!--/).until_after(/-->/),
						cdata: r.starting_with(/<!\[CDATA\[/).until_after(/]]>/),
						conditional_comment: r.starting_with(/<!\[/).until_after(/]>/),
						processing: r.starting_with(/<\?/).until_after(/\?>/)
					}, this._options.indent_handlebars && (this.__patterns.word = this.__patterns.word.exclude("handlebars"), this.__patterns.word_control_flow_close_excluded = this.__patterns.word_control_flow_close_excluded.exclude("handlebars")), this._unformatted_content_delimiter = null, this._options.unformatted_content_delimiter) {
						var a = this._input.get_literal_regexp(this._options.unformatted_content_delimiter);
						this.__patterns.unformatted_content_delimiter = r.matching(a).until_after(a);
					}
				};
				(h.prototype = new i())._is_comment = function(e) {
					return !1;
				}, h.prototype._is_opening = function(e) {
					return e.type === l.TAG_OPEN || e.type === l.CONTROL_FLOW_OPEN;
				}, h.prototype._is_closing = function(e, t) {
					return e.type === l.TAG_CLOSE && t && ((">" === e.text || "/>" === e.text) && "<" === t.text[0] || "}}" === e.text && "{" === t.text[0] && "{" === t.text[1]) || e.type === l.CONTROL_FLOW_CLOSE && "}" === e.text && t.text.endsWith("{");
				}, h.prototype._reset = function() {
					this._current_tag_name = "";
				}, h.prototype._get_next_token = function(e, t) {
					var n = null;
					this._readWhitespace();
					var i = this._input.peek();
					return null === i ? this._create_token(l.EOF, "") : n = (n = (n = (n = (n = (n = (n = (n = (n = (n = n || this._read_open_handlebars(i, t)) || this._read_attribute(i, e, t)) || this._read_close(i, t)) || this._read_control_flows(i, t)) || this._read_raw_content(i, e, t)) || this._read_content_word(i, t)) || this._read_comment_or_cdata(i)) || this._read_processing(i)) || this._read_open(i, t)) || this._create_token(l.UNKNOWN, this._input.next());
				}, h.prototype._read_comment_or_cdata = function(e) {
					var t = null, n = null, i = null;
					return "<" === e && ("!" === this._input.peek(1) && ((n = this.__patterns.comment.read()) ? (i = c.get_directives(n)) && "start" === i.ignore && (n += c.readIgnored(this._input)) : n = this.__patterns.cdata.read()), n && ((t = this._create_token(l.COMMENT, n)).directives = i)), t;
				}, h.prototype._read_processing = function(e) {
					var t = null, n = null;
					if ("<" === e) {
						var i = this._input.peek(1);
						"!" !== i && "?" !== i || (n = (n = this.__patterns.conditional_comment.read()) || this.__patterns.processing.read()), n && ((t = this._create_token(l.COMMENT, n)).directives = null);
					}
					return t;
				}, h.prototype._read_open = function(e, t) {
					var n = null, i = null;
					return t && t.type !== l.CONTROL_FLOW_OPEN || "<" === e && (n = this._input.next(), "/" === this._input.peek() && (n += this._input.next()), n += this.__patterns.element_name.read(), i = this._create_token(l.TAG_OPEN, n)), i;
				}, h.prototype._read_open_handlebars = function(e, t) {
					var n = null, i = null;
					return t && t.type !== l.CONTROL_FLOW_OPEN || this._options.indent_handlebars && "{" === e && "{" === this._input.peek(1) && ("!" === this._input.peek(2) ? (n = (n = this.__patterns.handlebars_comment.read()) || this.__patterns.handlebars.read(), i = this._create_token(l.COMMENT, n)) : (n = this.__patterns.handlebars_open.read(), i = this._create_token(l.TAG_OPEN, n))), i;
				}, h.prototype._read_control_flows = function(e, t) {
					var n = "", i = null;
					if (!this._options.templating.includes("angular") || !this._options.indent_handlebars) return i;
					if ("@" === e) {
						if ("" === (n = this.__patterns.angular_control_flow_start.read())) return i;
						for (var r = n.endsWith("(") ? 1 : 0, a = 0; !n.endsWith("{") || r !== a;) {
							var o = this._input.next();
							if (null === o) break;
							"(" === o ? r++ : ")" === o && a++, n += o;
						}
						i = this._create_token(l.CONTROL_FLOW_OPEN, n);
					} else "}" === e && t && t.type === l.CONTROL_FLOW_OPEN && (n = this._input.next(), i = this._create_token(l.CONTROL_FLOW_CLOSE, n));
					return i;
				}, h.prototype._read_close = function(e, t) {
					var n = null, i = null;
					return t && t.type === l.TAG_OPEN && ("<" === t.text[0] && (">" === e || "/" === e && ">" === this._input.peek(1)) ? (n = this._input.next(), "/" === e && (n += this._input.next()), i = this._create_token(l.TAG_CLOSE, n)) : "{" === t.text[0] && "}" === e && "}" === this._input.peek(1) && (this._input.next(), this._input.next(), i = this._create_token(l.TAG_CLOSE, "}}"))), i;
				}, h.prototype._read_attribute = function(e, t, n) {
					var i = null, r = "";
					if (n && "<" === n.text[0]) if ("=" === e) i = this._create_token(l.EQUALS, this._input.next());
					else if ("\"" === e || "'" === e) {
						var a = this._input.next();
						a += "\"" === e ? this.__patterns.double_quote.read() : this.__patterns.single_quote.read(), i = this._create_token(l.VALUE, a);
					} else (r = this.__patterns.attribute.read()) && (i = t.type === l.EQUALS ? this._create_token(l.VALUE, r) : this._create_token(l.ATTRIBUTE, r));
					return i;
				}, h.prototype._is_content_unformatted = function(e) {
					return -1 === this._options.void_elements.indexOf(e) && (-1 !== this._options.content_unformatted.indexOf(e) || -1 !== this._options.unformatted.indexOf(e));
				}, h.prototype._read_raw_content = function(e, t, n) {
					var i = "";
					if (n && "{" === n.text[0]) i = this.__patterns.handlebars_raw_close.read();
					else if (t.type === l.TAG_CLOSE && "<" === t.opened.text[0] && "/" !== t.text[0]) {
						var r = t.opened.text.substr(1).toLowerCase();
						if ("script" === r || "style" === r) {
							var a = this._read_comment_or_cdata(e);
							if (a) return a.type = l.TEXT, a;
							i = this._input.readUntil(new RegExp("</" + r + "[\\n\\r\\t ]*?>", "ig"));
						} else this._is_content_unformatted(r) && (i = this._input.readUntil(new RegExp("</" + r + "[\\n\\r\\t ]*?>", "ig")));
					}
					return i ? this._create_token(l.TEXT, i) : null;
				}, h.prototype._read_content_word = function(e, t) {
					var n = "";
					if (this._options.unformatted_content_delimiter && e === this._options.unformatted_content_delimiter[0] && (n = this.__patterns.unformatted_content_delimiter.read()), n || (n = t && t.type === l.CONTROL_FLOW_OPEN ? this.__patterns.word_control_flow_close_excluded.read() : this.__patterns.word.read()), n) return this._create_token(l.TEXT, n);
				}, e.exports.Tokenizer = h, e.exports.TOKEN = l;
			}
		], t = {};
		Xs = function n(i) {
			var r = t[i];
			if (void 0 !== r) return r.exports;
			var a = t[i] = { exports: {} };
			return e[i](a, a.exports, n), a.exports;
		}(18);
	})(), (() => {
		var e = { 470: (e) => {
			function t(e) {
				if ("string" != typeof e) throw new TypeError("Path must be a string. Received " + JSON.stringify(e));
			}
			function n(e, t) {
				for (var n, i = "", r = 0, a = -1, o = 0, s = 0; s <= e.length; ++s) {
					if (s < e.length) n = e.charCodeAt(s);
					else {
						if (47 === n) break;
						n = 47;
					}
					if (47 === n) {
						if (a === s - 1 || 1 === o);
						else if (a !== s - 1 && 2 === o) {
							if (i.length < 2 || 2 !== r || 46 !== i.charCodeAt(i.length - 1) || 46 !== i.charCodeAt(i.length - 2)) {
								if (i.length > 2) {
									var l = i.lastIndexOf("/");
									if (l !== i.length - 1) {
										-1 === l ? (i = "", r = 0) : r = (i = i.slice(0, l)).length - 1 - i.lastIndexOf("/"), a = s, o = 0;
										continue;
									}
								} else if (2 === i.length || 1 === i.length) {
									i = "", r = 0, a = s, o = 0;
									continue;
								}
							}
							t && (i.length > 0 ? i += "/.." : i = "..", r = 2);
						} else i.length > 0 ? i += "/" + e.slice(a + 1, s) : i = e.slice(a + 1, s), r = s - a - 1;
						a = s, o = 0;
					} else 46 === n && -1 !== o ? ++o : o = -1;
				}
				return i;
			}
			var i = {
				resolve: function() {
					for (var e, i = "", r = !1, a = arguments.length - 1; a >= -1 && !r; a--) {
						var o;
						a >= 0 ? o = arguments[a] : (void 0 === e && (e = process.cwd()), o = e), t(o), 0 !== o.length && (i = o + "/" + i, r = 47 === o.charCodeAt(0));
					}
					return i = n(i, !r), r ? i.length > 0 ? "/" + i : "/" : i.length > 0 ? i : ".";
				},
				normalize: function(e) {
					if (t(e), 0 === e.length) return ".";
					var i = 47 === e.charCodeAt(0), r = 47 === e.charCodeAt(e.length - 1);
					return 0 !== (e = n(e, !i)).length || i || (e = "."), e.length > 0 && r && (e += "/"), i ? "/" + e : e;
				},
				isAbsolute: function(e) {
					return t(e), e.length > 0 && 47 === e.charCodeAt(0);
				},
				join: function() {
					if (0 === arguments.length) return ".";
					for (var e, n = 0; n < arguments.length; ++n) {
						var r = arguments[n];
						t(r), r.length > 0 && (void 0 === e ? e = r : e += "/" + r);
					}
					return void 0 === e ? "." : i.normalize(e);
				},
				relative: function(e, n) {
					if (t(e), t(n), e === n) return "";
					if ((e = i.resolve(e)) === (n = i.resolve(n))) return "";
					for (var r = 1; r < e.length && 47 === e.charCodeAt(r); ++r);
					for (var a = e.length, o = a - r, s = 1; s < n.length && 47 === n.charCodeAt(s); ++s);
					for (var l = n.length - s, c = o < l ? o : l, h = -1, d = 0; d <= c; ++d) {
						if (d === c) {
							if (l > c) {
								if (47 === n.charCodeAt(s + d)) return n.slice(s + d + 1);
								if (0 === d) return n.slice(s + d);
							} else o > c && (47 === e.charCodeAt(r + d) ? h = d : 0 === d && (h = 0));
							break;
						}
						var u = e.charCodeAt(r + d);
						if (u !== n.charCodeAt(s + d)) break;
						47 === u && (h = d);
					}
					var m = "";
					for (d = r + h + 1; d <= a; ++d) d !== a && 47 !== e.charCodeAt(d) || (0 === m.length ? m += ".." : m += "/..");
					return m.length > 0 ? m + n.slice(s + h) : (s += h, 47 === n.charCodeAt(s) && ++s, n.slice(s));
				},
				_makeLong: function(e) {
					return e;
				},
				dirname: function(e) {
					if (t(e), 0 === e.length) return ".";
					for (var n = e.charCodeAt(0), i = 47 === n, r = -1, a = !0, o = e.length - 1; o >= 1; --o) if (47 === (n = e.charCodeAt(o))) {
						if (!a) {
							r = o;
							break;
						}
					} else a = !1;
					return -1 === r ? i ? "/" : "." : i && 1 === r ? "//" : e.slice(0, r);
				},
				basename: function(e, n) {
					if (void 0 !== n && "string" != typeof n) throw new TypeError("\"ext\" argument must be a string");
					t(e);
					var i, r = 0, a = -1, o = !0;
					if (void 0 !== n && n.length > 0 && n.length <= e.length) {
						if (n.length === e.length && n === e) return "";
						var s = n.length - 1, l = -1;
						for (i = e.length - 1; i >= 0; --i) {
							var c = e.charCodeAt(i);
							if (47 === c) {
								if (!o) {
									r = i + 1;
									break;
								}
							} else -1 === l && (o = !1, l = i + 1), s >= 0 && (c === n.charCodeAt(s) ? -1 == --s && (a = i) : (s = -1, a = l));
						}
						return r === a ? a = l : -1 === a && (a = e.length), e.slice(r, a);
					}
					for (i = e.length - 1; i >= 0; --i) if (47 === e.charCodeAt(i)) {
						if (!o) {
							r = i + 1;
							break;
						}
					} else -1 === a && (o = !1, a = i + 1);
					return -1 === a ? "" : e.slice(r, a);
				},
				extname: function(e) {
					t(e);
					for (var n = -1, i = 0, r = -1, a = !0, o = 0, s = e.length - 1; s >= 0; --s) {
						var l = e.charCodeAt(s);
						if (47 !== l) -1 === r && (a = !1, r = s + 1), 46 === l ? -1 === n ? n = s : 1 !== o && (o = 1) : -1 !== n && (o = -1);
						else if (!a) {
							i = s + 1;
							break;
						}
					}
					return -1 === n || -1 === r || 0 === o || 1 === o && n === r - 1 && n === i + 1 ? "" : e.slice(n, r);
				},
				format: function(e) {
					if (null === e || "object" != typeof e) throw new TypeError("The \"pathObject\" argument must be of type Object. Received type " + typeof e);
					return function(e, t) {
						var n = t.dir || t.root, i = t.base || (t.name || "") + (t.ext || "");
						return n ? n === t.root ? n + i : n + "/" + i : i;
					}(0, e);
				},
				parse: function(e) {
					t(e);
					var n = {
						root: "",
						dir: "",
						base: "",
						ext: "",
						name: ""
					};
					if (0 === e.length) return n;
					var i, r = e.charCodeAt(0), a = 47 === r;
					a ? (n.root = "/", i = 1) : i = 0;
					for (var o = -1, s = 0, l = -1, c = !0, h = e.length - 1, d = 0; h >= i; --h) if (47 !== (r = e.charCodeAt(h))) -1 === l && (c = !1, l = h + 1), 46 === r ? -1 === o ? o = h : 1 !== d && (d = 1) : -1 !== o && (d = -1);
					else if (!c) {
						s = h + 1;
						break;
					}
					return -1 === o || -1 === l || 0 === d || 1 === d && o === l - 1 && o === s + 1 ? -1 !== l && (n.base = n.name = 0 === s && a ? e.slice(1, l) : e.slice(s, l)) : (0 === s && a ? (n.name = e.slice(1, o), n.base = e.slice(1, l)) : (n.name = e.slice(s, o), n.base = e.slice(s, l)), n.ext = e.slice(o, l)), s > 0 ? n.dir = e.slice(0, s - 1) : a && (n.dir = "/"), n;
				},
				sep: "/",
				delimiter: ":",
				win32: null,
				posix: null
			};
			i.posix = i, e.exports = i;
		} }, t = {};
		function n(i) {
			var r = t[i];
			if (void 0 !== r) return r.exports;
			var a = t[i] = { exports: {} };
			return e[i](a, a.exports, n), a.exports;
		}
		n.d = (e, t) => {
			for (var i in t) n.o(t, i) && !n.o(e, i) && Object.defineProperty(e, i, {
				enumerable: !0,
				get: t[i]
			});
		}, n.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), n.r = (e) => {
			"undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
		};
		var i = {};
		(() => {
			let e;
			n.r(i), n.d(i, {
				URI: () => h,
				Utils: () => S
			}), "object" == typeof process ? e = "win32" === process.platform : "object" == typeof navigator && (e = navigator.userAgent.indexOf("Windows") >= 0);
			const t = /^\w[\w\d+.-]*$/, r = /^\//, a = /^\/\//;
			function o(e, n) {
				if (!e.scheme && n) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${e.authority}", path: "${e.path}", query: "${e.query}", fragment: "${e.fragment}"}`);
				if (e.scheme && !t.test(e.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
				if (e.path) {
					if (e.authority) {
						if (!r.test(e.path)) throw new Error("[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash (\"/\") character");
					} else if (a.test(e.path)) throw new Error("[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters (\"//\")");
				}
			}
			const s = "", l = "/", c = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
			class h {
				static isUri(e) {
					return e instanceof h || !!e && "string" == typeof e.authority && "string" == typeof e.fragment && "string" == typeof e.path && "string" == typeof e.query && "string" == typeof e.scheme && "string" == typeof e.fsPath && "function" == typeof e.with && "function" == typeof e.toString;
				}
				scheme;
				authority;
				path;
				query;
				fragment;
				constructor(e, t, n, i, r, a = !1) {
					"object" == typeof e ? (this.scheme = e.scheme || s, this.authority = e.authority || s, this.path = e.path || s, this.query = e.query || s, this.fragment = e.fragment || s) : (this.scheme = function(e, t) {
						return e || t ? e : "file";
					}(e, a), this.authority = t || s, this.path = function(e, t) {
						switch (e) {
							case "https":
							case "http":
							case "file": t ? t[0] !== l && (t = l + t) : t = l;
						}
						return t;
					}(this.scheme, n || s), this.query = i || s, this.fragment = r || s, o(this, a));
				}
				get fsPath() {
					return f(this);
				}
				with(e) {
					if (!e) return this;
					let { scheme: t, authority: n, path: i, query: r, fragment: a } = e;
					return void 0 === t ? t = this.scheme : null === t && (t = s), void 0 === n ? n = this.authority : null === n && (n = s), void 0 === i ? i = this.path : null === i && (i = s), void 0 === r ? r = this.query : null === r && (r = s), void 0 === a ? a = this.fragment : null === a && (a = s), t === this.scheme && n === this.authority && i === this.path && r === this.query && a === this.fragment ? this : new u(t, n, i, r, a);
				}
				static parse(e, t = !1) {
					const n = c.exec(e);
					return n ? new u(n[2] || s, v(n[4] || s), v(n[5] || s), v(n[7] || s), v(n[9] || s), t) : new u(s, s, s, s, s);
				}
				static file(t) {
					let n = s;
					if (e && (t = t.replace(/\\/g, l)), t[0] === l && t[1] === l) {
						const e = t.indexOf(l, 2);
						-1 === e ? (n = t.substring(2), t = l) : (n = t.substring(2, e), t = t.substring(e) || l);
					}
					return new u("file", n, t, s, s);
				}
				static from(e) {
					const t = new u(e.scheme, e.authority, e.path, e.query, e.fragment);
					return o(t, !0), t;
				}
				toString(e = !1) {
					return b(this, e);
				}
				toJSON() {
					return this;
				}
				static revive(e) {
					if (e) {
						if (e instanceof h) return e;
						{
							const t = new u(e);
							return t._formatted = e.external, t._fsPath = e._sep === d ? e.fsPath : null, t;
						}
					}
					return e;
				}
			}
			const d = e ? 1 : void 0;
			class u extends h {
				_formatted = null;
				_fsPath = null;
				get fsPath() {
					return this._fsPath || (this._fsPath = f(this)), this._fsPath;
				}
				toString(e = !1) {
					return e ? b(this, !0) : (this._formatted || (this._formatted = b(this, !1)), this._formatted);
				}
				toJSON() {
					const e = { $mid: 1 };
					return this._fsPath && (e.fsPath = this._fsPath, e._sep = d), this._formatted && (e.external = this._formatted), this.path && (e.path = this.path), this.scheme && (e.scheme = this.scheme), this.authority && (e.authority = this.authority), this.query && (e.query = this.query), this.fragment && (e.fragment = this.fragment), e;
				}
			}
			const m = {
				58: "%3A",
				47: "%2F",
				63: "%3F",
				35: "%23",
				91: "%5B",
				93: "%5D",
				64: "%40",
				33: "%21",
				36: "%24",
				38: "%26",
				39: "%27",
				40: "%28",
				41: "%29",
				42: "%2A",
				43: "%2B",
				44: "%2C",
				59: "%3B",
				61: "%3D",
				32: "%20"
			};
			function p(e, t, n) {
				let i, r = -1;
				for (let a = 0; a < e.length; a++) {
					const o = e.charCodeAt(a);
					if (o >= 97 && o <= 122 || o >= 65 && o <= 90 || o >= 48 && o <= 57 || 45 === o || 46 === o || 95 === o || 126 === o || t && 47 === o || n && 91 === o || n && 93 === o || n && 58 === o) -1 !== r && (i += encodeURIComponent(e.substring(r, a)), r = -1), void 0 !== i && (i += e.charAt(a));
					else {
						void 0 === i && (i = e.substr(0, a));
						const t = m[o];
						void 0 !== t ? (-1 !== r && (i += encodeURIComponent(e.substring(r, a)), r = -1), i += t) : -1 === r && (r = a);
					}
				}
				return -1 !== r && (i += encodeURIComponent(e.substring(r))), void 0 !== i ? i : e;
			}
			function g(e) {
				let t;
				for (let n = 0; n < e.length; n++) {
					const i = e.charCodeAt(n);
					35 === i || 63 === i ? (void 0 === t && (t = e.substr(0, n)), t += m[i]) : void 0 !== t && (t += e[n]);
				}
				return void 0 !== t ? t : e;
			}
			function f(t, n) {
				let i;
				return i = t.authority && t.path.length > 1 && "file" === t.scheme ? `//${t.authority}${t.path}` : 47 === t.path.charCodeAt(0) && (t.path.charCodeAt(1) >= 65 && t.path.charCodeAt(1) <= 90 || t.path.charCodeAt(1) >= 97 && t.path.charCodeAt(1) <= 122) && 58 === t.path.charCodeAt(2) ? t.path[1].toLowerCase() + t.path.substr(2) : t.path, e && (i = i.replace(/\//g, "\\")), i;
			}
			function b(e, t) {
				const n = t ? g : p;
				let i = "", { scheme: r, authority: a, path: o, query: s, fragment: c } = e;
				if (r && (i += r, i += ":"), (a || "file" === r) && (i += l, i += l), a) {
					let e = a.indexOf("@");
					if (-1 !== e) {
						const t = a.substr(0, e);
						a = a.substr(e + 1), e = t.lastIndexOf(":"), -1 === e ? i += n(t, !1, !1) : (i += n(t.substr(0, e), !1, !1), i += ":", i += n(t.substr(e + 1), !1, !0)), i += "@";
					}
					a = a.toLowerCase(), e = a.lastIndexOf(":"), -1 === e ? i += n(a, !1, !0) : (i += n(a.substr(0, e), !1, !0), i += a.substr(e));
				}
				if (o) {
					if (o.length >= 3 && 47 === o.charCodeAt(0) && 58 === o.charCodeAt(2)) {
						const e = o.charCodeAt(1);
						e >= 65 && e <= 90 && (o = `/${String.fromCharCode(e + 32)}:${o.substr(3)}`);
					} else if (o.length >= 2 && 58 === o.charCodeAt(1)) {
						const e = o.charCodeAt(0);
						e >= 65 && e <= 90 && (o = `${String.fromCharCode(e + 32)}:${o.substr(2)}`);
					}
					i += n(o, !0, !1);
				}
				return s && (i += "?", i += n(s, !1, !1)), c && (i += "#", i += t ? c : p(c, !1, !1)), i;
			}
			function _(e) {
				try {
					return decodeURIComponent(e);
				} catch {
					return e.length > 3 ? e.substr(0, 3) + _(e.substr(3)) : e;
				}
			}
			const w = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
			function v(e) {
				return e.match(w) ? e.replace(w, (e) => _(e)) : e;
			}
			var y = n(470);
			const T = y.posix || y, k = "/";
			var S;
			(function(e) {
				e.joinPath = function(e, ...t) {
					return e.with({ path: T.join(e.path, ...t) });
				}, e.resolvePath = function(e, ...t) {
					let n = e.path, i = !1;
					n[0] !== k && (n = k + n, i = !0);
					let r = T.resolve(n, ...t);
					return i && r[0] === k && !e.authority && (r = r.substring(1)), e.with({ path: r });
				}, e.dirname = function(e) {
					if (0 === e.path.length || e.path === k) return e;
					let t = T.dirname(e.path);
					return 1 === t.length && 46 === t.charCodeAt(0) && (t = ""), e.with({ path: t });
				}, e.basename = function(e) {
					return T.basename(e.path);
				}, e.extname = function(e) {
					return T.extname(e.path);
				};
			})(S || (S = {}));
		})(), Js = i;
	})();
	const { URI: rl, Utils: al } = Js;
	function ol(e) {
		const t = e[0];
		return t !== e[e.length - 1] || "'" !== t && "\"" !== t || (e = e.substring(1, e.length - 1)), e;
	}
	function sl(e, t, n, i, r, a) {
		const o = ol(n);
		if (s = o, l = e.languageId, !s.length || "handlebars" === l && /{{|}}/.test(s) || !/\b(w[\w\d+.-]*:\/\/)?[^\s()<>]+(?:\([\w\d]+\)|([^[:punct:]\s]|\/?))/.test(s)) return;
		var s, l;
		o.length < n.length && (i++, r--);
		const c = function(e, t, n, i) {
			if (/^\s*javascript\:/i.test(t) || /[\n\r]/.test(t)) return;
			const r = (t = t.replace(/^\s*/g, "")).match(/^(\w[\w\d+.-]*):/);
			if (r) {
				const e = r[1].toLowerCase();
				return "http" === e || "https" === e || "file" === e ? t : void 0;
			}
			return /^\#/i.test(t) ? e + t : /^\/\//i.test(t) ? (Ts(e, "https://") ? "https" : "http") + ":" + t.replace(/^\s*/g, "") : n ? n.resolveReference(t, i || e) : t;
		}(e.uri, o, t, a);
		if (!c) return;
		const h = function(e, t) {
			try {
				let n = rl.parse(e);
				return "file" === n.scheme && n.query && (n = n.with({ query: null }), e = n.toString(!0)), "file" !== n.scheme || !n.fragment || e.startsWith(t.uri) && e.charCodeAt(t.uri.length) === ll ? e : n.with({ fragment: null }).toString(!0);
			} catch (El) {
				return;
			}
		}(c, e);
		return {
			range: Ta.create(e.positionAt(i), e.positionAt(r)),
			target: h
		};
	}
	const ll = "#".charCodeAt(0);
	var cl = class {
		constructor(e) {
			this.dataManager = e;
		}
		findDocumentLinks(e, t) {
			const n = [], i = bs(e.getText(), 0);
			let r, a, o, s = i.scan(), l = !1;
			const c = {};
			for (; s !== Go.EOS;) {
				switch (s) {
					case Go.StartTag:
						a = i.getTokenText().toLowerCase(), o || (l = "base" === a);
						break;
					case Go.AttributeName:
						r = i.getTokenText().toLowerCase();
						break;
					case Go.AttributeValue: if (a && r && this.dataManager.isPathAttribute(a, r)) {
						const a = i.getTokenText();
						if (!l) {
							const r = sl(e, t, a, i.getTokenOffset(), i.getTokenEnd(), o);
							r && n.push(r);
						}
						l && void 0 === o && (o = ol(a), o && t && (o = t.resolveReference(o, e.uri))), l = !1, r = void 0;
					} else if ("id" === r) c[ol(i.getTokenText())] = i.getTokenOffset();
				}
				s = i.scan();
			}
			for (const h of n) {
				const t = e.uri + "#";
				if (h.target && Ts(h.target, t)) {
					const n = c[h.target.substring(t.length)];
					if (void 0 !== n) {
						const i = e.positionAt(n);
						h.target = `${t}${i.line + 1},${i.character + 1}`;
					} else h.target = e.uri;
				}
			}
			return n;
		}
	};
	function hl(e, t, n) {
		const i = e.offsetAt(t), r = n.findNodeAt(i);
		if (!r.tag) return [];
		const a = [], o = ml(Go.StartTag, e, r.start), s = "number" == typeof r.endTagStart && ml(Go.EndTag, e, r.endTagStart);
		return (o && ul(o, t) || s && ul(s, t)) && (o && a.push({
			kind: co.Read,
			range: o
		}), s && a.push({
			kind: co.Read,
			range: s
		})), a;
	}
	function dl(e, t) {
		return e.line < t.line || e.line === t.line && e.character <= t.character;
	}
	function ul(e, t) {
		return dl(e.start, t) && dl(t, e.end);
	}
	function ml(e, t, n) {
		const i = bs(t.getText(), n);
		let r = i.scan();
		for (; r !== Go.EOS && r !== e;) r = i.scan();
		return r !== Go.EOS ? {
			start: t.positionAt(i.getTokenOffset()),
			end: t.positionAt(i.getTokenEnd())
		} : null;
	}
	function pl(e, t) {
		const n = [], i = gl(e, t);
		for (const a of i) r(a, void 0);
		return n;
		function r(t, i) {
			const a = po.create(t.name, t.kind, t.range, e.uri, i?.name);
			if (a.containerName ?? (a.containerName = ""), n.push(a), t.children) for (const e of t.children) r(e, t);
		}
	}
	function gl(e, t) {
		const n = [];
		return t.roots.forEach((t) => {
			fl(e, t, n);
		}), n;
	}
	function fl(e, t, n) {
		const i = function(e) {
			let t = e.tag;
			if (e.attributes) {
				const n = e.attributes.id, i = e.attributes.class;
				n && (t += `#${n.replace(/[\"\']/g, "")}`), i && (t += i.replace(/[\"\']/g, "").split(/\s+/).map((e) => `.${e}`).join(""));
			}
			return t || "?";
		}(t), r = Ta.create(e.positionAt(t.start), e.positionAt(t.end)), a = fo.create(i, void 0, uo.Field, r, r);
		n.push(a), t.children.forEach((t) => {
			a.children ?? (a.children = []), fl(e, t, a.children);
		});
	}
	function bl(e, t, n, i) {
		const r = e.offsetAt(t), a = i.findNodeAt(r);
		if (!a.tag) return null;
		if (!function(e, t, n) {
			if (e.endTagStart && e.endTagStart + 2 <= t && t <= e.endTagStart + 2 + n.length) return !0;
			return e.start + 1 <= t && t <= e.start + 1 + n.length;
		}(a, r, a.tag)) return null;
		const o = [], s = {
			start: e.positionAt(a.start + 1),
			end: e.positionAt(a.start + 1 + a.tag.length)
		};
		if (o.push({
			range: s,
			newText: n
		}), a.endTagStart) {
			const t = {
				start: e.positionAt(a.endTagStart + 2),
				end: e.positionAt(a.endTagStart + 2 + a.tag.length)
			};
			o.push({
				range: t,
				newText: n
			});
		}
		return { changes: { [e.uri.toString()]: o } };
	}
	function _l(e, t, n) {
		const i = e.offsetAt(t), r = n.findNodeAt(i);
		if (!r.tag) return null;
		if (!r.endTagStart) return null;
		if (r.start + 1 <= i && i <= r.start + 1 + r.tag.length) {
			const t = i - 1 - r.start + r.endTagStart + 2;
			return e.positionAt(t);
		}
		if (r.endTagStart + 2 <= i && i <= r.endTagStart + 2 + r.tag.length) {
			const t = i - 2 - r.endTagStart + r.start + 1;
			return e.positionAt(t);
		}
		return null;
	}
	function wl(e, t, n) {
		const i = e.offsetAt(t), r = n.findNodeAt(i), a = r.tag ? r.tag.length : 0;
		return r.endTagStart && (r.start + 1 <= i && i <= r.start + 1 + a || r.endTagStart + 2 <= i && i <= r.endTagStart + 2 + a) ? [Ta.create(e.positionAt(r.start + 1), e.positionAt(r.start + 1 + a)), Ta.create(e.positionAt(r.endTagStart + 2), e.positionAt(r.endTagStart + 2 + a))] : null;
	}
	var vl = class {
		constructor(e) {
			this.dataManager = e;
		}
		limitRanges(e, t) {
			let n;
			e = e.sort((e, t) => {
				let n = e.startLine - t.startLine;
				return 0 === n && (n = e.endLine - t.endLine), n;
			});
			const i = [], r = [], a = [], o = (e, t) => {
				r[e] = t, t < 30 && (a[t] = (a[t] || 0) + 1);
			};
			for (let h = 0; h < e.length; h++) {
				const t = e[h];
				if (n) {
					if (t.startLine > n.startLine) {
						if (t.endLine <= n.endLine) i.push(n), n = t, o(h, i.length);
						else if (t.startLine > n.endLine) {
							do
								n = i.pop();
							while (n && t.startLine > n.endLine);
							n && i.push(n), n = t, o(h, i.length);
						}
					}
				} else n = t, o(h, 0);
			}
			let s = 0, l = 0;
			for (let h = 0; h < a.length; h++) {
				const e = a[h];
				if (e) {
					if (e + s > t) {
						l = h;
						break;
					}
					s += e;
				}
			}
			const c = [];
			for (let h = 0; h < e.length; h++) {
				const n = r[h];
				"number" == typeof n && (n < l || n === l && s++ < t) && c.push(e[h]);
			}
			return c;
		}
		getFoldingRanges(e, t) {
			const n = this.dataManager.getVoidElements(e.languageId), i = bs(e.getText());
			let r = i.scan();
			const a = [], o = [];
			let s = null, l = -1;
			function c(e) {
				a.push(e), l = e.startLine;
			}
			for (; r !== Go.EOS;) {
				switch (r) {
					case Go.StartTag: {
						const t = i.getTokenText(), n = e.positionAt(i.getTokenOffset()).line;
						o.push({
							startLine: n,
							tagName: t
						}), s = t;
						break;
					}
					case Go.EndTag:
						s = i.getTokenText();
						break;
					case Go.StartTagClose: if (!s || !this.dataManager.isVoidElement(s, n)) break;
					case Go.EndTagClose:
					case Go.StartTagSelfClose: {
						let t = o.length - 1;
						for (; t >= 0 && o[t].tagName !== s;) t--;
						if (t >= 0) {
							const n = o[t];
							o.length = t;
							const r = e.positionAt(i.getTokenOffset()).line, a = n.startLine, s = r - 1;
							s > a && l !== a && c({
								startLine: a,
								endLine: s
							});
						}
						break;
					}
					case Go.Comment: {
						let t = e.positionAt(i.getTokenOffset()).line;
						const n = i.getTokenText().match(/^\s*#(region\b)|(endregion\b)/);
						if (n) if (n[1]) o.push({
							startLine: t,
							tagName: ""
						});
						else {
							let e = o.length - 1;
							for (; e >= 0 && o[e].tagName.length;) e--;
							if (e >= 0) {
								const n = o[e];
								o.length = e;
								const i = t;
								t = n.startLine, i > t && l !== t && c({
									startLine: t,
									endLine: i,
									kind: Ea.Region
								});
							}
						}
						else {
							const n = e.positionAt(i.getTokenOffset() + i.getTokenLength()).line;
							t < n && c({
								startLine: t,
								endLine: n,
								kind: Ea.Comment
							});
						}
						break;
					}
				}
				r = i.scan();
			}
			const h = t && t.rangeLimit || Number.MAX_VALUE;
			return a.length > h ? this.limitRanges(a, h) : a;
		}
	}, yl = class {
		constructor(e) {
			this.htmlParser = e;
		}
		getSelectionRanges(e, t) {
			const n = this.htmlParser.parseDocument(e);
			return t.map((t) => this.getSelectionRange(t, e, n));
		}
		getSelectionRange(e, t, n) {
			const i = this.getApplicableRanges(t, e, n);
			let r, a;
			for (let o = i.length - 1; o >= 0; o--) {
				const e = i[o];
				r && e[0] === r[0] && e[1] === r[1] || (a = So.create(Ta.create(t.positionAt(i[o][0]), t.positionAt(i[o][1])), a)), r = e;
			}
			return a || (a = So.create(Ta.create(e, e))), a;
		}
		getApplicableRanges(e, t, n) {
			const i = e.offsetAt(t), r = n.findNodeAt(i);
			let a = this.getAllParentTagRanges(r);
			if (r.startTagEnd && !r.endTagStart) {
				if (r.startTagEnd !== r.end) return [[r.start, r.end]];
				const t = Ta.create(e.positionAt(r.startTagEnd - 2), e.positionAt(r.startTagEnd));
				return "/>" === e.getText(t) ? a.unshift([r.start + 1, r.startTagEnd - 2]) : a.unshift([r.start + 1, r.startTagEnd - 1]), a = this.getAttributeLevelRanges(e, r, i).concat(a), a;
			}
			return r.startTagEnd && r.endTagStart ? (a.unshift([r.start, r.end]), r.start < i && i < r.startTagEnd ? (a.unshift([r.start + 1, r.startTagEnd - 1]), a = this.getAttributeLevelRanges(e, r, i).concat(a), a) : r.startTagEnd <= i && i <= r.endTagStart ? (a.unshift([r.startTagEnd, r.endTagStart]), a) : (i >= r.endTagStart + 2 && a.unshift([r.endTagStart + 2, r.end - 1]), a)) : a;
		}
		getAllParentTagRanges(e) {
			let t = e;
			const n = [];
			for (; t.parent;) t = t.parent, this.getNodeRanges(t).forEach((e) => n.push(e));
			return n;
		}
		getNodeRanges(e) {
			return e.startTagEnd && e.endTagStart && e.startTagEnd < e.endTagStart ? [[e.startTagEnd, e.endTagStart], [e.start, e.end]] : [[e.start, e.end]];
		}
		getAttributeLevelRanges(e, t, n) {
			const i = Ta.create(e.positionAt(t.start), e.positionAt(t.end)), r = e.getText(i), a = n - t.start, o = bs(r);
			let s = o.scan();
			const l = t.start, c = [];
			let h = !1, d = -1;
			for (; s !== Go.EOS;) {
				switch (s) {
					case Go.AttributeName:
						if (a < o.getTokenOffset()) {
							h = !1;
							break;
						}
						a <= o.getTokenEnd() && c.unshift([o.getTokenOffset(), o.getTokenEnd()]), h = !0, d = o.getTokenOffset();
						break;
					case Go.AttributeValue: {
						if (!h) break;
						const e = o.getTokenText();
						if (a < o.getTokenOffset()) {
							c.push([d, o.getTokenEnd()]);
							break;
						}
						a >= o.getTokenOffset() && a <= o.getTokenEnd() && (c.unshift([o.getTokenOffset(), o.getTokenEnd()]), ("\"" === e[0] && "\"" === e[e.length - 1] || "'" === e[0] && "'" === e[e.length - 1]) && a >= o.getTokenOffset() + 1 && a <= o.getTokenEnd() - 1 && c.unshift([o.getTokenOffset() + 1, o.getTokenEnd() - 1]), c.push([d, o.getTokenEnd()]));
						break;
					}
				}
				s = o.scan();
			}
			return c.map((e) => [e[0] + l, e[1] + l]);
		}
	};
	const Tl = {
		version: 1.1,
		tags: [
			{
				name: "html",
				description: {
					kind: "markdown",
					value: "The html element represents the root of an HTML document."
				},
				attributes: [
					{
						name: "manifest",
						description: {
							kind: "markdown",
							value: "Specifies the URI of a resource manifest indicating resources that should be cached locally. See [Using the application cache](https://developer.mozilla.org/en-US/docs/Web/HTML/Using_the_application_cache) for details."
						}
					},
					{
						name: "version",
						description: "Specifies the version of the HTML [Document Type Definition](https://developer.mozilla.org/en-US/docs/Glossary/DTD \"Document Type Definition: In HTML, the doctype is the required \"<!DOCTYPE html>\" preamble found at the top of all documents. Its sole purpose is to prevent a browser from switching into so-called “quirks mode” when rendering a document; that is, the \"<!DOCTYPE html>\" doctype ensures that the browser makes a best-effort attempt at following the relevant specifications, rather than using a different rendering mode that is incompatible with some specifications.\") that governs the current document. This attribute is not needed, because it is redundant with the version information in the document type declaration."
					},
					{
						name: "xmlns",
						description: "Specifies the XML Namespace of the document. Default value is `\"http://www.w3.org/1999/xhtml\"`. This is required in documents parsed with XML parsers, and optional in text/html documents."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/html"
				}]
			},
			{
				name: "head",
				description: {
					kind: "markdown",
					value: "The head element represents a collection of metadata for the Document."
				},
				attributes: [{
					name: "profile",
					description: "The URIs of one or more metadata profiles, separated by white space."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/head"
				}]
			},
			{
				name: "title",
				description: {
					kind: "markdown",
					value: "The title element represents the document's title or name. Authors should use titles that identify their documents even when they are used out of context, for example in a user's history or bookmarks, or in search results. The document's title is often different from its first heading, since the first heading does not have to stand alone when taken out of context."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/title"
				}]
			},
			{
				name: "base",
				description: {
					kind: "markdown",
					value: "The base element allows authors to specify the document base URL for the purposes of resolving relative URLs, and the name of the default browsing context for the purposes of following hyperlinks. The element does not represent any content beyond this information."
				},
				void: !0,
				attributes: [{
					name: "href",
					description: {
						kind: "markdown",
						value: "The base URL to be used throughout the document for relative URL addresses. If this attribute is specified, this element must come before any other elements with attributes whose values are URLs. Absolute and relative URLs are allowed."
					}
				}, {
					name: "target",
					valueSet: "target",
					description: {
						kind: "markdown",
						value: "A name or keyword indicating the default location to display the result when hyperlinks or forms cause navigation, for elements that do not have an explicit target reference. It is a name of, or keyword for, a _browsing context_ (for example: tab, window, or inline frame). The following keywords have special meanings:\n\n*   `_self`: Load the result into the same browsing context as the current one. This value is the default if the attribute is not specified.\n*   `_blank`: Load the result into a new unnamed browsing context.\n*   `_parent`: Load the result into the parent browsing context of the current one. If there is no parent, this option behaves the same way as `_self`.\n*   `_top`: Load the result into the top-level browsing context (that is, the browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this option behaves the same way as `_self`.\n\nIf this attribute is specified, this element must come before any other elements with attributes whose values are URLs."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/base"
				}]
			},
			{
				name: "link",
				description: {
					kind: "markdown",
					value: "The link element allows authors to link their document to other resources."
				},
				void: !0,
				attributes: [
					{
						name: "href",
						description: {
							kind: "markdown",
							value: "This attribute specifies the [URL](https://developer.mozilla.org/en-US/docs/Glossary/URL \"URL: Uniform Resource Locator (URL) is a text string specifying where a resource can be found on the Internet.\") of the linked resource. A URL can be absolute or relative."
						}
					},
					{
						name: "crossorigin",
						valueSet: "xo",
						description: {
							kind: "markdown",
							value: "This enumerated attribute indicates whether [CORS](https://developer.mozilla.org/en-US/docs/Glossary/CORS \"CORS: CORS (Cross-Origin Resource Sharing) is a system, consisting of transmitting HTTP headers, that determines whether browsers block frontend JavaScript code from accessing responses for cross-origin requests.\") must be used when fetching the resource. [CORS-enabled images](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_Enabled_Image) can be reused in the [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas \"Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.\") element without being _tainted_. The allowed values are:\n\n`anonymous`\n\nA cross-origin request (i.e. with an [`Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin \"The Origin request header indicates where a fetch originates from. It doesn't include any path information, but only the server name. It is sent with CORS requests, as well as with POST requests. It is similar to the Referer header, but, unlike this header, it doesn't disclose the whole path.\") HTTP header) is performed, but no credential is sent (i.e. no cookie, X.509 certificate, or HTTP Basic authentication). If the server does not give credentials to the origin site (by not setting the [`Access-Control-Allow-Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin \"The Access-Control-Allow-Origin response header indicates whether the response can be shared with requesting code from the given origin.\") HTTP header) the image will be tainted and its usage restricted.\n\n`use-credentials`\n\nA cross-origin request (i.e. with an `Origin` HTTP header) is performed along with a credential sent (i.e. a cookie, certificate, and/or HTTP Basic authentication is performed). If the server does not give credentials to the origin site (through [`Access-Control-Allow-Credentials`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Credentials \"The Access-Control-Allow-Credentials response header tells browsers whether to expose the response to frontend JavaScript code when the request's credentials mode (Request.credentials) is \"include\".\") HTTP header), the resource will be _tainted_ and its usage restricted.\n\nIf the attribute is not present, the resource is fetched without a [CORS](https://developer.mozilla.org/en-US/docs/Glossary/CORS \"CORS: CORS (Cross-Origin Resource Sharing) is a system, consisting of transmitting HTTP headers, that determines whether browsers block frontend JavaScript code from accessing responses for cross-origin requests.\") request (i.e. without sending the `Origin` HTTP header), preventing its non-tainted usage. If invalid, it is handled as if the enumerated keyword **anonymous** was used. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_settings_attributes) for additional information."
						}
					},
					{
						name: "rel",
						description: {
							kind: "markdown",
							value: "This attribute names a relationship of the linked document to the current document. The attribute must be a space-separated list of the [link types values](https://developer.mozilla.org/en-US/docs/Web/HTML/Link_types)."
						}
					},
					{
						name: "media",
						description: {
							kind: "markdown",
							value: "This attribute specifies the media that the linked resource applies to. Its value must be a media type / [media query](https://developer.mozilla.org/en-US/docs/Web/CSS/Media_queries). This attribute is mainly useful when linking to external stylesheets — it allows the user agent to pick the best adapted one for the device it runs on.\n\n**Notes:**\n\n*   In HTML 4, this can only be a simple white-space-separated list of media description literals, i.e., [media types and groups](https://developer.mozilla.org/en-US/docs/Web/CSS/@media), where defined and allowed as values for this attribute, such as `print`, `screen`, `aural`, `braille`. HTML5 extended this to any kind of [media queries](https://developer.mozilla.org/en-US/docs/Web/CSS/Media_queries), which are a superset of the allowed values of HTML 4.\n*   Browsers not supporting [CSS3 Media Queries](https://developer.mozilla.org/en-US/docs/Web/CSS/Media_queries) won't necessarily recognize the adequate link; do not forget to set fallback links, the restricted set of media queries defined in HTML 4."
						}
					},
					{
						name: "hreflang",
						description: {
							kind: "markdown",
							value: "This attribute indicates the language of the linked resource. It is purely advisory. Allowed values are determined by [BCP47](https://www.ietf.org/rfc/bcp/bcp47.txt). Use this attribute only if the [`href`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a#attr-href) attribute is present."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "This attribute is used to define the type of the content linked to. The value of the attribute should be a MIME type such as **text/html**, **text/css**, and so on. The common use of this attribute is to define the type of stylesheet being referenced (such as **text/css**), but given that CSS is the only stylesheet language used on the web, not only is it possible to omit the `type` attribute, but is actually now recommended practice. It is also used on `rel=\"preload\"` link types, to make sure the browser only downloads file types that it supports."
						}
					},
					{
						name: "sizes",
						description: {
							kind: "markdown",
							value: "This attribute defines the sizes of the icons for visual media contained in the resource. It must be present only if the [`rel`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/link#attr-rel) contains a value of `icon` or a non-standard type such as Apple's `apple-touch-icon`. It may have the following values:\n\n*   `any`, meaning that the icon can be scaled to any size as it is in a vector format, like `image/svg+xml`.\n*   a white-space separated list of sizes, each in the format `_<width in pixels>_x_<height in pixels>_` or `_<width in pixels>_X_<height in pixels>_`. Each of these sizes must be contained in the resource.\n\n**Note:** Most icon formats are only able to store one single icon; therefore most of the time the [`sizes`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-sizes) contains only one entry. MS's ICO format does, as well as Apple's ICNS. ICO is more ubiquitous; you should definitely use it."
						}
					},
					{
						name: "as",
						description: "This attribute is only used when `rel=\"preload\"` or `rel=\"prefetch\"` has been set on the `<link>` element. It specifies the type of content being loaded by the `<link>`, which is necessary for content prioritization, request matching, application of correct [content security policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP), and setting of correct [`Accept`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Accept \"The Accept request HTTP header advertises which content types, expressed as MIME types, the client is able to understand. Using content negotiation, the server then selects one of the proposals, uses it and informs the client of its choice with the Content-Type response header. Browsers set adequate values for this header depending on\xA0the context where the request is done: when fetching a CSS stylesheet a different value is set for the request than when fetching an image,\xA0video or a script.\") request header."
					},
					{
						name: "importance",
						description: "Indicates the relative importance of the resource. Priority hints are delegated using the values:"
					},
					{
						name: "importance",
						description: "**`auto`**: Indicates\xA0**no\xA0preference**. The browser may use its own heuristics to decide the priority of the resource.\n\n**`high`**: Indicates to the\xA0browser\xA0that the resource is of\xA0**high** priority.\n\n**`low`**:\xA0Indicates to the\xA0browser\xA0that the resource is of\xA0**low** priority.\n\n**Note:** The `importance` attribute may only be used for the `<link>` element if `rel=\"preload\"` or `rel=\"prefetch\"` is present."
					},
					{
						name: "integrity",
						description: "Contains inline metadata — a base64-encoded cryptographic hash of the resource (file) you’re telling the browser to fetch. The browser can use this to verify that the fetched resource has been delivered free of unexpected manipulation. See [Subresource Integrity](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity)."
					},
					{
						name: "referrerpolicy",
						description: "A string indicating which referrer to use when fetching the resource:\n\n*   `no-referrer` means that the [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent.\n*   `no-referrer-when-downgrade` means that no [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will be sent when navigating to an origin without TLS (HTTPS). This is a user agent’s default behavior, if no policy is otherwise specified.\n*   `origin` means that the referrer will be the origin of the page, which is roughly the scheme, the host, and the port.\n*   `origin-when-cross-origin` means that navigating to other origins will be limited to the scheme, the host, and the port, while navigating on the same origin will include the referrer's path.\n*   `unsafe-url` means that the referrer will include the origin and the path (but not the fragment, password, or username). This case is unsafe because it can leak origins and paths from TLS-protected resources to insecure origins."
					},
					{
						name: "title",
						description: "The `title` attribute has special semantics on the `<link>` element. When used on a `<link rel=\"stylesheet\">` it defines a [preferred or an alternate stylesheet](https://developer.mozilla.org/en-US/docs/Web/CSS/Alternative_style_sheets). Incorrectly using it may [cause the stylesheet to be ignored](https://developer.mozilla.org/en-US/docs/Correctly_Using_Titles_With_External_Stylesheets)."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/link"
				}]
			},
			{
				name: "meta",
				description: {
					kind: "markdown",
					value: "The meta element represents various kinds of metadata that cannot be expressed using the title, base, link, style, and script elements."
				},
				void: !0,
				attributes: [
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "This attribute defines the name of a piece of document-level metadata. It should not be set if one of the attributes [`itemprop`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-itemprop), [`http-equiv`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-http-equiv) or [`charset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-charset) is also set.\n\nThis metadata name is associated with the value contained by the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) attribute. The possible values for the name attribute are:\n\n*   `application-name` which defines the name of the application running in the web page.\n    \n    **Note:**\n    \n    *   Browsers may use this to identify the application. It is different from the [`<title>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/title \"The HTML Title element (<title>) defines the document's title that is shown in a browser's title bar or a page's tab.\") element, which usually contain the application name, but may also contain information like the document name or a status.\n    *   Simple web pages shouldn't define an application-name.\n    \n*   `author` which defines the name of the document's author.\n*   `description` which contains a short and accurate summary of the content of the page. Several browsers, like Firefox and Opera, use this as the default description of bookmarked pages.\n*   `generator` which contains the identifier of the software that generated the page.\n*   `keywords` which contains words relevant to the page's content separated by commas.\n*   `referrer` which controls the [`Referer` HTTP header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer) attached to requests sent from the document:\n    \n    Values for the `content` attribute of `<meta name=\"referrer\">`\n    \n    `no-referrer`\n    \n    Do not send a HTTP `Referrer` header.\n    \n    `origin`\n    \n    Send the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) of the document.\n    \n    `no-referrer-when-downgrade`\n    \n    Send the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) as a referrer to URLs as secure as the current page, (https→https), but does not send a referrer to less secure URLs (https→http). This is the default behaviour.\n    \n    `origin-when-cross-origin`\n    \n    Send the full URL (stripped of parameters) for same-origin requests, but only send the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) for other cases.\n    \n    `same-origin`\n    \n    A referrer will be sent for [same-site origins](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy), but cross-origin requests will contain no referrer information.\n    \n    `strict-origin`\n    \n    Only send the origin of the document as the referrer to a-priori as-much-secure destination (HTTPS->HTTPS), but don't send it to a less secure destination (HTTPS->HTTP).\n    \n    `strict-origin-when-cross-origin`\n    \n    Send a full URL when performing a same-origin request, only send the origin of the document to a-priori as-much-secure destination (HTTPS->HTTPS), and send no header to a less secure destination (HTTPS->HTTP).\n    \n    `unsafe-URL`\n    \n    Send the full URL (stripped of parameters) for same-origin or cross-origin requests.\n    \n    **Notes:**\n    \n    *   Some browsers support the deprecated values of `always`, `default`, and `never` for referrer.\n    *   Dynamically inserting `<meta name=\"referrer\">` (with [`document.write`](https://developer.mozilla.org/en-US/docs/Web/API/Document/write) or [`appendChild`](https://developer.mozilla.org/en-US/docs/Web/API/Node/appendChild)) makes the referrer behaviour unpredictable.\n    *   When several conflicting policies are defined, the no-referrer policy is applied.\n    \n\nThis attribute may also have a value taken from the extended list defined on [WHATWG Wiki MetaExtensions page](https://wiki.whatwg.org/wiki/MetaExtensions). Although none have been formally accepted yet, a few commonly used names are:\n\n*   `creator` which defines the name of the creator of the document, such as an organization or institution. If there are more than one, several [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta \"The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.\") elements should be used.\n*   `googlebot`, a synonym of `robots`, is only followed by Googlebot (the indexing crawler for Google).\n*   `publisher` which defines the name of the document's publisher.\n*   `robots` which defines the behaviour that cooperative crawlers, or \"robots\", should use with the page. It is a comma-separated list of the values below:\n    \n    Values for the content of `<meta name=\"robots\">`\n    \n    Value\n    \n    Description\n    \n    Used by\n    \n    `index`\n    \n    Allows the robot to index the page (default).\n    \n    All\n    \n    `noindex`\n    \n    Requests the robot to not index the page.\n    \n    All\n    \n    `follow`\n    \n    Allows the robot to follow the links on the page (default).\n    \n    All\n    \n    `nofollow`\n    \n    Requests the robot to not follow the links on the page.\n    \n    All\n    \n    `none`\n    \n    Equivalent to `noindex, nofollow`\n    \n    [Google](https://support.google.com/webmasters/answer/79812)\n    \n    `noodp`\n    \n    Prevents using the [Open Directory Project](https://www.dmoz.org/) description, if any, as the page description in search engine results.\n    \n    [Google](https://support.google.com/webmasters/answer/35624#nodmoz), [Yahoo](https://help.yahoo.com/kb/search-for-desktop/meta-tags-robotstxt-yahoo-search-sln2213.html#cont5), [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)\n    \n    `noarchive`\n    \n    Requests the search engine not to cache the page content.\n    \n    [Google](https://developers.google.com/webmasters/control-crawl-index/docs/robots_meta_tag#valid-indexing--serving-directives), [Yahoo](https://help.yahoo.com/kb/search-for-desktop/SLN2213.html), [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)\n    \n    `nosnippet`\n    \n    Prevents displaying any description of the page in search engine results.\n    \n    [Google](https://developers.google.com/webmasters/control-crawl-index/docs/robots_meta_tag#valid-indexing--serving-directives), [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)\n    \n    `noimageindex`\n    \n    Requests this page not to appear as the referring page of an indexed image.\n    \n    [Google](https://developers.google.com/webmasters/control-crawl-index/docs/robots_meta_tag#valid-indexing--serving-directives)\n    \n    `nocache`\n    \n    Synonym of `noarchive`.\n    \n    [Bing](https://www.bing.com/webmaster/help/which-robots-metatags-does-bing-support-5198d240)\n    \n    **Notes:**\n    \n    *   Only cooperative robots follow these rules. Do not expect to prevent e-mail harvesters with them.\n    *   The robot still needs to access the page in order to read these rules. To prevent bandwidth consumption, use a _[robots.txt](https://developer.mozilla.org/en-US/docs/Glossary/robots.txt \"robots.txt: Robots.txt is a file which is usually placed in the root of any website. It decides whether\xA0crawlers are permitted or forbidden access to the web site.\")_ file.\n    *   If you want to remove a page, `noindex` will work, but only after the robot visits the page again. Ensure that the `robots.txt` file is not preventing revisits.\n    *   Some values are mutually exclusive, like `index` and `noindex`, or `follow` and `nofollow`. In these cases the robot's behaviour is undefined and may vary between them.\n    *   Some crawler robots, like Google, Yahoo and Bing, support the same values for the HTTP header `X-Robots-Tag`; this allows non-HTML documents like images to use these rules.\n    \n*   `slurp`, is a synonym of `robots`, but only for Slurp - the crawler for Yahoo Search.\n*   `viewport`, which gives hints about the size of the initial size of the [viewport](https://developer.mozilla.org/en-US/docs/Glossary/viewport \"viewport: A viewport represents a polygonal (normally rectangular) area in computer graphics that is currently being viewed. In web browser terms, it refers to the part of the document you're viewing which is currently visible in its window (or the screen, if the document is being viewed in full screen mode). Content outside the viewport is not visible onscreen until scrolled into view.\"). Used by mobile devices only.\n    \n    Values for the content of `<meta name=\"viewport\">`\n    \n    Value\n    \n    Possible subvalues\n    \n    Description\n    \n    `width`\n    \n    A positive integer number, or the text `device-width`\n    \n    Defines the pixel width of the viewport that you want the web site to be rendered at.\n    \n    `height`\n    \n    A positive integer, or the text `device-height`\n    \n    Defines the height of the viewport. Not used by any browser.\n    \n    `initial-scale`\n    \n    A positive number between `0.0` and `10.0`\n    \n    Defines the ratio between the device width (`device-width` in portrait mode or `device-height` in landscape mode) and the viewport size.\n    \n    `maximum-scale`\n    \n    A positive number between `0.0` and `10.0`\n    \n    Defines the maximum amount to zoom in. It must be greater or equal to the `minimum-scale` or the behaviour is undefined. Browser settings can ignore this rule and iOS10+ ignores it by default.\n    \n    `minimum-scale`\n    \n    A positive number between `0.0` and `10.0`\n    \n    Defines the minimum zoom level. It must be smaller or equal to the `maximum-scale` or the behaviour is undefined. Browser settings can ignore this rule and iOS10+ ignores it by default.\n    \n    `user-scalable`\n    \n    `yes` or `no`\n    \n    If set to `no`, the user is not able to zoom in the webpage. The default is `yes`. Browser settings can ignore this rule, and iOS10+ ignores it by default.\n    \n    Specification\n    \n    Status\n    \n    Comment\n    \n    [CSS Device Adaptation  \n    The definition of '<meta name=\"viewport\">' in that specification.](https://drafts.csswg.org/css-device-adapt/#viewport-meta)\n    \n    Working Draft\n    \n    Non-normatively describes the Viewport META element\n    \n    See also: [`@viewport`](https://developer.mozilla.org/en-US/docs/Web/CSS/@viewport \"The @viewport CSS at-rule lets you configure the viewport through which the document is viewed. It's primarily used for mobile devices, but is also used by desktop browsers that support features like \"snap to edge\" (such as Microsoft Edge).\")\n    \n    **Notes:**\n    \n    *   Though unstandardized, this declaration is respected by most mobile browsers due to de-facto dominance.\n    *   The default values may vary between devices and browsers.\n    *   To learn about this declaration in Firefox for Mobile, see [this article](https://developer.mozilla.org/en-US/docs/Mobile/Viewport_meta_tag \"Mobile/Viewport meta tag\")."
						}
					},
					{
						name: "http-equiv",
						description: {
							kind: "markdown",
							value: "Defines a pragma directive. The attribute is named `**http-equiv**(alent)` because all the allowed values are names of particular HTTP headers:\n\n*   `\"content-language\"`  \n    Defines the default language of the page. It can be overridden by the [lang](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/lang) attribute on any element.\n    \n    **Warning:** Do not use this value, as it is obsolete. Prefer the `lang` attribute on the [`<html>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/html \"The HTML <html> element represents the root (top-level element) of an HTML document, so it is also referred to as the root element. All other elements must be descendants of this element.\") element.\n    \n*   `\"content-security-policy\"`  \n    Allows page authors to define a [content policy](https://developer.mozilla.org/en-US/docs/Web/Security/CSP/CSP_policy_directives) for the current page. Content policies mostly specify allowed server origins and script endpoints which help guard against cross-site scripting attacks.\n*   `\"content-type\"`  \n    Defines the [MIME type](https://developer.mozilla.org/en-US/docs/Glossary/MIME_type) of the document, followed by its character encoding. It follows the same syntax as the HTTP `content-type` entity-header field, but as it is inside a HTML page, most values other than `text/html` are impossible. Therefore the valid syntax for its `content` is the string '`text/html`' followed by a character set with the following syntax: '`; charset=_IANAcharset_`', where `IANAcharset` is the _preferred MIME name_ for a character set as [defined by the IANA.](https://www.iana.org/assignments/character-sets)\n    \n    **Warning:** Do not use this value, as it is obsolete. Use the [`charset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-charset) attribute on the [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta \"The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.\") element.\n    \n    **Note:** As [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta \"The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.\") can't change documents' types in XHTML or HTML5's XHTML serialization, never set the MIME type to an XHTML MIME type with `<meta>`.\n    \n*   `\"refresh\"`  \n    This instruction specifies:\n    *   The number of seconds until the page should be reloaded - only if the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) attribute contains a positive integer.\n    *   The number of seconds until the page should redirect to another - only if the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) attribute contains a positive integer followed by the string '`;url=`', and a valid URL.\n*   `\"set-cookie\"`  \n    Defines a [cookie](https://developer.mozilla.org/en-US/docs/cookie) for the page. Its content must follow the syntax defined in the [IETF HTTP Cookie Specification](https://tools.ietf.org/html/draft-ietf-httpstate-cookie-14).\n    \n    **Warning:** Do not use this instruction, as it is obsolete. Use the HTTP header [`Set-Cookie`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Set-Cookie) instead."
						}
					},
					{
						name: "content",
						description: {
							kind: "markdown",
							value: "This attribute contains the value for the [`http-equiv`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-http-equiv) or [`name`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-name) attribute, depending on which is used."
						}
					},
					{
						name: "charset",
						description: {
							kind: "markdown",
							value: "This attribute declares the page's character encoding. It must contain a [standard IANA MIME name for character encodings](https://www.iana.org/assignments/character-sets). Although the standard doesn't request a specific encoding, it suggests:\n\n*   Authors are encouraged to use [`UTF-8`](https://developer.mozilla.org/en-US/docs/Glossary/UTF-8).\n*   Authors should not use ASCII-incompatible encodings to avoid security risk: browsers not supporting them may interpret harmful content as HTML. This happens with the `JIS_C6226-1983`, `JIS_X0212-1990`, `HZ-GB-2312`, `JOHAB`, the ISO-2022 family and the EBCDIC family.\n\n**Note:** ASCII-incompatible encodings are those that don't map the 8-bit code points `0x20` to `0x7E` to the `0x0020` to `0x007E` Unicode code points)\n\n*   Authors **must not** use `CESU-8`, `UTF-7`, `BOCU-1` and/or `SCSU` as [cross-site scripting](https://developer.mozilla.org/en-US/docs/Glossary/Cross-site_scripting) attacks with these encodings have been demonstrated.\n*   Authors should not use `UTF-32` because not all HTML5 encoding algorithms can distinguish it from `UTF-16`.\n\n**Notes:**\n\n*   The declared character encoding must match the one the page was saved with to avoid garbled characters and security holes.\n*   The [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta \"The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.\") element declaring the encoding must be inside the [`<head>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/head \"The HTML <head> element provides general information (metadata) about the document, including its title and links to its\xA0scripts and style sheets.\") element and **within the first 1024 bytes** of the HTML as some browsers only look at those bytes before choosing an encoding.\n*   This [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta \"The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.\") element is only one part of the [algorithm to determine a page's character set](https://www.whatwg.org/specs/web-apps/current-work/multipage/parsing.html#encoding-sniffing-algorithm \"Algorithm charset page\"). The [`Content-Type` header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Type) and any [Byte-Order Marks](https://developer.mozilla.org/en-US/docs/Glossary/Byte-Order_Mark \"The definition of that term (Byte-Order Marks) has not been written yet; please consider contributing it!\") override this element.\n*   It is strongly recommended to define the character encoding. If a page's encoding is undefined, cross-scripting techniques are possible, such as the [`UTF-7` fallback cross-scripting technique](https://code.google.com/p/doctype-mirror/wiki/ArticleUtf7).\n*   The [`<meta>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta \"The HTML <meta> element represents metadata that cannot be represented by other HTML meta-related elements, like <base>, <link>, <script>, <style> or <title>.\") element with a `charset` attribute is a synonym for the pre-HTML5 `<meta http-equiv=\"Content-Type\" content=\"text/html; charset=_IANAcharset_\">`, where _`IANAcharset`_ contains the value of the equivalent [`charset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-charset) attribute. This syntax is still allowed, although no longer recommended."
						}
					},
					{
						name: "scheme",
						description: "This attribute defines the scheme in which metadata is described. A scheme is a context leading to the correct interpretations of the [`content`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/meta#attr-content) value, like a format.\n\n**Warning:** Do not use this value, as it is obsolete. There is no replacement as there was no real usage for it."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/meta"
				}]
			},
			{
				name: "style",
				description: {
					kind: "markdown",
					value: "The style element allows authors to embed style information in their documents. The style element is one of several inputs to the styling processing model. The element does not represent content for the user."
				},
				attributes: [
					{
						name: "media",
						description: {
							kind: "markdown",
							value: "This attribute defines which media the style should be applied to. Its value is a [media query](https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Media_queries), which defaults to `all` if the attribute is missing."
						}
					},
					{
						name: "nonce",
						description: {
							kind: "markdown",
							value: "A cryptographic nonce (number used once) used to whitelist inline styles in a [style-src Content-Security-Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy/style-src). The server must generate a unique nonce value each time it transmits a policy. It is critical to provide a nonce that cannot be guessed as bypassing a resource’s policy is otherwise trivial."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "This attribute defines the styling language as a MIME type (charset should not be specified). This attribute is optional and defaults to `text/css` if it is not specified — there is very little reason to include this in modern web documents."
						}
					},
					{
						name: "scoped",
						valueSet: "v"
					},
					{
						name: "title",
						description: "This attribute specifies [alternative style sheet](https://developer.mozilla.org/en-US/docs/Web/CSS/Alternative_style_sheets) sets."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/style"
				}]
			},
			{
				name: "body",
				description: {
					kind: "markdown",
					value: "The body element represents the content of the document."
				},
				attributes: [
					{
						name: "onafterprint",
						description: {
							kind: "markdown",
							value: "Function to call after the user has printed the document."
						}
					},
					{
						name: "onbeforeprint",
						description: {
							kind: "markdown",
							value: "Function to call when the user requests printing of the document."
						}
					},
					{
						name: "onbeforeunload",
						description: {
							kind: "markdown",
							value: "Function to call when the document is about to be unloaded."
						}
					},
					{
						name: "onhashchange",
						description: {
							kind: "markdown",
							value: "Function to call when the fragment identifier part (starting with the hash (`'#'`) character) of the document's current address has changed."
						}
					},
					{
						name: "onlanguagechange",
						description: {
							kind: "markdown",
							value: "Function to call when the preferred languages changed."
						}
					},
					{
						name: "onmessage",
						description: {
							kind: "markdown",
							value: "Function to call when the document has received a message."
						}
					},
					{
						name: "onoffline",
						description: {
							kind: "markdown",
							value: "Function to call when network communication has failed."
						}
					},
					{
						name: "ononline",
						description: {
							kind: "markdown",
							value: "Function to call when network communication has been restored."
						}
					},
					{ name: "onpagehide" },
					{ name: "onpageshow" },
					{
						name: "onpopstate",
						description: {
							kind: "markdown",
							value: "Function to call when the user has navigated session history."
						}
					},
					{
						name: "onstorage",
						description: {
							kind: "markdown",
							value: "Function to call when the storage area has changed."
						}
					},
					{
						name: "onunload",
						description: {
							kind: "markdown",
							value: "Function to call when the document is going away."
						}
					},
					{
						name: "alink",
						description: "Color of text for hyperlinks when selected. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color \"The color CSS property sets the foreground color value of an element's text and text decorations, and sets the currentcolor value.\") property in conjunction with the [`:active`](https://developer.mozilla.org/en-US/docs/Web/CSS/:active \"The :active CSS pseudo-class represents an element (such as a button) that is being activated by the user.\") pseudo-class instead._"
					},
					{
						name: "background",
						description: "URI of a image to use as a background. _This method is non-conforming, use CSS [`background`](https://developer.mozilla.org/en-US/docs/Web/CSS/background \"The background shorthand CSS property sets all background style properties at once, such as color, image, origin and size, or repeat method.\") property on the element instead._"
					},
					{
						name: "bgcolor",
						description: "Background color for the document. _This method is non-conforming, use CSS [`background-color`](https://developer.mozilla.org/en-US/docs/Web/CSS/background-color \"The background-color CSS property sets the background color of an element.\") property on the element instead._"
					},
					{
						name: "bottommargin",
						description: "The margin of the bottom of the body. _This method is non-conforming, use CSS [`margin-bottom`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-bottom \"The margin-bottom CSS property sets the margin area on the bottom of an element. A positive value places it farther from its neighbors, while a negative value places it closer.\") property on the element instead._"
					},
					{
						name: "leftmargin",
						description: "The margin of the left of the body. _This method is non-conforming, use CSS [`margin-left`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-left \"The margin-left CSS property sets the margin area on the left side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.\") property on the element instead._"
					},
					{
						name: "link",
						description: "Color of text for unvisited hypertext links. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color \"The color CSS property sets the foreground color value of an element's text and text decorations, and sets the currentcolor value.\") property in conjunction with the [`:link`](https://developer.mozilla.org/en-US/docs/Web/CSS/:link \"The :link CSS pseudo-class represents an element that has not yet been visited. It matches every unvisited <a>, <area>, or <link> element that has an href attribute.\") pseudo-class instead._"
					},
					{
						name: "onblur",
						description: "Function to call when the document loses focus."
					},
					{
						name: "onerror",
						description: "Function to call when the document fails to load properly."
					},
					{
						name: "onfocus",
						description: "Function to call when the document receives focus."
					},
					{
						name: "onload",
						description: "Function to call when the document has finished loading."
					},
					{
						name: "onredo",
						description: "Function to call when the user has moved forward in undo transaction history."
					},
					{
						name: "onresize",
						description: "Function to call when the document has been resized."
					},
					{
						name: "onundo",
						description: "Function to call when the user has moved backward in undo transaction history."
					},
					{
						name: "rightmargin",
						description: "The margin of the right of the body. _This method is non-conforming, use CSS [`margin-right`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-right \"The margin-right CSS property sets the margin area on the right side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.\") property on the element instead._"
					},
					{
						name: "text",
						description: "Foreground color of text. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color \"The color CSS property sets the foreground color value of an element's text and text decorations, and sets the currentcolor value.\") property on the element instead._"
					},
					{
						name: "topmargin",
						description: "The margin of the top of the body. _This method is non-conforming, use CSS [`margin-top`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-top \"The margin-top CSS property sets the margin area on the top of an element. A positive value places it farther from its neighbors, while a negative value places it closer.\") property on the element instead._"
					},
					{
						name: "vlink",
						description: "Color of text for visited hypertext links. _This method is non-conforming, use CSS [`color`](https://developer.mozilla.org/en-US/docs/Web/CSS/color \"The color CSS property sets the foreground color value of an element's text and text decorations, and sets the currentcolor value.\") property in conjunction with the [`:visited`](https://developer.mozilla.org/en-US/docs/Web/CSS/:visited \"The :visited CSS pseudo-class represents links that the user has already visited. For privacy reasons, the styles that can be modified using this selector are very limited.\") pseudo-class instead._"
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/body"
				}]
			},
			{
				name: "article",
				description: {
					kind: "markdown",
					value: "The article element represents a complete, or self-contained, composition in a document, page, application, or site and that is, in principle, independently distributable or reusable, e.g. in syndication. This could be a forum post, a magazine or newspaper article, a blog entry, a user-submitted comment, an interactive widget or gadget, or any other independent item of content. Each article should be identified, typically by including a heading (h1–h6 element) as a child of the article element."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/article"
				}]
			},
			{
				name: "section",
				description: {
					kind: "markdown",
					value: "The section element represents a generic section of a document or application. A section, in this context, is a thematic grouping of content. Each section should be identified, typically by including a heading ( h1- h6 element) as a child of the section element."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/section"
				}]
			},
			{
				name: "nav",
				description: {
					kind: "markdown",
					value: "The nav element represents a section of a page that links to other pages or to parts within the page: a section with navigation links."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/nav"
				}]
			},
			{
				name: "aside",
				description: {
					kind: "markdown",
					value: "The aside element represents a section of a page that consists of content that is tangentially related to the content around the aside element, and which could be considered separate from that content. Such sections are often represented as sidebars in printed typography."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/aside"
				}]
			},
			{
				name: "h1",
				description: {
					kind: "markdown",
					value: "The h1 element represents a section heading."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
				}]
			},
			{
				name: "h2",
				description: {
					kind: "markdown",
					value: "The h2 element represents a section heading."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
				}]
			},
			{
				name: "h3",
				description: {
					kind: "markdown",
					value: "The h3 element represents a section heading."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
				}]
			},
			{
				name: "h4",
				description: {
					kind: "markdown",
					value: "The h4 element represents a section heading."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
				}]
			},
			{
				name: "h5",
				description: {
					kind: "markdown",
					value: "The h5 element represents a section heading."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
				}]
			},
			{
				name: "h6",
				description: {
					kind: "markdown",
					value: "The h6 element represents a section heading."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/Heading_Elements"
				}]
			},
			{
				name: "header",
				description: {
					kind: "markdown",
					value: "The header element represents introductory content for its nearest ancestor sectioning content or sectioning root element. A header typically contains a group of introductory or navigational aids. When the nearest ancestor sectioning content or sectioning root element is the body element, then it applies to the whole page."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/header"
				}]
			},
			{
				name: "footer",
				description: {
					kind: "markdown",
					value: "The footer element represents a footer for its nearest ancestor sectioning content or sectioning root element. A footer typically contains information about its section such as who wrote it, links to related documents, copyright data, and the like."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/footer"
				}]
			},
			{
				name: "address",
				description: {
					kind: "markdown",
					value: "The address element represents the contact information for its nearest article or body element ancestor. If that is the body element, then the contact information applies to the document as a whole."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/address"
				}]
			},
			{
				name: "p",
				description: {
					kind: "markdown",
					value: "The p element represents a paragraph."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/p"
				}]
			},
			{
				name: "hr",
				description: {
					kind: "markdown",
					value: "The hr element represents a paragraph-level thematic break, e.g. a scene change in a story, or a transition to another topic within a section of a reference book."
				},
				void: !0,
				attributes: [
					{
						name: "align",
						description: "Sets the alignment of the rule on the page. If no value is specified, the default value is `left`."
					},
					{
						name: "color",
						description: "Sets the color of the rule through color name or hexadecimal value."
					},
					{
						name: "noshade",
						description: "Sets the rule to have no shading."
					},
					{
						name: "size",
						description: "Sets the height, in pixels, of the rule."
					},
					{
						name: "width",
						description: "Sets the length of the rule on the page through a pixel or percentage value."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/hr"
				}]
			},
			{
				name: "pre",
				description: {
					kind: "markdown",
					value: "The pre element represents a block of preformatted text, in which structure is represented by typographic conventions rather than by elements."
				},
				attributes: [
					{
						name: "cols",
						description: "Contains the _preferred_ count of characters that a line should have. It was a non-standard synonym of [`width`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/pre#attr-width). To achieve such an effect, use CSS [`width`](https://developer.mozilla.org/en-US/docs/Web/CSS/width \"The width CSS property sets an element's width. By default it sets the width of the content area, but if box-sizing is set to border-box, it sets the width of the border area.\") instead."
					},
					{
						name: "width",
						description: "Contains the _preferred_ count of characters that a line should have. Though technically still implemented, this attribute has no visual effect; to achieve such an effect, use CSS [`width`](https://developer.mozilla.org/en-US/docs/Web/CSS/width \"The width CSS property sets an element's width. By default it sets the width of the content area, but if box-sizing is set to border-box, it sets the width of the border area.\") instead."
					},
					{
						name: "wrap",
						description: "Is a _hint_ indicating how the overflow must happen. In modern browser this hint is ignored and no visual effect results in its present; to achieve such an effect, use CSS [`white-space`](https://developer.mozilla.org/en-US/docs/Web/CSS/white-space \"The white-space CSS property sets how white space inside an element is handled.\") instead."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/pre"
				}]
			},
			{
				name: "blockquote",
				description: {
					kind: "markdown",
					value: "The blockquote element represents content that is quoted from another source, optionally with a citation which must be within a footer or cite element, and optionally with in-line changes such as annotations and abbreviations."
				},
				attributes: [{
					name: "cite",
					description: {
						kind: "markdown",
						value: "A URL that designates a source document or message for the information quoted. This attribute is intended to point to information explaining the context or the reference for the quote."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/blockquote"
				}]
			},
			{
				name: "ol",
				description: {
					kind: "markdown",
					value: "The ol element represents a list of items, where the items have been intentionally ordered, such that changing the order would change the meaning of the document."
				},
				attributes: [
					{
						name: "reversed",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute specifies that the items of the list are specified in reversed order."
						}
					},
					{
						name: "start",
						description: {
							kind: "markdown",
							value: "This integer attribute specifies the start value for numbering the individual list items. Although the ordering type of list elements might be Roman numerals, such as XXXI, or letters, the value of start is always represented as a number. To start numbering elements from the letter \"C\", use `<ol start=\"3\">`.\n\n**Note**: This attribute was deprecated in HTML4, but reintroduced in HTML5."
						}
					},
					{
						name: "type",
						valueSet: "lt",
						description: {
							kind: "markdown",
							value: "Indicates the numbering type:\n\n*   `'a'` indicates lowercase letters,\n*   `'A'` indicates uppercase letters,\n*   `'i'` indicates lowercase Roman numerals,\n*   `'I'` indicates uppercase Roman numerals,\n*   and `'1'` indicates numbers (default).\n\nThe type set is used for the entire list unless a different [`type`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/li#attr-type) attribute is used within an enclosed [`<li>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/li \"The HTML <li> element is used to represent an item in a list. It must be contained in a parent element: an ordered list (<ol>), an unordered list (<ul>), or a menu (<menu>). In menus and unordered lists, list items are usually displayed using bullet points. In ordered lists, they are usually displayed with an ascending counter on the left, such as a number or letter.\") element.\n\n**Note:** This attribute was deprecated in HTML4, but reintroduced in HTML5.\n\nUnless the value of the list number matters (e.g. in legal or technical documents where items are to be referenced by their number/letter), the CSS [`list-style-type`](https://developer.mozilla.org/en-US/docs/Web/CSS/list-style-type \"The list-style-type CSS property sets the marker (such as a disc, character, or custom counter style) of a list item element.\") property should be used instead."
						}
					},
					{
						name: "compact",
						description: "This Boolean attribute hints that the list should be rendered in a compact style. The interpretation of this attribute depends on the user agent and it doesn't work in all browsers.\n\n**Warning:** Do not use this attribute, as it has been deprecated: the [`<ol>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ol \"The HTML <ol> element represents an ordered list of items, typically rendered as a numbered list.\") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). To give an effect similar to the `compact` attribute, the [CSS](https://developer.mozilla.org/en-US/docs/CSS) property [`line-height`](https://developer.mozilla.org/en-US/docs/Web/CSS/line-height \"The line-height CSS property sets the amount of space used for lines, such as in text. On block-level elements, it specifies the minimum height of line boxes within the element. On non-replaced inline elements, it specifies the height that is used to calculate line box height.\") can be used with a value of `80%`."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/ol"
				}]
			},
			{
				name: "ul",
				description: {
					kind: "markdown",
					value: "The ul element represents a list of items, where the order of the items is not important — that is, where changing the order would not materially change the meaning of the document."
				},
				attributes: [{
					name: "compact",
					description: "This Boolean attribute hints that the list should be rendered in a compact style. The interpretation of this attribute depends on the user agent and it doesn't work in all browsers.\n\n**Usage note:\xA0**Do not use this attribute, as it has been deprecated: the [`<ul>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ul \"The HTML <ul> element represents an unordered list of items, typically rendered as a bulleted list.\") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). To give a similar effect as the `compact` attribute, the [CSS](https://developer.mozilla.org/en-US/docs/CSS) property [line-height](https://developer.mozilla.org/en-US/docs/CSS/line-height) can be used with a value of `80%`."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/ul"
				}]
			},
			{
				name: "li",
				description: {
					kind: "markdown",
					value: "The li element represents a list item. If its parent element is an ol, ul, or menu element, then the element is an item of the parent element's list, as defined for those elements. Otherwise, the list item has no defined list-related relationship to any other li element."
				},
				attributes: [{
					name: "value",
					description: {
						kind: "markdown",
						value: "This integer attribute indicates the current ordinal value of the list item as defined by the [`<ol>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ol \"The HTML <ol> element represents an ordered list of items, typically rendered as a numbered list.\") element. The only allowed value for this attribute is a number, even if the list is displayed with Roman numerals or letters. List items that follow this one continue numbering from the value set. The **value** attribute has no meaning for unordered lists ([`<ul>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ul \"The HTML <ul> element represents an unordered list of items, typically rendered as a bulleted list.\")) or for menus ([`<menu>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/menu \"The HTML <menu> element represents a group of commands that a user can perform or activate. This includes both list menus, which might appear across the top of a screen, as well as context menus, such as those that might appear underneath a button after it has been clicked.\")).\n\n**Note**: This attribute was deprecated in HTML4, but reintroduced in HTML5.\n\n**Note:** Prior to Gecko\xA09.0, negative values were incorrectly converted to 0. Starting in Gecko\xA09.0 all integer values are correctly parsed."
					}
				}, {
					name: "type",
					description: "This character attribute indicates the numbering type:\n\n*   `a`: lowercase letters\n*   `A`: uppercase letters\n*   `i`: lowercase Roman numerals\n*   `I`: uppercase Roman numerals\n*   `1`: numbers\n\nThis type overrides the one used by its parent [`<ol>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/ol \"The HTML <ol> element represents an ordered list of items, typically rendered as a numbered list.\") element, if any.\n\n**Usage note:** This attribute has been deprecated: use the CSS [`list-style-type`](https://developer.mozilla.org/en-US/docs/Web/CSS/list-style-type \"The list-style-type CSS property sets the marker (such as a disc, character, or custom counter style) of a list item element.\") property instead."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/li"
				}]
			},
			{
				name: "dl",
				description: {
					kind: "markdown",
					value: "The dl element represents an association list consisting of zero or more name-value groups (a description list). A name-value group consists of one or more names (dt elements) followed by one or more values (dd elements), ignoring any nodes other than dt and dd elements. Within a single dl element, there should not be more than one dt element for each name."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/dl"
				}]
			},
			{
				name: "dt",
				description: {
					kind: "markdown",
					value: "The dt element represents the term, or name, part of a term-description group in a description list (dl element)."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/dt"
				}]
			},
			{
				name: "dd",
				description: {
					kind: "markdown",
					value: "The dd element represents the description, definition, or value, part of a term-description group in a description list (dl element)."
				},
				attributes: [{
					name: "nowrap",
					description: "If the value of this attribute is set to `yes`, the definition text will not wrap. The default value is `no`."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/dd"
				}]
			},
			{
				name: "figure",
				description: {
					kind: "markdown",
					value: "The figure element represents some flow content, optionally with a caption, that is self-contained (like a complete sentence) and is typically referenced as a single unit from the main flow of the document."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/figure"
				}]
			},
			{
				name: "figcaption",
				description: {
					kind: "markdown",
					value: "The figcaption element represents a caption or legend for the rest of the contents of the figcaption element's parent figure element, if any."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/figcaption"
				}]
			},
			{
				name: "main",
				description: {
					kind: "markdown",
					value: "The main element represents the main content of the body of a document or application. The main content area consists of content that is directly related to or expands upon the central topic of a document or central functionality of an application."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/main"
				}]
			},
			{
				name: "div",
				description: {
					kind: "markdown",
					value: "The div element has no special meaning at all. It represents its children. It can be used with the class, lang, and title attributes to mark up semantics common to a group of consecutive elements."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/div"
				}]
			},
			{
				name: "a",
				description: {
					kind: "markdown",
					value: "If the a element has an href attribute, then it represents a hyperlink (a hypertext anchor) labeled by its contents."
				},
				attributes: [
					{
						name: "href",
						description: {
							kind: "markdown",
							value: "Contains a URL or a URL fragment that the hyperlink points to.\nA URL fragment is a name preceded by a hash mark (`#`), which specifies an internal target location (an [`id`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-id) of an HTML element) within the current document. URLs are not restricted to Web (HTTP)-based documents, but can use any protocol supported by the browser. For example, [`file:`](https://en.wikipedia.org/wiki/File_URI_scheme), `ftp:`, and `mailto:` work in most browsers.\n\n**Note:** You can use `href=\"#top\"` or the empty fragment `href=\"#\"` to link to the top of the current page. [This behavior is specified by HTML5](https://www.w3.org/TR/html5/single-page.html#scroll-to-fragid)."
						}
					},
					{
						name: "target",
						valueSet: "target",
						description: {
							kind: "markdown",
							value: "Specifies where to display the linked URL. It is a name of, or keyword for, a _browsing context_: a tab, window, or `<iframe>`. The following keywords have special meanings:\n\n*   `_self`: Load the URL into the same browsing context as the current one. This is the default behavior.\n*   `_blank`: Load the URL into a new browsing context. This is usually a tab, but users can configure browsers to use new windows instead.\n*   `_parent`: Load the URL into the parent browsing context of the current one. If there is no parent, this behaves the same way as `_self`.\n*   `_top`: Load the URL into the top-level browsing context (that is, the \"highest\" browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this behaves the same way as `_self`.\n\n**Note:** When using `target`, consider adding `rel=\"noreferrer\"` to avoid exploitation of the `window.opener` API.\n\n**Note:** Linking to another page using `target=\"_blank\"` will run the new page on the same process as your page. If the new page is executing expensive JS, your page's performance may suffer. To avoid this use `rel=\"noopener\"`."
						}
					},
					{
						name: "download",
						description: {
							kind: "markdown",
							value: "This attribute instructs browsers to download a URL instead of navigating to it, so the user will be prompted to save it as a local file. If the attribute has a value, it is used as the pre-filled file name in the Save prompt (the user can still change the file name if they want). There are no restrictions on allowed values, though `/` and `\\` are converted to underscores. Most file systems limit some punctuation in file names, and browsers will adjust the suggested name accordingly.\n\n**Notes:**\n\n*   This attribute only works for [same-origin URLs](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy).\n*   Although HTTP(s) URLs need to be in the same-origin, [`blob:` URLs](https://developer.mozilla.org/en-US/docs/Web/API/URL.createObjectURL) and [`data:` URLs](https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs) are allowed so that content generated by JavaScript, such as pictures created in an image-editor Web app, can be downloaded.\n*   If the HTTP header [`Content-Disposition:`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Disposition) gives a different filename than this attribute, the HTTP header takes priority over this attribute.\n*   If `Content-Disposition:` is set to `inline`, Firefox prioritizes `Content-Disposition`, like the filename case, while Chrome prioritizes the `download` attribute."
						}
					},
					{
						name: "ping",
						description: {
							kind: "markdown",
							value: "Contains a space-separated list of URLs to which, when the hyperlink is followed, [`POST`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/POST \"The HTTP POST method sends data to the server. The type of the body of the request is indicated by the Content-Type header.\") requests with the body `PING` will be sent by the browser (in the background). Typically used for tracking."
						}
					},
					{
						name: "rel",
						description: {
							kind: "markdown",
							value: "Specifies the relationship of the target object to the link object. The value is a space-separated list of [link types](https://developer.mozilla.org/en-US/docs/Web/HTML/Link_types)."
						}
					},
					{
						name: "hreflang",
						description: {
							kind: "markdown",
							value: "This attribute indicates the human language of the linked resource. It is purely advisory, with no built-in functionality. Allowed values are determined by [BCP47](https://www.ietf.org/rfc/bcp/bcp47.txt \"Tags for Identifying Languages\")."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "Specifies the media type in the form of a [MIME type](https://developer.mozilla.org/en-US/docs/Glossary/MIME_type \"MIME type: A\xA0MIME type\xA0(now properly called \"media type\", but\xA0also sometimes \"content type\") is a string sent along\xA0with a file indicating the type of the file (describing the content format, for example, a sound file might be labeled\xA0audio/ogg, or an image file\xA0image/png).\") for the linked URL. It is purely advisory, with no built-in functionality."
						}
					},
					{
						name: "referrerpolicy",
						description: "Indicates which [referrer](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer) to send when fetching the URL:\n\n*   `'no-referrer'` means the `Referer:` header will not be sent.\n*   `'no-referrer-when-downgrade'` means no `Referer:` header will be sent when navigating to an origin without HTTPS. This is the default behavior.\n*   `'origin'` means the referrer will be the [origin](https://developer.mozilla.org/en-US/docs/Glossary/Origin) of the page, not including information after the domain.\n*   `'origin-when-cross-origin'` meaning that navigations to other origins will be limited to the scheme, the host and the port, while navigations on the same origin will include the referrer's path.\n*   `'strict-origin-when-cross-origin'`\n*   `'unsafe-url'` means the referrer will include the origin and path, but not the fragment, password, or username. This is unsafe because it can leak data from secure URLs to insecure ones."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/a"
				}]
			},
			{
				name: "em",
				description: {
					kind: "markdown",
					value: "The em element represents stress emphasis of its contents."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/em"
				}]
			},
			{
				name: "strong",
				description: {
					kind: "markdown",
					value: "The strong element represents strong importance, seriousness, or urgency for its contents."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/strong"
				}]
			},
			{
				name: "small",
				description: {
					kind: "markdown",
					value: "The small element represents side comments such as small print."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/small"
				}]
			},
			{
				name: "s",
				description: {
					kind: "markdown",
					value: "The s element represents contents that are no longer accurate or no longer relevant."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/s"
				}]
			},
			{
				name: "cite",
				description: {
					kind: "markdown",
					value: "The cite element represents a reference to a creative work. It must include the title of the work or the name of the author(person, people or organization) or an URL reference, or a reference in abbreviated form as per the conventions used for the addition of citation metadata."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/cite"
				}]
			},
			{
				name: "q",
				description: {
					kind: "markdown",
					value: "The q element represents some phrasing content quoted from another source."
				},
				attributes: [{
					name: "cite",
					description: {
						kind: "markdown",
						value: "The value of this attribute is a URL that designates a source document or message for the information quoted. This attribute is intended to point to information explaining the context or the reference for the quote."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/q"
				}]
			},
			{
				name: "dfn",
				description: {
					kind: "markdown",
					value: "The dfn element represents the defining instance of a term. The paragraph, description list group, or section that is the nearest ancestor of the dfn element must also contain the definition(s) for the term given by the dfn element."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/dfn"
				}]
			},
			{
				name: "abbr",
				description: {
					kind: "markdown",
					value: "The abbr element represents an abbreviation or acronym, optionally with its expansion. The title attribute may be used to provide an expansion of the abbreviation. The attribute, if specified, must contain an expansion of the abbreviation, and nothing else."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/abbr"
				}]
			},
			{
				name: "ruby",
				description: {
					kind: "markdown",
					value: "The ruby element allows one or more spans of phrasing content to be marked with ruby annotations. Ruby annotations are short runs of text presented alongside base text, primarily used in East Asian typography as a guide for pronunciation or to include other annotations. In Japanese, this form of typography is also known as furigana. Ruby text can appear on either side, and sometimes both sides, of the base text, and it is possible to control its position using CSS. A more complete introduction to ruby can be found in the Use Cases & Exploratory Approaches for Ruby Markup document as well as in CSS Ruby Module Level 1. [RUBY-UC] [CSSRUBY]"
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/ruby"
				}]
			},
			{
				name: "rb",
				description: {
					kind: "markdown",
					value: "The rb element marks the base text component of a ruby annotation. When it is the child of a ruby element, it doesn't represent anything itself, but its parent ruby element uses it as part of determining what it represents."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/rb"
				}]
			},
			{
				name: "rt",
				description: {
					kind: "markdown",
					value: "The rt element marks the ruby text component of a ruby annotation. When it is the child of a ruby element or of an rtc element that is itself the child of a ruby element, it doesn't represent anything itself, but its ancestor ruby element uses it as part of determining what it represents."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/rt"
				}]
			},
			{
				name: "rp",
				description: {
					kind: "markdown",
					value: "The rp element is used to provide fallback text to be shown by user agents that don't support ruby annotations. One widespread convention is to provide parentheses around the ruby text component of a ruby annotation."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/rp"
				}]
			},
			{
				name: "time",
				description: {
					kind: "markdown",
					value: "The time element represents its contents, along with a machine-readable form of those contents in the datetime attribute. The kind of content is limited to various kinds of dates, times, time-zone offsets, and durations, as described below."
				},
				attributes: [{
					name: "datetime",
					description: {
						kind: "markdown",
						value: "This attribute indicates the time and/or date of the element and must be in one of the formats described below."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/time"
				}]
			},
			{
				name: "code",
				description: {
					kind: "markdown",
					value: "The code element represents a fragment of computer code. This could be an XML element name, a file name, a computer program, or any other string that a computer would recognize."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/code"
				}]
			},
			{
				name: "var",
				description: {
					kind: "markdown",
					value: "The var element represents a variable. This could be an actual variable in a mathematical expression or programming context, an identifier representing a constant, a symbol identifying a physical quantity, a function parameter, or just be a term used as a placeholder in prose."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/var"
				}]
			},
			{
				name: "samp",
				description: {
					kind: "markdown",
					value: "The samp element represents sample or quoted output from another program or computing system."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/samp"
				}]
			},
			{
				name: "kbd",
				description: {
					kind: "markdown",
					value: "The kbd element represents user input (typically keyboard input, although it may also be used to represent other input, such as voice commands)."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/kbd"
				}]
			},
			{
				name: "sub",
				description: {
					kind: "markdown",
					value: "The sub element represents a subscript."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/sub"
				}]
			},
			{
				name: "sup",
				description: {
					kind: "markdown",
					value: "The sup element represents a superscript."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/sup"
				}]
			},
			{
				name: "i",
				description: {
					kind: "markdown",
					value: "The i element represents a span of text in an alternate voice or mood, or otherwise offset from the normal prose in a manner indicating a different quality of text, such as a taxonomic designation, a technical term, an idiomatic phrase from another language, transliteration, a thought, or a ship name in Western texts."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/i"
				}]
			},
			{
				name: "b",
				description: {
					kind: "markdown",
					value: "The b element represents a span of text to which attention is being drawn for utilitarian purposes without conveying any extra importance and with no implication of an alternate voice or mood, such as key words in a document abstract, product names in a review, actionable words in interactive text-driven software, or an article lede."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/b"
				}]
			},
			{
				name: "u",
				description: {
					kind: "markdown",
					value: "The u element represents a span of text with an unarticulated, though explicitly rendered, non-textual annotation, such as labeling the text as being a proper name in Chinese text (a Chinese proper name mark), or labeling the text as being misspelt."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/u"
				}]
			},
			{
				name: "mark",
				description: {
					kind: "markdown",
					value: "The mark element represents a run of text in one document marked or highlighted for reference purposes, due to its relevance in another context. When used in a quotation or other block of text referred to from the prose, it indicates a highlight that was not originally present but which has been added to bring the reader's attention to a part of the text that might not have been considered important by the original author when the block was originally written, but which is now under previously unexpected scrutiny. When used in the main prose of a document, it indicates a part of the document that has been highlighted due to its likely relevance to the user's current activity."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/mark"
				}]
			},
			{
				name: "bdi",
				description: {
					kind: "markdown",
					value: "The bdi element represents a span of text that is to be isolated from its surroundings for the purposes of bidirectional text formatting. [BIDI]"
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/bdi"
				}]
			},
			{
				name: "bdo",
				description: {
					kind: "markdown",
					value: "The bdo element represents explicit text directionality formatting control for its children. It allows authors to override the Unicode bidirectional algorithm by explicitly specifying a direction override. [BIDI]"
				},
				attributes: [{
					name: "dir",
					description: "The direction in which text should be rendered in this element's contents. Possible values are:\n\n*   `ltr`: Indicates that the text should go in a left-to-right direction.\n*   `rtl`: Indicates that the text should go in a right-to-left direction."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/bdo"
				}]
			},
			{
				name: "span",
				description: {
					kind: "markdown",
					value: "The span element doesn't mean anything on its own, but can be useful when used together with the global attributes, e.g. class, lang, or dir. It represents its children."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/span"
				}]
			},
			{
				name: "br",
				description: {
					kind: "markdown",
					value: "The br element represents a line break."
				},
				void: !0,
				attributes: [{
					name: "clear",
					description: "Indicates where to begin the next line after the break."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/br"
				}]
			},
			{
				name: "wbr",
				description: {
					kind: "markdown",
					value: "The wbr element represents a line break opportunity."
				},
				void: !0,
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/wbr"
				}]
			},
			{
				name: "ins",
				description: {
					kind: "markdown",
					value: "The ins element represents an addition to the document."
				},
				attributes: [{
					name: "cite",
					description: "This attribute defines the URI of a resource that explains the change, such as a link to meeting minutes or a ticket in a troubleshooting system."
				}, {
					name: "datetime",
					description: "This attribute indicates the time and date of the change and must be a valid date with an optional time string. If the value cannot be parsed as a date with an optional time string, the element does not have an associated time stamp. For the format of the string without a time, see [Format of a valid date string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_date_string \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\"). The format of the string if it includes both date and time is covered in [Format of a valid local date and time string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_local_date_and_time_string \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\")."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/ins"
				}]
			},
			{
				name: "del",
				description: {
					kind: "markdown",
					value: "The del element represents a removal from the document."
				},
				attributes: [{
					name: "cite",
					description: {
						kind: "markdown",
						value: "A URI for a resource that explains the change (for example, meeting minutes)."
					}
				}, {
					name: "datetime",
					description: {
						kind: "markdown",
						value: "This attribute indicates the time and date of the change and must be a valid date string with an optional time. If the value cannot be parsed as a date with an optional time string, the element does not have an associated time stamp. For the format of the string without a time, see [Format of a valid date string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_date_string \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\"). The format of the string if it includes both date and time is covered in [Format of a valid local date and time string](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats#Format_of_a_valid_local_date_and_time_string \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\") in [Date and time formats used in HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Date_and_time_formats \"Certain HTML elements use date and/or time values. The formats of the strings that specify these are described in this article.\")."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/del"
				}]
			},
			{
				name: "picture",
				description: {
					kind: "markdown",
					value: "The picture element is a container which provides multiple sources to its contained img element to allow authors to declaratively control or give hints to the user agent about which image resource to use, based on the screen pixel density, viewport size, image format, and other factors. It represents its children."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/picture"
				}]
			},
			{
				name: "img",
				description: {
					kind: "markdown",
					value: "An img element represents an image."
				},
				void: !0,
				attributes: [
					{
						name: "alt",
						description: {
							kind: "markdown",
							value: "This attribute defines an alternative text description of the image.\n\n**Note:** Browsers do not always display the image referenced by the element. This is the case for non-graphical browsers (including those used by people with visual impairments), if the user chooses not to display images, or if the browser cannot display the image because it is invalid or an [unsupported type](#Supported_image_formats). In these cases, the browser may replace the image with the text defined in this element's `alt` attribute. You should, for these reasons and others, provide a useful value for `alt` whenever possible.\n\n**Note:** Omitting this attribute altogether indicates that the image is a key part of the content, and no textual equivalent is available. Setting this attribute to an empty string (`alt=\"\"`) indicates that this image is _not_ a key part of the content (decorative), and that non-visual browsers may omit it from rendering."
						}
					},
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "The image URL. This attribute is mandatory for the `<img>` element. On browsers supporting `srcset`, `src` is treated like a candidate image with a pixel density descriptor `1x` unless an image with this pixel density descriptor is already defined in `srcset,` or unless `srcset` contains '`w`' descriptors."
						}
					},
					{
						name: "srcset",
						description: {
							kind: "markdown",
							value: "A list of one or more strings separated by commas indicating a set of possible image sources for the user agent to use. Each string is composed of:\n\n1.  a URL to an image,\n2.  optionally, whitespace followed by one of:\n    *   A width descriptor, or a positive integer directly followed by '`w`'. The width descriptor is divided by the source size given in the `sizes` attribute to calculate the effective pixel density.\n    *   A pixel density descriptor, which is a positive floating point number directly followed by '`x`'.\n\nIf no descriptor is specified, the source is assigned the default descriptor: `1x`.\n\nIt is incorrect to mix width descriptors and pixel density descriptors in the same `srcset` attribute. Duplicate descriptors (for instance, two sources in the same `srcset` which are both described with '`2x`') are also invalid.\n\nThe user agent selects any one of the available sources at its discretion. This provides them with significant leeway to tailor their selection based on things like user preferences or bandwidth conditions. See our [Responsive images](https://developer.mozilla.org/en-US/docs/Learn/HTML/Multimedia_and_embedding/Responsive_images) tutorial for an example."
						}
					},
					{
						name: "crossorigin",
						valueSet: "xo",
						description: {
							kind: "markdown",
							value: "This enumerated attribute indicates if the fetching of the related image must be done using CORS or not. [CORS-enabled images](https://developer.mozilla.org/en-US/docs/CORS_Enabled_Image) can be reused in the [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas \"Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.\") element without being \"[tainted](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_enabled_image#What_is_a_tainted_canvas).\" The allowed values are:\n`anonymous`\n\nA cross-origin request (i.e., with `Origin:` HTTP header) is performed, but no credential is sent (i.e., no cookie, X.509 certificate, or HTTP Basic authentication). If the server does not give credentials to the origin site (by not setting the [`Access-Control-Allow-Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Access-Control-Allow-Origin \"The Access-Control-Allow-Origin response header indicates whether the response can be shared with requesting code from the given origin.\") HTTP header), the image will be tainted and its usage restricted.\n\n`use-credentials`\n\nA cross-origin request (i.e., with the [`Origin`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Origin \"The Origin request header indicates where a fetch originates from. It doesn't include any path information, but only the server name. It is sent with CORS requests, as well as with POST requests. It is similar to the Referer header, but, unlike this header, it doesn't disclose the whole path.\") HTTP header) performed along with credentials sent (i.e., a cookie, certificate, or HTTP Basic authentication). If the server does not give credentials to the origin site (through the `Access-Control-Allow-Credentials` HTTP header), the image will be tainted and its usage restricted.\n\nIf the attribute is not present, the resource is fetched without a CORS request (i.e., without sending the `Origin` HTTP header), preventing its non-tainted usage in [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas \"Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.\") elements. If invalid, it is handled as if the `anonymous` value was used. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/HTML/CORS_settings_attributes) for additional information."
						}
					},
					{
						name: "usemap",
						description: {
							kind: "markdown",
							value: "The partial URL (starting with '#') of an [image map](https://developer.mozilla.org/en-US/docs/HTML/Element/map) associated with the element.\n\n**Note:** You cannot use this attribute if the `<img>` element is a descendant of an [`<a>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a \"The HTML <a> element (or anchor element) creates a hyperlink to other web pages, files, locations within the same page, email addresses, or any other URL.\") or [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") element."
						}
					},
					{
						name: "ismap",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that the image is part of a server-side map. If so, the precise coordinates of a click are sent to the server.\n\n**Note:** This attribute is allowed only if the `<img>` element is a descendant of an [`<a>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a \"The HTML <a> element (or anchor element) creates a hyperlink to other web pages, files, locations within the same page, email addresses, or any other URL.\") element with a valid [`href`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a#attr-href) attribute."
						}
					},
					{
						name: "width",
						description: {
							kind: "markdown",
							value: "The intrinsic width of the image in pixels."
						}
					},
					{
						name: "height",
						description: {
							kind: "markdown",
							value: "The intrinsic height of the image in pixels."
						}
					},
					{
						name: "decoding",
						valueSet: "decoding",
						description: {
							kind: "markdown",
							value: "Provides an image decoding hint to the browser. The allowed values are:\n`sync`\n\nDecode the image synchronously for atomic presentation with other content.\n\n`async`\n\nDecode the image asynchronously to reduce delay in presenting other content.\n\n`auto`\n\nDefault mode, which indicates no preference for the decoding mode. The browser decides what is best for the user."
						}
					},
					{
						name: "loading",
						valueSet: "loading",
						description: {
							kind: "markdown",
							value: "Indicates how the browser should load the image."
						}
					},
					{
						name: "referrerpolicy",
						valueSet: "referrerpolicy",
						description: {
							kind: "markdown",
							value: "A string indicating which referrer to use when fetching the resource:\n\n*   `no-referrer:` The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent.\n*   `no-referrer-when-downgrade:` No `Referer` header will be sent when navigating to an origin without TLS (HTTPS). This is a user agent’s default behavior if no policy is otherwise specified.\n*   `origin:` The `Referer` header will include the page of origin's scheme, the host, and the port.\n*   `origin-when-cross-origin:` Navigating to other origins will limit the included referral data to the scheme, the host and the port, while navigating from the same origin will include the referrer's full path.\n*   `unsafe-url:` The `Referer` header will include the origin and the path, but not the fragment, password, or username. This case is unsafe because it can leak origins and paths from TLS-protected resources to insecure origins."
						}
					},
					{
						name: "sizes",
						description: {
							kind: "markdown",
							value: "A list of one or more strings separated by commas indicating a set of source sizes. Each source size consists of:\n\n1.  a media condition. This must be omitted for the last item.\n2.  a source size value.\n\nSource size values specify the intended display size of the image. User agents use the current source size to select one of the sources supplied by the `srcset` attribute, when those sources are described using width ('`w`') descriptors. The selected source size affects the intrinsic size of the image (the image’s display size if no CSS styling is applied). If the `srcset` attribute is absent, or contains no values with a width (`w`) descriptor, then the `sizes` attribute has no effect."
						}
					},
					{
						name: "importance",
						description: "Indicates the relative importance of the resource. Priority hints are delegated using the values:"
					},
					{
						name: "importance",
						description: "`auto`: Indicates\xA0**no\xA0preference**. The browser may use its own heuristics to decide the priority of the image.\n\n`high`: Indicates to the\xA0browser\xA0that the image is of\xA0**high** priority.\n\n`low`:\xA0Indicates to the\xA0browser\xA0that the image is of\xA0**low** priority."
					},
					{
						name: "intrinsicsize",
						description: "This attribute tells the browser to ignore the actual intrinsic size of the image and pretend it’s the size specified in the attribute. Specifically, the image would raster at these dimensions and `naturalWidth`/`naturalHeight` on images would return the values specified in this attribute. [Explainer](https://github.com/ojanvafai/intrinsicsize-attribute), [examples](https://googlechrome.github.io/samples/intrinsic-size/index.html)"
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/img"
				}]
			},
			{
				name: "iframe",
				description: {
					kind: "markdown",
					value: "The iframe element represents a nested browsing context."
				},
				attributes: [
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "The URL of the page to embed. Use a value of `about:blank` to embed an empty page that conforms to the [same-origin policy](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy#Inherited_origins). Also note that programatically removing an `<iframe>`'s src attribute (e.g. via [`Element.removeAttribute()`](https://developer.mozilla.org/en-US/docs/Web/API/Element/removeAttribute \"The Element method removeAttribute() removes the attribute with the specified name from the element.\")) causes `about:blank` to be loaded in the frame in Firefox (from version 65), Chromium-based browsers, and Safari/iOS."
						}
					},
					{
						name: "srcdoc",
						description: {
							kind: "markdown",
							value: "Inline HTML to embed, overriding the `src` attribute. If a browser does not support the `srcdoc` attribute, it will fall back to the URL in the `src` attribute."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "A targetable name for the embedded browsing context. This can be used in the `target` attribute of the [`<a>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/a \"The HTML <a> element (or anchor element) creates a hyperlink to other web pages, files, locations within the same page, email addresses, or any other URL.\"), [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\"), or [`<base>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/base \"The HTML <base> element specifies the base URL to use for all relative URLs contained within a document. There can be only one <base> element in a document.\") elements; the `formtarget` attribute of the [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") or [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") elements; or the `windowName` parameter in the [`window.open()`](https://developer.mozilla.org/en-US/docs/Web/API/Window/open \"The\xA0Window interface's open() method loads the specified resource into the browsing context (window, <iframe> or tab) with the specified name. If the name doesn't exist, then a new window is opened and the specified resource is loaded into its browsing context.\") method."
						}
					},
					{
						name: "sandbox",
						valueSet: "sb",
						description: {
							kind: "markdown",
							value: "Applies extra restrictions to the content in the frame. The value of the attribute can either be empty to apply all restrictions, or space-separated tokens to lift particular restrictions:\n\n*   `allow-forms`: Allows the resource to submit forms. If this keyword is not used, form submission is blocked.\n*   `allow-modals`: Lets the resource [open modal windows](https://html.spec.whatwg.org/multipage/origin.html#sandboxed-modals-flag).\n*   `allow-orientation-lock`: Lets the resource [lock the screen orientation](https://developer.mozilla.org/en-US/docs/Web/API/Screen/lockOrientation).\n*   `allow-pointer-lock`: Lets the resource use the [Pointer Lock API](https://developer.mozilla.org/en-US/docs/WebAPI/Pointer_Lock).\n*   `allow-popups`: Allows popups (such as `window.open()`, `target=\"_blank\"`, or `showModalDialog()`). If this keyword is not used, the popup will silently fail to open.\n*   `allow-popups-to-escape-sandbox`: Lets the sandboxed document open new windows without those windows inheriting the sandboxing. For example, this can safely sandbox an advertisement without forcing the same restrictions upon the page the ad links to.\n*   `allow-presentation`: Lets the resource start a [presentation session](https://developer.mozilla.org/en-US/docs/Web/API/PresentationRequest).\n*   `allow-same-origin`: If this token is not used, the resource is treated as being from a special origin that always fails the [same-origin policy](https://developer.mozilla.org/en-US/docs/Glossary/same-origin_policy \"same-origin policy: The same-origin policy is a critical security mechanism that restricts how a document or script loaded from one origin can interact with a resource from another origin.\").\n*   `allow-scripts`: Lets the resource run scripts (but not create popup windows).\n*   `allow-storage-access-by-user-activation` : Lets the resource request access to the parent's storage capabilities with the [Storage Access API](https://developer.mozilla.org/en-US/docs/Web/API/Storage_Access_API).\n*   `allow-top-navigation`: Lets the resource navigate the top-level browsing context (the one named `_top`).\n*   `allow-top-navigation-by-user-activation`: Lets the resource navigate the top-level browsing context, but only if initiated by a user gesture.\n\n**Notes about sandboxing:**\n\n*   When the embedded document has the same origin as the embedding page, it is **strongly discouraged** to use both `allow-scripts` and `allow-same-origin`, as that lets the embedded document remove the `sandbox` attribute — making it no more secure than not using the `sandbox` attribute at all.\n*   Sandboxing is useless if the attacker can display content outside a sandboxed `iframe` — such as if the viewer opens the frame in a new tab. Such content should be also served from a _separate origin_ to limit potential damage.\n*   The `sandbox` attribute is unsupported in Internet Explorer 9 and earlier."
						}
					},
					{
						name: "seamless",
						valueSet: "v"
					},
					{
						name: "allowfullscreen",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "Set to `true` if the `<iframe>` can activate fullscreen mode by calling the [`requestFullscreen()`](https://developer.mozilla.org/en-US/docs/Web/API/Element/requestFullscreen \"The Element.requestFullscreen() method issues an asynchronous request to make the element be displayed in full-screen mode.\") method.\nThis attribute is considered a legacy attribute and redefined as `allow=\"fullscreen\"`."
						}
					},
					{
						name: "width",
						description: {
							kind: "markdown",
							value: "The width of the frame in CSS pixels. Default is `300`."
						}
					},
					{
						name: "height",
						description: {
							kind: "markdown",
							value: "The height of the frame in CSS pixels. Default is `150`."
						}
					},
					{
						name: "allow",
						description: "Specifies a [feature policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Feature_Policy) for the `<iframe>`."
					},
					{
						name: "allowpaymentrequest",
						description: "Set to `true` if a cross-origin `<iframe>` should be allowed to invoke the [Payment Request API](https://developer.mozilla.org/en-US/docs/Web/API/Payment_Request_API)."
					},
					{
						name: "allowpaymentrequest",
						description: "This attribute is considered a legacy attribute and redefined as `allow=\"payment\"`."
					},
					{
						name: "csp",
						description: "A [Content Security Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP) enforced for the embedded resource. See [`HTMLIFrameElement.csp`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLIFrameElement/csp \"The csp property of the HTMLIFrameElement interface specifies the Content Security Policy that an embedded document must agree to enforce upon itself.\") for details."
					},
					{
						name: "importance",
						description: "The download priority of the resource in the `<iframe>`'s `src` attribute. Allowed values:\n\n`auto` (default)\n\nNo preference. The browser uses its own heuristics to decide the priority of the resource.\n\n`high`\n\nThe resource should be downloaded before other lower-priority page resources.\n\n`low`\n\nThe resource should be downloaded after other higher-priority page resources."
					},
					{
						name: "referrerpolicy",
						description: "Indicates which [referrer](https://developer.mozilla.org/en-US/docs/Web/API/Document/referrer) to send when fetching the frame's resource:\n\n*   `no-referrer`: The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent.\n*   `no-referrer-when-downgrade` (default): The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent to [origin](https://developer.mozilla.org/en-US/docs/Glossary/origin \"origin: Web content's origin is defined by the scheme (protocol), host (domain), and port of the URL used to access it. Two objects have the same origin only when the scheme, host, and port all match.\")s without [TLS](https://developer.mozilla.org/en-US/docs/Glossary/TLS \"TLS: Transport Layer Security (TLS), previously known as Secure Sockets Layer (SSL), is a protocol used by applications to communicate securely across a network, preventing tampering with and eavesdropping on email, web browsing, messaging, and other protocols.\") ([HTTPS](https://developer.mozilla.org/en-US/docs/Glossary/HTTPS \"HTTPS: HTTPS (HTTP Secure) is an encrypted version of the HTTP protocol. It usually uses SSL or TLS to encrypt all communication between a client and a server. This secure connection allows clients to safely exchange sensitive data with a server, for example for banking activities or online shopping.\")).\n*   `origin`: The sent referrer will be limited to the origin of the referring page: its [scheme](https://developer.mozilla.org/en-US/docs/Archive/Mozilla/URIScheme), [host](https://developer.mozilla.org/en-US/docs/Glossary/host \"host: A host is a device connected to the Internet (or a local network). Some hosts called servers offer additional services like serving webpages or storing files and emails.\"), and [port](https://developer.mozilla.org/en-US/docs/Glossary/port \"port: For a computer connected to a network with an IP address, a port is a communication endpoint. Ports are designated by numbers, and below 1024 each port is associated by default with a specific protocol.\").\n*   `origin-when-cross-origin`: The referrer sent to other origins will be limited to the scheme, the host, and the port. Navigations on the same origin will still include the path.\n*   `same-origin`: A referrer will be sent for [same origin](https://developer.mozilla.org/en-US/docs/Glossary/Same-origin_policy \"same origin: The same-origin policy is a critical security mechanism that restricts how a document or script loaded from one origin can interact with a resource from another origin.\"), but cross-origin requests will contain no referrer information.\n*   `strict-origin`: Only send the origin of the document as the referrer when the protocol security level stays the same (HTTPS→HTTPS), but don't send it to a less secure destination (HTTPS→HTTP).\n*   `strict-origin-when-cross-origin`: Send a full URL when performing a same-origin request, only send the origin when the protocol security level stays the same (HTTPS→HTTPS), and send no header to a less secure destination (HTTPS→HTTP).\n*   `unsafe-url`: The referrer will include the origin _and_ the path (but not the [fragment](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/hash), [password](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/password), or [username](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/username)). **This value is unsafe**, because it leaks origins and paths from TLS-protected resources to insecure origins."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/iframe"
				}]
			},
			{
				name: "embed",
				description: {
					kind: "markdown",
					value: "The embed element provides an integration point for an external (typically non-HTML) application or interactive content."
				},
				void: !0,
				attributes: [
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "The URL\xA0of the resource being embedded."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "The MIME\xA0type to use to select the plug-in to instantiate."
						}
					},
					{
						name: "width",
						description: {
							kind: "markdown",
							value: "The displayed width of the resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). This must be an absolute value; percentages are _not_ allowed."
						}
					},
					{
						name: "height",
						description: {
							kind: "markdown",
							value: "The displayed height of the resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). This must be an absolute value; percentages are _not_ allowed."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/embed"
				}]
			},
			{
				name: "object",
				description: {
					kind: "markdown",
					value: "The object element can represent an external resource, which, depending on the type of the resource, will either be treated as an image, as a nested browsing context, or as an external resource to be processed by a plugin."
				},
				attributes: [
					{
						name: "data",
						description: {
							kind: "markdown",
							value: "The address of the resource as a valid URL. At least one of **data** and **type** must be defined."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "The [content type](https://developer.mozilla.org/en-US/docs/Glossary/Content_type) of the resource specified by **data**. At least one of **data** and **type** must be defined."
						}
					},
					{
						name: "typemustmatch",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates if the **type** attribute and the actual [content type](https://developer.mozilla.org/en-US/docs/Glossary/Content_type) of the resource must match to be used."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "The name of valid browsing context (HTML5), or the name of the control (HTML 4)."
						}
					},
					{
						name: "usemap",
						description: {
							kind: "markdown",
							value: "A hash-name reference to a [`<map>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/map \"The HTML <map> element is used with <area> elements to define an image map (a clickable link area).\") element; that is a '#' followed by the value of a [`name`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/map#attr-name) of a map element."
						}
					},
					{
						name: "form",
						description: {
							kind: "markdown",
							value: "The form element, if any, that the object element is associated with (its _form owner_). The value of the attribute must be an ID of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element in the same document."
						}
					},
					{
						name: "width",
						description: {
							kind: "markdown",
							value: "The width of the display resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). -- (Absolute values only. [NO percentages](https://html.spec.whatwg.org/multipage/embedded-content.html#dimension-attributes))"
						}
					},
					{
						name: "height",
						description: {
							kind: "markdown",
							value: "The height of the displayed resource, in [CSS pixels](https://drafts.csswg.org/css-values/#px). -- (Absolute values only. [NO percentages](https://html.spec.whatwg.org/multipage/embedded-content.html#dimension-attributes))"
						}
					},
					{
						name: "archive",
						description: "A space-separated list of URIs for archives of resources for the object."
					},
					{
						name: "border",
						description: "The width of a border around the control, in pixels."
					},
					{
						name: "classid",
						description: "The URI of the object's implementation. It can be used together with, or in place of, the **data** attribute."
					},
					{
						name: "codebase",
						description: "The base path used to resolve relative URIs specified by **classid**, **data**, or **archive**. If not specified, the default is the base URI of the current document."
					},
					{
						name: "codetype",
						description: "The content type of the data specified by **classid**."
					},
					{
						name: "declare",
						description: "The presence of this Boolean attribute makes this element a declaration only. The object must be instantiated by a subsequent `<object>` element. In HTML5, repeat the <object> element completely each that that the resource is reused."
					},
					{
						name: "standby",
						description: "A message that the browser can show while loading the object's implementation and data."
					},
					{
						name: "tabindex",
						description: "The position of the element in the tabbing navigation order for the current document."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/object"
				}]
			},
			{
				name: "param",
				description: {
					kind: "markdown",
					value: "The param element defines parameters for plugins invoked by object elements. It does not represent anything on its own."
				},
				void: !0,
				attributes: [
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "Name of the parameter."
						}
					},
					{
						name: "value",
						description: {
							kind: "markdown",
							value: "Specifies the value of the parameter."
						}
					},
					{
						name: "type",
						description: "Only used if the `valuetype` is set to \"ref\". Specifies the MIME type of values found at the URI specified by value."
					},
					{
						name: "valuetype",
						description: "Specifies the type of the `value` attribute. Possible values are:\n\n*   data: Default value. The value is passed to the object's implementation as a string.\n*   ref: The value is a URI to a resource where run-time values are stored.\n*   object: An ID of another [`<object>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/object \"The HTML <object> element represents an external resource, which can be treated as an image, a nested browsing context, or a resource to be handled by a plugin.\") in the same document."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/param"
				}]
			},
			{
				name: "video",
				description: {
					kind: "markdown",
					value: "A video element is used for playing videos or movies, and audio files with captions."
				},
				attributes: [
					{ name: "src" },
					{
						name: "crossorigin",
						valueSet: "xo"
					},
					{ name: "poster" },
					{
						name: "preload",
						valueSet: "pl"
					},
					{
						name: "autoplay",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "A Boolean attribute; if specified, the video automatically begins to play back as soon as it can do so without stopping to finish loading the data.\n**Note**: Sites that automatically play audio (or video with an audio track) can be an unpleasant experience for users, so it should be avoided when possible. If you must offer autoplay functionality, you should make it opt-in (requiring a user to specifically enable it). However, this can be useful when creating media elements whose source will be set at a later time, under user control.\n\nTo disable video autoplay, `autoplay=\"false\"` will not work; the video will autoplay if the attribute is there in the `<video>` tag at all. To remove autoplay the attribute needs to be removed altogether.\n\nIn some browsers (e.g. Chrome 70.0) autoplay is not working if no `muted` attribute is present."
						}
					},
					{ name: "mediagroup" },
					{
						name: "loop",
						valueSet: "v"
					},
					{
						name: "muted",
						valueSet: "v"
					},
					{
						name: "controls",
						valueSet: "v"
					},
					{ name: "width" },
					{ name: "height" }
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/video"
				}]
			},
			{
				name: "audio",
				description: {
					kind: "markdown",
					value: "An audio element represents a sound or audio stream."
				},
				attributes: [
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "The URL of the audio to embed. This is subject to [HTTP access controls](https://developer.mozilla.org/en-US/docs/HTTP_access_control). This is optional; you may instead use the [`<source>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source \"The HTML <source> element specifies multiple media resources for the <picture>, the <audio> element, or the <video> element.\") element within the audio block to specify the audio to embed."
						}
					},
					{
						name: "crossorigin",
						valueSet: "xo",
						description: {
							kind: "markdown",
							value: "This enumerated attribute indicates whether to use CORS to fetch the related image. [CORS-enabled resources](https://developer.mozilla.org/en-US/docs/CORS_Enabled_Image) can be reused in the [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas \"Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.\") element without being _tainted_. The allowed values are:\n\nanonymous\n\nSends a cross-origin request without a credential. In other words, it sends the `Origin:` HTTP header without a cookie, X.509 certificate, or performing HTTP Basic authentication. If the server does not give credentials to the origin site (by not setting the `Access-Control-Allow-Origin:` HTTP header), the image will be _tainted_, and its usage restricted.\n\nuse-credentials\n\nSends a cross-origin request with a credential. In other words, it sends the `Origin:` HTTP header with a cookie, a certificate, or performing HTTP Basic authentication. If the server does not give credentials to the origin site (through `Access-Control-Allow-Credentials:` HTTP header), the image will be _tainted_ and its usage restricted.\n\nWhen not present, the resource is fetched without a CORS request (i.e. without sending the `Origin:` HTTP header), preventing its non-tainted used in [`<canvas>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/canvas \"Use the HTML <canvas> element with either the canvas scripting API or the WebGL API to draw graphics and animations.\") elements. If invalid, it is handled as if the enumerated keyword **anonymous** was used. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/HTML/CORS_settings_attributes) for additional information."
						}
					},
					{
						name: "preload",
						valueSet: "pl",
						description: {
							kind: "markdown",
							value: "This enumerated attribute is intended to provide a hint to the browser about what the author thinks will lead to the best user experience. It may have one of the following values:\n\n*   `none`: Indicates that the audio should not be preloaded.\n*   `metadata`: Indicates that only audio metadata (e.g. length) is fetched.\n*   `auto`: Indicates that the whole audio file can be downloaded, even if the user is not expected to use it.\n*   _empty string_: A synonym of the `auto` value.\n\nIf not set, `preload`'s default value is browser-defined (i.e. each browser may have its own default value). The spec advises it to be set to `metadata`.\n\n**Usage notes:**\n\n*   The `autoplay` attribute has precedence over\xA0`preload`. If `autoplay` is specified, the browser would obviously need to start downloading the audio for playback.\n*   The browser is not forced by the specification to follow the value of this attribute; it is a mere hint."
						}
					},
					{
						name: "autoplay",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "A Boolean attribute:\xA0if specified, the audio will automatically begin playback as soon as it can do so, without waiting for the entire audio file to finish downloading.\n\n**Note**: Sites that automatically play audio (or videos with an audio track) can be an unpleasant experience for users, so should be avoided when possible. If you must offer autoplay functionality, you should make it opt-in (requiring a user to specifically enable it). However, this can be useful when creating media elements whose source will be set at a later time, under user control."
						}
					},
					{ name: "mediagroup" },
					{
						name: "loop",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "A Boolean attribute:\xA0if specified, the audio player will\xA0automatically seek back to the start\xA0upon reaching the end of the audio."
						}
					},
					{
						name: "muted",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "A Boolean attribute that indicates whether the audio will be initially silenced. Its default value is `false`."
						}
					},
					{
						name: "controls",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "If this attribute is present, the browser will offer controls to allow the user to control audio playback, including volume, seeking, and pause/resume playback."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/audio"
				}]
			},
			{
				name: "source",
				description: {
					kind: "markdown",
					value: "The source element allows authors to specify multiple alternative media resources for media elements. It does not represent anything on its own."
				},
				void: !0,
				attributes: [
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "Required for [`<audio>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/audio \"The HTML <audio> element is used to embed sound content in documents. It may contain one or more audio sources, represented using the src attribute or the <source> element:\xA0the browser will choose the most suitable one. It can also be the destination for streamed media, using a MediaStream.\") and [`<video>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video \"The HTML Video element (<video>) embeds a media player which supports video playback into the document.\"), address of the media resource. The value of this attribute is ignored when the `<source>` element is placed inside a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture \"The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.\") element."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "The MIME-type of the resource, optionally with a `codecs` parameter. See [RFC 4281](https://tools.ietf.org/html/rfc4281) for information about how to specify codecs."
						}
					},
					{
						name: "sizes",
						description: "Is a list of source sizes that describes the final rendered width of the image represented by the source. Each source size consists of a comma-separated list of media condition-length pairs. This information is used by the browser to determine, before laying the page out, which image defined in [`srcset`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source#attr-srcset) to use.  \nThe `sizes` attribute has an effect only when the [`<source>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source \"The HTML <source> element specifies multiple media resources for the <picture>, the <audio> element, or the <video> element.\") element is the direct child of a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture \"The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.\") element."
					},
					{
						name: "srcset",
						description: "A list of one or more strings separated by commas indicating a set of possible images represented by the source for the browser to use. Each string is composed of:\n\n1.  one URL to an image,\n2.  a width descriptor, that is a positive integer directly followed by `'w'`. The default value, if missing, is the infinity.\n3.  a pixel density descriptor, that is a positive floating number directly followed by `'x'`. The default value, if missing, is `1x`.\n\nEach string in the list must have at least a width descriptor or a pixel density descriptor to be valid. Among the list, there must be only one string containing the same tuple of width descriptor and pixel density descriptor.  \nThe browser chooses the most adequate image to display at a given point of time.  \nThe `srcset` attribute has an effect only when the [`<source>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/source \"The HTML <source> element specifies multiple media resources for the <picture>, the <audio> element, or the <video> element.\") element is the direct child of a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture \"The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.\") element."
					},
					{
						name: "media",
						description: "[Media query](https://developer.mozilla.org/en-US/docs/CSS/Media_queries) of the resource's intended media; this should be used only in a [`<picture>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/picture \"The HTML <picture> element contains zero or more <source> elements and one <img> element to provide versions of an image for different display/device scenarios.\") element."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/source"
				}]
			},
			{
				name: "track",
				description: {
					kind: "markdown",
					value: "The track element allows authors to specify explicit external timed text tracks for media elements. It does not represent anything on its own."
				},
				void: !0,
				attributes: [
					{
						name: "default",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This attribute indicates that the track should be enabled unless the user's preferences indicate that another track is more appropriate. This may only be used on one `track` element per media element."
						}
					},
					{
						name: "kind",
						valueSet: "tk",
						description: {
							kind: "markdown",
							value: "How the text track is meant to be used. If omitted the default kind is `subtitles`. If the attribute is not present, it will use the `subtitles`. If the attribute contains an invalid value, it will use `metadata`. (Versions of Chrome earlier than 52 treated an invalid value as `subtitles`.)\xA0The following keywords are allowed:\n\n*   `subtitles`\n    *   Subtitles provide translation of content that cannot be understood by the viewer. For example dialogue or text that is not English in an English language film.\n    *   Subtitles may contain additional content, usually extra background information. For example the text at the beginning of the Star Wars films, or the date, time, and location of a scene.\n*   `captions`\n    *   Closed captions provide a transcription and possibly a translation of audio.\n    *   It may include important non-verbal information such as music cues or sound effects. It may indicate the cue's source (e.g. music, text, character).\n    *   Suitable for users who are deaf or when the sound is muted.\n*   `descriptions`\n    *   Textual description of the video content.\n    *   Suitable for users who are blind or where the video cannot be seen.\n*   `chapters`\n    *   Chapter titles are intended to be used when the user is navigating the media resource.\n*   `metadata`\n    *   Tracks used by scripts. Not visible to the user."
						}
					},
					{
						name: "label",
						description: {
							kind: "markdown",
							value: "A user-readable title of the text track which is used by the browser when listing available text tracks."
						}
					},
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "Address of the track (`.vtt` file). Must be a valid URL. This attribute must be specified and its URL value must have the same origin as the document — unless the [`<audio>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/audio \"The HTML <audio> element is used to embed sound content in documents. It may contain one or more audio sources, represented using the src attribute or the <source> element:\xA0the browser will choose the most suitable one. It can also be the destination for streamed media, using a MediaStream.\") or [`<video>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/video \"The HTML Video element (<video>) embeds a media player which supports video playback into the document.\") parent element of the `track` element has a [`crossorigin`](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_settings_attributes) attribute."
						}
					},
					{
						name: "srclang",
						description: {
							kind: "markdown",
							value: "Language of the track text data. It must be a valid [BCP 47](https://r12a.github.io/app-subtags/) language tag. If the `kind` attribute is set to\xA0`subtitles,` then `srclang` must be defined."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/track"
				}]
			},
			{
				name: "map",
				description: {
					kind: "markdown",
					value: "The map element, in conjunction with an img element and any area element descendants, defines an image map. The element represents its children."
				},
				attributes: [{
					name: "name",
					description: {
						kind: "markdown",
						value: "The name attribute gives the map a name so that it can be referenced. The attribute must be present and must have a non-empty value with no space characters. The value of the name attribute must not be a compatibility-caseless match for the value of the name attribute of another map element in the same document. If the id attribute is also specified, both attributes must have the same value."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/map"
				}]
			},
			{
				name: "area",
				description: {
					kind: "markdown",
					value: "The area element represents either a hyperlink with some text and a corresponding area on an image map, or a dead area on an image map."
				},
				void: !0,
				attributes: [
					{ name: "alt" },
					{ name: "coords" },
					{
						name: "shape",
						valueSet: "sh"
					},
					{ name: "href" },
					{
						name: "target",
						valueSet: "target"
					},
					{ name: "download" },
					{ name: "ping" },
					{ name: "rel" },
					{ name: "hreflang" },
					{ name: "type" },
					{
						name: "accesskey",
						description: "Specifies a keyboard navigation accelerator for the element. Pressing ALT or a similar key in association with the specified character selects the form control correlated with that key sequence. Page designers are forewarned to avoid key sequences already bound to browsers. This attribute is global since HTML5."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/area"
				}]
			},
			{
				name: "table",
				description: {
					kind: "markdown",
					value: "The table element represents data with more than one dimension, in the form of a table."
				},
				attributes: [{ name: "border" }, {
					name: "align",
					description: "This enumerated attribute indicates how the table must be aligned inside the containing document. It may have the following values:\n\n*   left: the table is displayed on the left side of the document;\n*   center: the table is displayed in the center of the document;\n*   right: the table is displayed on the right side of the document.\n\n**Usage Note**\n\n*   **Do not use this attribute**, as it has been deprecated. The [`<table>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/table \"The HTML <table> element represents tabular data — that is, information presented in a two-dimensional table comprised of rows and columns of cells containing data.\") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). Set [`margin-left`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-left \"The margin-left CSS property sets the margin area on the left side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.\") and [`margin-right`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin-right \"The margin-right CSS property sets the margin area on the right side of an element. A positive value places it farther from its neighbors, while a negative value places it closer.\") to `auto` or [`margin`](https://developer.mozilla.org/en-US/docs/Web/CSS/margin \"The margin CSS property sets the margin area on all four sides of an element. It is a shorthand for margin-top, margin-right, margin-bottom, and margin-left.\") to `0 auto` to achieve an effect that is similar to the align attribute.\n*   Prior to Firefox 4, Firefox also supported the `middle`, `absmiddle`, and `abscenter` values as synonyms of `center`, in quirks mode only."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/table"
				}]
			},
			{
				name: "caption",
				description: {
					kind: "markdown",
					value: "The caption element represents the title of the table that is its parent, if it has a parent and that is a table element."
				},
				attributes: [{
					name: "align",
					description: "This enumerated attribute indicates how the caption must be aligned with respect to the table. It may have one of the following values:\n\n`left`\n\nThe caption is displayed to the left of the table.\n\n`top`\n\nThe caption is displayed above the table.\n\n`right`\n\nThe caption is displayed to the right of the table.\n\n`bottom`\n\nThe caption is displayed below the table.\n\n**Usage note:** Do not use this attribute, as it has been deprecated. The [`<caption>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/caption \"The HTML Table Caption element (<caption>) specifies the caption (or title) of a table, and if used is always the first child of a <table>.\") element should be styled using the [CSS](https://developer.mozilla.org/en-US/docs/CSS) properties [`caption-side`](https://developer.mozilla.org/en-US/docs/Web/CSS/caption-side \"The caption-side CSS property puts the content of a table's <caption> on the specified side. The values are relative to the writing-mode of the table.\") and [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\")."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/caption"
				}]
			},
			{
				name: "colgroup",
				description: {
					kind: "markdown",
					value: "The colgroup element represents a group of one or more columns in the table that is its parent, if it has a parent and that is a table element."
				},
				attributes: [{ name: "span" }, {
					name: "align",
					description: "This enumerated attribute specifies how horizontal alignment of each column cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-charoff) attributes Unimplemented (see [bug\xA02212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 \"character alignment not implemented (align=char, charoff=, text-align:<string>)\")).\n\nIf this attribute is not set, the `left` value is assumed. The descendant [`<col>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col \"The HTML <col> element defines a column within a table and is used for defining common semantics on all common cells. It is generally found within a <colgroup> element.\") elements may override this value using their own [`align`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-align) attribute.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values:\n    *   Do not try to set the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property on a selector giving a [`<colgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup \"The HTML <colgroup> element defines a group of columns within a table.\") element. Because [`<td>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td \"The HTML <td> element defines a cell of a table that contains data. It participates in the table model.\") elements are not descendant of the [`<colgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup \"The HTML <colgroup> element defines a group of columns within a table.\") element, they won't inherit it.\n    *   If the table doesn't use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, use one `td:nth-child(an+b)` CSS selector per column, where a is the total number of the columns in the table and b is the ordinal position of this column in the table. Only after this selector the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property can be used.\n    *   If the table does use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, the effect can be achieved by combining adequate CSS attribute selectors like `[colspan=n]`, though this is not trivial.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property Unimplemented."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/colgroup"
				}]
			},
			{
				name: "col",
				description: {
					kind: "markdown",
					value: "If a col element has a parent and that is a colgroup element that itself has a parent that is a table element, then the col element represents one or more columns in the column group represented by that colgroup."
				},
				void: !0,
				attributes: [{ name: "span" }, {
					name: "align",
					description: "This enumerated attribute specifies how horizontal alignment of each column cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-charoff) attributes Unimplemented (see [bug\xA02212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 \"character alignment not implemented (align=char, charoff=, text-align:<string>)\")).\n\nIf this attribute is not set, its value is inherited from the [`align`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup#attr-align) of the [`<colgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/colgroup \"The HTML <colgroup> element defines a group of columns within a table.\") element this `<col>` element belongs too. If there are none, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values:\n    *   Do not try to set the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property on a selector giving a [`<col>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col \"The HTML <col> element defines a column within a table and is used for defining common semantics on all common cells. It is generally found within a <colgroup> element.\") element. Because [`<td>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td \"The HTML <td> element defines a cell of a table that contains data. It participates in the table model.\") elements are not descendant of the [`<col>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col \"The HTML <col> element defines a column within a table and is used for defining common semantics on all common cells. It is generally found within a <colgroup> element.\") element, they won't inherit it.\n    *   If the table doesn't use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, use the `td:nth-child(an+b)` CSS selector. Set `a` to zero and `b` to the position of the column in the table, e.g. `td:nth-child(2) { text-align: right; }` to right-align the second column.\n    *   If the table does use a [`colspan`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-colspan) attribute, the effect can be achieved by combining adequate CSS attribute selectors like `[colspan=n]`, though this is not trivial.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/col#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property Unimplemented."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/col"
				}]
			},
			{
				name: "tbody",
				description: {
					kind: "markdown",
					value: "The tbody element represents a block of rows that consist of a body of data for the parent table element, if the tbody element has a parent and it is a table."
				},
				attributes: [{
					name: "align",
					description: "This enumerated attribute specifies how horizontal alignment of each cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-charoff) attributes.\n\nIf this attribute is not set, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property on it.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property Unimplemented."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/tbody"
				}]
			},
			{
				name: "thead",
				description: {
					kind: "markdown",
					value: "The thead element represents the block of rows that consist of the column labels (headers) for the parent table element, if the thead element has a parent and it is a table."
				},
				attributes: [{
					name: "align",
					description: "This enumerated attribute specifies how horizontal alignment of each cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/thead#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/thead#attr-charoff) attributes Unimplemented (see [bug\xA02212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 \"character alignment not implemented (align=char, charoff=, text-align:<string>)\")).\n\nIf this attribute is not set, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property on it.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/thead#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property Unimplemented."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/thead"
				}]
			},
			{
				name: "tfoot",
				description: {
					kind: "markdown",
					value: "The tfoot element represents the block of rows that consist of the column summaries (footers) for the parent table element, if the tfoot element has a parent and it is a table."
				},
				attributes: [{
					name: "align",
					description: "This enumerated attribute specifies how horizontal alignment of each cell content will be handled. Possible values are:\n\n*   `left`, aligning the content to the left of the cell\n*   `center`, centering the content in the cell\n*   `right`, aligning the content to the right of the cell\n*   `justify`, inserting spaces into the textual content so that the content is justified in the cell\n*   `char`, aligning the textual content on a special character with a minimal offset, defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tbody#attr-charoff) attributes Unimplemented (see [bug\xA02212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 \"character alignment not implemented (align=char, charoff=, text-align:<string>)\")).\n\nIf this attribute is not set, the `left` value is assumed.\n\n**Note:** Do not use this attribute as it is obsolete (not supported) in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property on it.\n*   To achieve the same effect as the `char` value, in CSS3, you can use the value of the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tfoot#attr-char) as the value of the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property Unimplemented."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/tfoot"
				}]
			},
			{
				name: "tr",
				description: {
					kind: "markdown",
					value: "The tr element represents a row of cells in a table."
				},
				attributes: [{
					name: "align",
					description: "A [`DOMString`](https://developer.mozilla.org/en-US/docs/Web/API/DOMString \"DOMString is a UTF-16 String. As JavaScript already uses such strings, DOMString is mapped directly to a String.\") which specifies how the cell's context should be aligned horizontally within the cells in the row; this is shorthand for using `align` on every cell in the row individually. Possible values are:\n\n`left`\n\nAlign the content of each cell at its left edge.\n\n`center`\n\nCenter the contents of each cell between their left and right edges.\n\n`right`\n\nAlign the content of each cell at its right edge.\n\n`justify`\n\nWiden whitespaces within the text of each cell so that the text fills the full width of each cell (full justification).\n\n`char`\n\nAlign each cell in the row on a specific character (such that each row in the column that is configured this way will horizontally align its cells on that character). This uses the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tr#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/tr#attr-charoff) to establish the alignment character (typically \".\" or \",\" when aligning numerical data) and the number of characters that should follow the alignment character. This alignment type was never widely supported.\n\nIf no value is expressly set for `align`, the parent node's value is inherited.\n\nInstead of using the obsolete `align` attribute, you should instead use the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property to establish `left`, `center`, `right`, or `justify` alignment for the row's cells. To apply character-based alignment, set the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property to the alignment character (such as `\".\"` or `\",\"`)."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/tr"
				}]
			},
			{
				name: "td",
				description: {
					kind: "markdown",
					value: "The td element represents a data cell in a table."
				},
				attributes: [
					{ name: "colspan" },
					{ name: "rowspan" },
					{ name: "headers" },
					{
						name: "abbr",
						description: "This attribute contains a short abbreviated description of the cell's content. Some user-agents, such as speech readers, may present this description before the content itself.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard. Alternatively, you can put the abbreviated description inside the cell and place the long content in the **title** attribute."
					},
					{
						name: "align",
						description: "This enumerated attribute specifies how the cell content's horizontal alignment will be handled. Possible values are:\n\n*   `left`: The content is aligned to the left of the cell.\n*   `center`: The content is centered in the cell.\n*   `right`: The content is aligned to the right of the cell.\n*   `justify` (with text only): The content is stretched out inside the cell so that it covers its entire width.\n*   `char` (with text only): The content is aligned to a character inside the `<th>` element with minimal offset. This character is defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-charoff) attributes Unimplemented (see [bug\xA02212](https://bugzilla.mozilla.org/show_bug.cgi?id=2212 \"character alignment not implemented (align=char, charoff=, text-align:<string>)\")).\n\nThe default value when this attribute is not specified is `left`.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, apply the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property to the element.\n*   To achieve the same effect as the `char` value, give the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property the same value you would use for the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td#attr-char). Unimplemented in CSS3."
					},
					{
						name: "axis",
						description: "This attribute contains a list of space-separated strings. Each string is the `id` of a group of cells that this header applies to.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard."
					},
					{
						name: "bgcolor",
						description: "This attribute defines the background color of each cell in a column. It consists of a 6-digit hexadecimal code as defined in [sRGB](https://www.w3.org/Graphics/Color/sRGB) and is prefixed by '#'. This attribute may be used with one of sixteen predefined color strings:\n\n\xA0\n\n`black` = \"#000000\"\n\n\xA0\n\n`green` = \"#008000\"\n\n\xA0\n\n`silver` = \"#C0C0C0\"\n\n\xA0\n\n`lime` = \"#00FF00\"\n\n\xA0\n\n`gray` = \"#808080\"\n\n\xA0\n\n`olive` = \"#808000\"\n\n\xA0\n\n`white` = \"#FFFFFF\"\n\n\xA0\n\n`yellow` = \"#FFFF00\"\n\n\xA0\n\n`maroon` = \"#800000\"\n\n\xA0\n\n`navy` = \"#000080\"\n\n\xA0\n\n`red` = \"#FF0000\"\n\n\xA0\n\n`blue` = \"#0000FF\"\n\n\xA0\n\n`purple` = \"#800080\"\n\n\xA0\n\n`teal` = \"#008080\"\n\n\xA0\n\n`fuchsia` = \"#FF00FF\"\n\n\xA0\n\n`aqua` = \"#00FFFF\"\n\n**Note:** Do not use this attribute, as it is non-standard and only implemented in some versions of Microsoft Internet Explorer: The [`<td>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/td \"The HTML <td> element defines a cell of a table that contains data. It participates in the table model.\") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/CSS). To create a similar effect use the [`background-color`](https://developer.mozilla.org/en-US/docs/Web/CSS/background-color \"The background-color CSS property sets the background color of an element.\") property in [CSS](https://developer.mozilla.org/en-US/docs/CSS) instead."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/td"
				}]
			},
			{
				name: "th",
				description: {
					kind: "markdown",
					value: "The th element represents a header cell in a table."
				},
				attributes: [
					{ name: "colspan" },
					{ name: "rowspan" },
					{ name: "headers" },
					{
						name: "scope",
						valueSet: "s"
					},
					{ name: "sorted" },
					{
						name: "abbr",
						description: {
							kind: "markdown",
							value: "This attribute contains a short abbreviated description of the cell's content. Some user-agents, such as speech readers, may present this description before the content itself."
						}
					},
					{
						name: "align",
						description: "This enumerated attribute specifies how the cell content's horizontal alignment will be handled. Possible values are:\n\n*   `left`: The content is aligned to the left of the cell.\n*   `center`: The content is centered in the cell.\n*   `right`: The content is aligned to the right of the cell.\n*   `justify` (with text only): The content is stretched out inside the cell so that it covers its entire width.\n*   `char` (with text only): The content is aligned to a character inside the `<th>` element with minimal offset. This character is defined by the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-char) and [`charoff`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-charoff) attributes.\n\nThe default value when this attribute is not specified is `left`.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard.\n\n*   To achieve the same effect as the `left`, `center`, `right` or `justify` values, apply the CSS [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property to the element.\n*   To achieve the same effect as the `char` value, give the [`text-align`](https://developer.mozilla.org/en-US/docs/Web/CSS/text-align \"The text-align CSS property sets the horizontal alignment of an inline or table-cell box. This means it works like vertical-align but in the horizontal direction.\") property the same value you would use for the [`char`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-char). Unimplemented in CSS3."
					},
					{
						name: "axis",
						description: "This attribute contains a list of space-separated strings. Each string is the `id` of a group of cells that this header applies to.\n\n**Note:** Do not use this attribute as it is obsolete in the latest standard: use the [`scope`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th#attr-scope) attribute instead."
					},
					{
						name: "bgcolor",
						description: "This attribute defines the background color of each cell in a column. It consists of a 6-digit hexadecimal code as defined in [sRGB](https://www.w3.org/Graphics/Color/sRGB) and is prefixed by '#'. This attribute may be used with one of sixteen predefined color strings:\n\n\xA0\n\n`black` = \"#000000\"\n\n\xA0\n\n`green` = \"#008000\"\n\n\xA0\n\n`silver` = \"#C0C0C0\"\n\n\xA0\n\n`lime` = \"#00FF00\"\n\n\xA0\n\n`gray` = \"#808080\"\n\n\xA0\n\n`olive` = \"#808000\"\n\n\xA0\n\n`white` = \"#FFFFFF\"\n\n\xA0\n\n`yellow` = \"#FFFF00\"\n\n\xA0\n\n`maroon` = \"#800000\"\n\n\xA0\n\n`navy` = \"#000080\"\n\n\xA0\n\n`red` = \"#FF0000\"\n\n\xA0\n\n`blue` = \"#0000FF\"\n\n\xA0\n\n`purple` = \"#800080\"\n\n\xA0\n\n`teal` = \"#008080\"\n\n\xA0\n\n`fuchsia` = \"#FF00FF\"\n\n\xA0\n\n`aqua` = \"#00FFFF\"\n\n**Note:** Do not use this attribute, as it is non-standard and only implemented in some versions of Microsoft Internet Explorer: The [`<th>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/th \"The HTML <th> element defines a cell as header of a group of table cells. The exact nature of this group is defined by the scope and headers attributes.\") element should be styled using [CSS](https://developer.mozilla.org/en-US/docs/Web/CSS). To create a similar effect use the [`background-color`](https://developer.mozilla.org/en-US/docs/Web/CSS/background-color \"The background-color CSS property sets the background color of an element.\") property in [CSS](https://developer.mozilla.org/en-US/docs/Web/CSS) instead."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/th"
				}]
			},
			{
				name: "form",
				description: {
					kind: "markdown",
					value: "The form element represents a collection of form-associated elements, some of which can represent editable values that can be submitted to a server for processing."
				},
				attributes: [
					{
						name: "accept-charset",
						description: {
							kind: "markdown",
							value: "A space- or comma-delimited list of character encodings that the server accepts. The browser uses them in the order in which they are listed. The default value, the reserved string `\"UNKNOWN\"`, indicates the same encoding as that of the document containing the form element.  \nIn previous versions of HTML, the different character encodings could be delimited by spaces or commas. In HTML5, only spaces are allowed as delimiters."
						}
					},
					{
						name: "action",
						description: {
							kind: "markdown",
							value: "The URI of a program that processes the form information. This value can be overridden by a [`formaction`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formaction) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element."
						}
					},
					{
						name: "autocomplete",
						valueSet: "o",
						description: {
							kind: "markdown",
							value: "Indicates whether input elements can by default have their values automatically completed by the browser. This setting can be overridden by an `autocomplete` attribute on an element belonging to the form. Possible values are:\n\n*   `off`: The user must explicitly enter a value into each field for every use, or the document provides its own auto-completion method; the browser does not automatically complete entries.\n*   `on`: The browser can automatically complete values based on values that the user has previously entered in the form.\n\nFor most modern browsers (including Firefox 38+, Google Chrome 34+, IE 11+) setting the autocomplete attribute will not prevent a browser's password manager from asking the user if they want to store login fields (username and password), if the user permits the storage the browser will autofill the login the next time the user visits the page. See [The autocomplete attribute and login fields](https://developer.mozilla.org/en-US/docs/Web/Security/Securing_your_site/Turning_off_form_autocompletion#The_autocomplete_attribute_and_login_fields).\n**Note:** If you set `autocomplete` to `off` in a form because the document provides its own auto-completion, then you should also set `autocomplete` to `off` for each of the form's `input` elements that the document can auto-complete. For details, see the note regarding Google Chrome in the [Browser Compatibility chart](#compatChart)."
						}
					},
					{
						name: "enctype",
						valueSet: "et",
						description: {
							kind: "markdown",
							value: "When the value of the `method` attribute is `post`, enctype is the [MIME type](https://en.wikipedia.org/wiki/Mime_type) of content that is used to submit the form to the server. Possible values are:\n\n*   `application/x-www-form-urlencoded`: The default value if the attribute is not specified.\n*   `multipart/form-data`: The value used for an [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element with the `type` attribute set to \"file\".\n*   `text/plain`: (HTML5)\n\nThis value can be overridden by a [`formenctype`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formenctype) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element."
						}
					},
					{
						name: "method",
						valueSet: "m",
						description: {
							kind: "markdown",
							value: "The [HTTP](https://developer.mozilla.org/en-US/docs/Web/HTTP) method that the browser uses to submit the form. Possible values are:\n\n*   `post`: Corresponds to the HTTP [POST method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.5) ; form data are included in the body of the form and sent to the server.\n*   `get`: Corresponds to the HTTP [GET method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.3); form data are appended to the `action` attribute URI with a '?' as separator, and the resulting URI is sent to the server. Use this method when the form has no side-effects and contains only ASCII characters.\n*   `dialog`: Use when the form is inside a\xA0[`<dialog>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog \"The HTML <dialog> element represents a dialog box or other interactive component, such as an inspector or window.\") element to close the dialog when submitted.\n\nThis value can be overridden by a [`formmethod`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formmethod) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "The name of the form. In HTML 4, its use is deprecated (`id` should be used instead). It must be unique among the forms in a document and not just an empty string in HTML 5."
						}
					},
					{
						name: "novalidate",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that the form is not to be validated when submitted. If this attribute is not specified (and therefore the form is validated), this default setting can be overridden by a [`formnovalidate`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formnovalidate) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element belonging to the form."
						}
					},
					{
						name: "target",
						valueSet: "target",
						description: {
							kind: "markdown",
							value: "A name or keyword indicating where to display the response that is received after submitting the form. In HTML 4, this is the name/keyword for a frame. In HTML5, it is a name/keyword for a _browsing context_ (for example, tab, window, or inline frame). The following keywords have special meanings:\n\n*   `_self`: Load the response into the same HTML 4 frame (or HTML5 browsing context) as the current one. This value is the default if the attribute is not specified.\n*   `_blank`: Load the response into a new unnamed HTML 4 window or HTML5 browsing context.\n*   `_parent`: Load the response into the HTML 4 frameset parent of the current frame, or HTML5 parent browsing context of the current one. If there is no parent, this option behaves the same way as `_self`.\n*   `_top`: HTML 4: Load the response into the full original window, and cancel all other frames. HTML5: Load the response into the top-level browsing context (i.e., the browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this option behaves the same way as `_self`.\n*   _iframename_: The response is displayed in a named [`<iframe>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/iframe \"The HTML Inline Frame element (<iframe>) represents a nested browsing context, embedding another HTML page into the current one.\").\n\nHTML5: This value can be overridden by a [`formtarget`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-formtarget) attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") or [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element."
						}
					},
					{
						name: "accept",
						description: "A comma-separated list of content types that the server accepts.\n\n**Usage note:** This attribute has been removed in HTML5 and should no longer be used. Instead, use the [`accept`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-accept) attribute of the specific [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element."
					},
					{
						name: "autocapitalize",
						description: "This is a nonstandard attribute used by iOS Safari Mobile which controls whether and how the text value for textual form control descendants should be automatically capitalized as it is entered/edited by the user. If the `autocapitalize` attribute is specified on an individual form control descendant, it trumps the form-wide `autocapitalize` setting. The non-deprecated values are available in iOS 5 and later. The default value is `sentences`. Possible values are:\n\n*   `none`: Completely disables automatic capitalization\n*   `sentences`: Automatically capitalize the first letter of sentences.\n*   `words`: Automatically capitalize the first letter of words.\n*   `characters`: Automatically capitalize all characters.\n*   `on`: Deprecated since iOS 5.\n*   `off`: Deprecated since iOS 5."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/form"
				}]
			},
			{
				name: "label",
				description: {
					kind: "markdown",
					value: "The label element represents a caption in a user interface. The caption can be associated with a specific form control, known as the label element's labeled control, either using the for attribute, or by putting the form control inside the label element itself."
				},
				attributes: [{
					name: "form",
					description: {
						kind: "markdown",
						value: "The [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element with which the label is associated (its _form owner_). If specified, the value of the attribute is the `id` of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element in the same document. This lets you place label elements anywhere within a document, not just as descendants of their form elements."
					}
				}, {
					name: "for",
					description: {
						kind: "markdown",
						value: "The [`id`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes#attr-id) of a [labelable](https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Content_categories#Form_labelable) form-related element in the same document as the `<label>` element. The first element in the document with an `id` matching the value of the `for` attribute is the _labeled control_ for this label element, if it is a labelable element. If it is\xA0not labelable then the `for` attribute has no effect. If there are other elements which also match the `id` value, later in the document, they are not considered.\n\n**Note**: A `<label>` element can have both a `for` attribute and a contained control element, as long as the `for` attribute points to the contained control element."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/label"
				}]
			},
			{
				name: "input",
				description: {
					kind: "markdown",
					value: "The input element represents a typed data field, usually with a form control to allow the user to edit the data."
				},
				void: !0,
				attributes: [
					{ name: "accept" },
					{ name: "alt" },
					{
						name: "autocomplete",
						valueSet: "inputautocomplete"
					},
					{
						name: "autofocus",
						valueSet: "v"
					},
					{
						name: "checked",
						valueSet: "v"
					},
					{ name: "dirname" },
					{
						name: "disabled",
						valueSet: "v"
					},
					{ name: "form" },
					{ name: "formaction" },
					{
						name: "formenctype",
						valueSet: "et"
					},
					{
						name: "formmethod",
						valueSet: "fm"
					},
					{
						name: "formnovalidate",
						valueSet: "v"
					},
					{ name: "formtarget" },
					{ name: "height" },
					{
						name: "inputmode",
						valueSet: "im"
					},
					{ name: "list" },
					{ name: "max" },
					{ name: "maxlength" },
					{ name: "min" },
					{ name: "minlength" },
					{
						name: "multiple",
						valueSet: "v"
					},
					{ name: "name" },
					{ name: "pattern" },
					{ name: "placeholder" },
					{
						name: "readonly",
						valueSet: "v"
					},
					{
						name: "required",
						valueSet: "v"
					},
					{ name: "size" },
					{ name: "src" },
					{ name: "step" },
					{
						name: "type",
						valueSet: "t"
					},
					{ name: "value" },
					{ name: "width" }
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/input"
				}]
			},
			{
				name: "button",
				description: {
					kind: "markdown",
					value: "The button element represents a button labeled by its contents."
				},
				attributes: [
					{
						name: "autofocus",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute lets you specify that the button should have input focus when the page loads, unless the user overrides it, for example by typing in a different control. Only one form-associated element in a document can have this attribute specified."
						}
					},
					{
						name: "disabled",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that the user cannot interact with the button. If this attribute is not specified, the button inherits its setting from the containing element, for example [`<fieldset>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/fieldset \"The HTML <fieldset> element is used to group several controls as well as labels (<label>) within a web form.\"); if there is no containing element with the **disabled** attribute set, then the button is enabled.\n\nFirefox will, unlike other browsers, by default, [persist the dynamic disabled state](https://stackoverflow.com/questions/5985839/bug-with-firefox-disabled-attribute-of-input-not-resetting-when-refreshing) of a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") across page loads. Use the [`autocomplete`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button#attr-autocomplete) attribute to control this feature."
						}
					},
					{
						name: "form",
						description: {
							kind: "markdown",
							value: "The form element that the button is associated with (its _form owner_). The value of the attribute must be the **id** attribute of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element in the same document. If this attribute is not specified, the `<button>` element will be associated to an ancestor [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element, if one exists. This attribute enables you to associate `<button>` elements to [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") elements anywhere within a document, not just as descendants of [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") elements."
						}
					},
					{
						name: "formaction",
						description: {
							kind: "markdown",
							value: "The URI of a program that processes the information submitted by the button. If specified, it overrides the [`action`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-action) attribute of the button's form owner."
						}
					},
					{
						name: "formenctype",
						valueSet: "et",
						description: {
							kind: "markdown",
							value: "If the button is a submit button, this attribute specifies the type of content that is used to submit the form to the server. Possible values are:\n\n*   `application/x-www-form-urlencoded`: The default value if the attribute is not specified.\n*   `multipart/form-data`: Use this value if you are using an [`<input>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") element with the [`type`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#attr-type) attribute set to `file`.\n*   `text/plain`\n\nIf this attribute is specified, it overrides the [`enctype`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-enctype) attribute of the button's form owner."
						}
					},
					{
						name: "formmethod",
						valueSet: "fm",
						description: {
							kind: "markdown",
							value: "If the button is a submit button, this attribute specifies the HTTP method that the browser uses to submit the form. Possible values are:\n\n*   `post`: The data from the form are included in the body of the form and sent to the server.\n*   `get`: The data from the form are appended to the **form** attribute URI, with a '?' as a separator, and the resulting URI is sent to the server. Use this method when the form has no side-effects and contains only ASCII characters.\n\nIf specified, this attribute overrides the [`method`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-method) attribute of the button's form owner."
						}
					},
					{
						name: "formnovalidate",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "If the button is a submit button, this Boolean attribute specifies that the form is not to be validated when it is submitted. If this attribute is specified, it overrides the [`novalidate`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-novalidate) attribute of the button's form owner."
						}
					},
					{
						name: "formtarget",
						description: {
							kind: "markdown",
							value: "If the button is a submit button, this attribute is a name or keyword indicating where to display the response that is received after submitting the form. This is a name of, or keyword for, a _browsing context_ (for example, tab, window, or inline frame). If this attribute is specified, it overrides the [`target`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-target) attribute of the button's form owner. The following keywords have special meanings:\n\n*   `_self`: Load the response into the same browsing context as the current one. This value is the default if the attribute is not specified.\n*   `_blank`: Load the response into a new unnamed browsing context.\n*   `_parent`: Load the response into the parent browsing context of the current one. If there is no parent, this option behaves the same way as `_self`.\n*   `_top`: Load the response into the top-level browsing context (that is, the browsing context that is an ancestor of the current one, and has no parent). If there is no parent, this option behaves the same way as `_self`."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "The name of the button, which is submitted with the form data."
						}
					},
					{
						name: "type",
						valueSet: "bt",
						description: {
							kind: "markdown",
							value: "The type of the button. Possible values are:\n\n*   `submit`: The button submits the form data to the server. This is the default if the attribute is not specified, or if the attribute is dynamically changed to an empty or invalid value.\n*   `reset`: The button resets all the controls to their initial values.\n*   `button`: The button has no default behavior. It can have client-side scripts associated with the element's events, which are triggered when the events occur."
						}
					},
					{
						name: "value",
						description: {
							kind: "markdown",
							value: "The initial value of the button. It defines the value associated with the button which is submitted with the form data. This value is passed to the server in params when the form is submitted."
						}
					},
					{
						name: "autocomplete",
						description: "The use of this attribute on a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") is nonstandard and Firefox-specific. By default, unlike other browsers, [Firefox persists the dynamic disabled state](https://stackoverflow.com/questions/5985839/bug-with-firefox-disabled-attribute-of-input-not-resetting-when-refreshing) of a [`<button>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button \"The HTML <button> element represents a clickable button, which can be used in forms or anywhere in a document that needs simple, standard button functionality.\") across page loads. Setting the value of this attribute to `off` (i.e. `autocomplete=\"off\"`) disables this feature. See [bug\xA0654072](https://bugzilla.mozilla.org/show_bug.cgi?id=654072 \"if disabled state is changed with javascript, the normal state doesn't return after refreshing the page\")."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/button"
				}]
			},
			{
				name: "select",
				description: {
					kind: "markdown",
					value: "The select element represents a control for selecting amongst a set of options."
				},
				attributes: [
					{
						name: "autocomplete",
						valueSet: "inputautocomplete",
						description: {
							kind: "markdown",
							value: "A [`DOMString`](https://developer.mozilla.org/en-US/docs/Web/API/DOMString \"DOMString is a UTF-16 String. As JavaScript already uses such strings, DOMString is mapped directly to a String.\") providing a hint for a [user agent's](https://developer.mozilla.org/en-US/docs/Glossary/user_agent \"user agent's: A user agent is a computer program representing a person, for example, a browser in a Web context.\") autocomplete feature. See [The HTML autocomplete attribute](https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes/autocomplete) for a complete list of values and details on how to use autocomplete."
						}
					},
					{
						name: "autofocus",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute lets you specify that a form control should have input focus when the page loads. Only one form element in a document can have the `autofocus` attribute."
						}
					},
					{
						name: "disabled",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that the user cannot interact with the control. If this attribute is not specified, the control inherits its setting from the containing element, for example `fieldset`; if there is no containing element with the `disabled` attribute set, then the control is enabled."
						}
					},
					{
						name: "form",
						description: {
							kind: "markdown",
							value: "This attribute lets you specify the form element to\xA0which\xA0the select element is associated\xA0(that is, its \"form owner\"). If this attribute is specified, its value must be the same as the `id` of a form element in the same document. This enables you to place select elements anywhere within a document, not just as descendants of their form elements."
						}
					},
					{
						name: "multiple",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that multiple options can be selected in the list. If it is not specified, then only one option can be selected at a time. When `multiple` is specified, most browsers will show a scrolling list box instead of a single line dropdown."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "This attribute is used to specify the name of the control."
						}
					},
					{
						name: "required",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "A Boolean attribute indicating that an option with a non-empty string value must be selected."
						}
					},
					{
						name: "size",
						description: {
							kind: "markdown",
							value: "If the control is presented as a scrolling list box (e.g. when `multiple` is specified), this attribute represents the number of rows in the list that should be visible at one time. Browsers are not required to present a select element as a scrolled list box. The default value is 0.\n\n**Note:** According to the HTML5 specification, the default value for size should be 1; however, in practice, this has been found to break some web sites, and no other browser currently does that, so Mozilla has opted to continue to return 0 for the time being with Firefox."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/select"
				}]
			},
			{
				name: "datalist",
				description: {
					kind: "markdown",
					value: "The datalist element represents a set of option elements that represent predefined options for other controls. In the rendering, the datalist element represents nothing and it, along with its children, should be hidden."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/datalist"
				}]
			},
			{
				name: "optgroup",
				description: {
					kind: "markdown",
					value: "The optgroup element represents a group of option elements with a common label."
				},
				attributes: [{
					name: "disabled",
					valueSet: "v",
					description: {
						kind: "markdown",
						value: "If this Boolean attribute is set, none of the items in this option group is selectable. Often browsers grey out such control and it won't receive any browsing events, like mouse clicks or focus-related ones."
					}
				}, {
					name: "label",
					description: {
						kind: "markdown",
						value: "The name of the group of options, which the browser can use when labeling the options in the user interface. This attribute is mandatory if this element is used."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/optgroup"
				}]
			},
			{
				name: "option",
				description: {
					kind: "markdown",
					value: "The option element represents an option in a select element or as part of a list of suggestions in a datalist element."
				},
				attributes: [
					{
						name: "disabled",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "If this Boolean attribute is set, this option is not checkable. Often browsers grey out such control and it won't receive any browsing event, like mouse clicks or focus-related ones. If this attribute is not set, the element can still be disabled if one of its ancestors is a disabled [`<optgroup>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/optgroup \"The HTML <optgroup> element creates a grouping of options within a <select> element.\") element."
						}
					},
					{
						name: "label",
						description: {
							kind: "markdown",
							value: "This attribute is text for the label indicating the meaning of the option. If the `label` attribute isn't defined, its value is that of the element text content."
						}
					},
					{
						name: "selected",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "If present, this Boolean attribute indicates that the option is initially selected. If the `<option>` element is the descendant of a [`<select>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select \"The HTML <select> element represents a control that provides a menu of options\") element whose [`multiple`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select#attr-multiple) attribute is not set, only one single `<option>` of this [`<select>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/select \"The HTML <select> element represents a control that provides a menu of options\") element may have the `selected` attribute."
						}
					},
					{
						name: "value",
						description: {
							kind: "markdown",
							value: "The content of this attribute represents the value to be submitted with the form, should this option be selected.\xA0If this attribute is omitted, the value is taken from the text content of the option element."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/option"
				}]
			},
			{
				name: "textarea",
				description: {
					kind: "markdown",
					value: "The textarea element represents a multiline plain text edit control for the element's raw value. The contents of the control represent the control's default value."
				},
				attributes: [
					{
						name: "autocomplete",
						valueSet: "inputautocomplete",
						description: {
							kind: "markdown",
							value: "This attribute indicates whether the value of the control can be automatically completed by the browser. Possible values are:\n\n*   `off`: The user must explicitly enter a value into this field for every use, or the document provides its own auto-completion method; the browser does not automatically complete the entry.\n*   `on`: The browser can automatically complete the value based on values that the user has entered during previous uses.\n\nIf the `autocomplete` attribute is not specified on a `<textarea>` element, then the browser uses the `autocomplete` attribute value of the `<textarea>` element's form owner. The form owner is either the [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element that this `<textarea>` element is a descendant of or the form element whose `id` is specified by the `form` attribute of the input element. For more information, see the [`autocomplete`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form#attr-autocomplete) attribute in [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\")."
						}
					},
					{
						name: "autofocus",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute lets you specify that a form control should have input focus when the page loads. Only one form-associated element in a document can have this attribute specified."
						}
					},
					{
						name: "cols",
						description: {
							kind: "markdown",
							value: "The visible width of the text control, in average character widths. If it is specified, it must be a positive integer. If it is not specified, the default value is `20`."
						}
					},
					{ name: "dirname" },
					{
						name: "disabled",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that the user cannot interact with the control. If this attribute is not specified, the control inherits its setting from the containing element, for example [`<fieldset>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/fieldset \"The HTML <fieldset> element is used to group several controls as well as labels (<label>) within a web form.\"); if there is no containing element when the `disabled` attribute is set, the control is enabled."
						}
					},
					{
						name: "form",
						description: {
							kind: "markdown",
							value: "The form element that the `<textarea>` element is associated with (its \"form owner\"). The value of the attribute must be the `id` of a form element in the same document. If this attribute is not specified, the `<textarea>` element must be a descendant of a form element. This attribute enables you to place `<textarea>` elements anywhere within a document, not just as descendants of form elements."
						}
					},
					{
						name: "inputmode",
						valueSet: "im"
					},
					{
						name: "maxlength",
						description: {
							kind: "markdown",
							value: "The maximum number of characters (unicode code points) that the user can enter. If this value isn't specified, the user can enter an unlimited number of characters."
						}
					},
					{
						name: "minlength",
						description: {
							kind: "markdown",
							value: "The minimum number of characters (unicode code points) required that the user should enter."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "The name of the control."
						}
					},
					{
						name: "placeholder",
						description: {
							kind: "markdown",
							value: "A hint to the user of what can be entered in the control. Carriage returns or line-feeds within the placeholder text must be treated as line breaks when rendering the hint.\n\n**Note:** Placeholders should only be used to show an example of the type of data that should be entered into a form; they are _not_ a substitute for a proper [`<label>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/label \"The HTML <label> element represents a caption for an item in a user interface.\") element tied to the input. See [Labels and placeholders](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input#Labels_and_placeholders \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") in [<input>: The Input (Form Input) element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") for a full explanation."
						}
					},
					{
						name: "readonly",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute indicates that the user cannot modify the value of the control. Unlike the `disabled` attribute, the `readonly` attribute does not prevent the user from clicking or selecting in the control. The value of a read-only control is still submitted with the form."
						}
					},
					{
						name: "required",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This attribute specifies that the user must fill in a value before submitting a form."
						}
					},
					{
						name: "rows",
						description: {
							kind: "markdown",
							value: "The number of visible text lines for the control."
						}
					},
					{
						name: "wrap",
						valueSet: "w",
						description: {
							kind: "markdown",
							value: "Indicates how the control wraps text. Possible values are:\n\n*   `hard`: The browser automatically inserts line breaks (CR+LF) so that each line has no more than the width of the control; the `cols` attribute must also be specified for this to take effect.\n*   `soft`: The browser ensures that all line breaks in the value consist of a CR+LF pair, but does not insert any additional line breaks.\n*   `off` : Like `soft` but changes appearance to `white-space: pre` so line segments exceeding `cols` are not wrapped and the `<textarea>` becomes horizontally scrollable.\n\nIf this attribute is not specified, `soft` is its default value."
						}
					},
					{
						name: "autocapitalize",
						description: "This is a non-standard attribute supported by WebKit on iOS (therefore nearly all browsers running on iOS, including Safari, Firefox, and Chrome), which controls whether and how the text value should be automatically capitalized as it is entered/edited by the user. The non-deprecated values are available in iOS 5 and later. Possible values are:\n\n*   `none`: Completely disables automatic capitalization.\n*   `sentences`: Automatically capitalize the first letter of sentences.\n*   `words`: Automatically capitalize the first letter of words.\n*   `characters`: Automatically capitalize all characters.\n*   `on`: Deprecated since iOS 5.\n*   `off`: Deprecated since iOS 5."
					},
					{
						name: "spellcheck",
						description: "Specifies whether the `<textarea>` is subject to spell checking by the underlying browser/OS. the value can be:\n\n*   `true`: Indicates that the element needs to have its spelling and grammar checked.\n*   `default` : Indicates that the element is to act according to a default behavior, possibly based on the parent element's own `spellcheck` value.\n*   `false` : Indicates that the element should not be spell checked."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/textarea"
				}]
			},
			{
				name: "output",
				description: {
					kind: "markdown",
					value: "The output element represents the result of a calculation performed by the application, or the result of a user action."
				},
				attributes: [
					{
						name: "for",
						description: {
							kind: "markdown",
							value: "A space-separated list of other elements’ [`id`](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/id)s, indicating that those elements contributed input values to (or otherwise affected) the calculation."
						}
					},
					{
						name: "form",
						description: {
							kind: "markdown",
							value: "The [form element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form) that this element is associated with (its \"form owner\"). The value of the attribute must be an `id` of a form element in the same document. If this attribute is not specified, the output element must be a descendant of a form element. This attribute enables you to place output elements anywhere within a document, not just as descendants of their form elements."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "The name of the element, exposed in the [`HTMLFormElement`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement \"The HTMLFormElement interface represents a <form> element in the DOM; it allows access to and in some cases modification of aspects of the form, as well as access to its component elements.\") API."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/output"
				}]
			},
			{
				name: "progress",
				description: {
					kind: "markdown",
					value: "The progress element represents the completion progress of a task. The progress is either indeterminate, indicating that progress is being made but that it is not clear how much more work remains to be done before the task is complete (e.g. because the task is waiting for a remote host to respond), or the progress is a number in the range zero to a maximum, giving the fraction of work that has so far been completed."
				},
				attributes: [{
					name: "value",
					description: {
						kind: "markdown",
						value: "This attribute specifies how much of the task that has been completed. It must be a valid floating point number between 0 and `max`, or between 0 and 1 if `max` is omitted. If there is no `value` attribute, the progress bar is indeterminate; this indicates that an activity is ongoing with no indication of how long it is expected to take."
					}
				}, {
					name: "max",
					description: {
						kind: "markdown",
						value: "This attribute describes how much work the task indicated by the `progress` element requires. The `max` attribute, if present, must have a value greater than zero and be a valid floating point number. The default value is 1."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/progress"
				}]
			},
			{
				name: "meter",
				description: {
					kind: "markdown",
					value: "The meter element represents a scalar measurement within a known range, or a fractional value; for example disk usage, the relevance of a query result, or the fraction of a voting population to have selected a particular candidate."
				},
				attributes: [
					{
						name: "value",
						description: {
							kind: "markdown",
							value: "The current numeric value. This must be between the minimum and maximum values (`min` attribute and `max` attribute) if they are specified. If unspecified or malformed, the value is 0. If specified, but not within the range given by the `min` attribute and `max` attribute, the value is equal to the nearest end of the range.\n\n**Usage note:** Unless the `value` attribute is between `0` and `1` (inclusive), the `min` and `max` attributes should define the range so that the `value` attribute's value is within it."
						}
					},
					{
						name: "min",
						description: {
							kind: "markdown",
							value: "The lower numeric bound of the measured range. This must be less than the maximum value (`max` attribute), if specified. If unspecified, the minimum value is 0."
						}
					},
					{
						name: "max",
						description: {
							kind: "markdown",
							value: "The upper numeric bound of the measured range. This must be greater than the minimum value (`min` attribute), if specified. If unspecified, the maximum value is 1."
						}
					},
					{
						name: "low",
						description: {
							kind: "markdown",
							value: "The upper numeric bound of the low end of the measured range. This must be greater than the minimum value (`min` attribute), and it also must be less than the high value and maximum value (`high` attribute and `max` attribute, respectively), if any are specified. If unspecified, or if less than the minimum value, the `low` value is equal to the minimum value."
						}
					},
					{
						name: "high",
						description: {
							kind: "markdown",
							value: "The lower numeric bound of the high end of the measured range. This must be less than the maximum value (`max` attribute), and it also must be greater than the low value and minimum value (`low` attribute and **min** attribute, respectively), if any are specified. If unspecified, or if greater than the maximum value, the `high` value is equal to the maximum value."
						}
					},
					{
						name: "optimum",
						description: {
							kind: "markdown",
							value: "This attribute indicates the optimal numeric value. It must be within the range (as defined by the `min` attribute and `max` attribute). When used with the `low` attribute and `high` attribute, it gives an indication where along the range is considered preferable. For example, if it is between the `min` attribute and the `low` attribute, then the lower range is considered preferred."
						}
					},
					{
						name: "form",
						description: "This attribute associates the element with a `form` element that has ownership of the `meter` element. For example, a `meter` might be displaying a range corresponding to an `input` element of `type` _number_. This attribute is only used if the `meter` element is being used as a form-associated element; even then, it may be omitted if the element appears as a descendant of a `form` element."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/meter"
				}]
			},
			{
				name: "fieldset",
				description: {
					kind: "markdown",
					value: "The fieldset element represents a set of form controls optionally grouped under a common name."
				},
				attributes: [
					{
						name: "disabled",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "If this Boolean attribute is set, all form controls that are descendants of the `<fieldset>`, are disabled, meaning they are not editable and won't be submitted along with the `<form>`. They won't receive any browsing events, like mouse clicks or focus-related events. By default browsers display such controls grayed out. Note that form elements inside the [`<legend>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/legend \"The HTML <legend> element represents a caption for the content of its parent <fieldset>.\") element won't be disabled."
						}
					},
					{
						name: "form",
						description: {
							kind: "markdown",
							value: "This attribute takes the value of the `id` attribute of a [`<form>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/form \"The HTML <form> element represents a document section that contains interactive controls for submitting information to a web server.\") element you want the `<fieldset>` to be part of, even if it is not inside the form."
						}
					},
					{
						name: "name",
						description: {
							kind: "markdown",
							value: "The name associated with the group.\n\n**Note**: The caption for the fieldset is given by the first [`<legend>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/legend \"The HTML <legend> element represents a caption for the content of its parent <fieldset>.\") element nested inside it."
						}
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/fieldset"
				}]
			},
			{
				name: "legend",
				description: {
					kind: "markdown",
					value: "The legend element represents a caption for the rest of the contents of the legend element's parent fieldset element, if any."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/legend"
				}]
			},
			{
				name: "details",
				description: {
					kind: "markdown",
					value: "The details element represents a disclosure widget from which the user can obtain additional information or controls."
				},
				attributes: [{
					name: "open",
					valueSet: "v",
					description: {
						kind: "markdown",
						value: "This Boolean attribute indicates whether or not the details — that is, the contents of the `<details>` element — are currently visible. The default, `false`, means the details are not visible."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/details"
				}]
			},
			{
				name: "summary",
				description: {
					kind: "markdown",
					value: "The summary element represents a summary, caption, or legend for the rest of the contents of the summary element's parent details element, if any."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/summary"
				}]
			},
			{
				name: "dialog",
				description: {
					kind: "markdown",
					value: "The dialog element represents a part of an application that a user interacts with to perform a task, for example a dialog box, inspector, or window."
				},
				attributes: [{
					name: "open",
					description: "Indicates that the dialog is active and available for interaction. When the `open` attribute is not set, the dialog shouldn't be shown to the user."
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/dialog"
				}]
			},
			{
				name: "script",
				description: {
					kind: "markdown",
					value: "The script element allows authors to include dynamic script and data blocks in their documents. The element does not represent content for the user."
				},
				attributes: [
					{
						name: "src",
						description: {
							kind: "markdown",
							value: "This attribute specifies the URI of an external script; this can be used as an alternative to embedding a script directly within a document.\n\nIf a `script` element has a `src` attribute specified, it should not have a script embedded inside its tags."
						}
					},
					{
						name: "type",
						description: {
							kind: "markdown",
							value: "This attribute indicates the type of script represented. The value of this attribute will be in one of the following categories:\n\n*   **Omitted or a JavaScript MIME type:** For HTML5-compliant browsers this indicates the script is JavaScript. HTML5 specification urges authors to omit the attribute rather than provide a redundant MIME type. In earlier browsers, this identified the scripting language of the embedded or imported (via the `src` attribute) code. JavaScript MIME types are [listed in the specification](https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types#JavaScript_types).\n*   **`module`:** For HTML5-compliant browsers the code is treated as a JavaScript module. The processing of the script contents is not affected by the `charset` and `defer` attributes. For information on using `module`, see [ES6 in Depth: Modules](https://hacks.mozilla.org/2015/08/es6-in-depth-modules/). Code may behave differently when the `module` keyword is used.\n*   **Any other value:** The embedded content is treated as a data block which won't be processed by the browser. Developers must use a valid MIME type that is not a JavaScript MIME type to denote data blocks. The `src` attribute will be ignored.\n\n**Note:** in Firefox you could specify the version of JavaScript contained in a `<script>` element by including a non-standard `version` parameter inside the `type` attribute — for example `type=\"text/javascript;version=1.8\"`. This has been removed in Firefox 59 (see [bug\xA01428745](https://bugzilla.mozilla.org/show_bug.cgi?id=1428745 \"FIXED: Remove support for version parameter from script loader\"))."
						}
					},
					{ name: "charset" },
					{
						name: "async",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This is a Boolean attribute indicating that the browser should, if possible, load the script asynchronously.\n\nThis attribute must not be used if the `src` attribute is absent (i.e. for inline scripts). If it is included in this case it will have no effect.\n\nBrowsers usually assume the worst case scenario and load scripts synchronously, (i.e. `async=\"false\"`) during HTML parsing.\n\nDynamically inserted scripts (using [`document.createElement()`](https://developer.mozilla.org/en-US/docs/Web/API/Document/createElement \"In an HTML document, the document.createElement() method creates the HTML element specified by tagName, or an HTMLUnknownElement if tagName isn't recognized.\")) load asynchronously by default, so to turn on synchronous loading (i.e. scripts load in the order they were inserted) set `async=\"false\"`.\n\nSee [Browser compatibility](#Browser_compatibility) for notes on browser support. See also [Async scripts for asm.js](https://developer.mozilla.org/en-US/docs/Games/Techniques/Async_scripts)."
						}
					},
					{
						name: "defer",
						valueSet: "v",
						description: {
							kind: "markdown",
							value: "This Boolean attribute is set to indicate to a browser that the script is meant to be executed after the document has been parsed, but before firing [`DOMContentLoaded`](https://developer.mozilla.org/en-US/docs/Web/Events/DOMContentLoaded \"/en-US/docs/Web/Events/DOMContentLoaded\").\n\nScripts with the `defer` attribute will prevent the `DOMContentLoaded` event from firing until the script has loaded and finished evaluating.\n\nThis attribute must not be used if the `src` attribute is absent (i.e. for inline scripts), in this case it would have no effect.\n\nTo achieve a similar effect for dynamically inserted scripts use `async=\"false\"` instead. Scripts with the `defer` attribute will execute in the order in which they appear in the document."
						}
					},
					{
						name: "crossorigin",
						valueSet: "xo",
						description: {
							kind: "markdown",
							value: "Normal `script` elements pass minimal information to the [`window.onerror`](https://developer.mozilla.org/en-US/docs/Web/API/GlobalEventHandlers/onerror \"The onerror property of the GlobalEventHandlers mixin is an EventHandler that processes error events.\") for scripts which do not pass the standard [CORS](https://developer.mozilla.org/en-US/docs/Glossary/CORS \"CORS: CORS (Cross-Origin Resource Sharing) is a system, consisting of transmitting HTTP headers, that determines whether browsers block frontend JavaScript code from accessing responses for cross-origin requests.\") checks. To allow error logging for sites which use a separate domain for static media, use this attribute. See [CORS settings attributes](https://developer.mozilla.org/en-US/docs/Web/HTML/CORS_settings_attributes) for a more descriptive explanation of its valid arguments."
						}
					},
					{
						name: "nonce",
						description: {
							kind: "markdown",
							value: "A cryptographic nonce (number used once) to list the allowed inline scripts in a [script-src Content-Security-Policy](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Security-Policy/script-src). The server must generate a unique nonce value each time it transmits a policy. It is critical to provide a nonce that cannot be guessed as bypassing a resource's policy is otherwise trivial."
						}
					},
					{
						name: "integrity",
						description: "This attribute contains inline metadata that a user agent can use to verify that a fetched resource has been delivered free of unexpected manipulation. See [Subresource Integrity](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity)."
					},
					{
						name: "nomodule",
						description: "This Boolean attribute is set to indicate that the script should not be executed in browsers that support [ES2015 modules](https://hacks.mozilla.org/2015/08/es6-in-depth-modules/) — in effect, this can be used to serve fallback scripts to older browsers that do not support modular JavaScript code."
					},
					{
						name: "referrerpolicy",
						description: "Indicates which [referrer](https://developer.mozilla.org/en-US/docs/Web/API/Document/referrer) to send when fetching the script, or resources fetched by the script:\n\n*   `no-referrer`: The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent.\n*   `no-referrer-when-downgrade` (default): The [`Referer`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Referer \"The Referer request header contains the address of the previous web page from which a link to the currently requested page was followed. The Referer header allows servers to identify where people are visiting them from and may use that data for analytics, logging, or optimized caching, for example.\") header will not be sent to [origin](https://developer.mozilla.org/en-US/docs/Glossary/origin \"origin: Web content's origin is defined by the scheme (protocol), host (domain), and port of the URL used to access it. Two objects have the same origin only when the scheme, host, and port all match.\")s without [TLS](https://developer.mozilla.org/en-US/docs/Glossary/TLS \"TLS: Transport Layer Security (TLS), previously known as Secure Sockets Layer (SSL), is a protocol used by applications to communicate securely across a network, preventing tampering with and eavesdropping on email, web browsing, messaging, and other protocols.\") ([HTTPS](https://developer.mozilla.org/en-US/docs/Glossary/HTTPS \"HTTPS: HTTPS (HTTP Secure) is an encrypted version of the HTTP protocol. It usually uses SSL or TLS to encrypt all communication between a client and a server. This secure connection allows clients to safely exchange sensitive data with a server, for example for banking activities or online shopping.\")).\n*   `origin`: The sent referrer will be limited to the origin of the referring page: its [scheme](https://developer.mozilla.org/en-US/docs/Archive/Mozilla/URIScheme), [host](https://developer.mozilla.org/en-US/docs/Glossary/host \"host: A host is a device connected to the Internet (or a local network). Some hosts called servers offer additional services like serving webpages or storing files and emails.\"), and [port](https://developer.mozilla.org/en-US/docs/Glossary/port \"port: For a computer connected to a network with an IP address, a port is a communication endpoint. Ports are designated by numbers, and below 1024 each port is associated by default with a specific protocol.\").\n*   `origin-when-cross-origin`: The referrer sent to other origins will be limited to the scheme, the host, and the port. Navigations on the same origin will still include the path.\n*   `same-origin`: A referrer will be sent for [same origin](https://developer.mozilla.org/en-US/docs/Glossary/Same-origin_policy \"same origin: The same-origin policy is a critical security mechanism that restricts how a document or script loaded from one origin can interact with a resource from another origin.\"), but cross-origin requests will contain no referrer information.\n*   `strict-origin`: Only send the origin of the document as the referrer when the protocol security level stays the same (e.g. HTTPS→HTTPS), but don't send it to a less secure destination (e.g. HTTPS→HTTP).\n*   `strict-origin-when-cross-origin`: Send a full URL when performing a same-origin request, but only send the origin when the protocol security level stays the same (e.g.HTTPS→HTTPS), and send no header to a less secure destination (e.g. HTTPS→HTTP).\n*   `unsafe-url`: The referrer will include the origin _and_ the path (but not the [fragment](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/hash), [password](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/password), or [username](https://developer.mozilla.org/en-US/docs/Web/API/HTMLHyperlinkElementUtils/username)). **This value is unsafe**, because it leaks origins and paths from TLS-protected resources to insecure origins.\n\n**Note**: An empty string value (`\"\"`) is both the default value, and a fallback value if `referrerpolicy` is not supported. If `referrerpolicy` is not explicitly specified on the `<script>` element, it will adopt a higher-level referrer policy, i.e. one set on the whole document or domain. If a higher-level policy is not available,\xA0the empty string is treated as being equivalent to `no-referrer-when-downgrade`."
					},
					{
						name: "text",
						description: "Like the `textContent` attribute, this attribute sets the text content of the element. Unlike the `textContent` attribute, however, this attribute is evaluated as executable code after the node is inserted into the DOM."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/script"
				}]
			},
			{
				name: "noscript",
				description: {
					kind: "markdown",
					value: "The noscript element represents nothing if scripting is enabled, and represents its children if scripting is disabled. It is used to present different markup to user agents that support scripting and those that don't support scripting, by affecting how the document is parsed."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/noscript"
				}]
			},
			{
				name: "template",
				description: {
					kind: "markdown",
					value: "The template element is used to declare fragments of HTML that can be cloned and inserted in the document by script."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/template"
				}]
			},
			{
				name: "canvas",
				description: {
					kind: "markdown",
					value: "The canvas element provides scripts with a resolution-dependent bitmap canvas, which can be used for rendering graphs, game graphics, art, or other visual images on the fly."
				},
				attributes: [
					{
						name: "width",
						description: {
							kind: "markdown",
							value: "The width of the coordinate space in CSS pixels. Defaults to 300."
						}
					},
					{
						name: "height",
						description: {
							kind: "markdown",
							value: "The height of the coordinate space in CSS pixels. Defaults to 150."
						}
					},
					{
						name: "moz-opaque",
						description: "Lets the canvas know whether or not translucency will be a factor. If the canvas knows there's no translucency, painting performance can be optimized. This is only supported by Mozilla-based browsers; use the standardized [`canvas.getContext('2d', { alpha: false })`](https://developer.mozilla.org/en-US/docs/Web/API/HTMLCanvasElement/getContext \"The HTMLCanvasElement.getContext() method returns a drawing context on the canvas, or null if the context identifier is not supported.\") instead."
					}
				],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/canvas"
				}]
			},
			{
				name: "slot",
				description: {
					kind: "markdown",
					value: "The slot element is a placeholder inside a web component that you can fill with your own markup, which lets you create separate DOM trees and present them together."
				},
				attributes: [{
					name: "name",
					description: {
						kind: "markdown",
						value: "The slot's name.\nA **named slot** is a `<slot>` element with a `name` attribute."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/slot"
				}]
			},
			{
				name: "data",
				description: {
					kind: "markdown",
					value: "The data element links a given piece of content with a machine-readable translation."
				},
				attributes: [{
					name: "value",
					description: {
						kind: "markdown",
						value: "This attribute specifies the machine-readable translation of the content of the element."
					}
				}],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/data"
				}]
			},
			{
				name: "hgroup",
				description: {
					kind: "markdown",
					value: "The hgroup element represents a heading and related content. It groups a single h1–h6 element with one or more p."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/hgroup"
				}]
			},
			{
				name: "menu",
				description: {
					kind: "markdown",
					value: "The menu element represents an unordered list of interactive items."
				},
				attributes: [],
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Element/menu"
				}]
			}
		],
		globalAttributes: [
			{
				name: "accesskey",
				description: {
					kind: "markdown",
					value: "Provides a hint for generating a keyboard shortcut for the current element. This attribute consists of a space-separated list of characters. The browser should use the first one that exists on the computer keyboard layout."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/accesskey"
				}]
			},
			{
				name: "autocapitalize",
				description: {
					kind: "markdown",
					value: "Controls whether and how text input is automatically capitalized as it is entered/edited by the user. It can have the following values:\n\n*   `off` or `none`, no autocapitalization is applied (all letters default to lowercase)\n*   `on` or `sentences`, the first letter of each sentence defaults to a capital letter; all other letters default to lowercase\n*   `words`, the first letter of each word defaults to a capital letter; all other letters default to lowercase\n*   `characters`, all letters should default to uppercase"
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/autocapitalize"
				}]
			},
			{
				name: "class",
				description: {
					kind: "markdown",
					value: "A space-separated list of the classes of the element. Classes allows CSS and JavaScript to select and access specific elements via the [class selectors](https://developer.mozilla.org/docs/Web/CSS/Class_selectors) or functions like the method [`Document.getElementsByClassName()`](https://developer.mozilla.org/docs/Web/API/Document/getElementsByClassName \"returns an array-like object of all child elements which have all of the given class names.\")."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/class"
				}]
			},
			{
				name: "contenteditable",
				description: {
					kind: "markdown",
					value: "An enumerated attribute indicating if the element should be editable by the user. If so, the browser modifies its widget to allow editing. The attribute must take one of the following values:\n\n*   `true` or the _empty string_, which indicates that the element must be editable;\n*   `false`, which indicates that the element must not be editable."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/contenteditable"
				}]
			},
			{
				name: "contextmenu",
				description: {
					kind: "markdown",
					value: "The `[**id**](#attr-id)` of a [`<menu>`](https://developer.mozilla.org/docs/Web/HTML/Element/menu \"The HTML <menu> element represents a group of commands that a user can perform or activate. This includes both list menus, which might appear across the top of a screen, as well as context menus, such as those that might appear underneath a button after it has been clicked.\") to use as the contextual menu for this element."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/contextmenu"
				}]
			},
			{
				name: "dir",
				description: {
					kind: "markdown",
					value: "An enumerated attribute indicating the directionality of the element's text. It can have the following values:\n\n*   `ltr`, which means _left to right_ and is to be used for languages that are written from the left to the right (like English);\n*   `rtl`, which means _right to left_ and is to be used for languages that are written from the right to the left (like Arabic);\n*   `auto`, which lets the user agent decide. It uses a basic algorithm as it parses the characters inside the element until it finds a character with a strong directionality, then it applies that directionality to the whole element."
				},
				valueSet: "d",
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/dir"
				}]
			},
			{
				name: "draggable",
				description: {
					kind: "markdown",
					value: "An enumerated attribute indicating whether the element can be dragged, using the [Drag and Drop API](https://developer.mozilla.org/docs/DragDrop/Drag_and_Drop). It can have the following values:\n\n*   `true`, which indicates that the element may be dragged\n*   `false`, which indicates that the element may not be dragged."
				},
				valueSet: "b",
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/draggable"
				}]
			},
			{
				name: "dropzone",
				description: {
					kind: "markdown",
					value: "An enumerated attribute indicating what types of content can be dropped on an element, using the [Drag and Drop API](https://developer.mozilla.org/docs/DragDrop/Drag_and_Drop). It can have the following values:\n\n*   `copy`, which indicates that dropping will create a copy of the element that was dragged\n*   `move`, which indicates that the element that was dragged will be moved to this new location.\n*   `link`, will create a link to the dragged data."
				}
			},
			{
				name: "exportparts",
				description: {
					kind: "markdown",
					value: "Used to transitively export shadow parts from a nested shadow tree into a containing light tree."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/exportparts"
				}]
			},
			{
				name: "hidden",
				description: {
					kind: "markdown",
					value: "A Boolean attribute indicates that the element is not yet, or is no longer, _relevant_. For example, it can be used to hide elements of the page that can't be used until the login process has been completed. The browser won't render such elements. This attribute must not be used to hide content that could legitimately be shown."
				},
				valueSet: "v",
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/hidden"
				}]
			},
			{
				name: "id",
				description: {
					kind: "markdown",
					value: "Defines a unique identifier (ID) which must be unique in the whole document. Its purpose is to identify the element when linking (using a fragment identifier), scripting, or styling (with CSS)."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/id"
				}]
			},
			{
				name: "inputmode",
				description: {
					kind: "markdown",
					value: "Provides a hint to browsers as to the type of virtual keyboard configuration to use when editing this element or its contents. Used primarily on [`<input>`](https://developer.mozilla.org/docs/Web/HTML/Element/input \"The HTML <input> element is used to create interactive controls for web-based forms in order to accept data from the user; a wide variety of types of input data and control widgets are available, depending on the device and user agent.\") elements, but is usable on any element while in `[contenteditable](https://developer.mozilla.org/docs/Web/HTML/Global_attributes#attr-contenteditable)` mode."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/inputmode"
				}]
			},
			{
				name: "is",
				description: {
					kind: "markdown",
					value: "Allows you to specify that a standard HTML element should behave like a registered custom built-in element (see [Using custom elements](https://developer.mozilla.org/docs/Web/Web_Components/Using_custom_elements) for more details)."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/is"
				}]
			},
			{
				name: "itemid",
				description: {
					kind: "markdown",
					value: "The unique, global identifier of an item."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemid"
				}]
			},
			{
				name: "itemprop",
				description: {
					kind: "markdown",
					value: "Used to add properties to an item. Every HTML element may have an `itemprop` attribute specified, where an `itemprop` consists of a name and value pair."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemprop"
				}]
			},
			{
				name: "itemref",
				description: {
					kind: "markdown",
					value: "Properties that are not descendants of an element with the `itemscope` attribute can be associated with the item using an `itemref`. It provides a list of element ids (not `itemid`s) with additional properties elsewhere in the document."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemref"
				}]
			},
			{
				name: "itemscope",
				description: {
					kind: "markdown",
					value: "`itemscope` (usually) works along with `[itemtype](https://developer.mozilla.org/docs/Web/HTML/Global_attributes#attr-itemtype)` to specify that the HTML contained in a block is about a particular item. `itemscope` creates the Item and defines the scope of the `itemtype` associated with it. `itemtype` is a valid URL of a vocabulary (such as [schema.org](https://schema.org/)) that describes the item and its properties context."
				},
				valueSet: "v",
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemscope"
				}]
			},
			{
				name: "itemtype",
				description: {
					kind: "markdown",
					value: "Specifies the URL of the vocabulary that will be used to define `itemprop`s (item properties) in the data structure. `[itemscope](https://developer.mozilla.org/docs/Web/HTML/Global_attributes#attr-itemscope)` is used to set the scope of where in the data structure the vocabulary set by `itemtype` will be active."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/itemtype"
				}]
			},
			{
				name: "lang",
				description: {
					kind: "markdown",
					value: "Helps define the language of an element: the language that non-editable elements are in, or the language that editable elements should be written in by the user. The attribute contains one “language tag” (made of hyphen-separated “language subtags”) in the format defined in [_Tags for Identifying Languages (BCP47)_](https://www.ietf.org/rfc/bcp/bcp47.txt). [**xml:lang**](#attr-xml:lang) has priority over it."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/lang"
				}]
			},
			{
				name: "part",
				description: {
					kind: "markdown",
					value: "A space-separated list of the part names of the element. Part names allows CSS to select and style specific elements in a shadow tree via the [`::part`](https://developer.mozilla.org/docs/Web/CSS/::part \"The ::part CSS pseudo-element represents any element within a shadow tree that has a matching part attribute.\") pseudo-element."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/part"
				}]
			},
			{
				name: "role",
				valueSet: "roles"
			},
			{
				name: "slot",
				description: {
					kind: "markdown",
					value: "Assigns a slot in a [shadow DOM](https://developer.mozilla.org/docs/Web/Web_Components/Shadow_DOM) shadow tree to an element: An element with a `slot` attribute is assigned to the slot created by the [`<slot>`](https://developer.mozilla.org/docs/Web/HTML/Element/slot \"The HTML <slot> element—part of the Web Components technology suite—is a placeholder inside a web component that you can fill with your own markup, which lets you create separate DOM trees and present them together.\") element whose `[name](https://developer.mozilla.org/docs/Web/HTML/Element/slot#attr-name)` attribute's value matches that `slot` attribute's value."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/slot"
				}]
			},
			{
				name: "spellcheck",
				description: {
					kind: "markdown",
					value: "An enumerated attribute defines whether the element may be checked for spelling errors. It may have the following values:\n\n*   `true`, which indicates that the element should be, if possible, checked for spelling errors;\n*   `false`, which indicates that the element should not be checked for spelling errors."
				},
				valueSet: "b",
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/spellcheck"
				}]
			},
			{
				name: "style",
				description: {
					kind: "markdown",
					value: "Contains [CSS](https://developer.mozilla.org/docs/Web/CSS) styling declarations to be applied to the element. Note that it is recommended for styles to be defined in a separate file or files. This attribute and the [`<style>`](https://developer.mozilla.org/docs/Web/HTML/Element/style \"The HTML <style> element contains style information for a document, or part of a document.\") element have mainly the purpose of allowing for quick styling, for example for testing purposes."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/style"
				}]
			},
			{
				name: "tabindex",
				description: {
					kind: "markdown",
					value: "An integer attribute indicating if the element can take input focus (is _focusable_), if it should participate to sequential keyboard navigation, and if so, at what position. It can take several values:\n\n*   a _negative value_ means that the element should be focusable, but should not be reachable via sequential keyboard navigation;\n*   `0` means that the element should be focusable and reachable via sequential keyboard navigation, but its relative order is defined by the platform convention;\n*   a _positive value_ means that the element should be focusable and reachable via sequential keyboard navigation; the order in which the elements are focused is the increasing value of the [**tabindex**](#attr-tabindex). If several elements share the same tabindex, their relative order follows their relative positions in the document."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/tabindex"
				}]
			},
			{
				name: "title",
				description: {
					kind: "markdown",
					value: "Contains a text representing advisory information related to the element it belongs to. Such information can typically, but not necessarily, be presented to the user as a tooltip."
				},
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/title"
				}]
			},
			{
				name: "translate",
				description: {
					kind: "markdown",
					value: "An enumerated attribute that is used to specify whether an element's attribute values and the values of its [`Text`](https://developer.mozilla.org/docs/Web/API/Text \"The Text interface represents the textual content of Element or Attr. If an element has no markup within its content, it has a single child implementing Text that contains the element's text. However, if the element contains markup, it is parsed into information items and Text nodes that form its children.\") node children are to be translated when the page is localized, or whether to leave them unchanged. It can have the following values:\n\n*   empty string and `yes`, which indicates that the element will be translated.\n*   `no`, which indicates that the element will not be translated."
				},
				valueSet: "y",
				references: [{
					name: "MDN Reference",
					url: "https://developer.mozilla.org/docs/Web/HTML/Global_attributes/translate"
				}]
			},
			{
				name: "onabort",
				description: {
					kind: "markdown",
					value: "The loading of a resource has been aborted."
				}
			},
			{
				name: "onblur",
				description: {
					kind: "markdown",
					value: "An element has lost focus (does not bubble)."
				}
			},
			{
				name: "oncanplay",
				description: {
					kind: "markdown",
					value: "The user agent can play the media, but estimates that not enough data has been loaded to play the media up to its end without having to stop for further buffering of content."
				}
			},
			{
				name: "oncanplaythrough",
				description: {
					kind: "markdown",
					value: "The user agent can play the media up to its end without having to stop for further buffering of content."
				}
			},
			{
				name: "onchange",
				description: {
					kind: "markdown",
					value: "The change event is fired for <input>, <select>, and <textarea> elements when a change to the element's value is committed by the user."
				}
			},
			{
				name: "onclick",
				description: {
					kind: "markdown",
					value: "A pointing device button has been pressed and released on an element."
				}
			},
			{
				name: "oncontextmenu",
				description: {
					kind: "markdown",
					value: "The right button of the mouse is clicked (before the context menu is displayed)."
				}
			},
			{
				name: "ondblclick",
				description: {
					kind: "markdown",
					value: "A pointing device button is clicked twice on an element."
				}
			},
			{
				name: "ondrag",
				description: {
					kind: "markdown",
					value: "An element or text selection is being dragged (every 350ms)."
				}
			},
			{
				name: "ondragend",
				description: {
					kind: "markdown",
					value: "A drag operation is being ended (by releasing a mouse button or hitting the escape key)."
				}
			},
			{
				name: "ondragenter",
				description: {
					kind: "markdown",
					value: "A dragged element or text selection enters a valid drop target."
				}
			},
			{
				name: "ondragleave",
				description: {
					kind: "markdown",
					value: "A dragged element or text selection leaves a valid drop target."
				}
			},
			{
				name: "ondragover",
				description: {
					kind: "markdown",
					value: "An element or text selection is being dragged over a valid drop target (every 350ms)."
				}
			},
			{
				name: "ondragstart",
				description: {
					kind: "markdown",
					value: "The user starts dragging an element or text selection."
				}
			},
			{
				name: "ondrop",
				description: {
					kind: "markdown",
					value: "An element is dropped on a valid drop target."
				}
			},
			{
				name: "ondurationchange",
				description: {
					kind: "markdown",
					value: "The duration attribute has been updated."
				}
			},
			{
				name: "onemptied",
				description: {
					kind: "markdown",
					value: "The media has become empty; for example, this event is sent if the media has already been loaded (or partially loaded), and the load() method is called to reload it."
				}
			},
			{
				name: "onended",
				description: {
					kind: "markdown",
					value: "Playback has stopped because the end of the media was reached."
				}
			},
			{
				name: "onerror",
				description: {
					kind: "markdown",
					value: "A resource failed to load."
				}
			},
			{
				name: "onfocus",
				description: {
					kind: "markdown",
					value: "An element has received focus (does not bubble)."
				}
			},
			{ name: "onformchange" },
			{ name: "onforminput" },
			{
				name: "oninput",
				description: {
					kind: "markdown",
					value: "The value of an element changes or the content of an element with the attribute contenteditable is modified."
				}
			},
			{
				name: "oninvalid",
				description: {
					kind: "markdown",
					value: "A submittable element has been checked and doesn't satisfy its constraints."
				}
			},
			{
				name: "onkeydown",
				description: {
					kind: "markdown",
					value: "A key is pressed down."
				}
			},
			{
				name: "onkeypress",
				description: {
					kind: "markdown",
					value: "A key is pressed down and that key normally produces a character value (use input instead)."
				}
			},
			{
				name: "onkeyup",
				description: {
					kind: "markdown",
					value: "A key is released."
				}
			},
			{
				name: "onload",
				description: {
					kind: "markdown",
					value: "A resource and its dependent resources have finished loading."
				}
			},
			{
				name: "onloadeddata",
				description: {
					kind: "markdown",
					value: "The first frame of the media has finished loading."
				}
			},
			{
				name: "onloadedmetadata",
				description: {
					kind: "markdown",
					value: "The metadata has been loaded."
				}
			},
			{
				name: "onloadstart",
				description: {
					kind: "markdown",
					value: "Progress has begun."
				}
			},
			{
				name: "onmousedown",
				description: {
					kind: "markdown",
					value: "A pointing device button (usually a mouse) is pressed on an element."
				}
			},
			{
				name: "onmousemove",
				description: {
					kind: "markdown",
					value: "A pointing device is moved over an element."
				}
			},
			{
				name: "onmouseout",
				description: {
					kind: "markdown",
					value: "A pointing device is moved off the element that has the listener attached or off one of its children."
				}
			},
			{
				name: "onmouseover",
				description: {
					kind: "markdown",
					value: "A pointing device is moved onto the element that has the listener attached or onto one of its children."
				}
			},
			{
				name: "onmouseup",
				description: {
					kind: "markdown",
					value: "A pointing device button is released over an element."
				}
			},
			{ name: "onmousewheel" },
			{
				name: "onmouseenter",
				description: {
					kind: "markdown",
					value: "A pointing device is moved onto the element that has the listener attached."
				}
			},
			{
				name: "onmouseleave",
				description: {
					kind: "markdown",
					value: "A pointing device is moved off the element that has the listener attached."
				}
			},
			{
				name: "onpause",
				description: {
					kind: "markdown",
					value: "Playback has been paused."
				}
			},
			{
				name: "onplay",
				description: {
					kind: "markdown",
					value: "Playback has begun."
				}
			},
			{
				name: "onplaying",
				description: {
					kind: "markdown",
					value: "Playback is ready to start after having been paused or delayed due to lack of data."
				}
			},
			{
				name: "onprogress",
				description: {
					kind: "markdown",
					value: "In progress."
				}
			},
			{
				name: "onratechange",
				description: {
					kind: "markdown",
					value: "The playback rate has changed."
				}
			},
			{
				name: "onreset",
				description: {
					kind: "markdown",
					value: "A form is reset."
				}
			},
			{
				name: "onresize",
				description: {
					kind: "markdown",
					value: "The document view has been resized."
				}
			},
			{
				name: "onreadystatechange",
				description: {
					kind: "markdown",
					value: "The readyState attribute of a document has changed."
				}
			},
			{
				name: "onscroll",
				description: {
					kind: "markdown",
					value: "The document view or an element has been scrolled."
				}
			},
			{
				name: "onseeked",
				description: {
					kind: "markdown",
					value: "A seek operation completed."
				}
			},
			{
				name: "onseeking",
				description: {
					kind: "markdown",
					value: "A seek operation began."
				}
			},
			{
				name: "onselect",
				description: {
					kind: "markdown",
					value: "Some text is being selected."
				}
			},
			{
				name: "onshow",
				description: {
					kind: "markdown",
					value: "A contextmenu event was fired on/bubbled to an element that has a contextmenu attribute"
				}
			},
			{
				name: "onstalled",
				description: {
					kind: "markdown",
					value: "The user agent is trying to fetch media data, but data is unexpectedly not forthcoming."
				}
			},
			{
				name: "onsubmit",
				description: {
					kind: "markdown",
					value: "A form is submitted."
				}
			},
			{
				name: "onsuspend",
				description: {
					kind: "markdown",
					value: "Media data loading has been suspended."
				}
			},
			{
				name: "ontimeupdate",
				description: {
					kind: "markdown",
					value: "The time indicated by the currentTime attribute has been updated."
				}
			},
			{
				name: "onvolumechange",
				description: {
					kind: "markdown",
					value: "The volume has changed."
				}
			},
			{
				name: "onwaiting",
				description: {
					kind: "markdown",
					value: "Playback has stopped because of a temporary lack of data."
				}
			},
			{
				name: "onpointercancel",
				description: {
					kind: "markdown",
					value: "The pointer is unlikely to produce any more events."
				}
			},
			{
				name: "onpointerdown",
				description: {
					kind: "markdown",
					value: "The pointer enters the active buttons state."
				}
			},
			{
				name: "onpointerenter",
				description: {
					kind: "markdown",
					value: "Pointing device is moved inside the hit-testing boundary."
				}
			},
			{
				name: "onpointerleave",
				description: {
					kind: "markdown",
					value: "Pointing device is moved out of the hit-testing boundary."
				}
			},
			{
				name: "onpointerlockchange",
				description: {
					kind: "markdown",
					value: "The pointer was locked or released."
				}
			},
			{
				name: "onpointerlockerror",
				description: {
					kind: "markdown",
					value: "It was impossible to lock the pointer for technical reasons or because the permission was denied."
				}
			},
			{
				name: "onpointermove",
				description: {
					kind: "markdown",
					value: "The pointer changed coordinates."
				}
			},
			{
				name: "onpointerout",
				description: {
					kind: "markdown",
					value: "The pointing device moved out of hit-testing boundary or leaves detectable hover range."
				}
			},
			{
				name: "onpointerover",
				description: {
					kind: "markdown",
					value: "The pointing device is moved into the hit-testing boundary."
				}
			},
			{
				name: "onpointerup",
				description: {
					kind: "markdown",
					value: "The pointer leaves the active buttons state."
				}
			},
			{
				name: "aria-activedescendant",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-activedescendant"
				}],
				description: {
					kind: "markdown",
					value: "Identifies the currently active element when DOM focus is on a [`composite`](https://www.w3.org/TR/wai-aria-1.1/#composite) widget, [`textbox`](https://www.w3.org/TR/wai-aria-1.1/#textbox), [`group`](https://www.w3.org/TR/wai-aria-1.1/#group), or [`application`](https://www.w3.org/TR/wai-aria-1.1/#application)."
				}
			},
			{
				name: "aria-atomic",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-atomic"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether [assistive technologies](https://www.w3.org/TR/wai-aria-1.1/#dfn-assistive-technology) will present all, or only parts of, the changed region based on the change notifications defined by the [`aria-relevant`](https://www.w3.org/TR/wai-aria-1.1/#aria-relevant) attribute."
				}
			},
			{
				name: "aria-autocomplete",
				valueSet: "autocomplete",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-autocomplete"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether inputting text could trigger display of one or more predictions of the user's intended value for an input and specifies how predictions would be presented if they are made."
				}
			},
			{
				name: "aria-busy",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-busy"
				}],
				description: {
					kind: "markdown",
					value: "Indicates an element is being modified and that assistive technologies _MAY_ want to wait until the modifications are complete before exposing them to the user."
				}
			},
			{
				name: "aria-checked",
				valueSet: "tristate",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-checked"
				}],
				description: {
					kind: "markdown",
					value: "Indicates the current \"checked\" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) of checkboxes, radio buttons, and other [widgets](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget). See related [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.1/#aria-pressed) and [`aria-selected`](https://www.w3.org/TR/wai-aria-1.1/#aria-selected)."
				}
			},
			{
				name: "aria-colcount",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-colcount"
				}],
				description: {
					kind: "markdown",
					value: "Defines the total number of columns in a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-colindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-colindex)."
				}
			},
			{
				name: "aria-colindex",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-colindex"
				}],
				description: {
					kind: "markdown",
					value: "Defines an [element's](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) column index or position with respect to the total number of columns within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-colcount`](https://www.w3.org/TR/wai-aria-1.1/#aria-colcount) and [`aria-colspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-colspan)."
				}
			},
			{
				name: "aria-colspan",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-colspan"
				}],
				description: {
					kind: "markdown",
					value: "Defines the number of columns spanned by a cell or gridcell within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-colindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-colindex) and [`aria-rowspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowspan)."
				}
			},
			{
				name: "aria-controls",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-controls"
				}],
				description: {
					kind: "markdown",
					value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) whose contents or presence are controlled by the current element. See related [`aria-owns`](https://www.w3.org/TR/wai-aria-1.1/#aria-owns)."
				}
			},
			{
				name: "aria-current",
				valueSet: "current",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-current"
				}],
				description: {
					kind: "markdown",
					value: "Indicates the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) that represents the current item within a container or set of related elements."
				}
			},
			{
				name: "aria-describedby",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-describedby"
				}],
				description: {
					kind: "markdown",
					value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) that describes the [object](https://www.w3.org/TR/wai-aria-1.1/#dfn-object). See related [`aria-labelledby`](https://www.w3.org/TR/wai-aria-1.1/#aria-labelledby)."
				}
			},
			{
				name: "aria-disabled",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-disabled"
				}],
				description: {
					kind: "markdown",
					value: "Indicates that the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is [perceivable](https://www.w3.org/TR/wai-aria-1.1/#dfn-perceivable) but disabled, so it is not editable or otherwise [operable](https://www.w3.org/TR/wai-aria-1.1/#dfn-operable). See related [`aria-hidden`](https://www.w3.org/TR/wai-aria-1.1/#aria-hidden) and [`aria-readonly`](https://www.w3.org/TR/wai-aria-1.1/#aria-readonly)."
				}
			},
			{
				name: "aria-dropeffect",
				valueSet: "dropeffect",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-dropeffect"
				}],
				description: {
					kind: "markdown",
					value: "\\[Deprecated in ARIA 1.1\\] Indicates what functions can be performed when a dragged object is released on the drop target."
				}
			},
			{
				name: "aria-errormessage",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-errormessage"
				}],
				description: {
					kind: "markdown",
					value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) that provides an error message for the [object](https://www.w3.org/TR/wai-aria-1.1/#dfn-object). See related [`aria-invalid`](https://www.w3.org/TR/wai-aria-1.1/#aria-invalid) and [`aria-describedby`](https://www.w3.org/TR/wai-aria-1.1/#aria-describedby)."
				}
			},
			{
				name: "aria-expanded",
				valueSet: "u",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-expanded"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether the element, or another grouping element it controls, is currently expanded or collapsed."
				}
			},
			{
				name: "aria-flowto",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-flowto"
				}],
				description: {
					kind: "markdown",
					value: "Identifies the next [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) in an alternate reading order of content which, at the user's discretion, allows assistive technology to override the general default of reading in document source order."
				}
			},
			{
				name: "aria-grabbed",
				valueSet: "u",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-grabbed"
				}],
				description: {
					kind: "markdown",
					value: "\\[Deprecated in ARIA 1.1\\] Indicates an element's \"grabbed\" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) in a drag-and-drop operation."
				}
			},
			{
				name: "aria-haspopup",
				valueSet: "haspopup",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-haspopup"
				}],
				description: {
					kind: "markdown",
					value: "Indicates the availability and type of interactive popup element, such as menu or dialog, that can be triggered by an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element)."
				}
			},
			{
				name: "aria-hidden",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-hidden"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is exposed to an accessibility API. See related [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.1/#aria-disabled)."
				}
			},
			{
				name: "aria-invalid",
				valueSet: "invalid",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-invalid"
				}],
				description: {
					kind: "markdown",
					value: "Indicates the entered value does not conform to the format expected by the application. See related [`aria-errormessage`](https://www.w3.org/TR/wai-aria-1.1/#aria-errormessage)."
				}
			},
			{
				name: "aria-label",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-label"
				}],
				description: {
					kind: "markdown",
					value: "Defines a string value that labels the current element. See related [`aria-labelledby`](https://www.w3.org/TR/wai-aria-1.1/#aria-labelledby)."
				}
			},
			{
				name: "aria-labelledby",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-labelledby"
				}],
				description: {
					kind: "markdown",
					value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) that labels the current element. See related [`aria-describedby`](https://www.w3.org/TR/wai-aria-1.1/#aria-describedby)."
				}
			},
			{
				name: "aria-level",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-level"
				}],
				description: {
					kind: "markdown",
					value: "Defines the hierarchical level of an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) within a structure."
				}
			},
			{
				name: "aria-live",
				valueSet: "live",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-live"
				}],
				description: {
					kind: "markdown",
					value: "Indicates that an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) will be updated, and describes the types of updates the [user agents](https://www.w3.org/TR/wai-aria-1.1/#dfn-user-agent), [assistive technologies](https://www.w3.org/TR/wai-aria-1.1/#dfn-assistive-technology), and user can expect from the [live region](https://www.w3.org/TR/wai-aria-1.1/#dfn-live-region)."
				}
			},
			{
				name: "aria-modal",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-modal"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is modal when displayed."
				}
			},
			{
				name: "aria-multiline",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-multiline"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether a text box accepts multiple lines of input or only a single line."
				}
			},
			{
				name: "aria-multiselectable",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-multiselectable"
				}],
				description: {
					kind: "markdown",
					value: "Indicates that the user may select more than one item from the current selectable descendants."
				}
			},
			{
				name: "aria-orientation",
				valueSet: "orientation",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-orientation"
				}],
				description: {
					kind: "markdown",
					value: "Indicates whether the element's orientation is horizontal, vertical, or unknown/ambiguous."
				}
			},
			{
				name: "aria-owns",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-owns"
				}],
				description: {
					kind: "markdown",
					value: "Identifies an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) (or elements) in order to define a visual, functional, or contextual parent/child [relationship](https://www.w3.org/TR/wai-aria-1.1/#dfn-relationship) between DOM elements where the DOM hierarchy cannot be used to represent the relationship. See related [`aria-controls`](https://www.w3.org/TR/wai-aria-1.1/#aria-controls)."
				}
			},
			{
				name: "aria-placeholder",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-placeholder"
				}],
				description: {
					kind: "markdown",
					value: "Defines a short hint (a word or short phrase) intended to aid the user with data entry when the control has no value. A hint could be a sample value or a brief description of the expected format."
				}
			},
			{
				name: "aria-posinset",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-posinset"
				}],
				description: {
					kind: "markdown",
					value: "Defines an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element)'s number or position in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM. See related [`aria-setsize`](https://www.w3.org/TR/wai-aria-1.1/#aria-setsize)."
				}
			},
			{
				name: "aria-pressed",
				valueSet: "tristate",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-pressed"
				}],
				description: {
					kind: "markdown",
					value: "Indicates the current \"pressed\" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) of toggle buttons. See related [`aria-checked`](https://www.w3.org/TR/wai-aria-1.1/#aria-checked) and [`aria-selected`](https://www.w3.org/TR/wai-aria-1.1/#aria-selected)."
				}
			},
			{
				name: "aria-readonly",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-readonly"
				}],
				description: {
					kind: "markdown",
					value: "Indicates that the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) is not editable, but is otherwise [operable](https://www.w3.org/TR/wai-aria-1.1/#dfn-operable). See related [`aria-disabled`](https://www.w3.org/TR/wai-aria-1.1/#aria-disabled)."
				}
			},
			{
				name: "aria-relevant",
				valueSet: "relevant",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-relevant"
				}],
				description: {
					kind: "markdown",
					value: "Indicates what notifications the user agent will trigger when the accessibility tree within a live region is modified. See related [`aria-atomic`](https://www.w3.org/TR/wai-aria-1.1/#aria-atomic)."
				}
			},
			{
				name: "aria-required",
				valueSet: "b",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-required"
				}],
				description: {
					kind: "markdown",
					value: "Indicates that user input is required on the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) before a form may be submitted."
				}
			},
			{
				name: "aria-roledescription",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-roledescription"
				}],
				description: {
					kind: "markdown",
					value: "Defines a human-readable, author-localized description for the [role](https://www.w3.org/TR/wai-aria-1.1/#dfn-role) of an [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element)."
				}
			},
			{
				name: "aria-rowcount",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-rowcount"
				}],
				description: {
					kind: "markdown",
					value: "Defines the total number of rows in a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-rowindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowindex)."
				}
			},
			{
				name: "aria-rowindex",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-rowindex"
				}],
				description: {
					kind: "markdown",
					value: "Defines an [element's](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) row index or position with respect to the total number of rows within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-rowcount`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowcount) and [`aria-rowspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowspan)."
				}
			},
			{
				name: "aria-rowspan",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-rowspan"
				}],
				description: {
					kind: "markdown",
					value: "Defines the number of rows spanned by a cell or gridcell within a [`table`](https://www.w3.org/TR/wai-aria-1.1/#table), [`grid`](https://www.w3.org/TR/wai-aria-1.1/#grid), or [`treegrid`](https://www.w3.org/TR/wai-aria-1.1/#treegrid). See related [`aria-rowindex`](https://www.w3.org/TR/wai-aria-1.1/#aria-rowindex) and [`aria-colspan`](https://www.w3.org/TR/wai-aria-1.1/#aria-colspan)."
				}
			},
			{
				name: "aria-selected",
				valueSet: "u",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-selected"
				}],
				description: {
					kind: "markdown",
					value: "Indicates the current \"selected\" [state](https://www.w3.org/TR/wai-aria-1.1/#dfn-state) of various [widgets](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget). See related [`aria-checked`](https://www.w3.org/TR/wai-aria-1.1/#aria-checked) and [`aria-pressed`](https://www.w3.org/TR/wai-aria-1.1/#aria-pressed)."
				}
			},
			{
				name: "aria-setsize",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-setsize"
				}],
				description: {
					kind: "markdown",
					value: "Defines the number of items in the current set of listitems or treeitems. Not required if all elements in the set are present in the DOM. See related [`aria-posinset`](https://www.w3.org/TR/wai-aria-1.1/#aria-posinset)."
				}
			},
			{
				name: "aria-sort",
				valueSet: "sort",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-sort"
				}],
				description: {
					kind: "markdown",
					value: "Indicates if items in a table or grid are sorted in ascending or descending order."
				}
			},
			{
				name: "aria-valuemax",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuemax"
				}],
				description: {
					kind: "markdown",
					value: "Defines the maximum allowed value for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget)."
				}
			},
			{
				name: "aria-valuemin",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuemin"
				}],
				description: {
					kind: "markdown",
					value: "Defines the minimum allowed value for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget)."
				}
			},
			{
				name: "aria-valuenow",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuenow"
				}],
				description: {
					kind: "markdown",
					value: "Defines the current value for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget). See related [`aria-valuetext`](https://www.w3.org/TR/wai-aria-1.1/#aria-valuetext)."
				}
			},
			{
				name: "aria-valuetext",
				references: [{
					name: "WAI-ARIA Reference",
					url: "https://www.w3.org/TR/wai-aria-1.1/#aria-valuetext"
				}],
				description: {
					kind: "markdown",
					value: "Defines the human readable text alternative of [`aria-valuenow`](https://www.w3.org/TR/wai-aria-1.1/#aria-valuenow) for a range [widget](https://www.w3.org/TR/wai-aria-1.1/#dfn-widget)."
				}
			},
			{
				name: "aria-details",
				description: {
					kind: "markdown",
					value: "Identifies the [element](https://www.w3.org/TR/wai-aria-1.1/#dfn-element) that provides a detailed, extended description for the [object](https://www.w3.org/TR/wai-aria-1.1/#dfn-object). See related [`aria-describedby`](https://www.w3.org/TR/wai-aria-1.1/#aria-describedby)."
				}
			},
			{
				name: "aria-keyshortcuts",
				description: {
					kind: "markdown",
					value: "Indicates keyboard shortcuts that an author has implemented to activate or give focus to an element."
				}
			}
		],
		valueSets: [
			{
				name: "b",
				values: [{ name: "true" }, { name: "false" }]
			},
			{
				name: "u",
				values: [
					{ name: "true" },
					{ name: "false" },
					{ name: "undefined" }
				]
			},
			{
				name: "o",
				values: [{ name: "on" }, { name: "off" }]
			},
			{
				name: "y",
				values: [{ name: "yes" }, { name: "no" }]
			},
			{
				name: "w",
				values: [{ name: "soft" }, { name: "hard" }]
			},
			{
				name: "d",
				values: [
					{ name: "ltr" },
					{ name: "rtl" },
					{ name: "auto" }
				]
			},
			{
				name: "m",
				values: [
					{
						name: "get",
						description: {
							kind: "markdown",
							value: "Corresponds to the HTTP [GET method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.3); form data are appended to the `action` attribute URI with a '?' as separator, and the resulting URI is sent to the server. Use this method when the form has no side-effects and contains only ASCII characters."
						}
					},
					{
						name: "post",
						description: {
							kind: "markdown",
							value: "Corresponds to the HTTP [POST method](https://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html#sec9.5); form data are included in the body of the form and sent to the server."
						}
					},
					{
						name: "dialog",
						description: {
							kind: "markdown",
							value: "Use when the form is inside a [`<dialog>`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog) element to close the dialog when submitted."
						}
					}
				]
			},
			{
				name: "fm",
				values: [{ name: "get" }, { name: "post" }]
			},
			{
				name: "s",
				values: [
					{ name: "row" },
					{ name: "col" },
					{ name: "rowgroup" },
					{ name: "colgroup" }
				]
			},
			{
				name: "t",
				values: [
					{ name: "hidden" },
					{ name: "text" },
					{ name: "search" },
					{ name: "tel" },
					{ name: "url" },
					{ name: "email" },
					{ name: "password" },
					{ name: "datetime" },
					{ name: "date" },
					{ name: "month" },
					{ name: "week" },
					{ name: "time" },
					{ name: "datetime-local" },
					{ name: "number" },
					{ name: "range" },
					{ name: "color" },
					{ name: "checkbox" },
					{ name: "radio" },
					{ name: "file" },
					{ name: "submit" },
					{ name: "image" },
					{ name: "reset" },
					{ name: "button" }
				]
			},
			{
				name: "im",
				values: [
					{ name: "verbatim" },
					{ name: "latin" },
					{ name: "latin-name" },
					{ name: "latin-prose" },
					{ name: "full-width-latin" },
					{ name: "kana" },
					{ name: "kana-name" },
					{ name: "katakana" },
					{ name: "numeric" },
					{ name: "tel" },
					{ name: "email" },
					{ name: "url" }
				]
			},
			{
				name: "bt",
				values: [
					{ name: "button" },
					{ name: "submit" },
					{ name: "reset" },
					{ name: "menu" }
				]
			},
			{
				name: "lt",
				values: [
					{ name: "1" },
					{ name: "a" },
					{ name: "A" },
					{ name: "i" },
					{ name: "I" }
				]
			},
			{
				name: "mt",
				values: [{ name: "context" }, { name: "toolbar" }]
			},
			{
				name: "mit",
				values: [
					{ name: "command" },
					{ name: "checkbox" },
					{ name: "radio" }
				]
			},
			{
				name: "et",
				values: [
					{ name: "application/x-www-form-urlencoded" },
					{ name: "multipart/form-data" },
					{ name: "text/plain" }
				]
			},
			{
				name: "tk",
				values: [
					{ name: "subtitles" },
					{ name: "captions" },
					{ name: "descriptions" },
					{ name: "chapters" },
					{ name: "metadata" }
				]
			},
			{
				name: "pl",
				values: [
					{ name: "none" },
					{ name: "metadata" },
					{ name: "auto" }
				]
			},
			{
				name: "sh",
				values: [
					{ name: "circle" },
					{ name: "default" },
					{ name: "poly" },
					{ name: "rect" }
				]
			},
			{
				name: "xo",
				values: [{ name: "anonymous" }, { name: "use-credentials" }]
			},
			{
				name: "target",
				values: [
					{ name: "_self" },
					{ name: "_blank" },
					{ name: "_parent" },
					{ name: "_top" }
				]
			},
			{
				name: "sb",
				values: [
					{ name: "allow-forms" },
					{ name: "allow-modals" },
					{ name: "allow-pointer-lock" },
					{ name: "allow-popups" },
					{ name: "allow-popups-to-escape-sandbox" },
					{ name: "allow-same-origin" },
					{ name: "allow-scripts" },
					{ name: "allow-top-navigation" }
				]
			},
			{
				name: "tristate",
				values: [
					{ name: "true" },
					{ name: "false" },
					{ name: "mixed" },
					{ name: "undefined" }
				]
			},
			{
				name: "inputautocomplete",
				values: [
					{ name: "additional-name" },
					{ name: "address-level1" },
					{ name: "address-level2" },
					{ name: "address-level3" },
					{ name: "address-level4" },
					{ name: "address-line1" },
					{ name: "address-line2" },
					{ name: "address-line3" },
					{ name: "bday" },
					{ name: "bday-year" },
					{ name: "bday-day" },
					{ name: "bday-month" },
					{ name: "billing" },
					{ name: "cc-additional-name" },
					{ name: "cc-csc" },
					{ name: "cc-exp" },
					{ name: "cc-exp-month" },
					{ name: "cc-exp-year" },
					{ name: "cc-family-name" },
					{ name: "cc-given-name" },
					{ name: "cc-name" },
					{ name: "cc-number" },
					{ name: "cc-type" },
					{ name: "country" },
					{ name: "country-name" },
					{ name: "current-password" },
					{ name: "email" },
					{ name: "family-name" },
					{ name: "fax" },
					{ name: "given-name" },
					{ name: "home" },
					{ name: "honorific-prefix" },
					{ name: "honorific-suffix" },
					{ name: "impp" },
					{ name: "language" },
					{ name: "mobile" },
					{ name: "name" },
					{ name: "new-password" },
					{ name: "nickname" },
					{ name: "off" },
					{ name: "on" },
					{ name: "organization" },
					{ name: "organization-title" },
					{ name: "pager" },
					{ name: "photo" },
					{ name: "postal-code" },
					{ name: "sex" },
					{ name: "shipping" },
					{ name: "street-address" },
					{ name: "tel-area-code" },
					{ name: "tel" },
					{ name: "tel-country-code" },
					{ name: "tel-extension" },
					{ name: "tel-local" },
					{ name: "tel-local-prefix" },
					{ name: "tel-local-suffix" },
					{ name: "tel-national" },
					{ name: "transaction-amount" },
					{ name: "transaction-currency" },
					{ name: "url" },
					{ name: "username" },
					{ name: "work" }
				]
			},
			{
				name: "autocomplete",
				values: [
					{ name: "inline" },
					{ name: "list" },
					{ name: "both" },
					{ name: "none" }
				]
			},
			{
				name: "current",
				values: [
					{ name: "page" },
					{ name: "step" },
					{ name: "location" },
					{ name: "date" },
					{ name: "time" },
					{ name: "true" },
					{ name: "false" }
				]
			},
			{
				name: "dropeffect",
				values: [
					{ name: "copy" },
					{ name: "move" },
					{ name: "link" },
					{ name: "execute" },
					{ name: "popup" },
					{ name: "none" }
				]
			},
			{
				name: "invalid",
				values: [
					{ name: "grammar" },
					{ name: "false" },
					{ name: "spelling" },
					{ name: "true" }
				]
			},
			{
				name: "live",
				values: [
					{ name: "off" },
					{ name: "polite" },
					{ name: "assertive" }
				]
			},
			{
				name: "orientation",
				values: [
					{ name: "vertical" },
					{ name: "horizontal" },
					{ name: "undefined" }
				]
			},
			{
				name: "relevant",
				values: [
					{ name: "additions" },
					{ name: "removals" },
					{ name: "text" },
					{ name: "all" },
					{ name: "additions text" }
				]
			},
			{
				name: "sort",
				values: [
					{ name: "ascending" },
					{ name: "descending" },
					{ name: "none" },
					{ name: "other" }
				]
			},
			{
				name: "roles",
				values: [
					{ name: "alert" },
					{ name: "alertdialog" },
					{ name: "button" },
					{ name: "checkbox" },
					{ name: "dialog" },
					{ name: "gridcell" },
					{ name: "link" },
					{ name: "log" },
					{ name: "marquee" },
					{ name: "menuitem" },
					{ name: "menuitemcheckbox" },
					{ name: "menuitemradio" },
					{ name: "option" },
					{ name: "progressbar" },
					{ name: "radio" },
					{ name: "scrollbar" },
					{ name: "searchbox" },
					{ name: "slider" },
					{ name: "spinbutton" },
					{ name: "status" },
					{ name: "switch" },
					{ name: "tab" },
					{ name: "tabpanel" },
					{ name: "textbox" },
					{ name: "timer" },
					{ name: "tooltip" },
					{ name: "treeitem" },
					{ name: "combobox" },
					{ name: "grid" },
					{ name: "listbox" },
					{ name: "menu" },
					{ name: "menubar" },
					{ name: "radiogroup" },
					{ name: "tablist" },
					{ name: "tree" },
					{ name: "treegrid" },
					{ name: "application" },
					{ name: "article" },
					{ name: "cell" },
					{ name: "columnheader" },
					{ name: "definition" },
					{ name: "directory" },
					{ name: "document" },
					{ name: "feed" },
					{ name: "figure" },
					{ name: "group" },
					{ name: "heading" },
					{ name: "img" },
					{ name: "list" },
					{ name: "listitem" },
					{ name: "math" },
					{ name: "none" },
					{ name: "note" },
					{ name: "presentation" },
					{ name: "region" },
					{ name: "row" },
					{ name: "rowgroup" },
					{ name: "rowheader" },
					{ name: "separator" },
					{ name: "table" },
					{ name: "term" },
					{ name: "text" },
					{ name: "toolbar" },
					{ name: "banner" },
					{ name: "complementary" },
					{ name: "contentinfo" },
					{ name: "form" },
					{ name: "main" },
					{ name: "navigation" },
					{ name: "region" },
					{ name: "search" },
					{ name: "doc-abstract" },
					{ name: "doc-acknowledgments" },
					{ name: "doc-afterword" },
					{ name: "doc-appendix" },
					{ name: "doc-backlink" },
					{ name: "doc-biblioentry" },
					{ name: "doc-bibliography" },
					{ name: "doc-biblioref" },
					{ name: "doc-chapter" },
					{ name: "doc-colophon" },
					{ name: "doc-conclusion" },
					{ name: "doc-cover" },
					{ name: "doc-credit" },
					{ name: "doc-credits" },
					{ name: "doc-dedication" },
					{ name: "doc-endnote" },
					{ name: "doc-endnotes" },
					{ name: "doc-epigraph" },
					{ name: "doc-epilogue" },
					{ name: "doc-errata" },
					{ name: "doc-example" },
					{ name: "doc-footnote" },
					{ name: "doc-foreword" },
					{ name: "doc-glossary" },
					{ name: "doc-glossref" },
					{ name: "doc-index" },
					{ name: "doc-introduction" },
					{ name: "doc-noteref" },
					{ name: "doc-notice" },
					{ name: "doc-pagebreak" },
					{ name: "doc-pagelist" },
					{ name: "doc-part" },
					{ name: "doc-preface" },
					{ name: "doc-prologue" },
					{ name: "doc-pullquote" },
					{ name: "doc-qna" },
					{ name: "doc-subtitle" },
					{ name: "doc-tip" },
					{ name: "doc-toc" }
				]
			},
			{
				name: "metanames",
				values: [
					{ name: "application-name" },
					{ name: "author" },
					{ name: "description" },
					{ name: "format-detection" },
					{ name: "generator" },
					{ name: "keywords" },
					{ name: "publisher" },
					{ name: "referrer" },
					{ name: "robots" },
					{ name: "theme-color" },
					{ name: "viewport" }
				]
			},
			{
				name: "haspopup",
				values: [
					{
						name: "false",
						description: {
							kind: "markdown",
							value: "(default) Indicates the element does not have a popup."
						}
					},
					{
						name: "true",
						description: {
							kind: "markdown",
							value: "Indicates the popup is a menu."
						}
					},
					{
						name: "menu",
						description: {
							kind: "markdown",
							value: "Indicates the popup is a menu."
						}
					},
					{
						name: "listbox",
						description: {
							kind: "markdown",
							value: "Indicates the popup is a listbox."
						}
					},
					{
						name: "tree",
						description: {
							kind: "markdown",
							value: "Indicates the popup is a tree."
						}
					},
					{
						name: "grid",
						description: {
							kind: "markdown",
							value: "Indicates the popup is a grid."
						}
					},
					{
						name: "dialog",
						description: {
							kind: "markdown",
							value: "Indicates the popup is a dialog."
						}
					}
				]
			},
			{
				name: "decoding",
				values: [
					{ name: "sync" },
					{ name: "async" },
					{ name: "auto" }
				]
			},
			{
				name: "loading",
				values: [{
					name: "eager",
					description: {
						kind: "markdown",
						value: "Loads the image immediately, regardless of whether or not the image is currently within the visible viewport (this is the default value)."
					}
				}, {
					name: "lazy",
					description: {
						kind: "markdown",
						value: "Defers loading the image until it reaches a calculated distance from the viewport, as defined by the browser. The intent is to avoid the network and storage bandwidth needed to handle the image until it's reasonably certain that it will be needed. This generally improves the performance of the content in most typical use cases."
					}
				}]
			},
			{
				name: "referrerpolicy",
				values: [
					{ name: "no-referrer" },
					{ name: "no-referrer-when-downgrade" },
					{ name: "origin" },
					{ name: "origin-when-cross-origin" },
					{ name: "same-origin" },
					{ name: "strict-origin" },
					{ name: "strict-origin-when-cross-origin" },
					{ name: "unsafe-url" }
				]
			}
		]
	};
	var kl = class {
		constructor(e) {
			this.dataProviders = [], this.setDataProviders(!1 !== e.useDefaultDataProvider, e.customDataProviders || []);
		}
		setDataProviders(e, t) {
			this.dataProviders = [], e && this.dataProviders.push(new Is("html5", Tl)), this.dataProviders.push(...t);
		}
		getDataProviders() {
			return this.dataProviders;
		}
		isVoidElement(e, t) {
			return !!e && function(e, t, n) {
				let i = 0, r = e.length - 1;
				for (; i <= r;) {
					const a = (i + r) / 2 | 0, o = n(e[a], t);
					if (o < 0) i = a + 1;
					else {
						if (!(o > 0)) return a;
						r = a - 1;
					}
				}
				return -(i + 1);
			}(t, e.toLowerCase(), (e, t) => e.localeCompare(t)) >= 0;
		}
		getVoidElements(e) {
			const t = Array.isArray(e) ? e : this.getDataProviders().filter((t) => t.isApplicable(e)), n = [];
			return t.forEach((e) => {
				e.provideTags().filter((e) => e.void).forEach((e) => n.push(e.name));
			}), n.sort();
		}
		isPathAttribute(e, t) {
			if ("src" === t || "href" === t) return !0;
			const n = Sl[e];
			return !!n && ("string" == typeof n ? n === t : -1 !== n.indexOf(t));
		}
	};
	const Sl = {
		a: "href",
		area: "href",
		body: "background",
		blockquote: "cite",
		del: "cite",
		form: "action",
		frame: ["src", "longdesc"],
		img: ["src", "longdesc"],
		ins: "cite",
		link: "href",
		object: "data",
		q: "cite",
		script: "src",
		audio: "src",
		button: "formaction",
		command: "icon",
		embed: "src",
		html: "manifest",
		input: ["src", "formaction"],
		source: "src",
		track: "src",
		video: ["src", "poster"]
	}, Ll = {};
	function xl(e, t) {
		return new Is(e, t);
	}
	var Cl = class {
		constructor(e, t) {
			this._ctx = e, this._languageSettings = t.languageSettings, this._languageId = t.languageId;
			const n = this._languageSettings.data, i = n?.useDefaultDataProvider, r = [];
			if (n?.dataProviders) for (const a in n.dataProviders) r.push(xl(a, n.dataProviders[a]));
			this._languageService = function(e = Ll) {
				const t = new kl(e), n = new Gs(e, t), i = new Fs(e, t), r = new vs(t), a = new yl(r), o = new vl(t), s = new cl(t);
				return {
					setDataProviders: t.setDataProviders.bind(t),
					createScanner: bs,
					parseHTMLDocument: r.parseDocument.bind(r),
					doComplete: i.doComplete.bind(i),
					doComplete2: i.doComplete2.bind(i),
					setCompletionParticipants: i.setCompletionParticipants.bind(i),
					doHover: n.doHover.bind(n),
					format: Qs,
					findDocumentHighlights: hl,
					findDocumentLinks: s.findDocumentLinks.bind(s),
					findDocumentSymbols: pl,
					findDocumentSymbols2: gl,
					getFoldingRanges: o.getFoldingRanges.bind(o),
					getSelectionRanges: a.getSelectionRanges.bind(a),
					doQuoteComplete: i.doQuoteComplete.bind(i),
					doTagComplete: i.doTagComplete.bind(i),
					doRename: bl,
					findMatchingTagPosition: _l,
					findOnTypeRenameRanges: wl,
					findLinkedEditingRanges: wl
				};
			}({
				useDefaultDataProvider: i,
				customDataProviders: r
			});
		}
		async doComplete(e, t) {
			let n = this._getTextDocument(e);
			if (!n) return null;
			let i = this._languageService.parseHTMLDocument(n);
			return Promise.resolve(this._languageService.doComplete(n, t, i, this._languageSettings && this._languageSettings.suggest));
		}
		async format(e, t, n) {
			let i = this._getTextDocument(e);
			if (!i) return [];
			let r = {
				...this._languageSettings.format,
				...n
			}, a = this._languageService.format(i, t, r);
			return Promise.resolve(a);
		}
		async doHover(e, t) {
			let n = this._getTextDocument(e);
			if (!n) return null;
			let i = this._languageService.parseHTMLDocument(n), r = this._languageService.doHover(n, t, i);
			return Promise.resolve(r);
		}
		async findDocumentHighlights(e, t) {
			let n = this._getTextDocument(e);
			if (!n) return [];
			let i = this._languageService.parseHTMLDocument(n), r = this._languageService.findDocumentHighlights(n, t, i);
			return Promise.resolve(r);
		}
		async findDocumentLinks(e) {
			let t = this._getTextDocument(e);
			if (!t) return [];
			let n = this._languageService.findDocumentLinks(t, null);
			return Promise.resolve(n);
		}
		async findDocumentSymbols(e) {
			let t = this._getTextDocument(e);
			if (!t) return [];
			let n = this._languageService.parseHTMLDocument(t), i = this._languageService.findDocumentSymbols(t, n);
			return Promise.resolve(i);
		}
		async getFoldingRanges(e, t) {
			let n = this._getTextDocument(e);
			if (!n) return [];
			let i = this._languageService.getFoldingRanges(n, t);
			return Promise.resolve(i);
		}
		async getSelectionRanges(e, t) {
			let n = this._getTextDocument(e);
			if (!n) return [];
			let i = this._languageService.getSelectionRanges(n, t);
			return Promise.resolve(i);
		}
		async doRename(e, t, n) {
			let i = this._getTextDocument(e);
			if (!i) return null;
			let r = this._languageService.parseHTMLDocument(i), a = this._languageService.doRename(i, t, n, r);
			return Promise.resolve(a);
		}
		_getTextDocument(e) {
			let t = this._ctx.getMirrorModels();
			for (let n of t) if (n.uri.toString() === e) return jo.create(e, this._languageId, n.version, n.getValue());
			return null;
		}
	};
	self.onmessage = () => {
		var e = (e, t) => new Cl(e, t);
		self.onmessage = (t) => {
			pa((n) => e(n, t.data));
		};
	};
})();
