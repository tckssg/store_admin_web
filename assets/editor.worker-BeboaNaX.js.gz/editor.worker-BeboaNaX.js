(function() {
	const e = new class {
		constructor() {
			this.listeners = [], this.unexpectedErrorHandler = function(e) {
				setTimeout(() => {
					if (e.stack) {
						if (s.isErrorNoTelemetry(e)) throw new s(e.message + "\n\n" + e.stack);
						throw new Error(e.message + "\n\n" + e.stack);
					}
					throw e;
				}, 0);
			};
		}
		emit(e) {
			this.listeners.forEach((t) => {
				t(e);
			});
		}
		onUnexpectedError(e) {
			this.unexpectedErrorHandler(e), this.emit(e);
		}
		onUnexpectedExternalError(e) {
			this.unexpectedErrorHandler(e);
		}
	}();
	function t(t) {
		var n;
		(n = t) instanceof i || n instanceof Error && "Canceled" === n.name && "Canceled" === n.message || e.onUnexpectedError(t);
	}
	function n(e) {
		if (e instanceof Error) {
			const { name: t, message: r, cause: i } = e;
			return {
				$isError: !0,
				name: t,
				message: r,
				stack: e.stacktrace || e.stack,
				noTelemetry: s.isErrorNoTelemetry(e),
				cause: i ? n(i) : void 0,
				code: e.code
			};
		}
		return e;
	}
	var r, i = class extends Error {
		constructor() {
			super("Canceled"), this.name = this.message;
		}
	}, s = class e extends Error {
		constructor(e) {
			super(e), this.name = "CodeExpectedError";
		}
		static fromError(t) {
			if (t instanceof e) return t;
			const n = new e();
			return n.message = t.message, n.stack = t.stack, n;
		}
		static isErrorNoTelemetry(e) {
			return "CodeExpectedError" === e.name;
		}
	}, o = class e extends Error {
		constructor(t) {
			super(t || "An unexpected bug occurred."), Object.setPrototypeOf(this, e.prototype);
		}
	};
	function a(e, t = "Unreachable") {
		throw new Error(t);
	}
	function l(e) {
		e() || (e(), t(new o("Assertion Failed")));
	}
	function u(e, t) {
		let n = 0;
		for (; n < e.length - 1;) {
			if (!t(e[n], e[n + 1])) return !1;
			n++;
		}
		return !0;
	}
	function h(e) {
		return !!e && "function" == typeof e[Symbol.iterator];
	}
	function c(e) {
		if (r.is(e)) {
			const n = [];
			for (const r of e) if (r) try {
				r.dispose();
			} catch (t) {
				n.push(t);
			}
			if (1 === n.length) throw n[0];
			if (n.length > 1) throw new AggregateError(n, "Encountered errors while disposing of store");
			return Array.isArray(e) ? [] : e;
		}
		if (e) return e.dispose(), e;
	}
	(function(e) {
		function t(e) {
			return !!e && "object" == typeof e && "function" == typeof e[Symbol.iterator];
		}
		e.is = t;
		const n = Object.freeze([]);
		function* r(e) {
			yield e;
		}
		e.empty = function() {
			return n;
		}, e.single = r, e.wrap = function(e) {
			return t(e) ? e : r(e);
		}, e.from = function(e) {
			return e || n;
		}, e.reverse = function* (e) {
			for (let t = e.length - 1; t >= 0; t--) yield e[t];
		}, e.isEmpty = function(e) {
			return !e || !0 === e[Symbol.iterator]().next().done;
		}, e.first = function(e) {
			return e[Symbol.iterator]().next().value;
		}, e.some = function(e, t) {
			let n = 0;
			for (const r of e) if (t(r, n++)) return !0;
			return !1;
		}, e.every = function(e, t) {
			let n = 0;
			for (const r of e) if (!t(r, n++)) return !1;
			return !0;
		}, e.find = function(e, t) {
			for (const n of e) if (t(n)) return n;
		}, e.filter = function* (e, t) {
			for (const n of e) t(n) && (yield n);
		}, e.map = function* (e, t) {
			let n = 0;
			for (const r of e) yield t(r, n++);
		}, e.flatMap = function* (e, t) {
			let n = 0;
			for (const r of e) yield* t(r, n++);
		}, e.concat = function* (...e) {
			for (const t of e) h(t) ? yield* t : yield t;
		}, e.reduce = function(e, t, n) {
			let r = n;
			for (const i of e) r = t(r, i);
			return r;
		}, e.length = function(e) {
			let t = 0;
			for (const n of e) t++;
			return t;
		}, e.slice = function* (e, t, n = e.length) {
			for (t < -e.length && (t = 0), t < 0 && (t += e.length), n < 0 ? n += e.length : n > e.length && (n = e.length); t < n; t++) yield e[t];
		}, e.consume = function(t, n = Number.POSITIVE_INFINITY) {
			const r = [];
			if (0 === n) return [r, t];
			const i = t[Symbol.iterator]();
			for (let s = 0; s < n; s++) {
				const t = i.next();
				if (t.done) return [r, e.empty()];
				r.push(t.value);
			}
			return [r, { [Symbol.iterator]: () => i }];
		}, e.asyncToArray = async function(e) {
			const t = [];
			for await (const n of e) t.push(n);
			return t;
		}, e.asyncToArrayFlat = async function(e) {
			let t = [];
			for await (const n of e) t = t.concat(n);
			return t;
		};
	})(r || (r = {}));
	var d = class {
		constructor(e) {
			this._isDisposed = !1, this._fn = e;
		}
		dispose() {
			if (!this._isDisposed) {
				if (!this._fn) throw new Error("Unbound disposable context: Need to use an arrow function to preserve the value of this");
				this._isDisposed = !0, this._fn();
			}
		}
	};
	function g(e) {
		return new d(e);
	}
	var m = class e {
		static {
			this.DISABLE_DISPOSED_WARNING = !1;
		}
		constructor() {
			this._toDispose = /* @__PURE__ */ new Set(), this._isDisposed = !1;
		}
		dispose() {
			this._isDisposed || (this._isDisposed = !0, this.clear());
		}
		get isDisposed() {
			return this._isDisposed;
		}
		clear() {
			if (0 !== this._toDispose.size) try {
				c(this._toDispose);
			} finally {
				this._toDispose.clear();
			}
		}
		add(t) {
			if (!t || t === f.None) return t;
			if (t === this) throw new Error("Cannot register a disposable on itself!");
			return this._isDisposed ? e.DISABLE_DISPOSED_WARNING : this._toDispose.add(t), t;
		}
		delete(e) {
			if (e) {
				if (e === this) throw new Error("Cannot dispose a disposable on itself!");
				this._toDispose.delete(e), e.dispose();
			}
		}
	}, f = class {
		static {
			this.None = Object.freeze({ dispose() {} });
		}
		constructor() {
			this._store = new m(), this._store;
		}
		dispose() {
			this._store.dispose();
		}
		_register(e) {
			if (e === this) throw new Error("Cannot register a disposable on itself!");
			return this._store.add(e);
		}
	}, p = class e {
		static {
			this.Undefined = new e(void 0);
		}
		constructor(t) {
			this.element = t, this.next = e.Undefined, this.prev = e.Undefined;
		}
	}, b = class {
		constructor() {
			this._first = p.Undefined, this._last = p.Undefined, this._size = 0;
		}
		get size() {
			return this._size;
		}
		isEmpty() {
			return this._first === p.Undefined;
		}
		clear() {
			let e = this._first;
			for (; e !== p.Undefined;) {
				const t = e.next;
				e.prev = p.Undefined, e.next = p.Undefined, e = t;
			}
			this._first = p.Undefined, this._last = p.Undefined, this._size = 0;
		}
		unshift(e) {
			return this._insert(e, !1);
		}
		push(e) {
			return this._insert(e, !0);
		}
		_insert(e, t) {
			const n = new p(e);
			if (this._first === p.Undefined) this._first = n, this._last = n;
			else if (t) {
				const e = this._last;
				this._last = n, n.prev = e, e.next = n;
			} else {
				const e = this._first;
				this._first = n, n.next = e, e.prev = n;
			}
			this._size += 1;
			let r = !1;
			return () => {
				r || (r = !0, this._remove(n));
			};
		}
		shift() {
			if (this._first !== p.Undefined) {
				const e = this._first.element;
				return this._remove(this._first), e;
			}
		}
		pop() {
			if (this._last !== p.Undefined) {
				const e = this._last.element;
				return this._remove(this._last), e;
			}
		}
		_remove(e) {
			if (e.prev !== p.Undefined && e.next !== p.Undefined) {
				const t = e.prev;
				t.next = e.next, e.next.prev = t;
			} else e.prev === p.Undefined && e.next === p.Undefined ? (this._first = p.Undefined, this._last = p.Undefined) : e.next === p.Undefined ? (this._last = this._last.prev, this._last.next = p.Undefined) : e.prev === p.Undefined && (this._first = this._first.next, this._first.prev = p.Undefined);
			this._size -= 1;
		}
		*[Symbol.iterator]() {
			let e = this._first;
			for (; e !== p.Undefined;) yield e.element, e = e.next;
		}
	};
	const w = globalThis.performance.now.bind(globalThis.performance);
	var _, C = class e {
		static create(t) {
			return new e(t);
		}
		constructor(e) {
			this._now = !1 === e ? Date.now : w, this._startTime = this._now(), this._stopTime = -1;
		}
		stop() {
			this._stopTime = this._now();
		}
		reset() {
			this._startTime = this._now(), this._stopTime = -1;
		}
		elapsed() {
			return -1 !== this._stopTime ? this._stopTime - this._startTime : this._now() - this._startTime;
		}
	};
	(function(e) {
		function t(e) {
			return (t, n = null, r) => {
				let i, s = !1;
				return i = e((e) => {
					if (!s) return i ? i.dispose() : s = !0, t.call(n, e);
				}, null, r), s && i.dispose(), i;
			};
		}
		function n(e, t, n) {
			return i((n, r = null, i) => e((e) => n.call(r, t(e)), null, i), n);
		}
		function r(e, t, n) {
			return i((n, r = null, i) => e((e) => t(e) && n.call(r, e), null, i), n);
		}
		function i(e, t) {
			let n;
			const r = new R({
				onWillAddFirstListener() {
					n = e(r.fire, r);
				},
				onDidRemoveLastListener() {
					n?.dispose();
				}
			});
			return t?.add(r), r.event;
		}
		function s(e, t, n = 100, r = !1, i = !1, s, o) {
			let a, l, u, h, c = 0;
			const d = new R({
				leakWarningThreshold: s,
				onWillAddFirstListener() {
					a = e((e) => {
						c++, l = t(l, e), r && !u && (d.fire(l), l = void 0), h = () => {
							const e = l;
							l = void 0, u = void 0, (!r || c > 1) && d.fire(e), c = 0;
						}, "number" == typeof n ? (u && clearTimeout(u), u = setTimeout(h, n)) : void 0 === u && (u = null, queueMicrotask(h));
					});
				},
				onWillRemoveListener() {
					i && c > 0 && h?.();
				},
				onDidRemoveLastListener() {
					h = void 0, a.dispose();
				}
			});
			return o?.add(d), d.event;
		}
		e.None = () => f.None, e.defer = function(e, t) {
			return s(e, () => {}, 0, void 0, !0, void 0, t);
		}, e.once = t, e.onceIf = function(t, n) {
			return e.once(e.filter(t, n));
		}, e.map = n, e.forEach = function(e, t, n) {
			return i((n, r = null, i) => e((e) => {
				t(e), n.call(r, e);
			}, null, i), n);
		}, e.filter = r, e.signal = function(e) {
			return e;
		}, e.any = function(...e) {
			return (t, n = null, r) => function(e, t) {
				t instanceof Array ? t.push(e) : t && t.add(e);
				return e;
			}(function(...e) {
				return g(() => c(e));
			}(...e.map((e) => e((e) => t.call(n, e)))), r);
		}, e.reduce = function(e, t, r, i) {
			let s = r;
			return n(e, (e) => (s = t(s, e), s), i);
		}, e.debounce = s, e.accumulate = function(t, n = 0, r) {
			return e.debounce(t, (e, t) => e ? (e.push(t), e) : [t], n, void 0, !0, void 0, r);
		}, e.latch = function(e, t = (e, t) => e === t, n) {
			let i, s = !0;
			return r(e, (e) => {
				const n = s || !t(e, i);
				return s = !1, i = e, n;
			}, n);
		}, e.split = function(t, n, r) {
			return [e.filter(t, n, r), e.filter(t, (e) => !n(e), r)];
		}, e.buffer = function(e, t = !1, n = [], r) {
			let i = n.slice(), s = e((e) => {
				i ? i.push(e) : a.fire(e);
			});
			r && r.add(s);
			const o = () => {
				i?.forEach((e) => a.fire(e)), i = null;
			}, a = new R({
				onWillAddFirstListener() {
					s || (s = e((e) => a.fire(e)), r && r.add(s));
				},
				onDidAddFirstListener() {
					i && (t ? setTimeout(o) : o());
				},
				onDidRemoveLastListener() {
					s && s.dispose(), s = null;
				}
			});
			return r && r.add(a), a.event;
		}, e.chain = function(e, t) {
			return (n, r, i) => {
				const s = t(new a());
				return e(function(e) {
					const t = s.evaluate(e);
					t !== o && n.call(r, t);
				}, void 0, i);
			};
		};
		const o = Symbol("HaltChainable");
		class a {
			constructor() {
				this.steps = [];
			}
			map(e) {
				return this.steps.push(e), this;
			}
			forEach(e) {
				return this.steps.push((t) => (e(t), t)), this;
			}
			filter(e) {
				return this.steps.push((t) => e(t) ? t : o), this;
			}
			reduce(e, t) {
				let n = t;
				return this.steps.push((t) => (n = e(n, t), n)), this;
			}
			latch(e = (e, t) => e === t) {
				let t, n = !0;
				return this.steps.push((r) => {
					const i = n || !e(r, t);
					return n = !1, t = r, i ? r : o;
				}), this;
			}
			evaluate(e) {
				for (const t of this.steps) if ((e = t(e)) === o) break;
				return e;
			}
		}
		e.fromNodeEventEmitter = function(e, t, n = (e) => e) {
			const r = (...e) => i.fire(n(...e)), i = new R({
				onWillAddFirstListener: () => e.on(t, r),
				onDidRemoveLastListener: () => e.removeListener(t, r)
			});
			return i.event;
		}, e.fromDOMEventEmitter = function(e, t, n = (e) => e) {
			const r = (...e) => i.fire(n(...e)), i = new R({
				onWillAddFirstListener: () => e.addEventListener(t, r),
				onDidRemoveLastListener: () => e.removeEventListener(t, r)
			});
			return i.event;
		}, e.toPromise = function(e, n) {
			let r;
			const i = new Promise((i, s) => {
				const o = t(e)(i, null, n);
				r = () => o.dispose();
			});
			return i.cancel = r, i;
		}, e.forward = function(e, t) {
			return e((e) => t.fire(e));
		}, e.runAndSubscribe = function(e, t, n) {
			return t(n), e((e) => t(e));
		};
		class l {
			constructor(e, t) {
				this._observable = e, this._counter = 0, this._hasChanged = !1, this.emitter = new R({
					onWillAddFirstListener: () => {
						e.addObserver(this), this._observable.reportChanges();
					},
					onDidRemoveLastListener: () => {
						e.removeObserver(this);
					}
				}), t && t.add(this.emitter);
			}
			beginUpdate(e) {
				this._counter++;
			}
			handlePossibleChange(e) {}
			handleChange(e, t) {
				this._hasChanged = !0;
			}
			endUpdate(e) {
				this._counter--, 0 === this._counter && (this._observable.reportChanges(), this._hasChanged && (this._hasChanged = !1, this.emitter.fire(this._observable.get())));
			}
		}
		e.fromObservable = function(e, t) {
			return new l(e, t).emitter.event;
		}, e.fromObservableLight = function(e) {
			return (t, n, r) => {
				let i = 0, s = !1;
				const o = {
					beginUpdate() {
						i++;
					},
					endUpdate() {
						i--, 0 === i && (e.reportChanges(), s && (s = !1, t.call(n)));
					},
					handlePossibleChange() {},
					handleChange() {
						s = !0;
					}
				};
				e.addObserver(o), e.reportChanges();
				const a = { dispose() {
					e.removeObserver(o);
				} };
				return r instanceof m ? r.add(a) : Array.isArray(r) && r.push(a), a;
			};
		};
	})(_ || (_ = {}));
	var y = class e {
		static {
			this.all = /* @__PURE__ */ new Set();
		}
		static {
			this._idPool = 0;
		}
		constructor(t) {
			this.listenerCount = 0, this.invocationCount = 0, this.elapsedOverall = 0, this.durations = [], this.name = `${t}_${e._idPool++}`, e.all.add(this);
		}
		start(e) {
			this._stopWatch = new C(), this.listenerCount = e;
		}
		stop() {
			if (this._stopWatch) {
				const e = this._stopWatch.elapsed();
				this.durations.push(e), this.elapsedOverall += e, this.invocationCount += 1, this._stopWatch = void 0;
			}
		}
	};
	var v = class e {
		static {
			this._idPool = 1;
		}
		constructor(t, n, r = (e._idPool++).toString(16).padStart(3, "0")) {
			this._errorHandler = t, this.threshold = n, this.name = r, this._warnCountdown = 0;
		}
		dispose() {
			this._stacks?.clear();
		}
		check(e, t) {
			const n = this.threshold;
			if (n <= 0 || t < n) return;
			this._stacks || (this._stacks = /* @__PURE__ */ new Map());
			const r = this._stacks.get(e.value) || 0;
			if (this._stacks.set(e.value, r + 1), this._warnCountdown -= 1, this._warnCountdown <= 0) {
				this._warnCountdown = .5 * n;
				const [e, r] = this.getMostFrequentStack(), s = new N(`[${this.name}] potential listener LEAK detected, having ${t} listeners already. MOST frequent listener (${r}):`, e);
				this._errorHandler(s);
			}
			return () => {
				const t = this._stacks.get(e.value) || 0;
				this._stacks.set(e.value, t - 1);
			};
		}
		getMostFrequentStack() {
			if (!this._stacks) return;
			let e, t = 0;
			for (const [n, r] of this._stacks) (!e || t < r) && (e = [n, r], t = r);
			return e;
		}
	}, L = class e {
		static create() {
			return new e((/* @__PURE__ */ new Error()).stack ?? "");
		}
		constructor(e) {
			this.value = e;
		}
		print() {}
	}, N = class extends Error {
		constructor(e, t) {
			super(e), this.name = "ListenerLeakError", this.stack = t;
		}
	}, E = class extends Error {
		constructor(e, t) {
			super(e), this.name = "ListenerRefusalError", this.stack = t;
		}
	}, S = class {
		constructor(e) {
			this.value = e;
		}
	};
	var R = class {
		constructor(e) {
			this._size = 0, this._options = e, this._leakageMon = this._options?.leakWarningThreshold ? new v(e?.onListenerError ?? t, this._options?.leakWarningThreshold ?? -1) : void 0, this._perfMon = this._options?._profName ? new y(this._options._profName) : void 0, this._deliveryQueue = this._options?.deliveryQueue;
		}
		dispose() {
			this._disposed || (this._disposed = !0, this._deliveryQueue?.current === this && this._deliveryQueue.reset(), this._listeners && (this._listeners = void 0, this._size = 0), this._options?.onDidRemoveLastListener?.(), this._leakageMon?.dispose());
		}
		get event() {
			return this._event ??= (e, n, r) => {
				if (this._leakageMon && this._size > this._leakageMon.threshold ** 2) {
					const e = `[${this._leakageMon.name}] REFUSES to accept new listeners because it exceeded its threshold by far (${this._size} vs ${this._leakageMon.threshold})`, n = this._leakageMon.getMostFrequentStack() ?? ["UNKNOWN stack", -1], r = new E(`${e}. HINT: Stack shows most frequent listener (${n[1]}-times)`, n[0]);
					return (this._options?.onListenerError || t)(r), f.None;
				}
				if (this._disposed) return f.None;
				n && (e = e.bind(n));
				const i = new S(e);
				let s;
				this._leakageMon && this._size >= Math.ceil(.2 * this._leakageMon.threshold) && (i.stack = L.create(), s = this._leakageMon.check(i.stack, this._size + 1)), this._listeners ? this._listeners instanceof S ? (this._deliveryQueue ??= new x(), this._listeners = [this._listeners, i]) : this._listeners.push(i) : (this._options?.onWillAddFirstListener?.(this), this._listeners = i, this._options?.onDidAddFirstListener?.(this)), this._options?.onDidAddListener?.(this), this._size++;
				const o = g(() => {
					s?.(), this._removeListener(i);
				});
				return r instanceof m ? r.add(o) : Array.isArray(r) && r.push(o), o;
			}, this._event;
		}
		_removeListener(e) {
			if (this._options?.onWillRemoveListener?.(this), !this._listeners) return;
			if (1 === this._size) return this._listeners = void 0, this._options?.onDidRemoveLastListener?.(this), void (this._size = 0);
			const t = this._listeners, n = t.indexOf(e);
			if (-1 === n) throw new Error("Attempted to dispose unknown listener");
			this._size--, t[n] = void 0;
			const r = this._deliveryQueue.current === this;
			if (2 * this._size <= t.length) {
				let e = 0;
				for (let n = 0; n < t.length; n++) t[n] ? t[e++] = t[n] : r && e < this._deliveryQueue.end && (this._deliveryQueue.end--, e < this._deliveryQueue.i && this._deliveryQueue.i--);
				t.length = e;
			}
		}
		_deliver(e, n) {
			if (!e) return;
			const r = this._options?.onListenerError || t;
			if (r) try {
				e.value(n);
			} catch (i) {
				r(i);
			}
			else e.value(n);
		}
		_deliverQueue(e) {
			const t = e.current._listeners;
			for (; e.i < e.end;) this._deliver(t[e.i++], e.value);
			e.reset();
		}
		fire(e) {
			if (this._deliveryQueue?.current && (this._deliverQueue(this._deliveryQueue), this._perfMon?.stop()), this._perfMon?.start(this._size), this._listeners) if (this._listeners instanceof S) this._deliver(this._listeners, e);
			else {
				const t = this._deliveryQueue;
				t.enqueue(this, e, this._listeners.length), this._deliverQueue(t);
			}
			this._perfMon?.stop();
		}
		hasListeners() {
			return this._size > 0;
		}
	}, x = class {
		constructor() {
			this.i = -1, this.end = 0;
		}
		enqueue(e, t, n) {
			this.i = 0, this.end = n, this.current = e, this.value = t;
		}
		reset() {
			this.i = this.end, this.current = void 0, this.value = void 0;
		}
	};
	function A() {
		return globalThis._VSCODE_NLS_LANGUAGE;
	}
	const k = "pseudo" === A() || "undefined" != typeof document && document.location && "string" == typeof document.location.hash && document.location.hash.indexOf("pseudo=true") >= 0;
	function M(e, t) {
		let n;
		return n = 0 === t.length ? e : e.replace(/\{(\d+)\}/g, (e, n) => {
			const r = t[n[0]];
			let i = e;
			return "string" == typeof r ? i = r : "number" != typeof r && "boolean" != typeof r && null != r || (i = String(r)), i;
		}), k && (n = "［" + n.replace(/[aouei]/g, "$&$&") + "］"), n;
	}
	function O(e, t, ...n) {
		return M("number" == typeof e ? function(e, t) {
			const n = globalThis._VSCODE_NLS_MESSAGES?.[e];
			if ("string" != typeof n) {
				if ("string" == typeof t) return t;
				throw new Error(`!!! NLS MISSING: ${e} !!!`);
			}
			return n;
		}(e, t) : t, n);
	}
	let I, T = !1, P = !1, F = !1, q = !1;
	const U = globalThis;
	let $;
	void 0 !== U.vscode && void 0 !== U.vscode.process ? $ = U.vscode.process : "undefined" != typeof process && "string" == typeof process?.versions?.node && ($ = process);
	const W = "string" == typeof $?.versions?.electron && "renderer" === $?.type;
	if ("object" == typeof $) {
		T = "win32" === $.platform, P = "darwin" === $.platform, F = "linux" === $.platform, F && $.env.SNAP && $.env.SNAP_REVISION, $.env.CI || $.env.BUILD_ARTIFACTSTAGINGDIRECTORY || $.env.GITHUB_WORKSPACE;
		const e = $.env.VSCODE_NLS_CONFIG;
		if (e) try {
			const t = JSON.parse(e);
			t.userLocale, t.osLocale, t.resolvedLanguage, t.languagePack;
		} catch (fs) {}
	} else "object" != typeof navigator || W || (I = navigator.userAgent, T = I.indexOf("Windows") >= 0, P = I.indexOf("Macintosh") >= 0, (I.indexOf("Macintosh") >= 0 || I.indexOf("iPad") >= 0 || I.indexOf("iPhone") >= 0) && navigator.maxTouchPoints && navigator.maxTouchPoints, F = I.indexOf("Linux") >= 0, I?.indexOf("Mobi"), q = !0, A(), navigator.language.toLowerCase());
	const H = T, j = P, G = (q && "function" == typeof U.importScripts && U.origin, I), X = "function" == typeof U.postMessage && !U.importScripts;
	(() => {
		if (X) {
			const e = [];
			U.addEventListener("message", (t) => {
				if (t.data && t.data.vscodeScheduleAsyncWork) for (let n = 0, r = e.length; n < r; n++) {
					const r = e[n];
					if (r.id === t.data.vscodeScheduleAsyncWork) return e.splice(n, 1), void r.callback();
				}
			});
			let t = 0;
			return (n) => {
				const r = ++t;
				e.push({
					id: r,
					callback: n
				}), U.postMessage({ vscodeScheduleAsyncWork: r }, "*");
			};
		}
		return (e) => setTimeout(e);
	})();
	const Y = !!(G && G.indexOf("Chrome") >= 0);
	G && G.indexOf("Firefox"), !Y && G && G.indexOf("Safari"), G && G.indexOf("Edg/"), G && G.indexOf("Android");
	function J(e) {
		return e;
	}
	var Z, ee = class {
		constructor(e, t) {
			this.lastCache = void 0, this.lastArgKey = void 0, "function" == typeof e ? (this._fn = e, this._computeKey = J) : (this._fn = t, this._computeKey = e.getCacheKey);
		}
		get(e) {
			const t = this._computeKey(e);
			return this.lastArgKey !== t && (this.lastArgKey = t, this.lastCache = this._fn(e)), this.lastCache;
		}
	};
	(function(e) {
		e[e.Uninitialized = 0] = "Uninitialized", e[e.Running = 1] = "Running", e[e.Completed = 2] = "Completed";
	})(Z || (Z = {}));
	var te = class {
		constructor(e) {
			this.executor = e, this._state = Z.Uninitialized;
		}
		get value() {
			if (this._state === Z.Uninitialized) {
				this._state = Z.Running;
				try {
					this._value = this.executor();
				} catch (e) {
					this._error = e;
				} finally {
					this._state = Z.Completed;
				}
			} else if (this._state === Z.Running) throw new Error("Cannot read the value of a lazy that is being initialized");
			if (this._error) throw this._error;
			return this._value;
		}
		get rawValue() {
			return this._value;
		}
	};
	function ne(e) {
		return e >= 65 && e <= 90;
	}
	function re(e) {
		return 55296 <= e && e <= 56319;
	}
	function ie(e) {
		return 56320 <= e && e <= 57343;
	}
	function se(e, t) {
		return t - 56320 + (e - 55296 << 10) + 65536;
	}
	function oe(e, t, n) {
		const r = e.charCodeAt(n);
		if (re(r) && n + 1 < t) {
			const t = e.charCodeAt(n + 1);
			if (ie(t)) return se(r, t);
		}
		return r;
	}
	const ae = /^[\t\n\r\x20-\x7E]*$/;
	function le(e) {
		return ae.test(e);
	}
	(class e {
		static {
			this._INSTANCE = null;
		}
		static getInstance() {
			return e._INSTANCE || (e._INSTANCE = new e()), e._INSTANCE;
		}
		constructor() {
			this._data = JSON.parse("[0,0,0,51229,51255,12,44061,44087,12,127462,127487,6,7083,7085,5,47645,47671,12,54813,54839,12,128678,128678,14,3270,3270,5,9919,9923,14,45853,45879,12,49437,49463,12,53021,53047,12,71216,71218,7,128398,128399,14,129360,129374,14,2519,2519,5,4448,4519,9,9742,9742,14,12336,12336,14,44957,44983,12,46749,46775,12,48541,48567,12,50333,50359,12,52125,52151,12,53917,53943,12,69888,69890,5,73018,73018,5,127990,127990,14,128558,128559,14,128759,128760,14,129653,129655,14,2027,2035,5,2891,2892,7,3761,3761,5,6683,6683,5,8293,8293,4,9825,9826,14,9999,9999,14,43452,43453,5,44509,44535,12,45405,45431,12,46301,46327,12,47197,47223,12,48093,48119,12,48989,49015,12,49885,49911,12,50781,50807,12,51677,51703,12,52573,52599,12,53469,53495,12,54365,54391,12,65279,65279,4,70471,70472,7,72145,72147,7,119173,119179,5,127799,127818,14,128240,128244,14,128512,128512,14,128652,128652,14,128721,128722,14,129292,129292,14,129445,129450,14,129734,129743,14,1476,1477,5,2366,2368,7,2750,2752,7,3076,3076,5,3415,3415,5,4141,4144,5,6109,6109,5,6964,6964,5,7394,7400,5,9197,9198,14,9770,9770,14,9877,9877,14,9968,9969,14,10084,10084,14,43052,43052,5,43713,43713,5,44285,44311,12,44733,44759,12,45181,45207,12,45629,45655,12,46077,46103,12,46525,46551,12,46973,46999,12,47421,47447,12,47869,47895,12,48317,48343,12,48765,48791,12,49213,49239,12,49661,49687,12,50109,50135,12,50557,50583,12,51005,51031,12,51453,51479,12,51901,51927,12,52349,52375,12,52797,52823,12,53245,53271,12,53693,53719,12,54141,54167,12,54589,54615,12,55037,55063,12,69506,69509,5,70191,70193,5,70841,70841,7,71463,71467,5,72330,72342,5,94031,94031,5,123628,123631,5,127763,127765,14,127941,127941,14,128043,128062,14,128302,128317,14,128465,128467,14,128539,128539,14,128640,128640,14,128662,128662,14,128703,128703,14,128745,128745,14,129004,129007,14,129329,129330,14,129402,129402,14,129483,129483,14,129686,129704,14,130048,131069,14,173,173,4,1757,1757,1,2200,2207,5,2434,2435,7,2631,2632,5,2817,2817,5,3008,3008,5,3201,3201,5,3387,3388,5,3542,3542,5,3902,3903,7,4190,4192,5,6002,6003,5,6439,6440,5,6765,6770,7,7019,7027,5,7154,7155,7,8205,8205,13,8505,8505,14,9654,9654,14,9757,9757,14,9792,9792,14,9852,9853,14,9890,9894,14,9937,9937,14,9981,9981,14,10035,10036,14,11035,11036,14,42654,42655,5,43346,43347,7,43587,43587,5,44006,44007,7,44173,44199,12,44397,44423,12,44621,44647,12,44845,44871,12,45069,45095,12,45293,45319,12,45517,45543,12,45741,45767,12,45965,45991,12,46189,46215,12,46413,46439,12,46637,46663,12,46861,46887,12,47085,47111,12,47309,47335,12,47533,47559,12,47757,47783,12,47981,48007,12,48205,48231,12,48429,48455,12,48653,48679,12,48877,48903,12,49101,49127,12,49325,49351,12,49549,49575,12,49773,49799,12,49997,50023,12,50221,50247,12,50445,50471,12,50669,50695,12,50893,50919,12,51117,51143,12,51341,51367,12,51565,51591,12,51789,51815,12,52013,52039,12,52237,52263,12,52461,52487,12,52685,52711,12,52909,52935,12,53133,53159,12,53357,53383,12,53581,53607,12,53805,53831,12,54029,54055,12,54253,54279,12,54477,54503,12,54701,54727,12,54925,54951,12,55149,55175,12,68101,68102,5,69762,69762,7,70067,70069,7,70371,70378,5,70720,70721,7,71087,71087,5,71341,71341,5,71995,71996,5,72249,72249,7,72850,72871,5,73109,73109,5,118576,118598,5,121505,121519,5,127245,127247,14,127568,127569,14,127777,127777,14,127872,127891,14,127956,127967,14,128015,128016,14,128110,128172,14,128259,128259,14,128367,128368,14,128424,128424,14,128488,128488,14,128530,128532,14,128550,128551,14,128566,128566,14,128647,128647,14,128656,128656,14,128667,128673,14,128691,128693,14,128715,128715,14,128728,128732,14,128752,128752,14,128765,128767,14,129096,129103,14,129311,129311,14,129344,129349,14,129394,129394,14,129413,129425,14,129466,129471,14,129511,129535,14,129664,129666,14,129719,129722,14,129760,129767,14,917536,917631,5,13,13,2,1160,1161,5,1564,1564,4,1807,1807,1,2085,2087,5,2307,2307,7,2382,2383,7,2497,2500,5,2563,2563,7,2677,2677,5,2763,2764,7,2879,2879,5,2914,2915,5,3021,3021,5,3142,3144,5,3263,3263,5,3285,3286,5,3398,3400,7,3530,3530,5,3633,3633,5,3864,3865,5,3974,3975,5,4155,4156,7,4229,4230,5,5909,5909,7,6078,6085,7,6277,6278,5,6451,6456,7,6744,6750,5,6846,6846,5,6972,6972,5,7074,7077,5,7146,7148,7,7222,7223,5,7416,7417,5,8234,8238,4,8417,8417,5,9000,9000,14,9203,9203,14,9730,9731,14,9748,9749,14,9762,9763,14,9776,9783,14,9800,9811,14,9831,9831,14,9872,9873,14,9882,9882,14,9900,9903,14,9929,9933,14,9941,9960,14,9974,9974,14,9989,9989,14,10006,10006,14,10062,10062,14,10160,10160,14,11647,11647,5,12953,12953,14,43019,43019,5,43232,43249,5,43443,43443,5,43567,43568,7,43696,43696,5,43765,43765,7,44013,44013,5,44117,44143,12,44229,44255,12,44341,44367,12,44453,44479,12,44565,44591,12,44677,44703,12,44789,44815,12,44901,44927,12,45013,45039,12,45125,45151,12,45237,45263,12,45349,45375,12,45461,45487,12,45573,45599,12,45685,45711,12,45797,45823,12,45909,45935,12,46021,46047,12,46133,46159,12,46245,46271,12,46357,46383,12,46469,46495,12,46581,46607,12,46693,46719,12,46805,46831,12,46917,46943,12,47029,47055,12,47141,47167,12,47253,47279,12,47365,47391,12,47477,47503,12,47589,47615,12,47701,47727,12,47813,47839,12,47925,47951,12,48037,48063,12,48149,48175,12,48261,48287,12,48373,48399,12,48485,48511,12,48597,48623,12,48709,48735,12,48821,48847,12,48933,48959,12,49045,49071,12,49157,49183,12,49269,49295,12,49381,49407,12,49493,49519,12,49605,49631,12,49717,49743,12,49829,49855,12,49941,49967,12,50053,50079,12,50165,50191,12,50277,50303,12,50389,50415,12,50501,50527,12,50613,50639,12,50725,50751,12,50837,50863,12,50949,50975,12,51061,51087,12,51173,51199,12,51285,51311,12,51397,51423,12,51509,51535,12,51621,51647,12,51733,51759,12,51845,51871,12,51957,51983,12,52069,52095,12,52181,52207,12,52293,52319,12,52405,52431,12,52517,52543,12,52629,52655,12,52741,52767,12,52853,52879,12,52965,52991,12,53077,53103,12,53189,53215,12,53301,53327,12,53413,53439,12,53525,53551,12,53637,53663,12,53749,53775,12,53861,53887,12,53973,53999,12,54085,54111,12,54197,54223,12,54309,54335,12,54421,54447,12,54533,54559,12,54645,54671,12,54757,54783,12,54869,54895,12,54981,55007,12,55093,55119,12,55243,55291,10,66045,66045,5,68325,68326,5,69688,69702,5,69817,69818,5,69957,69958,7,70089,70092,5,70198,70199,5,70462,70462,5,70502,70508,5,70750,70750,5,70846,70846,7,71100,71101,5,71230,71230,7,71351,71351,5,71737,71738,5,72000,72000,7,72160,72160,5,72273,72278,5,72752,72758,5,72882,72883,5,73031,73031,5,73461,73462,7,94192,94193,7,119149,119149,7,121403,121452,5,122915,122916,5,126980,126980,14,127358,127359,14,127535,127535,14,127759,127759,14,127771,127771,14,127792,127793,14,127825,127867,14,127897,127899,14,127945,127945,14,127985,127986,14,128000,128007,14,128021,128021,14,128066,128100,14,128184,128235,14,128249,128252,14,128266,128276,14,128335,128335,14,128379,128390,14,128407,128419,14,128444,128444,14,128481,128481,14,128499,128499,14,128526,128526,14,128536,128536,14,128543,128543,14,128556,128556,14,128564,128564,14,128577,128580,14,128643,128645,14,128649,128649,14,128654,128654,14,128660,128660,14,128664,128664,14,128675,128675,14,128686,128689,14,128695,128696,14,128705,128709,14,128717,128719,14,128725,128725,14,128736,128741,14,128747,128748,14,128755,128755,14,128762,128762,14,128981,128991,14,129009,129023,14,129160,129167,14,129296,129304,14,129320,129327,14,129340,129342,14,129356,129356,14,129388,129392,14,129399,129400,14,129404,129407,14,129432,129442,14,129454,129455,14,129473,129474,14,129485,129487,14,129648,129651,14,129659,129660,14,129671,129679,14,129709,129711,14,129728,129730,14,129751,129753,14,129776,129782,14,917505,917505,4,917760,917999,5,10,10,3,127,159,4,768,879,5,1471,1471,5,1536,1541,1,1648,1648,5,1767,1768,5,1840,1866,5,2070,2073,5,2137,2139,5,2274,2274,1,2363,2363,7,2377,2380,7,2402,2403,5,2494,2494,5,2507,2508,7,2558,2558,5,2622,2624,7,2641,2641,5,2691,2691,7,2759,2760,5,2786,2787,5,2876,2876,5,2881,2884,5,2901,2902,5,3006,3006,5,3014,3016,7,3072,3072,5,3134,3136,5,3157,3158,5,3260,3260,5,3266,3266,5,3274,3275,7,3328,3329,5,3391,3392,7,3405,3405,5,3457,3457,5,3536,3537,7,3551,3551,5,3636,3642,5,3764,3772,5,3895,3895,5,3967,3967,7,3993,4028,5,4146,4151,5,4182,4183,7,4226,4226,5,4253,4253,5,4957,4959,5,5940,5940,7,6070,6070,7,6087,6088,7,6158,6158,4,6432,6434,5,6448,6449,7,6679,6680,5,6742,6742,5,6754,6754,5,6783,6783,5,6912,6915,5,6966,6970,5,6978,6978,5,7042,7042,7,7080,7081,5,7143,7143,7,7150,7150,7,7212,7219,5,7380,7392,5,7412,7412,5,8203,8203,4,8232,8232,4,8265,8265,14,8400,8412,5,8421,8432,5,8617,8618,14,9167,9167,14,9200,9200,14,9410,9410,14,9723,9726,14,9733,9733,14,9745,9745,14,9752,9752,14,9760,9760,14,9766,9766,14,9774,9774,14,9786,9786,14,9794,9794,14,9823,9823,14,9828,9828,14,9833,9850,14,9855,9855,14,9875,9875,14,9880,9880,14,9885,9887,14,9896,9897,14,9906,9916,14,9926,9927,14,9935,9935,14,9939,9939,14,9962,9962,14,9972,9972,14,9978,9978,14,9986,9986,14,9997,9997,14,10002,10002,14,10017,10017,14,10055,10055,14,10071,10071,14,10133,10135,14,10548,10549,14,11093,11093,14,12330,12333,5,12441,12442,5,42608,42610,5,43010,43010,5,43045,43046,5,43188,43203,7,43302,43309,5,43392,43394,5,43446,43449,5,43493,43493,5,43571,43572,7,43597,43597,7,43703,43704,5,43756,43757,5,44003,44004,7,44009,44010,7,44033,44059,12,44089,44115,12,44145,44171,12,44201,44227,12,44257,44283,12,44313,44339,12,44369,44395,12,44425,44451,12,44481,44507,12,44537,44563,12,44593,44619,12,44649,44675,12,44705,44731,12,44761,44787,12,44817,44843,12,44873,44899,12,44929,44955,12,44985,45011,12,45041,45067,12,45097,45123,12,45153,45179,12,45209,45235,12,45265,45291,12,45321,45347,12,45377,45403,12,45433,45459,12,45489,45515,12,45545,45571,12,45601,45627,12,45657,45683,12,45713,45739,12,45769,45795,12,45825,45851,12,45881,45907,12,45937,45963,12,45993,46019,12,46049,46075,12,46105,46131,12,46161,46187,12,46217,46243,12,46273,46299,12,46329,46355,12,46385,46411,12,46441,46467,12,46497,46523,12,46553,46579,12,46609,46635,12,46665,46691,12,46721,46747,12,46777,46803,12,46833,46859,12,46889,46915,12,46945,46971,12,47001,47027,12,47057,47083,12,47113,47139,12,47169,47195,12,47225,47251,12,47281,47307,12,47337,47363,12,47393,47419,12,47449,47475,12,47505,47531,12,47561,47587,12,47617,47643,12,47673,47699,12,47729,47755,12,47785,47811,12,47841,47867,12,47897,47923,12,47953,47979,12,48009,48035,12,48065,48091,12,48121,48147,12,48177,48203,12,48233,48259,12,48289,48315,12,48345,48371,12,48401,48427,12,48457,48483,12,48513,48539,12,48569,48595,12,48625,48651,12,48681,48707,12,48737,48763,12,48793,48819,12,48849,48875,12,48905,48931,12,48961,48987,12,49017,49043,12,49073,49099,12,49129,49155,12,49185,49211,12,49241,49267,12,49297,49323,12,49353,49379,12,49409,49435,12,49465,49491,12,49521,49547,12,49577,49603,12,49633,49659,12,49689,49715,12,49745,49771,12,49801,49827,12,49857,49883,12,49913,49939,12,49969,49995,12,50025,50051,12,50081,50107,12,50137,50163,12,50193,50219,12,50249,50275,12,50305,50331,12,50361,50387,12,50417,50443,12,50473,50499,12,50529,50555,12,50585,50611,12,50641,50667,12,50697,50723,12,50753,50779,12,50809,50835,12,50865,50891,12,50921,50947,12,50977,51003,12,51033,51059,12,51089,51115,12,51145,51171,12,51201,51227,12,51257,51283,12,51313,51339,12,51369,51395,12,51425,51451,12,51481,51507,12,51537,51563,12,51593,51619,12,51649,51675,12,51705,51731,12,51761,51787,12,51817,51843,12,51873,51899,12,51929,51955,12,51985,52011,12,52041,52067,12,52097,52123,12,52153,52179,12,52209,52235,12,52265,52291,12,52321,52347,12,52377,52403,12,52433,52459,12,52489,52515,12,52545,52571,12,52601,52627,12,52657,52683,12,52713,52739,12,52769,52795,12,52825,52851,12,52881,52907,12,52937,52963,12,52993,53019,12,53049,53075,12,53105,53131,12,53161,53187,12,53217,53243,12,53273,53299,12,53329,53355,12,53385,53411,12,53441,53467,12,53497,53523,12,53553,53579,12,53609,53635,12,53665,53691,12,53721,53747,12,53777,53803,12,53833,53859,12,53889,53915,12,53945,53971,12,54001,54027,12,54057,54083,12,54113,54139,12,54169,54195,12,54225,54251,12,54281,54307,12,54337,54363,12,54393,54419,12,54449,54475,12,54505,54531,12,54561,54587,12,54617,54643,12,54673,54699,12,54729,54755,12,54785,54811,12,54841,54867,12,54897,54923,12,54953,54979,12,55009,55035,12,55065,55091,12,55121,55147,12,55177,55203,12,65024,65039,5,65520,65528,4,66422,66426,5,68152,68154,5,69291,69292,5,69633,69633,5,69747,69748,5,69811,69814,5,69826,69826,5,69932,69932,7,70016,70017,5,70079,70080,7,70095,70095,5,70196,70196,5,70367,70367,5,70402,70403,7,70464,70464,5,70487,70487,5,70709,70711,7,70725,70725,7,70833,70834,7,70843,70844,7,70849,70849,7,71090,71093,5,71103,71104,5,71227,71228,7,71339,71339,5,71344,71349,5,71458,71461,5,71727,71735,5,71985,71989,7,71998,71998,5,72002,72002,7,72154,72155,5,72193,72202,5,72251,72254,5,72281,72283,5,72344,72345,5,72766,72766,7,72874,72880,5,72885,72886,5,73023,73029,5,73104,73105,5,73111,73111,5,92912,92916,5,94095,94098,5,113824,113827,4,119142,119142,7,119155,119162,4,119362,119364,5,121476,121476,5,122888,122904,5,123184,123190,5,125252,125258,5,127183,127183,14,127340,127343,14,127377,127386,14,127491,127503,14,127548,127551,14,127744,127756,14,127761,127761,14,127769,127769,14,127773,127774,14,127780,127788,14,127796,127797,14,127820,127823,14,127869,127869,14,127894,127895,14,127902,127903,14,127943,127943,14,127947,127950,14,127972,127972,14,127988,127988,14,127992,127994,14,128009,128011,14,128019,128019,14,128023,128041,14,128064,128064,14,128102,128107,14,128174,128181,14,128238,128238,14,128246,128247,14,128254,128254,14,128264,128264,14,128278,128299,14,128329,128330,14,128348,128359,14,128371,128377,14,128392,128393,14,128401,128404,14,128421,128421,14,128433,128434,14,128450,128452,14,128476,128478,14,128483,128483,14,128495,128495,14,128506,128506,14,128519,128520,14,128528,128528,14,128534,128534,14,128538,128538,14,128540,128542,14,128544,128549,14,128552,128555,14,128557,128557,14,128560,128563,14,128565,128565,14,128567,128576,14,128581,128591,14,128641,128642,14,128646,128646,14,128648,128648,14,128650,128651,14,128653,128653,14,128655,128655,14,128657,128659,14,128661,128661,14,128663,128663,14,128665,128666,14,128674,128674,14,128676,128677,14,128679,128685,14,128690,128690,14,128694,128694,14,128697,128702,14,128704,128704,14,128710,128714,14,128716,128716,14,128720,128720,14,128723,128724,14,128726,128727,14,128733,128735,14,128742,128744,14,128746,128746,14,128749,128751,14,128753,128754,14,128756,128758,14,128761,128761,14,128763,128764,14,128884,128895,14,128992,129003,14,129008,129008,14,129036,129039,14,129114,129119,14,129198,129279,14,129293,129295,14,129305,129310,14,129312,129319,14,129328,129328,14,129331,129338,14,129343,129343,14,129351,129355,14,129357,129359,14,129375,129387,14,129393,129393,14,129395,129398,14,129401,129401,14,129403,129403,14,129408,129412,14,129426,129431,14,129443,129444,14,129451,129453,14,129456,129465,14,129472,129472,14,129475,129482,14,129484,129484,14,129488,129510,14,129536,129647,14,129652,129652,14,129656,129658,14,129661,129663,14,129667,129670,14,129680,129685,14,129705,129708,14,129712,129718,14,129723,129727,14,129731,129733,14,129744,129750,14,129754,129759,14,129768,129775,14,129783,129791,14,917504,917504,4,917506,917535,4,917632,917759,4,918000,921599,4,0,9,4,11,12,4,14,31,4,169,169,14,174,174,14,1155,1159,5,1425,1469,5,1473,1474,5,1479,1479,5,1552,1562,5,1611,1631,5,1750,1756,5,1759,1764,5,1770,1773,5,1809,1809,5,1958,1968,5,2045,2045,5,2075,2083,5,2089,2093,5,2192,2193,1,2250,2273,5,2275,2306,5,2362,2362,5,2364,2364,5,2369,2376,5,2381,2381,5,2385,2391,5,2433,2433,5,2492,2492,5,2495,2496,7,2503,2504,7,2509,2509,5,2530,2531,5,2561,2562,5,2620,2620,5,2625,2626,5,2635,2637,5,2672,2673,5,2689,2690,5,2748,2748,5,2753,2757,5,2761,2761,7,2765,2765,5,2810,2815,5,2818,2819,7,2878,2878,5,2880,2880,7,2887,2888,7,2893,2893,5,2903,2903,5,2946,2946,5,3007,3007,7,3009,3010,7,3018,3020,7,3031,3031,5,3073,3075,7,3132,3132,5,3137,3140,7,3146,3149,5,3170,3171,5,3202,3203,7,3262,3262,7,3264,3265,7,3267,3268,7,3271,3272,7,3276,3277,5,3298,3299,5,3330,3331,7,3390,3390,5,3393,3396,5,3402,3404,7,3406,3406,1,3426,3427,5,3458,3459,7,3535,3535,5,3538,3540,5,3544,3550,7,3570,3571,7,3635,3635,7,3655,3662,5,3763,3763,7,3784,3789,5,3893,3893,5,3897,3897,5,3953,3966,5,3968,3972,5,3981,3991,5,4038,4038,5,4145,4145,7,4153,4154,5,4157,4158,5,4184,4185,5,4209,4212,5,4228,4228,7,4237,4237,5,4352,4447,8,4520,4607,10,5906,5908,5,5938,5939,5,5970,5971,5,6068,6069,5,6071,6077,5,6086,6086,5,6089,6099,5,6155,6157,5,6159,6159,5,6313,6313,5,6435,6438,7,6441,6443,7,6450,6450,5,6457,6459,5,6681,6682,7,6741,6741,7,6743,6743,7,6752,6752,5,6757,6764,5,6771,6780,5,6832,6845,5,6847,6862,5,6916,6916,7,6965,6965,5,6971,6971,7,6973,6977,7,6979,6980,7,7040,7041,5,7073,7073,7,7078,7079,7,7082,7082,7,7142,7142,5,7144,7145,5,7149,7149,5,7151,7153,5,7204,7211,7,7220,7221,7,7376,7378,5,7393,7393,7,7405,7405,5,7415,7415,7,7616,7679,5,8204,8204,5,8206,8207,4,8233,8233,4,8252,8252,14,8288,8292,4,8294,8303,4,8413,8416,5,8418,8420,5,8482,8482,14,8596,8601,14,8986,8987,14,9096,9096,14,9193,9196,14,9199,9199,14,9201,9202,14,9208,9210,14,9642,9643,14,9664,9664,14,9728,9729,14,9732,9732,14,9735,9741,14,9743,9744,14,9746,9746,14,9750,9751,14,9753,9756,14,9758,9759,14,9761,9761,14,9764,9765,14,9767,9769,14,9771,9773,14,9775,9775,14,9784,9785,14,9787,9791,14,9793,9793,14,9795,9799,14,9812,9822,14,9824,9824,14,9827,9827,14,9829,9830,14,9832,9832,14,9851,9851,14,9854,9854,14,9856,9861,14,9874,9874,14,9876,9876,14,9878,9879,14,9881,9881,14,9883,9884,14,9888,9889,14,9895,9895,14,9898,9899,14,9904,9905,14,9917,9918,14,9924,9925,14,9928,9928,14,9934,9934,14,9936,9936,14,9938,9938,14,9940,9940,14,9961,9961,14,9963,9967,14,9970,9971,14,9973,9973,14,9975,9977,14,9979,9980,14,9982,9985,14,9987,9988,14,9992,9996,14,9998,9998,14,10000,10001,14,10004,10004,14,10013,10013,14,10024,10024,14,10052,10052,14,10060,10060,14,10067,10069,14,10083,10083,14,10085,10087,14,10145,10145,14,10175,10175,14,11013,11015,14,11088,11088,14,11503,11505,5,11744,11775,5,12334,12335,5,12349,12349,14,12951,12951,14,42607,42607,5,42612,42621,5,42736,42737,5,43014,43014,5,43043,43044,7,43047,43047,7,43136,43137,7,43204,43205,5,43263,43263,5,43335,43345,5,43360,43388,8,43395,43395,7,43444,43445,7,43450,43451,7,43454,43456,7,43561,43566,5,43569,43570,5,43573,43574,5,43596,43596,5,43644,43644,5,43698,43700,5,43710,43711,5,43755,43755,7,43758,43759,7,43766,43766,5,44005,44005,5,44008,44008,5,44012,44012,7,44032,44032,11,44060,44060,11,44088,44088,11,44116,44116,11,44144,44144,11,44172,44172,11,44200,44200,11,44228,44228,11,44256,44256,11,44284,44284,11,44312,44312,11,44340,44340,11,44368,44368,11,44396,44396,11,44424,44424,11,44452,44452,11,44480,44480,11,44508,44508,11,44536,44536,11,44564,44564,11,44592,44592,11,44620,44620,11,44648,44648,11,44676,44676,11,44704,44704,11,44732,44732,11,44760,44760,11,44788,44788,11,44816,44816,11,44844,44844,11,44872,44872,11,44900,44900,11,44928,44928,11,44956,44956,11,44984,44984,11,45012,45012,11,45040,45040,11,45068,45068,11,45096,45096,11,45124,45124,11,45152,45152,11,45180,45180,11,45208,45208,11,45236,45236,11,45264,45264,11,45292,45292,11,45320,45320,11,45348,45348,11,45376,45376,11,45404,45404,11,45432,45432,11,45460,45460,11,45488,45488,11,45516,45516,11,45544,45544,11,45572,45572,11,45600,45600,11,45628,45628,11,45656,45656,11,45684,45684,11,45712,45712,11,45740,45740,11,45768,45768,11,45796,45796,11,45824,45824,11,45852,45852,11,45880,45880,11,45908,45908,11,45936,45936,11,45964,45964,11,45992,45992,11,46020,46020,11,46048,46048,11,46076,46076,11,46104,46104,11,46132,46132,11,46160,46160,11,46188,46188,11,46216,46216,11,46244,46244,11,46272,46272,11,46300,46300,11,46328,46328,11,46356,46356,11,46384,46384,11,46412,46412,11,46440,46440,11,46468,46468,11,46496,46496,11,46524,46524,11,46552,46552,11,46580,46580,11,46608,46608,11,46636,46636,11,46664,46664,11,46692,46692,11,46720,46720,11,46748,46748,11,46776,46776,11,46804,46804,11,46832,46832,11,46860,46860,11,46888,46888,11,46916,46916,11,46944,46944,11,46972,46972,11,47000,47000,11,47028,47028,11,47056,47056,11,47084,47084,11,47112,47112,11,47140,47140,11,47168,47168,11,47196,47196,11,47224,47224,11,47252,47252,11,47280,47280,11,47308,47308,11,47336,47336,11,47364,47364,11,47392,47392,11,47420,47420,11,47448,47448,11,47476,47476,11,47504,47504,11,47532,47532,11,47560,47560,11,47588,47588,11,47616,47616,11,47644,47644,11,47672,47672,11,47700,47700,11,47728,47728,11,47756,47756,11,47784,47784,11,47812,47812,11,47840,47840,11,47868,47868,11,47896,47896,11,47924,47924,11,47952,47952,11,47980,47980,11,48008,48008,11,48036,48036,11,48064,48064,11,48092,48092,11,48120,48120,11,48148,48148,11,48176,48176,11,48204,48204,11,48232,48232,11,48260,48260,11,48288,48288,11,48316,48316,11,48344,48344,11,48372,48372,11,48400,48400,11,48428,48428,11,48456,48456,11,48484,48484,11,48512,48512,11,48540,48540,11,48568,48568,11,48596,48596,11,48624,48624,11,48652,48652,11,48680,48680,11,48708,48708,11,48736,48736,11,48764,48764,11,48792,48792,11,48820,48820,11,48848,48848,11,48876,48876,11,48904,48904,11,48932,48932,11,48960,48960,11,48988,48988,11,49016,49016,11,49044,49044,11,49072,49072,11,49100,49100,11,49128,49128,11,49156,49156,11,49184,49184,11,49212,49212,11,49240,49240,11,49268,49268,11,49296,49296,11,49324,49324,11,49352,49352,11,49380,49380,11,49408,49408,11,49436,49436,11,49464,49464,11,49492,49492,11,49520,49520,11,49548,49548,11,49576,49576,11,49604,49604,11,49632,49632,11,49660,49660,11,49688,49688,11,49716,49716,11,49744,49744,11,49772,49772,11,49800,49800,11,49828,49828,11,49856,49856,11,49884,49884,11,49912,49912,11,49940,49940,11,49968,49968,11,49996,49996,11,50024,50024,11,50052,50052,11,50080,50080,11,50108,50108,11,50136,50136,11,50164,50164,11,50192,50192,11,50220,50220,11,50248,50248,11,50276,50276,11,50304,50304,11,50332,50332,11,50360,50360,11,50388,50388,11,50416,50416,11,50444,50444,11,50472,50472,11,50500,50500,11,50528,50528,11,50556,50556,11,50584,50584,11,50612,50612,11,50640,50640,11,50668,50668,11,50696,50696,11,50724,50724,11,50752,50752,11,50780,50780,11,50808,50808,11,50836,50836,11,50864,50864,11,50892,50892,11,50920,50920,11,50948,50948,11,50976,50976,11,51004,51004,11,51032,51032,11,51060,51060,11,51088,51088,11,51116,51116,11,51144,51144,11,51172,51172,11,51200,51200,11,51228,51228,11,51256,51256,11,51284,51284,11,51312,51312,11,51340,51340,11,51368,51368,11,51396,51396,11,51424,51424,11,51452,51452,11,51480,51480,11,51508,51508,11,51536,51536,11,51564,51564,11,51592,51592,11,51620,51620,11,51648,51648,11,51676,51676,11,51704,51704,11,51732,51732,11,51760,51760,11,51788,51788,11,51816,51816,11,51844,51844,11,51872,51872,11,51900,51900,11,51928,51928,11,51956,51956,11,51984,51984,11,52012,52012,11,52040,52040,11,52068,52068,11,52096,52096,11,52124,52124,11,52152,52152,11,52180,52180,11,52208,52208,11,52236,52236,11,52264,52264,11,52292,52292,11,52320,52320,11,52348,52348,11,52376,52376,11,52404,52404,11,52432,52432,11,52460,52460,11,52488,52488,11,52516,52516,11,52544,52544,11,52572,52572,11,52600,52600,11,52628,52628,11,52656,52656,11,52684,52684,11,52712,52712,11,52740,52740,11,52768,52768,11,52796,52796,11,52824,52824,11,52852,52852,11,52880,52880,11,52908,52908,11,52936,52936,11,52964,52964,11,52992,52992,11,53020,53020,11,53048,53048,11,53076,53076,11,53104,53104,11,53132,53132,11,53160,53160,11,53188,53188,11,53216,53216,11,53244,53244,11,53272,53272,11,53300,53300,11,53328,53328,11,53356,53356,11,53384,53384,11,53412,53412,11,53440,53440,11,53468,53468,11,53496,53496,11,53524,53524,11,53552,53552,11,53580,53580,11,53608,53608,11,53636,53636,11,53664,53664,11,53692,53692,11,53720,53720,11,53748,53748,11,53776,53776,11,53804,53804,11,53832,53832,11,53860,53860,11,53888,53888,11,53916,53916,11,53944,53944,11,53972,53972,11,54000,54000,11,54028,54028,11,54056,54056,11,54084,54084,11,54112,54112,11,54140,54140,11,54168,54168,11,54196,54196,11,54224,54224,11,54252,54252,11,54280,54280,11,54308,54308,11,54336,54336,11,54364,54364,11,54392,54392,11,54420,54420,11,54448,54448,11,54476,54476,11,54504,54504,11,54532,54532,11,54560,54560,11,54588,54588,11,54616,54616,11,54644,54644,11,54672,54672,11,54700,54700,11,54728,54728,11,54756,54756,11,54784,54784,11,54812,54812,11,54840,54840,11,54868,54868,11,54896,54896,11,54924,54924,11,54952,54952,11,54980,54980,11,55008,55008,11,55036,55036,11,55064,55064,11,55092,55092,11,55120,55120,11,55148,55148,11,55176,55176,11,55216,55238,9,64286,64286,5,65056,65071,5,65438,65439,5,65529,65531,4,66272,66272,5,68097,68099,5,68108,68111,5,68159,68159,5,68900,68903,5,69446,69456,5,69632,69632,7,69634,69634,7,69744,69744,5,69759,69761,5,69808,69810,7,69815,69816,7,69821,69821,1,69837,69837,1,69927,69931,5,69933,69940,5,70003,70003,5,70018,70018,7,70070,70078,5,70082,70083,1,70094,70094,7,70188,70190,7,70194,70195,7,70197,70197,7,70206,70206,5,70368,70370,7,70400,70401,5,70459,70460,5,70463,70463,7,70465,70468,7,70475,70477,7,70498,70499,7,70512,70516,5,70712,70719,5,70722,70724,5,70726,70726,5,70832,70832,5,70835,70840,5,70842,70842,5,70845,70845,5,70847,70848,5,70850,70851,5,71088,71089,7,71096,71099,7,71102,71102,7,71132,71133,5,71219,71226,5,71229,71229,5,71231,71232,5,71340,71340,7,71342,71343,7,71350,71350,7,71453,71455,5,71462,71462,7,71724,71726,7,71736,71736,7,71984,71984,5,71991,71992,7,71997,71997,7,71999,71999,1,72001,72001,1,72003,72003,5,72148,72151,5,72156,72159,7,72164,72164,7,72243,72248,5,72250,72250,1,72263,72263,5,72279,72280,7,72324,72329,1,72343,72343,7,72751,72751,7,72760,72765,5,72767,72767,5,72873,72873,7,72881,72881,7,72884,72884,7,73009,73014,5,73020,73021,5,73030,73030,1,73098,73102,7,73107,73108,7,73110,73110,7,73459,73460,5,78896,78904,4,92976,92982,5,94033,94087,7,94180,94180,5,113821,113822,5,118528,118573,5,119141,119141,5,119143,119145,5,119150,119154,5,119163,119170,5,119210,119213,5,121344,121398,5,121461,121461,5,121499,121503,5,122880,122886,5,122907,122913,5,122918,122922,5,123566,123566,5,125136,125142,5,126976,126979,14,126981,127182,14,127184,127231,14,127279,127279,14,127344,127345,14,127374,127374,14,127405,127461,14,127489,127490,14,127514,127514,14,127538,127546,14,127561,127567,14,127570,127743,14,127757,127758,14,127760,127760,14,127762,127762,14,127766,127768,14,127770,127770,14,127772,127772,14,127775,127776,14,127778,127779,14,127789,127791,14,127794,127795,14,127798,127798,14,127819,127819,14,127824,127824,14,127868,127868,14,127870,127871,14,127892,127893,14,127896,127896,14,127900,127901,14,127904,127940,14,127942,127942,14,127944,127944,14,127946,127946,14,127951,127955,14,127968,127971,14,127973,127984,14,127987,127987,14,127989,127989,14,127991,127991,14,127995,127999,5,128008,128008,14,128012,128014,14,128017,128018,14,128020,128020,14,128022,128022,14,128042,128042,14,128063,128063,14,128065,128065,14,128101,128101,14,128108,128109,14,128173,128173,14,128182,128183,14,128236,128237,14,128239,128239,14,128245,128245,14,128248,128248,14,128253,128253,14,128255,128258,14,128260,128263,14,128265,128265,14,128277,128277,14,128300,128301,14,128326,128328,14,128331,128334,14,128336,128347,14,128360,128366,14,128369,128370,14,128378,128378,14,128391,128391,14,128394,128397,14,128400,128400,14,128405,128406,14,128420,128420,14,128422,128423,14,128425,128432,14,128435,128443,14,128445,128449,14,128453,128464,14,128468,128475,14,128479,128480,14,128482,128482,14,128484,128487,14,128489,128494,14,128496,128498,14,128500,128505,14,128507,128511,14,128513,128518,14,128521,128525,14,128527,128527,14,128529,128529,14,128533,128533,14,128535,128535,14,128537,128537,14]");
		}
		getGraphemeBreakType(e) {
			if (e < 32) return 10 === e ? 3 : 13 === e ? 2 : 4;
			if (e < 127) return 0;
			const t = this._data, n = t.length / 3;
			let r = 1;
			for (; r <= n;) if (e < t[3 * r]) r *= 2;
			else {
				if (!(e > t[3 * r + 1])) return t[3 * r + 2];
				r = 2 * r + 1;
			}
			return 0;
		}
	});
	var ue = class e {
		static {
			this.ambiguousCharacterData = new te(() => JSON.parse("{\"_common\":[8232,32,8233,32,5760,32,8192,32,8193,32,8194,32,8195,32,8196,32,8197,32,8198,32,8200,32,8201,32,8202,32,8287,32,8199,32,8239,32,2042,95,65101,95,65102,95,65103,95,8208,45,8209,45,8210,45,65112,45,1748,45,8259,45,727,45,8722,45,10134,45,11450,45,1549,44,1643,44,184,44,42233,44,894,59,2307,58,2691,58,1417,58,1795,58,1796,58,5868,58,65072,58,6147,58,6153,58,8282,58,1475,58,760,58,42889,58,8758,58,720,58,42237,58,451,33,11601,33,660,63,577,63,2429,63,5038,63,42731,63,119149,46,8228,46,1793,46,1794,46,42510,46,68176,46,1632,46,1776,46,42232,46,1373,96,65287,96,8219,96,1523,96,8242,96,1370,96,8175,96,65344,96,900,96,8189,96,8125,96,8127,96,8190,96,697,96,884,96,712,96,714,96,715,96,756,96,699,96,701,96,700,96,702,96,42892,96,1497,96,2036,96,2037,96,5194,96,5836,96,94033,96,94034,96,65339,91,10088,40,10098,40,12308,40,64830,40,65341,93,10089,41,10099,41,12309,41,64831,41,10100,123,119060,123,10101,125,65342,94,8270,42,1645,42,8727,42,66335,42,5941,47,8257,47,8725,47,8260,47,9585,47,10187,47,10744,47,119354,47,12755,47,12339,47,11462,47,20031,47,12035,47,65340,92,65128,92,8726,92,10189,92,10741,92,10745,92,119311,92,119355,92,12756,92,20022,92,12034,92,42872,38,708,94,710,94,5869,43,10133,43,66203,43,8249,60,10094,60,706,60,119350,60,5176,60,5810,60,5120,61,11840,61,12448,61,42239,61,8250,62,10095,62,707,62,119351,62,5171,62,94015,62,8275,126,732,126,8128,126,8764,126,65372,124,65293,45,118002,50,120784,50,120794,50,120804,50,120814,50,120824,50,130034,50,42842,50,423,50,1000,50,42564,50,5311,50,42735,50,119302,51,118003,51,120785,51,120795,51,120805,51,120815,51,120825,51,130035,51,42923,51,540,51,439,51,42858,51,11468,51,1248,51,94011,51,71882,51,118004,52,120786,52,120796,52,120806,52,120816,52,120826,52,130036,52,5070,52,71855,52,118005,53,120787,53,120797,53,120807,53,120817,53,120827,53,130037,53,444,53,71867,53,118006,54,120788,54,120798,54,120808,54,120818,54,120828,54,130038,54,11474,54,5102,54,71893,54,119314,55,118007,55,120789,55,120799,55,120809,55,120819,55,120829,55,130039,55,66770,55,71878,55,2819,56,2538,56,2666,56,125131,56,118008,56,120790,56,120800,56,120810,56,120820,56,120830,56,130040,56,547,56,546,56,66330,56,2663,57,2920,57,2541,57,3437,57,118009,57,120791,57,120801,57,120811,57,120821,57,120831,57,130041,57,42862,57,11466,57,71884,57,71852,57,71894,57,9082,97,65345,97,119834,97,119886,97,119938,97,119990,97,120042,97,120094,97,120146,97,120198,97,120250,97,120302,97,120354,97,120406,97,120458,97,593,97,945,97,120514,97,120572,97,120630,97,120688,97,120746,97,65313,65,117974,65,119808,65,119860,65,119912,65,119964,65,120016,65,120068,65,120120,65,120172,65,120224,65,120276,65,120328,65,120380,65,120432,65,913,65,120488,65,120546,65,120604,65,120662,65,120720,65,5034,65,5573,65,42222,65,94016,65,66208,65,119835,98,119887,98,119939,98,119991,98,120043,98,120095,98,120147,98,120199,98,120251,98,120303,98,120355,98,120407,98,120459,98,388,98,5071,98,5234,98,5551,98,65314,66,8492,66,117975,66,119809,66,119861,66,119913,66,120017,66,120069,66,120121,66,120173,66,120225,66,120277,66,120329,66,120381,66,120433,66,42932,66,914,66,120489,66,120547,66,120605,66,120663,66,120721,66,5108,66,5623,66,42192,66,66178,66,66209,66,66305,66,65347,99,8573,99,119836,99,119888,99,119940,99,119992,99,120044,99,120096,99,120148,99,120200,99,120252,99,120304,99,120356,99,120408,99,120460,99,7428,99,1010,99,11429,99,43951,99,66621,99,128844,67,71913,67,71922,67,65315,67,8557,67,8450,67,8493,67,117976,67,119810,67,119862,67,119914,67,119966,67,120018,67,120174,67,120226,67,120278,67,120330,67,120382,67,120434,67,1017,67,11428,67,5087,67,42202,67,66210,67,66306,67,66581,67,66844,67,8574,100,8518,100,119837,100,119889,100,119941,100,119993,100,120045,100,120097,100,120149,100,120201,100,120253,100,120305,100,120357,100,120409,100,120461,100,1281,100,5095,100,5231,100,42194,100,8558,68,8517,68,117977,68,119811,68,119863,68,119915,68,119967,68,120019,68,120071,68,120123,68,120175,68,120227,68,120279,68,120331,68,120383,68,120435,68,5024,68,5598,68,5610,68,42195,68,8494,101,65349,101,8495,101,8519,101,119838,101,119890,101,119942,101,120046,101,120098,101,120150,101,120202,101,120254,101,120306,101,120358,101,120410,101,120462,101,43826,101,1213,101,8959,69,65317,69,8496,69,117978,69,119812,69,119864,69,119916,69,120020,69,120072,69,120124,69,120176,69,120228,69,120280,69,120332,69,120384,69,120436,69,917,69,120492,69,120550,69,120608,69,120666,69,120724,69,11577,69,5036,69,42224,69,71846,69,71854,69,66182,69,119839,102,119891,102,119943,102,119995,102,120047,102,120099,102,120151,102,120203,102,120255,102,120307,102,120359,102,120411,102,120463,102,43829,102,42905,102,383,102,7837,102,1412,102,119315,70,8497,70,117979,70,119813,70,119865,70,119917,70,120021,70,120073,70,120125,70,120177,70,120229,70,120281,70,120333,70,120385,70,120437,70,42904,70,988,70,120778,70,5556,70,42205,70,71874,70,71842,70,66183,70,66213,70,66853,70,65351,103,8458,103,119840,103,119892,103,119944,103,120048,103,120100,103,120152,103,120204,103,120256,103,120308,103,120360,103,120412,103,120464,103,609,103,7555,103,397,103,1409,103,117980,71,119814,71,119866,71,119918,71,119970,71,120022,71,120074,71,120126,71,120178,71,120230,71,120282,71,120334,71,120386,71,120438,71,1292,71,5056,71,5107,71,42198,71,65352,104,8462,104,119841,104,119945,104,119997,104,120049,104,120101,104,120153,104,120205,104,120257,104,120309,104,120361,104,120413,104,120465,104,1211,104,1392,104,5058,104,65320,72,8459,72,8460,72,8461,72,117981,72,119815,72,119867,72,119919,72,120023,72,120179,72,120231,72,120283,72,120335,72,120387,72,120439,72,919,72,120494,72,120552,72,120610,72,120668,72,120726,72,11406,72,5051,72,5500,72,42215,72,66255,72,731,105,9075,105,65353,105,8560,105,8505,105,8520,105,119842,105,119894,105,119946,105,119998,105,120050,105,120102,105,120154,105,120206,105,120258,105,120310,105,120362,105,120414,105,120466,105,120484,105,618,105,617,105,953,105,8126,105,890,105,120522,105,120580,105,120638,105,120696,105,120754,105,1110,105,42567,105,1231,105,43893,105,5029,105,71875,105,65354,106,8521,106,119843,106,119895,106,119947,106,119999,106,120051,106,120103,106,120155,106,120207,106,120259,106,120311,106,120363,106,120415,106,120467,106,1011,106,1112,106,65322,74,117983,74,119817,74,119869,74,119921,74,119973,74,120025,74,120077,74,120129,74,120181,74,120233,74,120285,74,120337,74,120389,74,120441,74,42930,74,895,74,1032,74,5035,74,5261,74,42201,74,119844,107,119896,107,119948,107,120000,107,120052,107,120104,107,120156,107,120208,107,120260,107,120312,107,120364,107,120416,107,120468,107,8490,75,65323,75,117984,75,119818,75,119870,75,119922,75,119974,75,120026,75,120078,75,120130,75,120182,75,120234,75,120286,75,120338,75,120390,75,120442,75,922,75,120497,75,120555,75,120613,75,120671,75,120729,75,11412,75,5094,75,5845,75,42199,75,66840,75,1472,108,8739,73,9213,73,65512,73,1633,108,1777,73,66336,108,125127,108,118001,108,120783,73,120793,73,120803,73,120813,73,120823,73,130033,73,65321,73,8544,73,8464,73,8465,73,117982,108,119816,73,119868,73,119920,73,120024,73,120128,73,120180,73,120232,73,120284,73,120336,73,120388,73,120440,73,65356,108,8572,73,8467,108,119845,108,119897,108,119949,108,120001,108,120053,108,120105,73,120157,73,120209,73,120261,73,120313,73,120365,73,120417,73,120469,73,448,73,120496,73,120554,73,120612,73,120670,73,120728,73,11410,73,1030,73,1216,73,1493,108,1503,108,1575,108,126464,108,126592,108,65166,108,65165,108,1994,108,11599,73,5825,73,42226,73,93992,73,66186,124,66313,124,119338,76,8556,76,8466,76,117985,76,119819,76,119871,76,119923,76,120027,76,120079,76,120131,76,120183,76,120235,76,120287,76,120339,76,120391,76,120443,76,11472,76,5086,76,5290,76,42209,76,93974,76,71843,76,71858,76,66587,76,66854,76,65325,77,8559,77,8499,77,117986,77,119820,77,119872,77,119924,77,120028,77,120080,77,120132,77,120184,77,120236,77,120288,77,120340,77,120392,77,120444,77,924,77,120499,77,120557,77,120615,77,120673,77,120731,77,1018,77,11416,77,5047,77,5616,77,5846,77,42207,77,66224,77,66321,77,119847,110,119899,110,119951,110,120003,110,120055,110,120107,110,120159,110,120211,110,120263,110,120315,110,120367,110,120419,110,120471,110,1400,110,1404,110,65326,78,8469,78,117987,78,119821,78,119873,78,119925,78,119977,78,120029,78,120081,78,120185,78,120237,78,120289,78,120341,78,120393,78,120445,78,925,78,120500,78,120558,78,120616,78,120674,78,120732,78,11418,78,42208,78,66835,78,3074,111,3202,111,3330,111,3458,111,2406,111,2662,111,2790,111,3046,111,3174,111,3302,111,3430,111,3664,111,3792,111,4160,111,1637,111,1781,111,65359,111,8500,111,119848,111,119900,111,119952,111,120056,111,120108,111,120160,111,120212,111,120264,111,120316,111,120368,111,120420,111,120472,111,7439,111,7441,111,43837,111,959,111,120528,111,120586,111,120644,111,120702,111,120760,111,963,111,120532,111,120590,111,120648,111,120706,111,120764,111,11423,111,4351,111,1413,111,1505,111,1607,111,126500,111,126564,111,126596,111,65259,111,65260,111,65258,111,65257,111,1726,111,64428,111,64429,111,64427,111,64426,111,1729,111,64424,111,64425,111,64423,111,64422,111,1749,111,3360,111,4125,111,66794,111,71880,111,71895,111,66604,111,1984,79,2534,79,2918,79,12295,79,70864,79,71904,79,118000,79,120782,79,120792,79,120802,79,120812,79,120822,79,130032,79,65327,79,117988,79,119822,79,119874,79,119926,79,119978,79,120030,79,120082,79,120134,79,120186,79,120238,79,120290,79,120342,79,120394,79,120446,79,927,79,120502,79,120560,79,120618,79,120676,79,120734,79,11422,79,1365,79,11604,79,4816,79,2848,79,66754,79,42227,79,71861,79,66194,79,66219,79,66564,79,66838,79,9076,112,65360,112,119849,112,119901,112,119953,112,120005,112,120057,112,120109,112,120161,112,120213,112,120265,112,120317,112,120369,112,120421,112,120473,112,961,112,120530,112,120544,112,120588,112,120602,112,120646,112,120660,112,120704,112,120718,112,120762,112,120776,112,11427,112,65328,80,8473,80,117989,80,119823,80,119875,80,119927,80,119979,80,120031,80,120083,80,120187,80,120239,80,120291,80,120343,80,120395,80,120447,80,929,80,120504,80,120562,80,120620,80,120678,80,120736,80,11426,80,5090,80,5229,80,42193,80,66197,80,119850,113,119902,113,119954,113,120006,113,120058,113,120110,113,120162,113,120214,113,120266,113,120318,113,120370,113,120422,113,120474,113,1307,113,1379,113,1382,113,8474,81,117990,81,119824,81,119876,81,119928,81,119980,81,120032,81,120084,81,120188,81,120240,81,120292,81,120344,81,120396,81,120448,81,11605,81,119851,114,119903,114,119955,114,120007,114,120059,114,120111,114,120163,114,120215,114,120267,114,120319,114,120371,114,120423,114,120475,114,43847,114,43848,114,7462,114,11397,114,43905,114,119318,82,8475,82,8476,82,8477,82,117991,82,119825,82,119877,82,119929,82,120033,82,120189,82,120241,82,120293,82,120345,82,120397,82,120449,82,422,82,5025,82,5074,82,66740,82,5511,82,42211,82,94005,82,65363,115,119852,115,119904,115,119956,115,120008,115,120060,115,120112,115,120164,115,120216,115,120268,115,120320,115,120372,115,120424,115,120476,115,42801,115,445,115,1109,115,43946,115,71873,115,66632,115,65331,83,117992,83,119826,83,119878,83,119930,83,119982,83,120034,83,120086,83,120138,83,120190,83,120242,83,120294,83,120346,83,120398,83,120450,83,1029,83,1359,83,5077,83,5082,83,42210,83,94010,83,66198,83,66592,83,119853,116,119905,116,119957,116,120009,116,120061,116,120113,116,120165,116,120217,116,120269,116,120321,116,120373,116,120425,116,120477,116,8868,84,10201,84,128872,84,65332,84,117993,84,119827,84,119879,84,119931,84,119983,84,120035,84,120087,84,120139,84,120191,84,120243,84,120295,84,120347,84,120399,84,120451,84,932,84,120507,84,120565,84,120623,84,120681,84,120739,84,11430,84,5026,84,42196,84,93962,84,71868,84,66199,84,66225,84,66325,84,119854,117,119906,117,119958,117,120010,117,120062,117,120114,117,120166,117,120218,117,120270,117,120322,117,120374,117,120426,117,120478,117,42911,117,7452,117,43854,117,43858,117,651,117,965,117,120534,117,120592,117,120650,117,120708,117,120766,117,1405,117,66806,117,71896,117,8746,85,8899,85,117994,85,119828,85,119880,85,119932,85,119984,85,120036,85,120088,85,120140,85,120192,85,120244,85,120296,85,120348,85,120400,85,120452,85,1357,85,4608,85,66766,85,5196,85,42228,85,94018,85,71864,85,8744,118,8897,118,65366,118,8564,118,119855,118,119907,118,119959,118,120011,118,120063,118,120115,118,120167,118,120219,118,120271,118,120323,118,120375,118,120427,118,120479,118,7456,118,957,118,120526,118,120584,118,120642,118,120700,118,120758,118,1141,118,1496,118,71430,118,43945,118,71872,118,119309,86,1639,86,1783,86,8548,86,117995,86,119829,86,119881,86,119933,86,119985,86,120037,86,120089,86,120141,86,120193,86,120245,86,120297,86,120349,86,120401,86,120453,86,1140,86,11576,86,5081,86,5167,86,42719,86,42214,86,93960,86,71840,86,66845,86,623,119,119856,119,119908,119,119960,119,120012,119,120064,119,120116,119,120168,119,120220,119,120272,119,120324,119,120376,119,120428,119,120480,119,7457,119,1121,119,1309,119,1377,119,71434,119,71438,119,71439,119,43907,119,71910,87,71919,87,117996,87,119830,87,119882,87,119934,87,119986,87,120038,87,120090,87,120142,87,120194,87,120246,87,120298,87,120350,87,120402,87,120454,87,1308,87,5043,87,5076,87,42218,87,5742,120,10539,120,10540,120,10799,120,65368,120,8569,120,119857,120,119909,120,119961,120,120013,120,120065,120,120117,120,120169,120,120221,120,120273,120,120325,120,120377,120,120429,120,120481,120,5441,120,5501,120,5741,88,9587,88,66338,88,71916,88,65336,88,8553,88,117997,88,119831,88,119883,88,119935,88,119987,88,120039,88,120091,88,120143,88,120195,88,120247,88,120299,88,120351,88,120403,88,120455,88,42931,88,935,88,120510,88,120568,88,120626,88,120684,88,120742,88,11436,88,11613,88,5815,88,42219,88,66192,88,66228,88,66327,88,66855,88,611,121,7564,121,65369,121,119858,121,119910,121,119962,121,120014,121,120066,121,120118,121,120170,121,120222,121,120274,121,120326,121,120378,121,120430,121,120482,121,655,121,7935,121,43866,121,947,121,8509,121,120516,121,120574,121,120632,121,120690,121,120748,121,1199,121,4327,121,71900,121,65337,89,117998,89,119832,89,119884,89,119936,89,119988,89,120040,89,120092,89,120144,89,120196,89,120248,89,120300,89,120352,89,120404,89,120456,89,933,89,978,89,120508,89,120566,89,120624,89,120682,89,120740,89,11432,89,1198,89,5033,89,5053,89,42220,89,94019,89,71844,89,66226,89,119859,122,119911,122,119963,122,120015,122,120067,122,120119,122,120171,122,120223,122,120275,122,120327,122,120379,122,120431,122,120483,122,7458,122,43923,122,71876,122,71909,90,66293,90,65338,90,8484,90,8488,90,117999,90,119833,90,119885,90,119937,90,119989,90,120041,90,120197,90,120249,90,120301,90,120353,90,120405,90,120457,90,918,90,120493,90,120551,90,120609,90,120667,90,120725,90,5059,90,42204,90,71849,90,65282,34,65283,35,65284,36,65285,37,65286,38,65290,42,65291,43,65294,46,65295,47,65296,48,65298,50,65299,51,65300,52,65301,53,65302,54,65303,55,65304,56,65305,57,65308,60,65309,61,65310,62,65312,64,65316,68,65318,70,65319,71,65324,76,65329,81,65330,82,65333,85,65334,86,65335,87,65343,95,65346,98,65348,100,65350,102,65355,107,65357,109,65358,110,65361,113,65362,114,65364,116,65365,117,65367,119,65370,122,65371,123,65373,125,119846,109],\"_default\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8217,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"cs\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"de\":[65374,126,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"es\":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"fr\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"it\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"ja\":[8211,45,8218,44,65281,33,8216,96,8245,96,180,96,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65292,44,65297,49,65307,59],\"ko\":[8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"pl\":[65374,126,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"pt-BR\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"qps-ploc\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"ru\":[65374,126,8218,44,65306,58,65281,33,8216,96,8245,96,180,96,12494,47,305,105,921,73,1009,112,215,120,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"tr\":[160,32,8211,45,65374,126,8218,44,65306,58,65281,33,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65288,40,65289,41,65292,44,65297,49,65307,59,65311,63],\"zh-hans\":[160,32,65374,126,8218,44,8245,96,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89,65297,49],\"zh-hant\":[8211,45,65374,126,8218,44,180,96,12494,47,1047,51,1073,54,1072,97,1040,65,1068,98,1042,66,1089,99,1057,67,1077,101,1045,69,1053,72,305,105,1050,75,921,73,1052,77,1086,111,1054,79,1009,112,1088,112,1056,80,1075,114,1058,84,215,120,1093,120,1061,88,1091,121,1059,89]}"));
		}
		static {
			this.cache = new ee({ getCacheKey: JSON.stringify }, (t) => {
				function n(e) {
					const t = /* @__PURE__ */ new Map();
					for (let n = 0; n < e.length; n += 2) t.set(e[n], e[n + 1]);
					return t;
				}
				function r(e, t) {
					if (!e) return t;
					const n = /* @__PURE__ */ new Map();
					for (const [r, i] of e) t.has(r) && n.set(r, i);
					return n;
				}
				const i = this.ambiguousCharacterData.value;
				let s, o = t.filter((e) => !e.startsWith("_") && Object.hasOwn(i, e));
				0 === o.length && (o = ["_default"]);
				for (const e of o) s = r(s, n(i[e]));
				return new e(function(e, t) {
					const n = new Map(e);
					for (const [r, i] of t) n.set(r, i);
					return n;
				}(n(i._common), s));
			});
		}
		static getInstance(t) {
			return e.cache.get(Array.from(t));
		}
		static {
			this._locales = new te(() => Object.keys(e.ambiguousCharacterData.value).filter((e) => !e.startsWith("_")));
		}
		static getLocales() {
			return e._locales.value;
		}
		constructor(e) {
			this.confusableDictionary = e;
		}
		isAmbiguous(e) {
			return this.confusableDictionary.has(e);
		}
		getPrimaryConfusable(e) {
			return this.confusableDictionary.get(e);
		}
		getConfusableCodePoints() {
			return new Set(this.confusableDictionary.keys());
		}
	}, he = class e {
		static getRawData() {
			return JSON.parse("{\"_common\":[11,12,13,127,847,1564,4447,4448,6068,6069,6155,6156,6157,6158,7355,7356,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8204,8205,8206,8207,8234,8235,8236,8237,8238,8239,8287,8288,8289,8290,8291,8292,8293,8294,8295,8296,8297,8298,8299,8300,8301,8302,8303,10240,12644,65024,65025,65026,65027,65028,65029,65030,65031,65032,65033,65034,65035,65036,65037,65038,65039,65279,65440,65520,65521,65522,65523,65524,65525,65526,65527,65528,65532,78844,119155,119156,119157,119158,119159,119160,119161,119162,917504,917505,917506,917507,917508,917509,917510,917511,917512,917513,917514,917515,917516,917517,917518,917519,917520,917521,917522,917523,917524,917525,917526,917527,917528,917529,917530,917531,917532,917533,917534,917535,917536,917537,917538,917539,917540,917541,917542,917543,917544,917545,917546,917547,917548,917549,917550,917551,917552,917553,917554,917555,917556,917557,917558,917559,917560,917561,917562,917563,917564,917565,917566,917567,917568,917569,917570,917571,917572,917573,917574,917575,917576,917577,917578,917579,917580,917581,917582,917583,917584,917585,917586,917587,917588,917589,917590,917591,917592,917593,917594,917595,917596,917597,917598,917599,917600,917601,917602,917603,917604,917605,917606,917607,917608,917609,917610,917611,917612,917613,917614,917615,917616,917617,917618,917619,917620,917621,917622,917623,917624,917625,917626,917627,917628,917629,917630,917631,917760,917761,917762,917763,917764,917765,917766,917767,917768,917769,917770,917771,917772,917773,917774,917775,917776,917777,917778,917779,917780,917781,917782,917783,917784,917785,917786,917787,917788,917789,917790,917791,917792,917793,917794,917795,917796,917797,917798,917799,917800,917801,917802,917803,917804,917805,917806,917807,917808,917809,917810,917811,917812,917813,917814,917815,917816,917817,917818,917819,917820,917821,917822,917823,917824,917825,917826,917827,917828,917829,917830,917831,917832,917833,917834,917835,917836,917837,917838,917839,917840,917841,917842,917843,917844,917845,917846,917847,917848,917849,917850,917851,917852,917853,917854,917855,917856,917857,917858,917859,917860,917861,917862,917863,917864,917865,917866,917867,917868,917869,917870,917871,917872,917873,917874,917875,917876,917877,917878,917879,917880,917881,917882,917883,917884,917885,917886,917887,917888,917889,917890,917891,917892,917893,917894,917895,917896,917897,917898,917899,917900,917901,917902,917903,917904,917905,917906,917907,917908,917909,917910,917911,917912,917913,917914,917915,917916,917917,917918,917919,917920,917921,917922,917923,917924,917925,917926,917927,917928,917929,917930,917931,917932,917933,917934,917935,917936,917937,917938,917939,917940,917941,917942,917943,917944,917945,917946,917947,917948,917949,917950,917951,917952,917953,917954,917955,917956,917957,917958,917959,917960,917961,917962,917963,917964,917965,917966,917967,917968,917969,917970,917971,917972,917973,917974,917975,917976,917977,917978,917979,917980,917981,917982,917983,917984,917985,917986,917987,917988,917989,917990,917991,917992,917993,917994,917995,917996,917997,917998,917999],\"cs\":[173,8203,12288],\"de\":[173,8203,12288],\"es\":[8203,12288],\"fr\":[173,8203,12288],\"it\":[160,173,12288],\"ja\":[173],\"ko\":[173,12288],\"pl\":[173,8203,12288],\"pt-BR\":[173,8203,12288],\"qps-ploc\":[160,173,8203,12288],\"ru\":[173,12288],\"tr\":[160,173,8203,12288],\"zh-hans\":[160,173,8203,12288],\"zh-hant\":[173,12288]}");
		}
		static {
			this._data = void 0;
		}
		static getData() {
			return this._data || (this._data = new Set([...Object.values(e.getRawData())].flat())), this._data;
		}
		static isInvisibleCharacter(t) {
			return e.getData().has(t);
		}
		static get codePoints() {
			return e.getData();
		}
	};
	const ce = "default";
	var de = class {
		constructor(e, t, n, r, i) {
			this.vsWorker = e, this.req = t, this.channel = n, this.method = r, this.args = i, this.type = 0;
		}
	}, ge = class {
		constructor(e, t, n, r) {
			this.vsWorker = e, this.seq = t, this.res = n, this.err = r, this.type = 1;
		}
	}, me = class {
		constructor(e, t, n, r, i) {
			this.vsWorker = e, this.req = t, this.channel = n, this.eventName = r, this.arg = i, this.type = 2;
		}
	}, fe = class {
		constructor(e, t, n) {
			this.vsWorker = e, this.req = t, this.event = n, this.type = 3;
		}
	}, pe = class {
		constructor(e, t) {
			this.vsWorker = e, this.req = t, this.type = 4;
		}
	}, be = class {
		constructor(e) {
			this._workerId = -1, this._handler = e, this._lastSentReq = 0, this._pendingReplies = Object.create(null), this._pendingEmitters = /* @__PURE__ */ new Map(), this._pendingEvents = /* @__PURE__ */ new Map();
		}
		setWorkerId(e) {
			this._workerId = e;
		}
		async sendMessage(e, t, n) {
			const r = String(++this._lastSentReq);
			return new Promise((i, s) => {
				this._pendingReplies[r] = {
					resolve: i,
					reject: s
				}, this._send(new de(this._workerId, r, e, t, n));
			});
		}
		listen(e, t, n) {
			let r = null;
			const i = new R({
				onWillAddFirstListener: () => {
					r = String(++this._lastSentReq), this._pendingEmitters.set(r, i), this._send(new me(this._workerId, r, e, t, n));
				},
				onDidRemoveLastListener: () => {
					this._pendingEmitters.delete(r), this._send(new pe(this._workerId, r)), r = null;
				}
			});
			return i.event;
		}
		handleMessage(e) {
			e && e.vsWorker && (-1 !== this._workerId && e.vsWorker !== this._workerId || this._handleMessage(e));
		}
		createProxyToRemoteChannel(e, t) {
			return new Proxy(Object.create(null), { get: (n, r) => ("string" != typeof r || n[r] || (_e(r) ? n[r] = (t) => this.listen(e, r, t) : we(r) ? n[r] = this.listen(e, r, void 0) : 36 === r.charCodeAt(0) && (n[r] = async (...n) => (await t?.(), this.sendMessage(e, r, n)))), n[r]) });
		}
		_handleMessage(e) {
			switch (e.type) {
				case 1: return this._handleReplyMessage(e);
				case 0: return this._handleRequestMessage(e);
				case 2: return this._handleSubscribeEventMessage(e);
				case 3: return this._handleEventMessage(e);
				case 4: return this._handleUnsubscribeEventMessage(e);
			}
		}
		_handleReplyMessage(e) {
			if (!this._pendingReplies[e.seq]) return;
			const t = this._pendingReplies[e.seq];
			if (delete this._pendingReplies[e.seq], e.err) {
				let n = e.err;
				if (e.err.$isError) {
					const t = /* @__PURE__ */ new Error();
					t.name = e.err.name, t.message = e.err.message, t.stack = e.err.stack, n = t;
				}
				t.reject(n);
				return;
			}
			t.resolve(e.res);
		}
		_handleRequestMessage(e) {
			const t = e.req;
			this._handler.handleMessage(e.channel, e.method, e.args).then((e) => {
				this._send(new ge(this._workerId, t, e, void 0));
			}, (e) => {
				e.detail instanceof Error && (e.detail = n(e.detail)), this._send(new ge(this._workerId, t, void 0, n(e)));
			});
		}
		_handleSubscribeEventMessage(e) {
			const t = e.req, n = this._handler.handleEvent(e.channel, e.eventName, e.arg)((e) => {
				this._send(new fe(this._workerId, t, e));
			});
			this._pendingEvents.set(t, n);
		}
		_handleEventMessage(e) {
			this._pendingEmitters.has(e.req) && this._pendingEmitters.get(e.req).fire(e.event);
		}
		_handleUnsubscribeEventMessage(e) {
			this._pendingEvents.has(e.req) && (this._pendingEvents.get(e.req).dispose(), this._pendingEvents.delete(e.req));
		}
		_send(e) {
			const t = [];
			if (0 === e.type) for (let n = 0; n < e.args.length; n++) {
				const r = e.args[n];
				r instanceof ArrayBuffer && t.push(r);
			}
			else 1 === e.type && e.res instanceof ArrayBuffer && t.push(e.res);
			this._handler.sendMessage(e, t);
		}
	};
	function we(e) {
		return "o" === e[0] && "n" === e[1] && ne(e.charCodeAt(2));
	}
	function _e(e) {
		return /^onDynamic/.test(e) && ne(e.charCodeAt(9));
	}
	var Ce = class {
		constructor(e, t) {
			this._localChannels = /* @__PURE__ */ new Map(), this._remoteChannels = /* @__PURE__ */ new Map(), this._protocol = new be({
				sendMessage: (t, n) => {
					e(t, n);
				},
				handleMessage: (e, t, n) => this._handleMessage(e, t, n),
				handleEvent: (e, t, n) => this._handleEvent(e, t, n)
			}), this.requestHandler = t(this);
		}
		onmessage(e) {
			this._protocol.handleMessage(e);
		}
		_handleMessage(e, t, n) {
			if (e === ce && "$initialize" === t) return this.initialize(n[0]);
			const r = e === ce ? this.requestHandler : this._localChannels.get(e);
			if (!r) return Promise.reject(/* @__PURE__ */ new Error(`Missing channel ${e} on worker thread`));
			const i = r[t];
			if ("function" != typeof i) return Promise.reject(/* @__PURE__ */ new Error(`Missing method ${t} on worker thread channel ${e}`));
			try {
				return Promise.resolve(i.apply(r, n));
			} catch (fs) {
				return Promise.reject(fs);
			}
		}
		_handleEvent(e, t, n) {
			const r = e === ce ? this.requestHandler : this._localChannels.get(e);
			if (!r) throw new Error(`Missing channel ${e} on worker thread`);
			if (_e(t)) {
				const e = r[t];
				if ("function" != typeof e) throw new Error(`Missing dynamic event ${t} on request handler.`);
				const i = e.call(r, n);
				if ("function" != typeof i) throw new Error(`Missing dynamic event ${t} on request handler.`);
				return i;
			}
			if (we(t)) {
				const e = r[t];
				if ("function" != typeof e) throw new Error(`Missing event ${t} on request handler.`);
				return e;
			}
			throw new Error(`Malformed event name ${t}`);
		}
		getChannel(e) {
			if (!this._remoteChannels.has(e)) {
				const t = this._protocol.createProxyToRemoteChannel(e);
				this._remoteChannels.set(e, t);
			}
			return this._remoteChannels.get(e);
		}
		async initialize(e) {
			this._protocol.setWorkerId(e);
		}
	};
	let ye = !1;
	var ve = class {
		constructor(e, t, n, r) {
			this.originalStart = e, this.originalLength = t, this.modifiedStart = n, this.modifiedLength = r;
		}
		getOriginalEnd() {
			return this.originalStart + this.originalLength;
		}
		getModifiedEnd() {
			return this.modifiedStart + this.modifiedLength;
		}
	};
	const Le = "undefined" != typeof Buffer;
	let Ne;
	new te(() => new Uint8Array(256));
	var Ee = class e {
		static wrap(t) {
			return Le && !Buffer.isBuffer(t) && (t = Buffer.from(t.buffer, t.byteOffset, t.byteLength)), new e(t);
		}
		constructor(e) {
			this.buffer = e, this.byteLength = this.buffer.byteLength;
		}
		toString() {
			return Le ? this.buffer.toString() : (Ne || (Ne = new TextDecoder()), Ne.decode(this.buffer));
		}
	};
	const Se = "0123456789abcdef";
	function Re(e, t) {
		return (t << 5) - t + e | 0;
	}
	function xe(e, t) {
		t = Re(149417, t);
		for (let n = 0, r = e.length; n < r; n++) t = Re(e.charCodeAt(n), t);
		return t;
	}
	function Ae(e, t, n = 32) {
		const r = n - t;
		return (e << t | (~((1 << r) - 1) & e) >>> r) >>> 0;
	}
	function ke(e, t = 32) {
		return e instanceof ArrayBuffer ? function({ buffer: e }) {
			let t = "";
			for (let n = 0; n < e.length; n++) {
				const r = e[n];
				t += Se[r >>> 4], t += Se[15 & r];
			}
			return t;
		}(Ee.wrap(new Uint8Array(e))) : (e >>> 0).toString(16).padStart(t / 4, "0");
	}
	(class e {
		static {
			this._bigBlock32 = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(320));
		}
		constructor() {
			this._h0 = 1732584193, this._h1 = 4023233417, this._h2 = 2562383102, this._h3 = 271733878, this._h4 = 3285377520, this._buff = new Uint8Array(67), this._buffDV = new DataView(this._buff.buffer), this._buffLen = 0, this._totalLen = 0, this._leftoverHighSurrogate = 0, this._finished = !1;
		}
		update(e) {
			const t = e.length;
			if (0 === t) return;
			const n = this._buff;
			let r, i, s = this._buffLen, o = this._leftoverHighSurrogate;
			for (0 !== o ? (r = o, i = -1, o = 0) : (r = e.charCodeAt(0), i = 0);;) {
				let a = r;
				if (re(r)) {
					if (!(i + 1 < t)) {
						o = r;
						break;
					}
					{
						const t = e.charCodeAt(i + 1);
						ie(t) ? (i++, a = se(r, t)) : a = 65533;
					}
				} else ie(r) && (a = 65533);
				if (s = this._push(n, s, a), i++, !(i < t)) break;
				r = e.charCodeAt(i);
			}
			this._buffLen = s, this._leftoverHighSurrogate = o;
		}
		_push(e, t, n) {
			return n < 128 ? e[t++] = n : n < 2048 ? (e[t++] = 192 | (1984 & n) >>> 6, e[t++] = 128 | (63 & n) >>> 0) : n < 65536 ? (e[t++] = 224 | (61440 & n) >>> 12, e[t++] = 128 | (4032 & n) >>> 6, e[t++] = 128 | (63 & n) >>> 0) : (e[t++] = 240 | (1835008 & n) >>> 18, e[t++] = 128 | (258048 & n) >>> 12, e[t++] = 128 | (4032 & n) >>> 6, e[t++] = 128 | (63 & n) >>> 0), t >= 64 && (this._step(), t -= 64, this._totalLen += 64, e[0] = e[64], e[1] = e[65], e[2] = e[66]), t;
		}
		digest() {
			return this._finished || (this._finished = !0, this._leftoverHighSurrogate && (this._leftoverHighSurrogate = 0, this._buffLen = this._push(this._buff, this._buffLen, 65533)), this._totalLen += this._buffLen, this._wrapUp()), ke(this._h0) + ke(this._h1) + ke(this._h2) + ke(this._h3) + ke(this._h4);
		}
		_wrapUp() {
			this._buff[this._buffLen++] = 128, this._buff.subarray(this._buffLen).fill(0), this._buffLen > 56 && (this._step(), this._buff.fill(0));
			const e = 8 * this._totalLen;
			this._buffDV.setUint32(56, Math.floor(e / 4294967296), !1), this._buffDV.setUint32(60, e % 4294967296, !1), this._step();
		}
		_step() {
			const t = e._bigBlock32, n = this._buffDV;
			for (let e = 0; e < 64; e += 4) t.setUint32(e, n.getUint32(e, !1), !1);
			for (let e = 64; e < 320; e += 4) t.setUint32(e, Ae(t.getUint32(e - 12, !1) ^ t.getUint32(e - 32, !1) ^ t.getUint32(e - 56, !1) ^ t.getUint32(e - 64, !1), 1), !1);
			let r, i, s, o = this._h0, a = this._h1, l = this._h2, u = this._h3, h = this._h4;
			for (let e = 0; e < 80; e++) e < 20 ? (r = a & l | ~a & u, i = 1518500249) : e < 40 ? (r = a ^ l ^ u, i = 1859775393) : e < 60 ? (r = a & l | a & u | l & u, i = 2400959708) : (r = a ^ l ^ u, i = 3395469782), s = Ae(o, 5) + r + h + i + t.getUint32(4 * e, !1) & 4294967295, h = u, u = l, l = Ae(a, 30), a = o, o = s;
			this._h0 = this._h0 + o & 4294967295, this._h1 = this._h1 + a & 4294967295, this._h2 = this._h2 + l & 4294967295, this._h3 = this._h3 + u & 4294967295, this._h4 = this._h4 + h & 4294967295;
		}
	});
	var Me = class {
		constructor(e) {
			this.source = e;
		}
		getElements() {
			const e = this.source, t = new Int32Array(e.length);
			for (let n = 0, r = e.length; n < r; n++) t[n] = e.charCodeAt(n);
			return t;
		}
	};
	function Oe(e, t, n) {
		return new Fe(new Me(e), new Me(t)).ComputeDiff(n).changes;
	}
	var Ie = class {
		static Assert(e, t) {
			if (!e) throw new Error(t);
		}
	}, Te = class {
		static Copy(e, t, n, r, i) {
			for (let s = 0; s < i; s++) n[r + s] = e[t + s];
		}
		static Copy2(e, t, n, r, i) {
			for (let s = 0; s < i; s++) n[r + s] = e[t + s];
		}
	}, Pe = class {
		constructor() {
			this.m_changes = [], this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824, this.m_originalCount = 0, this.m_modifiedCount = 0;
		}
		MarkNextChange() {
			(this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.m_changes.push(new ve(this.m_originalStart, this.m_originalCount, this.m_modifiedStart, this.m_modifiedCount)), this.m_originalCount = 0, this.m_modifiedCount = 0, this.m_originalStart = 1073741824, this.m_modifiedStart = 1073741824;
		}
		AddOriginalElement(e, t) {
			this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, t), this.m_originalCount++;
		}
		AddModifiedElement(e, t) {
			this.m_originalStart = Math.min(this.m_originalStart, e), this.m_modifiedStart = Math.min(this.m_modifiedStart, t), this.m_modifiedCount++;
		}
		getChanges() {
			return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes;
		}
		getReverseChanges() {
			return (this.m_originalCount > 0 || this.m_modifiedCount > 0) && this.MarkNextChange(), this.m_changes.reverse(), this.m_changes;
		}
	}, Fe = class e {
		constructor(t, n, r = null) {
			this.ContinueProcessingPredicate = r, this._originalSequence = t, this._modifiedSequence = n;
			const [i, s, o] = e._getElements(t), [a, l, u] = e._getElements(n);
			this._hasStrings = o && u, this._originalStringElements = i, this._originalElementsOrHash = s, this._modifiedStringElements = a, this._modifiedElementsOrHash = l, this.m_forwardHistory = [], this.m_reverseHistory = [];
		}
		static _isStringArray(e) {
			return e.length > 0 && "string" == typeof e[0];
		}
		static _getElements(t) {
			const n = t.getElements();
			if (e._isStringArray(n)) {
				const e = new Int32Array(n.length);
				for (let t = 0, r = n.length; t < r; t++) e[t] = xe(n[t], 0);
				return [
					n,
					e,
					!0
				];
			}
			return n instanceof Int32Array ? [
				[],
				n,
				!1
			] : [
				[],
				new Int32Array(n),
				!1
			];
		}
		ElementsAreEqual(e, t) {
			return this._originalElementsOrHash[e] === this._modifiedElementsOrHash[t] && (!this._hasStrings || this._originalStringElements[e] === this._modifiedStringElements[t]);
		}
		ElementsAreStrictEqual(t, n) {
			return !!this.ElementsAreEqual(t, n) && e._getStrictElement(this._originalSequence, t) === e._getStrictElement(this._modifiedSequence, n);
		}
		static _getStrictElement(e, t) {
			return "function" == typeof e.getStrictElement ? e.getStrictElement(t) : null;
		}
		OriginalElementsAreEqual(e, t) {
			return this._originalElementsOrHash[e] === this._originalElementsOrHash[t] && (!this._hasStrings || this._originalStringElements[e] === this._originalStringElements[t]);
		}
		ModifiedElementsAreEqual(e, t) {
			return this._modifiedElementsOrHash[e] === this._modifiedElementsOrHash[t] && (!this._hasStrings || this._modifiedStringElements[e] === this._modifiedStringElements[t]);
		}
		ComputeDiff(e) {
			return this._ComputeDiff(0, this._originalElementsOrHash.length - 1, 0, this._modifiedElementsOrHash.length - 1, e);
		}
		_ComputeDiff(e, t, n, r, i) {
			const s = [!1];
			let o = this.ComputeDiffRecursive(e, t, n, r, s);
			return i && (o = this.PrettifyChanges(o)), {
				quitEarly: s[0],
				changes: o
			};
		}
		ComputeDiffRecursive(e, t, n, r, i) {
			for (i[0] = !1; e <= t && n <= r && this.ElementsAreEqual(e, n);) e++, n++;
			for (; t >= e && r >= n && this.ElementsAreEqual(t, r);) t--, r--;
			if (e > t || n > r) {
				let i;
				return n <= r ? (Ie.Assert(e === t + 1, "originalStart should only be one more than originalEnd"), i = [new ve(e, 0, n, r - n + 1)]) : e <= t ? (Ie.Assert(n === r + 1, "modifiedStart should only be one more than modifiedEnd"), i = [new ve(e, t - e + 1, n, 0)]) : (Ie.Assert(e === t + 1, "originalStart should only be one more than originalEnd"), Ie.Assert(n === r + 1, "modifiedStart should only be one more than modifiedEnd"), i = []), i;
			}
			const s = [0], o = [0], a = this.ComputeRecursionPoint(e, t, n, r, s, o, i), l = s[0], u = o[0];
			if (null !== a) return a;
			if (!i[0]) {
				const s = this.ComputeDiffRecursive(e, l, n, u, i);
				let o = [];
				return o = i[0] ? [new ve(l + 1, t - (l + 1) + 1, u + 1, r - (u + 1) + 1)] : this.ComputeDiffRecursive(l + 1, t, u + 1, r, i), this.ConcatenateChanges(s, o);
			}
			return [new ve(e, t - e + 1, n, r - n + 1)];
		}
		WALKTRACE(e, t, n, r, i, s, o, a, l, u, h, c, d, g, m, f, p, b) {
			let w = null, _ = null, C = new Pe(), y = t, v = n, L = d[0] - f[0] - r, N = -1073741824, E = this.m_forwardHistory.length - 1;
			do {
				const t = L + e;
				t === y || t < v && l[t - 1] < l[t + 1] ? (g = (h = l[t + 1]) - L - r, h < N && C.MarkNextChange(), N = h, C.AddModifiedElement(h + 1, g), L = t + 1 - e) : (g = (h = l[t - 1] + 1) - L - r, h < N && C.MarkNextChange(), N = h - 1, C.AddOriginalElement(h, g + 1), L = t - 1 - e), E >= 0 && (e = (l = this.m_forwardHistory[E])[0], y = 1, v = l.length - 1);
			} while (--E >= -1);
			if (w = C.getReverseChanges(), b[0]) {
				let e = d[0] + 1, t = f[0] + 1;
				if (null !== w && w.length > 0) {
					const n = w[w.length - 1];
					e = Math.max(e, n.getOriginalEnd()), t = Math.max(t, n.getModifiedEnd());
				}
				_ = [new ve(e, c - e + 1, t, m - t + 1)];
			} else {
				C = new Pe(), y = s, v = o, L = d[0] - f[0] - a, N = 1073741824, E = p ? this.m_reverseHistory.length - 1 : this.m_reverseHistory.length - 2;
				do {
					const e = L + i;
					e === y || e < v && u[e - 1] >= u[e + 1] ? (g = (h = u[e + 1] - 1) - L - a, h > N && C.MarkNextChange(), N = h + 1, C.AddOriginalElement(h + 1, g + 1), L = e + 1 - i) : (g = (h = u[e - 1]) - L - a, h > N && C.MarkNextChange(), N = h, C.AddModifiedElement(h + 1, g + 1), L = e - 1 - i), E >= 0 && (i = (u = this.m_reverseHistory[E])[0], y = 1, v = u.length - 1);
				} while (--E >= -1);
				_ = C.getChanges();
			}
			return this.ConcatenateChanges(w, _);
		}
		ComputeRecursionPoint(e, t, n, r, i, s, o) {
			let a = 0, l = 0, u = 0, h = 0, c = 0, d = 0;
			e--, n--, i[0] = 0, s[0] = 0, this.m_forwardHistory = [], this.m_reverseHistory = [];
			const g = t - e + (r - n), m = g + 1, f = new Int32Array(m), p = new Int32Array(m), b = r - n, w = t - e, _ = e - n, C = t - r, y = (w - b) % 2 == 0;
			f[b] = e, p[w] = t, o[0] = !1;
			for (let v = 1; v <= g / 2 + 1; v++) {
				let g = 0, L = 0;
				u = this.ClipDiagonalBound(b - v, v, b, m), h = this.ClipDiagonalBound(b + v, v, b, m);
				for (let e = u; e <= h; e += 2) {
					a = e === u || e < h && f[e - 1] < f[e + 1] ? f[e + 1] : f[e - 1] + 1, l = a - (e - b) - _;
					const n = a;
					for (; a < t && l < r && this.ElementsAreEqual(a + 1, l + 1);) a++, l++;
					if (f[e] = a, a + l > g + L && (g = a, L = l), !y && Math.abs(e - w) <= v - 1 && a >= p[e]) return i[0] = a, s[0] = l, n <= p[e] && v <= 1448 ? this.WALKTRACE(b, u, h, _, w, c, d, C, f, p, a, t, i, l, r, s, y, o) : null;
				}
				const N = (g - e + (L - n) - v) / 2;
				if (null !== this.ContinueProcessingPredicate && !this.ContinueProcessingPredicate(g, N)) return o[0] = !0, i[0] = g, s[0] = L, N > 0 && v <= 1448 ? this.WALKTRACE(b, u, h, _, w, c, d, C, f, p, a, t, i, l, r, s, y, o) : (e++, n++, [new ve(e, t - e + 1, n, r - n + 1)]);
				c = this.ClipDiagonalBound(w - v, v, w, m), d = this.ClipDiagonalBound(w + v, v, w, m);
				for (let m = c; m <= d; m += 2) {
					a = m === c || m < d && p[m - 1] >= p[m + 1] ? p[m + 1] - 1 : p[m - 1], l = a - (m - w) - C;
					const g = a;
					for (; a > e && l > n && this.ElementsAreEqual(a, l);) a--, l--;
					if (p[m] = a, y && Math.abs(m - b) <= v && a <= f[m]) return i[0] = a, s[0] = l, g >= f[m] && v <= 1448 ? this.WALKTRACE(b, u, h, _, w, c, d, C, f, p, a, t, i, l, r, s, y, o) : null;
				}
				if (v <= 1447) {
					let e = new Int32Array(h - u + 2);
					e[0] = b - u + 1, Te.Copy2(f, u, e, 1, h - u + 1), this.m_forwardHistory.push(e), e = new Int32Array(d - c + 2), e[0] = w - c + 1, Te.Copy2(p, c, e, 1, d - c + 1), this.m_reverseHistory.push(e);
				}
			}
			return this.WALKTRACE(b, u, h, _, w, c, d, C, f, p, a, t, i, l, r, s, y, o);
		}
		PrettifyChanges(e) {
			for (let t = 0; t < e.length; t++) {
				const n = e[t], r = t < e.length - 1 ? e[t + 1].originalStart : this._originalElementsOrHash.length, i = t < e.length - 1 ? e[t + 1].modifiedStart : this._modifiedElementsOrHash.length, s = n.originalLength > 0, o = n.modifiedLength > 0;
				for (; n.originalStart + n.originalLength < r && n.modifiedStart + n.modifiedLength < i && (!s || this.OriginalElementsAreEqual(n.originalStart, n.originalStart + n.originalLength)) && (!o || this.ModifiedElementsAreEqual(n.modifiedStart, n.modifiedStart + n.modifiedLength));) {
					const e = this.ElementsAreStrictEqual(n.originalStart, n.modifiedStart);
					if (this.ElementsAreStrictEqual(n.originalStart + n.originalLength, n.modifiedStart + n.modifiedLength) && !e) break;
					n.originalStart++, n.modifiedStart++;
				}
				const a = [null];
				t < e.length - 1 && this.ChangesOverlap(e[t], e[t + 1], a) && (e[t] = a[0], e.splice(t + 1, 1), t--);
			}
			for (let t = e.length - 1; t >= 0; t--) {
				const n = e[t];
				let r = 0, i = 0;
				if (t > 0) {
					const n = e[t - 1];
					r = n.originalStart + n.originalLength, i = n.modifiedStart + n.modifiedLength;
				}
				const s = n.originalLength > 0, o = n.modifiedLength > 0;
				let a = 0, l = this._boundaryScore(n.originalStart, n.originalLength, n.modifiedStart, n.modifiedLength);
				for (let e = 1;; e++) {
					const t = n.originalStart - e, u = n.modifiedStart - e;
					if (t < r || u < i) break;
					if (s && !this.OriginalElementsAreEqual(t, t + n.originalLength)) break;
					if (o && !this.ModifiedElementsAreEqual(u, u + n.modifiedLength)) break;
					const h = (t === r && u === i ? 5 : 0) + this._boundaryScore(t, n.originalLength, u, n.modifiedLength);
					h > l && (l = h, a = e);
				}
				n.originalStart -= a, n.modifiedStart -= a;
				const u = [null];
				t > 0 && this.ChangesOverlap(e[t - 1], e[t], u) && (e[t - 1] = u[0], e.splice(t, 1), t++);
			}
			if (this._hasStrings) for (let t = 1, n = e.length; t < n; t++) {
				const n = e[t - 1], r = e[t], i = r.originalStart - n.originalStart - n.originalLength, s = n.originalStart, o = r.originalStart + r.originalLength, a = o - s, l = n.modifiedStart, u = r.modifiedStart + r.modifiedLength, h = u - l;
				if (i < 5 && a < 20 && h < 20) {
					const e = this._findBetterContiguousSequence(s, a, l, h, i);
					if (e) {
						const [t, s] = e;
						t === n.originalStart + n.originalLength && s === n.modifiedStart + n.modifiedLength || (n.originalLength = t - n.originalStart, n.modifiedLength = s - n.modifiedStart, r.originalStart = t + i, r.modifiedStart = s + i, r.originalLength = o - r.originalStart, r.modifiedLength = u - r.modifiedStart);
					}
				}
			}
			return e;
		}
		_findBetterContiguousSequence(e, t, n, r, i) {
			if (t < i || r < i) return null;
			const s = e + t - i + 1, o = n + r - i + 1;
			let a = 0, l = 0, u = 0;
			for (let h = e; h < s; h++) for (let e = n; e < o; e++) {
				const t = this._contiguousSequenceScore(h, e, i);
				t > 0 && t > a && (a = t, l = h, u = e);
			}
			return a > 0 ? [l, u] : null;
		}
		_contiguousSequenceScore(e, t, n) {
			let r = 0;
			for (let i = 0; i < n; i++) {
				if (!this.ElementsAreEqual(e + i, t + i)) return 0;
				r += this._originalStringElements[e + i].length;
			}
			return r;
		}
		_OriginalIsBoundary(e) {
			return e <= 0 || e >= this._originalElementsOrHash.length - 1 || this._hasStrings && /^\s*$/.test(this._originalStringElements[e]);
		}
		_OriginalRegionIsBoundary(e, t) {
			if (this._OriginalIsBoundary(e) || this._OriginalIsBoundary(e - 1)) return !0;
			if (t > 0) {
				const n = e + t;
				if (this._OriginalIsBoundary(n - 1) || this._OriginalIsBoundary(n)) return !0;
			}
			return !1;
		}
		_ModifiedIsBoundary(e) {
			return e <= 0 || e >= this._modifiedElementsOrHash.length - 1 || this._hasStrings && /^\s*$/.test(this._modifiedStringElements[e]);
		}
		_ModifiedRegionIsBoundary(e, t) {
			if (this._ModifiedIsBoundary(e) || this._ModifiedIsBoundary(e - 1)) return !0;
			if (t > 0) {
				const n = e + t;
				if (this._ModifiedIsBoundary(n - 1) || this._ModifiedIsBoundary(n)) return !0;
			}
			return !1;
		}
		_boundaryScore(e, t, n, r) {
			return (this._OriginalRegionIsBoundary(e, t) ? 1 : 0) + (this._ModifiedRegionIsBoundary(n, r) ? 1 : 0);
		}
		ConcatenateChanges(e, t) {
			const n = [];
			if (0 === e.length || 0 === t.length) return t.length > 0 ? t : e;
			if (this.ChangesOverlap(e[e.length - 1], t[0], n)) {
				const r = new Array(e.length + t.length - 1);
				return Te.Copy(e, 0, r, 0, e.length - 1), r[e.length - 1] = n[0], Te.Copy(t, 1, r, e.length, t.length - 1), r;
			}
			{
				const n = new Array(e.length + t.length);
				return Te.Copy(e, 0, n, 0, e.length), Te.Copy(t, 0, n, e.length, t.length), n;
			}
		}
		ChangesOverlap(e, t, n) {
			if (Ie.Assert(e.originalStart <= t.originalStart, "Left change is not less than or equal to right change"), Ie.Assert(e.modifiedStart <= t.modifiedStart, "Left change is not less than or equal to right change"), e.originalStart + e.originalLength >= t.originalStart || e.modifiedStart + e.modifiedLength >= t.modifiedStart) {
				const r = e.originalStart;
				let i = e.originalLength;
				const s = e.modifiedStart;
				let o = e.modifiedLength;
				return e.originalStart + e.originalLength >= t.originalStart && (i = t.originalStart + t.originalLength - e.originalStart), e.modifiedStart + e.modifiedLength >= t.modifiedStart && (o = t.modifiedStart + t.modifiedLength - e.modifiedStart), n[0] = new ve(r, i, s, o), !0;
			}
			return n[0] = null, !1;
		}
		ClipDiagonalBound(e, t, n, r) {
			if (e >= 0 && e < r) return e;
			const i = t % 2 == 0;
			return e < 0 ? i === (n % 2 == 0) ? 0 : 1 : i === ((r - n - 1) % 2 == 0) ? r - 1 : r - 2;
		}
	}, De = class e {
		constructor(e, t) {
			this.lineNumber = e, this.column = t;
		}
		with(t = this.lineNumber, n = this.column) {
			return t === this.lineNumber && n === this.column ? this : new e(t, n);
		}
		delta(e = 0, t = 0) {
			return this.with(Math.max(1, this.lineNumber + e), Math.max(1, this.column + t));
		}
		equals(t) {
			return e.equals(this, t);
		}
		static equals(e, t) {
			return !e && !t || !!e && !!t && e.lineNumber === t.lineNumber && e.column === t.column;
		}
		isBefore(t) {
			return e.isBefore(this, t);
		}
		static isBefore(e, t) {
			return e.lineNumber < t.lineNumber || !(t.lineNumber < e.lineNumber) && e.column < t.column;
		}
		isBeforeOrEqual(t) {
			return e.isBeforeOrEqual(this, t);
		}
		static isBeforeOrEqual(e, t) {
			return e.lineNumber < t.lineNumber || !(t.lineNumber < e.lineNumber) && e.column <= t.column;
		}
		static compare(e, t) {
			const n = 0 | e.lineNumber, r = 0 | t.lineNumber;
			return n === r ? (0 | e.column) - (0 | t.column) : n - r;
		}
		clone() {
			return new e(this.lineNumber, this.column);
		}
		toString() {
			return "(" + this.lineNumber + "," + this.column + ")";
		}
		static lift(t) {
			return new e(t.lineNumber, t.column);
		}
		static isIPosition(e) {
			return !!e && "number" == typeof e.lineNumber && "number" == typeof e.column;
		}
		toJSON() {
			return {
				lineNumber: this.lineNumber,
				column: this.column
			};
		}
	}, qe = class e {
		constructor(e, t, n, r) {
			e > n || e === n && t > r ? (this.startLineNumber = n, this.startColumn = r, this.endLineNumber = e, this.endColumn = t) : (this.startLineNumber = e, this.startColumn = t, this.endLineNumber = n, this.endColumn = r);
		}
		isEmpty() {
			return e.isEmpty(this);
		}
		static isEmpty(e) {
			return e.startLineNumber === e.endLineNumber && e.startColumn === e.endColumn;
		}
		containsPosition(t) {
			return e.containsPosition(this, t);
		}
		static containsPosition(e, t) {
			return !(t.lineNumber < e.startLineNumber || t.lineNumber > e.endLineNumber) && !(t.lineNumber === e.startLineNumber && t.column < e.startColumn) && !(t.lineNumber === e.endLineNumber && t.column > e.endColumn);
		}
		static strictContainsPosition(e, t) {
			return !(t.lineNumber < e.startLineNumber || t.lineNumber > e.endLineNumber) && !(t.lineNumber === e.startLineNumber && t.column <= e.startColumn) && !(t.lineNumber === e.endLineNumber && t.column >= e.endColumn);
		}
		containsRange(t) {
			return e.containsRange(this, t);
		}
		static containsRange(e, t) {
			return !(t.startLineNumber < e.startLineNumber || t.endLineNumber < e.startLineNumber) && !(t.startLineNumber > e.endLineNumber || t.endLineNumber > e.endLineNumber) && !(t.startLineNumber === e.startLineNumber && t.startColumn < e.startColumn) && !(t.endLineNumber === e.endLineNumber && t.endColumn > e.endColumn);
		}
		strictContainsRange(t) {
			return e.strictContainsRange(this, t);
		}
		static strictContainsRange(e, t) {
			return !(t.startLineNumber < e.startLineNumber || t.endLineNumber < e.startLineNumber) && !(t.startLineNumber > e.endLineNumber || t.endLineNumber > e.endLineNumber) && !(t.startLineNumber === e.startLineNumber && t.startColumn <= e.startColumn) && !(t.endLineNumber === e.endLineNumber && t.endColumn >= e.endColumn);
		}
		plusRange(t) {
			return e.plusRange(this, t);
		}
		static plusRange(t, n) {
			let r, i, s, o;
			return n.startLineNumber < t.startLineNumber ? (r = n.startLineNumber, i = n.startColumn) : n.startLineNumber === t.startLineNumber ? (r = n.startLineNumber, i = Math.min(n.startColumn, t.startColumn)) : (r = t.startLineNumber, i = t.startColumn), n.endLineNumber > t.endLineNumber ? (s = n.endLineNumber, o = n.endColumn) : n.endLineNumber === t.endLineNumber ? (s = n.endLineNumber, o = Math.max(n.endColumn, t.endColumn)) : (s = t.endLineNumber, o = t.endColumn), new e(r, i, s, o);
		}
		intersectRanges(t) {
			return e.intersectRanges(this, t);
		}
		static intersectRanges(t, n) {
			let r = t.startLineNumber, i = t.startColumn, s = t.endLineNumber, o = t.endColumn;
			const a = n.startLineNumber, l = n.startColumn, u = n.endLineNumber, h = n.endColumn;
			return r < a ? (r = a, i = l) : r === a && (i = Math.max(i, l)), s > u ? (s = u, o = h) : s === u && (o = Math.min(o, h)), r > s || r === s && i > o ? null : new e(r, i, s, o);
		}
		equalsRange(t) {
			return e.equalsRange(this, t);
		}
		static equalsRange(e, t) {
			return !e && !t || !!e && !!t && e.startLineNumber === t.startLineNumber && e.startColumn === t.startColumn && e.endLineNumber === t.endLineNumber && e.endColumn === t.endColumn;
		}
		getEndPosition() {
			return e.getEndPosition(this);
		}
		static getEndPosition(e) {
			return new De(e.endLineNumber, e.endColumn);
		}
		getStartPosition() {
			return e.getStartPosition(this);
		}
		static getStartPosition(e) {
			return new De(e.startLineNumber, e.startColumn);
		}
		toString() {
			return "[" + this.startLineNumber + "," + this.startColumn + " -> " + this.endLineNumber + "," + this.endColumn + "]";
		}
		setEndPosition(t, n) {
			return new e(this.startLineNumber, this.startColumn, t, n);
		}
		setStartPosition(t, n) {
			return new e(t, n, this.endLineNumber, this.endColumn);
		}
		collapseToStart() {
			return e.collapseToStart(this);
		}
		static collapseToStart(t) {
			return new e(t.startLineNumber, t.startColumn, t.startLineNumber, t.startColumn);
		}
		collapseToEnd() {
			return e.collapseToEnd(this);
		}
		static collapseToEnd(t) {
			return new e(t.endLineNumber, t.endColumn, t.endLineNumber, t.endColumn);
		}
		delta(t) {
			return new e(this.startLineNumber + t, this.startColumn, this.endLineNumber + t, this.endColumn);
		}
		isSingleLine() {
			return this.startLineNumber === this.endLineNumber;
		}
		static fromPositions(t, n = t) {
			return new e(t.lineNumber, t.column, n.lineNumber, n.column);
		}
		static lift(t) {
			return t ? new e(t.startLineNumber, t.startColumn, t.endLineNumber, t.endColumn) : null;
		}
		static isIRange(e) {
			return !!e && "number" == typeof e.startLineNumber && "number" == typeof e.startColumn && "number" == typeof e.endLineNumber && "number" == typeof e.endColumn;
		}
		static areIntersectingOrTouching(e, t) {
			return !(e.endLineNumber < t.startLineNumber || e.endLineNumber === t.startLineNumber && e.endColumn < t.startColumn) && !(t.endLineNumber < e.startLineNumber || t.endLineNumber === e.startLineNumber && t.endColumn < e.startColumn);
		}
		static areIntersecting(e, t) {
			return !(e.endLineNumber < t.startLineNumber || e.endLineNumber === t.startLineNumber && e.endColumn <= t.startColumn) && !(t.endLineNumber < e.startLineNumber || t.endLineNumber === e.startLineNumber && t.endColumn <= e.startColumn);
		}
		static areOnlyIntersecting(e, t) {
			return !(e.endLineNumber < t.startLineNumber - 1 || e.endLineNumber === t.startLineNumber && e.endColumn < t.startColumn - 1) && !(t.endLineNumber < e.startLineNumber - 1 || t.endLineNumber === e.startLineNumber && t.endColumn < e.startColumn - 1);
		}
		static compareRangesUsingStarts(e, t) {
			if (e && t) {
				const n = 0 | e.startLineNumber, r = 0 | t.startLineNumber;
				if (n === r) {
					const n = 0 | e.startColumn, r = 0 | t.startColumn;
					if (n === r) {
						const n = 0 | e.endLineNumber, r = 0 | t.endLineNumber;
						return n === r ? (0 | e.endColumn) - (0 | t.endColumn) : n - r;
					}
					return n - r;
				}
				return n - r;
			}
			return (e ? 1 : 0) - (t ? 1 : 0);
		}
		static compareRangesUsingEnds(e, t) {
			return e.endLineNumber === t.endLineNumber ? e.endColumn === t.endColumn ? e.startLineNumber === t.startLineNumber ? e.startColumn - t.startColumn : e.startLineNumber - t.startLineNumber : e.endColumn - t.endColumn : e.endLineNumber - t.endLineNumber;
		}
		static spansMultipleLines(e) {
			return e.endLineNumber > e.startLineNumber;
		}
		toJSON() {
			return this;
		}
	};
	function Ve(e) {
		return e < 0 ? 0 : e > 255 ? 255 : 0 | e;
	}
	function Ke(e) {
		return e < 0 ? 0 : e > 4294967295 ? 4294967295 : 0 | e;
	}
	var Be = class e {
		constructor(t) {
			const n = Ve(t);
			this._defaultValue = n, this._asciiMap = e._createAsciiMap(n), this._map = /* @__PURE__ */ new Map();
		}
		static _createAsciiMap(e) {
			const t = new Uint8Array(256);
			return t.fill(e), t;
		}
		set(e, t) {
			const n = Ve(t);
			e >= 0 && e < 256 ? this._asciiMap[e] = n : this._map.set(e, n);
		}
		get(e) {
			return e >= 0 && e < 256 ? this._asciiMap[e] : this._map.get(e) || this._defaultValue;
		}
		clear() {
			this._asciiMap.fill(this._defaultValue), this._map.clear();
		}
	}, Ue = class {
		constructor(e, t, n) {
			const r = new Uint8Array(e * t);
			for (let i = 0, s = e * t; i < s; i++) r[i] = n;
			this._data = r, this.rows = e, this.cols = t;
		}
		get(e, t) {
			return this._data[e * this.cols + t];
		}
		set(e, t, n) {
			this._data[e * this.cols + t] = n;
		}
	}, $e = class {
		constructor(e) {
			let t = 0, n = 0;
			for (let i = 0, s = e.length; i < s; i++) {
				const [r, s, o] = e[i];
				s > t && (t = s), r > n && (n = r), o > n && (n = o);
			}
			t++, n++;
			const r = new Ue(n, t, 0);
			for (let i = 0, s = e.length; i < s; i++) {
				const [t, n, s] = e[i];
				r.set(t, n, s);
			}
			this._states = r, this._maxCharCode = t;
		}
		nextState(e, t) {
			return t < 0 || t >= this._maxCharCode ? 0 : this._states.get(e, t);
		}
	};
	let We = null;
	let ze = null;
	var He = class e {
		static _createLink(e, t, n, r, i) {
			let s = i - 1;
			do {
				const n = t.charCodeAt(s);
				if (2 !== e.get(n)) break;
				s--;
			} while (s > r);
			if (r > 0) {
				const e = t.charCodeAt(r - 1), n = t.charCodeAt(s);
				(40 === e && 41 === n || 91 === e && 93 === n || 123 === e && 125 === n) && s--;
			}
			return {
				range: {
					startLineNumber: n,
					startColumn: r + 1,
					endLineNumber: n,
					endColumn: s + 2
				},
				url: t.substring(r, s + 1)
			};
		}
		static computeLinks(t, n = function() {
			return null === We && (We = new $e([
				[
					1,
					104,
					2
				],
				[
					1,
					72,
					2
				],
				[
					1,
					102,
					6
				],
				[
					1,
					70,
					6
				],
				[
					2,
					116,
					3
				],
				[
					2,
					84,
					3
				],
				[
					3,
					116,
					4
				],
				[
					3,
					84,
					4
				],
				[
					4,
					112,
					5
				],
				[
					4,
					80,
					5
				],
				[
					5,
					115,
					9
				],
				[
					5,
					83,
					9
				],
				[
					5,
					58,
					10
				],
				[
					6,
					105,
					7
				],
				[
					6,
					73,
					7
				],
				[
					7,
					108,
					8
				],
				[
					7,
					76,
					8
				],
				[
					8,
					101,
					9
				],
				[
					8,
					69,
					9
				],
				[
					9,
					58,
					10
				],
				[
					10,
					47,
					11
				],
				[
					11,
					47,
					12
				]
			])), We;
		}()) {
			const r = function() {
				if (null === ze) {
					ze = new Be(0);
					const e = " 	<>'\"、。｡､，．：；‘〈「『〔（［｛｢｣｝］）〕』」〉’｀～…|";
					for (let n = 0; n < 36; n++) ze.set(e.charCodeAt(n), 1);
					const t = ".,;:";
					for (let n = 0; n < 4; n++) ze.set(t.charCodeAt(n), 2);
				}
				return ze;
			}(), i = [];
			for (let s = 1, o = t.getLineCount(); s <= o; s++) {
				const o = t.getLineContent(s), a = o.length;
				let l = 0, u = 0, h = 0, c = 1, d = !1, g = !1, m = !1, f = !1;
				for (; l < a;) {
					let t = !1;
					const a = o.charCodeAt(l);
					if (13 === c) {
						let n;
						switch (a) {
							case 40:
								d = !0, n = 0;
								break;
							case 41:
								n = d ? 0 : 1;
								break;
							case 91:
								m = !0, g = !0, n = 0;
								break;
							case 93:
								m = !1, n = g ? 0 : 1;
								break;
							case 123:
								f = !0, n = 0;
								break;
							case 125:
								n = f ? 0 : 1;
								break;
							case 39:
							case 34:
							case 96:
								n = h === a ? 1 : 39 === h || 34 === h || 96 === h ? 0 : 1;
								break;
							case 42:
								n = 42 === h ? 1 : 0;
								break;
							case 32:
								n = m ? 0 : 1;
								break;
							default: n = r.get(a);
						}
						1 === n && (i.push(e._createLink(r, o, s, u, l)), t = !0);
					} else if (12 === c) {
						let e;
						91 === a ? (g = !0, e = 0) : e = r.get(a), 1 === e ? t = !0 : c = 13;
					} else c = n.nextState(c, a), 0 === c && (t = !0);
					t && (c = 1, d = !1, g = !1, f = !1, u = l + 1, h = a), l++;
				}
				13 === c && i.push(e._createLink(r, o, s, u, a));
			}
			return i;
		}
	};
	var je = class e {
		constructor() {
			this._defaultValueSet = [
				["true", "false"],
				["True", "False"],
				[
					"Private",
					"Public",
					"Friend",
					"ReadOnly",
					"Partial",
					"Protected",
					"WriteOnly"
				],
				[
					"public",
					"protected",
					"private"
				]
			];
		}
		static {
			this.INSTANCE = new e();
		}
		navigateValueSet(e, t, n, r, i) {
			if (e && t) {
				const n = this.doNavigateValueSet(t, i);
				if (n) return {
					range: e,
					value: n
				};
			}
			if (n && r) {
				const e = this.doNavigateValueSet(r, i);
				if (e) return {
					range: n,
					value: e
				};
			}
			return null;
		}
		doNavigateValueSet(e, t) {
			const n = this.numberReplace(e, t);
			return null !== n ? n : this.textReplace(e, t);
		}
		numberReplace(e, t) {
			const n = Math.pow(10, e.length - (e.lastIndexOf(".") + 1));
			let r = Number(e);
			const i = parseFloat(e);
			return isNaN(r) || isNaN(i) || r !== i ? null : 0 !== r || t ? (r = Math.floor(r * n), r += t ? n : -n, String(r / n)) : null;
		}
		textReplace(e, t) {
			return this.valueSetsReplace(this._defaultValueSet, e, t);
		}
		valueSetsReplace(e, t, n) {
			let r = null;
			for (let i = 0, s = e.length; null === r && i < s; i++) r = this.valueSetReplace(e[i], t, n);
			return r;
		}
		valueSetReplace(e, t, n) {
			let r = e.indexOf(t);
			return r >= 0 ? (r += n ? 1 : -1, r < 0 ? r = e.length - 1 : r %= e.length, e[r]) : null;
		}
	};
	const Ge = Object.freeze(function(e, t) {
		const n = setTimeout(e.bind(t), 0);
		return { dispose() {
			clearTimeout(n);
		} };
	});
	var Xe;
	(function(e) {
		e.isCancellationToken = function(t) {
			return t === e.None || t === e.Cancelled || t instanceof Qe || !(!t || "object" != typeof t) && "boolean" == typeof t.isCancellationRequested && "function" == typeof t.onCancellationRequested;
		}, e.None = Object.freeze({
			isCancellationRequested: !1,
			onCancellationRequested: _.None
		}), e.Cancelled = Object.freeze({
			isCancellationRequested: !0,
			onCancellationRequested: Ge
		});
	})(Xe || (Xe = {}));
	var Qe = class {
		constructor() {
			this._isCancelled = !1, this._emitter = null;
		}
		cancel() {
			this._isCancelled || (this._isCancelled = !0, this._emitter && (this._emitter.fire(void 0), this.dispose()));
		}
		get isCancellationRequested() {
			return this._isCancelled;
		}
		get onCancellationRequested() {
			return this._isCancelled ? Ge : (this._emitter || (this._emitter = new R()), this._emitter.event);
		}
		dispose() {
			this._emitter && (this._emitter.dispose(), this._emitter = null);
		}
	}, Ye = class {
		constructor(e) {
			this._token = void 0, this._parentListener = void 0, this._parentListener = e && e.onCancellationRequested(this.cancel, this);
		}
		get token() {
			return this._token || (this._token = new Qe()), this._token;
		}
		cancel() {
			this._token ? this._token instanceof Qe && this._token.cancel() : this._token = Xe.Cancelled;
		}
		dispose(e = !1) {
			e && this.cancel(), this._parentListener?.dispose(), this._token ? this._token instanceof Qe && this._token.dispose() : this._token = Xe.None;
		}
	}, Je = class {
		constructor() {
			this._keyCodeToStr = [], this._strToKeyCode = Object.create(null);
		}
		define(e, t) {
			this._keyCodeToStr[e] = t, this._strToKeyCode[t.toLowerCase()] = e;
		}
		keyCodeToStr(e) {
			return this._keyCodeToStr[e];
		}
		strToKeyCode(e) {
			return this._strToKeyCode[e.toLowerCase()] || 0;
		}
	};
	const Ze = new Je(), et = new Je(), tt = new Je(), nt = new Array(230), rt = Object.create(null), it = Object.create(null), st = [];
	for (let ps = 0; ps <= 193; ps++) st[ps] = -1;
	var ot;
	let at;
	(function() {
		const e = "", t = [
			[
				1,
				0,
				"None",
				0,
				"unknown",
				0,
				"VK_UNKNOWN",
				e,
				e
			],
			[
				1,
				1,
				"Hyper",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				2,
				"Super",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				3,
				"Fn",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				4,
				"FnLock",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				5,
				"Suspend",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				6,
				"Resume",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				7,
				"Turbo",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				8,
				"Sleep",
				0,
				e,
				0,
				"VK_SLEEP",
				e,
				e
			],
			[
				1,
				9,
				"WakeUp",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				0,
				10,
				"KeyA",
				31,
				"A",
				65,
				"VK_A",
				e,
				e
			],
			[
				0,
				11,
				"KeyB",
				32,
				"B",
				66,
				"VK_B",
				e,
				e
			],
			[
				0,
				12,
				"KeyC",
				33,
				"C",
				67,
				"VK_C",
				e,
				e
			],
			[
				0,
				13,
				"KeyD",
				34,
				"D",
				68,
				"VK_D",
				e,
				e
			],
			[
				0,
				14,
				"KeyE",
				35,
				"E",
				69,
				"VK_E",
				e,
				e
			],
			[
				0,
				15,
				"KeyF",
				36,
				"F",
				70,
				"VK_F",
				e,
				e
			],
			[
				0,
				16,
				"KeyG",
				37,
				"G",
				71,
				"VK_G",
				e,
				e
			],
			[
				0,
				17,
				"KeyH",
				38,
				"H",
				72,
				"VK_H",
				e,
				e
			],
			[
				0,
				18,
				"KeyI",
				39,
				"I",
				73,
				"VK_I",
				e,
				e
			],
			[
				0,
				19,
				"KeyJ",
				40,
				"J",
				74,
				"VK_J",
				e,
				e
			],
			[
				0,
				20,
				"KeyK",
				41,
				"K",
				75,
				"VK_K",
				e,
				e
			],
			[
				0,
				21,
				"KeyL",
				42,
				"L",
				76,
				"VK_L",
				e,
				e
			],
			[
				0,
				22,
				"KeyM",
				43,
				"M",
				77,
				"VK_M",
				e,
				e
			],
			[
				0,
				23,
				"KeyN",
				44,
				"N",
				78,
				"VK_N",
				e,
				e
			],
			[
				0,
				24,
				"KeyO",
				45,
				"O",
				79,
				"VK_O",
				e,
				e
			],
			[
				0,
				25,
				"KeyP",
				46,
				"P",
				80,
				"VK_P",
				e,
				e
			],
			[
				0,
				26,
				"KeyQ",
				47,
				"Q",
				81,
				"VK_Q",
				e,
				e
			],
			[
				0,
				27,
				"KeyR",
				48,
				"R",
				82,
				"VK_R",
				e,
				e
			],
			[
				0,
				28,
				"KeyS",
				49,
				"S",
				83,
				"VK_S",
				e,
				e
			],
			[
				0,
				29,
				"KeyT",
				50,
				"T",
				84,
				"VK_T",
				e,
				e
			],
			[
				0,
				30,
				"KeyU",
				51,
				"U",
				85,
				"VK_U",
				e,
				e
			],
			[
				0,
				31,
				"KeyV",
				52,
				"V",
				86,
				"VK_V",
				e,
				e
			],
			[
				0,
				32,
				"KeyW",
				53,
				"W",
				87,
				"VK_W",
				e,
				e
			],
			[
				0,
				33,
				"KeyX",
				54,
				"X",
				88,
				"VK_X",
				e,
				e
			],
			[
				0,
				34,
				"KeyY",
				55,
				"Y",
				89,
				"VK_Y",
				e,
				e
			],
			[
				0,
				35,
				"KeyZ",
				56,
				"Z",
				90,
				"VK_Z",
				e,
				e
			],
			[
				0,
				36,
				"Digit1",
				22,
				"1",
				49,
				"VK_1",
				e,
				e
			],
			[
				0,
				37,
				"Digit2",
				23,
				"2",
				50,
				"VK_2",
				e,
				e
			],
			[
				0,
				38,
				"Digit3",
				24,
				"3",
				51,
				"VK_3",
				e,
				e
			],
			[
				0,
				39,
				"Digit4",
				25,
				"4",
				52,
				"VK_4",
				e,
				e
			],
			[
				0,
				40,
				"Digit5",
				26,
				"5",
				53,
				"VK_5",
				e,
				e
			],
			[
				0,
				41,
				"Digit6",
				27,
				"6",
				54,
				"VK_6",
				e,
				e
			],
			[
				0,
				42,
				"Digit7",
				28,
				"7",
				55,
				"VK_7",
				e,
				e
			],
			[
				0,
				43,
				"Digit8",
				29,
				"8",
				56,
				"VK_8",
				e,
				e
			],
			[
				0,
				44,
				"Digit9",
				30,
				"9",
				57,
				"VK_9",
				e,
				e
			],
			[
				0,
				45,
				"Digit0",
				21,
				"0",
				48,
				"VK_0",
				e,
				e
			],
			[
				1,
				46,
				"Enter",
				3,
				"Enter",
				13,
				"VK_RETURN",
				e,
				e
			],
			[
				1,
				47,
				"Escape",
				9,
				"Escape",
				27,
				"VK_ESCAPE",
				e,
				e
			],
			[
				1,
				48,
				"Backspace",
				1,
				"Backspace",
				8,
				"VK_BACK",
				e,
				e
			],
			[
				1,
				49,
				"Tab",
				2,
				"Tab",
				9,
				"VK_TAB",
				e,
				e
			],
			[
				1,
				50,
				"Space",
				10,
				"Space",
				32,
				"VK_SPACE",
				e,
				e
			],
			[
				0,
				51,
				"Minus",
				88,
				"-",
				189,
				"VK_OEM_MINUS",
				"-",
				"OEM_MINUS"
			],
			[
				0,
				52,
				"Equal",
				86,
				"=",
				187,
				"VK_OEM_PLUS",
				"=",
				"OEM_PLUS"
			],
			[
				0,
				53,
				"BracketLeft",
				92,
				"[",
				219,
				"VK_OEM_4",
				"[",
				"OEM_4"
			],
			[
				0,
				54,
				"BracketRight",
				94,
				"]",
				221,
				"VK_OEM_6",
				"]",
				"OEM_6"
			],
			[
				0,
				55,
				"Backslash",
				93,
				"\\",
				220,
				"VK_OEM_5",
				"\\",
				"OEM_5"
			],
			[
				0,
				56,
				"IntlHash",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				0,
				57,
				"Semicolon",
				85,
				";",
				186,
				"VK_OEM_1",
				";",
				"OEM_1"
			],
			[
				0,
				58,
				"Quote",
				95,
				"'",
				222,
				"VK_OEM_7",
				"'",
				"OEM_7"
			],
			[
				0,
				59,
				"Backquote",
				91,
				"`",
				192,
				"VK_OEM_3",
				"`",
				"OEM_3"
			],
			[
				0,
				60,
				"Comma",
				87,
				",",
				188,
				"VK_OEM_COMMA",
				",",
				"OEM_COMMA"
			],
			[
				0,
				61,
				"Period",
				89,
				".",
				190,
				"VK_OEM_PERIOD",
				".",
				"OEM_PERIOD"
			],
			[
				0,
				62,
				"Slash",
				90,
				"/",
				191,
				"VK_OEM_2",
				"/",
				"OEM_2"
			],
			[
				1,
				63,
				"CapsLock",
				8,
				"CapsLock",
				20,
				"VK_CAPITAL",
				e,
				e
			],
			[
				1,
				64,
				"F1",
				59,
				"F1",
				112,
				"VK_F1",
				e,
				e
			],
			[
				1,
				65,
				"F2",
				60,
				"F2",
				113,
				"VK_F2",
				e,
				e
			],
			[
				1,
				66,
				"F3",
				61,
				"F3",
				114,
				"VK_F3",
				e,
				e
			],
			[
				1,
				67,
				"F4",
				62,
				"F4",
				115,
				"VK_F4",
				e,
				e
			],
			[
				1,
				68,
				"F5",
				63,
				"F5",
				116,
				"VK_F5",
				e,
				e
			],
			[
				1,
				69,
				"F6",
				64,
				"F6",
				117,
				"VK_F6",
				e,
				e
			],
			[
				1,
				70,
				"F7",
				65,
				"F7",
				118,
				"VK_F7",
				e,
				e
			],
			[
				1,
				71,
				"F8",
				66,
				"F8",
				119,
				"VK_F8",
				e,
				e
			],
			[
				1,
				72,
				"F9",
				67,
				"F9",
				120,
				"VK_F9",
				e,
				e
			],
			[
				1,
				73,
				"F10",
				68,
				"F10",
				121,
				"VK_F10",
				e,
				e
			],
			[
				1,
				74,
				"F11",
				69,
				"F11",
				122,
				"VK_F11",
				e,
				e
			],
			[
				1,
				75,
				"F12",
				70,
				"F12",
				123,
				"VK_F12",
				e,
				e
			],
			[
				1,
				76,
				"PrintScreen",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				77,
				"ScrollLock",
				84,
				"ScrollLock",
				145,
				"VK_SCROLL",
				e,
				e
			],
			[
				1,
				78,
				"Pause",
				7,
				"PauseBreak",
				19,
				"VK_PAUSE",
				e,
				e
			],
			[
				1,
				79,
				"Insert",
				19,
				"Insert",
				45,
				"VK_INSERT",
				e,
				e
			],
			[
				1,
				80,
				"Home",
				14,
				"Home",
				36,
				"VK_HOME",
				e,
				e
			],
			[
				1,
				81,
				"PageUp",
				11,
				"PageUp",
				33,
				"VK_PRIOR",
				e,
				e
			],
			[
				1,
				82,
				"Delete",
				20,
				"Delete",
				46,
				"VK_DELETE",
				e,
				e
			],
			[
				1,
				83,
				"End",
				13,
				"End",
				35,
				"VK_END",
				e,
				e
			],
			[
				1,
				84,
				"PageDown",
				12,
				"PageDown",
				34,
				"VK_NEXT",
				e,
				e
			],
			[
				1,
				85,
				"ArrowRight",
				17,
				"RightArrow",
				39,
				"VK_RIGHT",
				"Right",
				e
			],
			[
				1,
				86,
				"ArrowLeft",
				15,
				"LeftArrow",
				37,
				"VK_LEFT",
				"Left",
				e
			],
			[
				1,
				87,
				"ArrowDown",
				18,
				"DownArrow",
				40,
				"VK_DOWN",
				"Down",
				e
			],
			[
				1,
				88,
				"ArrowUp",
				16,
				"UpArrow",
				38,
				"VK_UP",
				"Up",
				e
			],
			[
				1,
				89,
				"NumLock",
				83,
				"NumLock",
				144,
				"VK_NUMLOCK",
				e,
				e
			],
			[
				1,
				90,
				"NumpadDivide",
				113,
				"NumPad_Divide",
				111,
				"VK_DIVIDE",
				e,
				e
			],
			[
				1,
				91,
				"NumpadMultiply",
				108,
				"NumPad_Multiply",
				106,
				"VK_MULTIPLY",
				e,
				e
			],
			[
				1,
				92,
				"NumpadSubtract",
				111,
				"NumPad_Subtract",
				109,
				"VK_SUBTRACT",
				e,
				e
			],
			[
				1,
				93,
				"NumpadAdd",
				109,
				"NumPad_Add",
				107,
				"VK_ADD",
				e,
				e
			],
			[
				1,
				94,
				"NumpadEnter",
				3,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				95,
				"Numpad1",
				99,
				"NumPad1",
				97,
				"VK_NUMPAD1",
				e,
				e
			],
			[
				1,
				96,
				"Numpad2",
				100,
				"NumPad2",
				98,
				"VK_NUMPAD2",
				e,
				e
			],
			[
				1,
				97,
				"Numpad3",
				101,
				"NumPad3",
				99,
				"VK_NUMPAD3",
				e,
				e
			],
			[
				1,
				98,
				"Numpad4",
				102,
				"NumPad4",
				100,
				"VK_NUMPAD4",
				e,
				e
			],
			[
				1,
				99,
				"Numpad5",
				103,
				"NumPad5",
				101,
				"VK_NUMPAD5",
				e,
				e
			],
			[
				1,
				100,
				"Numpad6",
				104,
				"NumPad6",
				102,
				"VK_NUMPAD6",
				e,
				e
			],
			[
				1,
				101,
				"Numpad7",
				105,
				"NumPad7",
				103,
				"VK_NUMPAD7",
				e,
				e
			],
			[
				1,
				102,
				"Numpad8",
				106,
				"NumPad8",
				104,
				"VK_NUMPAD8",
				e,
				e
			],
			[
				1,
				103,
				"Numpad9",
				107,
				"NumPad9",
				105,
				"VK_NUMPAD9",
				e,
				e
			],
			[
				1,
				104,
				"Numpad0",
				98,
				"NumPad0",
				96,
				"VK_NUMPAD0",
				e,
				e
			],
			[
				1,
				105,
				"NumpadDecimal",
				112,
				"NumPad_Decimal",
				110,
				"VK_DECIMAL",
				e,
				e
			],
			[
				0,
				106,
				"IntlBackslash",
				97,
				"OEM_102",
				226,
				"VK_OEM_102",
				e,
				e
			],
			[
				1,
				107,
				"ContextMenu",
				58,
				"ContextMenu",
				93,
				e,
				e,
				e
			],
			[
				1,
				108,
				"Power",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				109,
				"NumpadEqual",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				110,
				"F13",
				71,
				"F13",
				124,
				"VK_F13",
				e,
				e
			],
			[
				1,
				111,
				"F14",
				72,
				"F14",
				125,
				"VK_F14",
				e,
				e
			],
			[
				1,
				112,
				"F15",
				73,
				"F15",
				126,
				"VK_F15",
				e,
				e
			],
			[
				1,
				113,
				"F16",
				74,
				"F16",
				127,
				"VK_F16",
				e,
				e
			],
			[
				1,
				114,
				"F17",
				75,
				"F17",
				128,
				"VK_F17",
				e,
				e
			],
			[
				1,
				115,
				"F18",
				76,
				"F18",
				129,
				"VK_F18",
				e,
				e
			],
			[
				1,
				116,
				"F19",
				77,
				"F19",
				130,
				"VK_F19",
				e,
				e
			],
			[
				1,
				117,
				"F20",
				78,
				"F20",
				131,
				"VK_F20",
				e,
				e
			],
			[
				1,
				118,
				"F21",
				79,
				"F21",
				132,
				"VK_F21",
				e,
				e
			],
			[
				1,
				119,
				"F22",
				80,
				"F22",
				133,
				"VK_F22",
				e,
				e
			],
			[
				1,
				120,
				"F23",
				81,
				"F23",
				134,
				"VK_F23",
				e,
				e
			],
			[
				1,
				121,
				"F24",
				82,
				"F24",
				135,
				"VK_F24",
				e,
				e
			],
			[
				1,
				122,
				"Open",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				123,
				"Help",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				124,
				"Select",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				125,
				"Again",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				126,
				"Undo",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				127,
				"Cut",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				128,
				"Copy",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				129,
				"Paste",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				130,
				"Find",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				131,
				"AudioVolumeMute",
				117,
				"AudioVolumeMute",
				173,
				"VK_VOLUME_MUTE",
				e,
				e
			],
			[
				1,
				132,
				"AudioVolumeUp",
				118,
				"AudioVolumeUp",
				175,
				"VK_VOLUME_UP",
				e,
				e
			],
			[
				1,
				133,
				"AudioVolumeDown",
				119,
				"AudioVolumeDown",
				174,
				"VK_VOLUME_DOWN",
				e,
				e
			],
			[
				1,
				134,
				"NumpadComma",
				110,
				"NumPad_Separator",
				108,
				"VK_SEPARATOR",
				e,
				e
			],
			[
				0,
				135,
				"IntlRo",
				115,
				"ABNT_C1",
				193,
				"VK_ABNT_C1",
				e,
				e
			],
			[
				1,
				136,
				"KanaMode",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				0,
				137,
				"IntlYen",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				138,
				"Convert",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				139,
				"NonConvert",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				140,
				"Lang1",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				141,
				"Lang2",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				142,
				"Lang3",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				143,
				"Lang4",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				144,
				"Lang5",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				145,
				"Abort",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				146,
				"Props",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				147,
				"NumpadParenLeft",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				148,
				"NumpadParenRight",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				149,
				"NumpadBackspace",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				150,
				"NumpadMemoryStore",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				151,
				"NumpadMemoryRecall",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				152,
				"NumpadMemoryClear",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				153,
				"NumpadMemoryAdd",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				154,
				"NumpadMemorySubtract",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				155,
				"NumpadClear",
				131,
				"Clear",
				12,
				"VK_CLEAR",
				e,
				e
			],
			[
				1,
				156,
				"NumpadClearEntry",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				0,
				e,
				5,
				"Ctrl",
				17,
				"VK_CONTROL",
				e,
				e
			],
			[
				1,
				0,
				e,
				4,
				"Shift",
				16,
				"VK_SHIFT",
				e,
				e
			],
			[
				1,
				0,
				e,
				6,
				"Alt",
				18,
				"VK_MENU",
				e,
				e
			],
			[
				1,
				0,
				e,
				57,
				"Meta",
				91,
				"VK_COMMAND",
				e,
				e
			],
			[
				1,
				157,
				"ControlLeft",
				5,
				e,
				0,
				"VK_LCONTROL",
				e,
				e
			],
			[
				1,
				158,
				"ShiftLeft",
				4,
				e,
				0,
				"VK_LSHIFT",
				e,
				e
			],
			[
				1,
				159,
				"AltLeft",
				6,
				e,
				0,
				"VK_LMENU",
				e,
				e
			],
			[
				1,
				160,
				"MetaLeft",
				57,
				e,
				0,
				"VK_LWIN",
				e,
				e
			],
			[
				1,
				161,
				"ControlRight",
				5,
				e,
				0,
				"VK_RCONTROL",
				e,
				e
			],
			[
				1,
				162,
				"ShiftRight",
				4,
				e,
				0,
				"VK_RSHIFT",
				e,
				e
			],
			[
				1,
				163,
				"AltRight",
				6,
				e,
				0,
				"VK_RMENU",
				e,
				e
			],
			[
				1,
				164,
				"MetaRight",
				57,
				e,
				0,
				"VK_RWIN",
				e,
				e
			],
			[
				1,
				165,
				"BrightnessUp",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				166,
				"BrightnessDown",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				167,
				"MediaPlay",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				168,
				"MediaRecord",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				169,
				"MediaFastForward",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				170,
				"MediaRewind",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				171,
				"MediaTrackNext",
				124,
				"MediaTrackNext",
				176,
				"VK_MEDIA_NEXT_TRACK",
				e,
				e
			],
			[
				1,
				172,
				"MediaTrackPrevious",
				125,
				"MediaTrackPrevious",
				177,
				"VK_MEDIA_PREV_TRACK",
				e,
				e
			],
			[
				1,
				173,
				"MediaStop",
				126,
				"MediaStop",
				178,
				"VK_MEDIA_STOP",
				e,
				e
			],
			[
				1,
				174,
				"Eject",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				175,
				"MediaPlayPause",
				127,
				"MediaPlayPause",
				179,
				"VK_MEDIA_PLAY_PAUSE",
				e,
				e
			],
			[
				1,
				176,
				"MediaSelect",
				128,
				"LaunchMediaPlayer",
				181,
				"VK_MEDIA_LAUNCH_MEDIA_SELECT",
				e,
				e
			],
			[
				1,
				177,
				"LaunchMail",
				129,
				"LaunchMail",
				180,
				"VK_MEDIA_LAUNCH_MAIL",
				e,
				e
			],
			[
				1,
				178,
				"LaunchApp2",
				130,
				"LaunchApp2",
				183,
				"VK_MEDIA_LAUNCH_APP2",
				e,
				e
			],
			[
				1,
				179,
				"LaunchApp1",
				0,
				e,
				0,
				"VK_MEDIA_LAUNCH_APP1",
				e,
				e
			],
			[
				1,
				180,
				"SelectTask",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				181,
				"LaunchScreenSaver",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				182,
				"BrowserSearch",
				120,
				"BrowserSearch",
				170,
				"VK_BROWSER_SEARCH",
				e,
				e
			],
			[
				1,
				183,
				"BrowserHome",
				121,
				"BrowserHome",
				172,
				"VK_BROWSER_HOME",
				e,
				e
			],
			[
				1,
				184,
				"BrowserBack",
				122,
				"BrowserBack",
				166,
				"VK_BROWSER_BACK",
				e,
				e
			],
			[
				1,
				185,
				"BrowserForward",
				123,
				"BrowserForward",
				167,
				"VK_BROWSER_FORWARD",
				e,
				e
			],
			[
				1,
				186,
				"BrowserStop",
				0,
				e,
				0,
				"VK_BROWSER_STOP",
				e,
				e
			],
			[
				1,
				187,
				"BrowserRefresh",
				0,
				e,
				0,
				"VK_BROWSER_REFRESH",
				e,
				e
			],
			[
				1,
				188,
				"BrowserFavorites",
				0,
				e,
				0,
				"VK_BROWSER_FAVORITES",
				e,
				e
			],
			[
				1,
				189,
				"ZoomToggle",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				190,
				"MailReply",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				191,
				"MailForward",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				192,
				"MailSend",
				0,
				e,
				0,
				e,
				e,
				e
			],
			[
				1,
				0,
				e,
				114,
				"KeyInComposition",
				229,
				e,
				e,
				e
			],
			[
				1,
				0,
				e,
				116,
				"ABNT_C2",
				194,
				"VK_ABNT_C2",
				e,
				e
			],
			[
				1,
				0,
				e,
				96,
				"OEM_8",
				223,
				"VK_OEM_8",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_KANA",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_HANGUL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_JUNJA",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_FINAL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_HANJA",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_KANJI",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_CONVERT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_NONCONVERT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_ACCEPT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_MODECHANGE",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_SELECT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PRINT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_EXECUTE",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_SNAPSHOT",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_HELP",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_APPS",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PROCESSKEY",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PACKET",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_DBE_SBCSCHAR",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_DBE_DBCSCHAR",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_ATTN",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_CRSEL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_EXSEL",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_EREOF",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PLAY",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_ZOOM",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_NONAME",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_PA1",
				e,
				e
			],
			[
				1,
				0,
				e,
				0,
				e,
				0,
				"VK_OEM_CLEAR",
				e,
				e
			]
		], n = [], r = [];
		for (const i of t) {
			const [e, t, s, o, a, l, u, h, c] = i;
			if (r[t] || (r[t] = !0, rt[s] = t, it[s.toLowerCase()] = t, e && (st[t] = o)), !n[o]) {
				if (n[o] = !0, !a) throw new Error(`String representation missing for key code ${o} around scan code ${s}`);
				Ze.define(o, a), et.define(o, h || a), tt.define(o, c || h || a);
			}
			l && (nt[l] = o);
		}
	})(), function(e) {
		e.toString = function(e) {
			return Ze.keyCodeToStr(e);
		}, e.fromString = function(e) {
			return Ze.strToKeyCode(e);
		}, e.toUserSettingsUS = function(e) {
			return et.keyCodeToStr(e);
		}, e.toUserSettingsGeneral = function(e) {
			return tt.keyCodeToStr(e);
		}, e.fromUserSettings = function(e) {
			return et.strToKeyCode(e) || tt.strToKeyCode(e);
		}, e.toElectronAccelerator = function(e) {
			if (e >= 98 && e <= 113) return null;
			switch (e) {
				case 16: return "Up";
				case 18: return "Down";
				case 15: return "Left";
				case 17: return "Right";
			}
			return Ze.keyCodeToStr(e);
		};
	}(ot || (ot = {}));
	const lt = globalThis.vscode;
	if (void 0 !== lt && void 0 !== lt.process) {
		const e = lt.process;
		at = {
			get platform() {
				return e.platform;
			},
			get arch() {
				return e.arch;
			},
			get env() {
				return e.env;
			},
			cwd: () => e.cwd()
		};
	} else at = "undefined" != typeof process && "string" == typeof process?.versions?.node ? {
		get platform() {
			return process.platform;
		},
		get arch() {
			return process.arch;
		},
		get env() {
			return {};
		},
		cwd: () => ({}).VSCODE_CWD || process.cwd()
	} : {
		get platform() {
			return H ? "win32" : j ? "darwin" : "linux";
		},
		get arch() {},
		get env() {
			return {};
		},
		cwd: () => "/"
	};
	const ut = at.cwd, ht = at.env, ct = at.platform, dt = 46, gt = 47, mt = 92, ft = 58;
	var pt = class extends Error {
		constructor(e, t, n) {
			let r;
			"string" == typeof t && 0 === t.indexOf("not ") ? (r = "must not be", t = t.replace(/^not /, "")) : r = "must be";
			let i = `The "${e}" ${-1 !== e.indexOf(".") ? "property" : "argument"} ${r} of type ${t}`;
			i += ". Received type " + typeof n, super(i), this.code = "ERR_INVALID_ARG_TYPE";
		}
	};
	function bt(e, t) {
		if ("string" != typeof e) throw new pt(t, "string", e);
	}
	const wt = "win32" === ct;
	function _t(e) {
		return e === gt || e === mt;
	}
	function Ct(e) {
		return e === gt;
	}
	function yt(e) {
		return e >= 65 && e <= 90 || e >= 97 && e <= 122;
	}
	function vt(e, t, n, r) {
		let i = "", s = 0, o = -1, a = 0, l = 0;
		for (let u = 0; u <= e.length; ++u) {
			if (u < e.length) l = e.charCodeAt(u);
			else {
				if (r(l)) break;
				l = gt;
			}
			if (r(l)) {
				if (o === u - 1 || 1 === a);
				else if (2 === a) {
					if (i.length < 2 || 2 !== s || i.charCodeAt(i.length - 1) !== dt || i.charCodeAt(i.length - 2) !== dt) {
						if (i.length > 2) {
							const e = i.lastIndexOf(n);
							-1 === e ? (i = "", s = 0) : (i = i.slice(0, e), s = i.length - 1 - i.lastIndexOf(n)), o = u, a = 0;
							continue;
						}
						if (0 !== i.length) {
							i = "", s = 0, o = u, a = 0;
							continue;
						}
					}
					t && (i += i.length > 0 ? `${n}..` : "..", s = 2);
				} else i.length > 0 ? i += `${n}${e.slice(o + 1, u)}` : i = e.slice(o + 1, u), s = u - o - 1;
				o = u, a = 0;
			} else l === dt && -1 !== a ? ++a : a = -1;
		}
		return i;
	}
	function Lt(e, t) {
		(function(e, t) {
			if (null === e || "object" != typeof e) throw new pt(t, "Object", e);
		})(t, "pathObject");
		const n = t.dir || t.root, r = t.base || `${t.name || ""}${i = t.ext, i ? `${"." === i[0] ? "" : "."}${i}` : ""}`;
		var i;
		return n ? n === t.root ? `${n}${r}` : `${n}${e}${r}` : r;
	}
	const Nt = {
		resolve(...e) {
			let t = "", n = "", r = !1;
			for (let i = e.length - 1; i >= -1; i--) {
				let s;
				if (i >= 0) {
					if (s = e[i], bt(s, `paths[${i}]`), 0 === s.length) continue;
				} else 0 === t.length ? s = ut() : (s = ht[`=${t}`] || ut(), (void 0 === s || s.slice(0, 2).toLowerCase() !== t.toLowerCase() && s.charCodeAt(2) === mt) && (s = `${t}\\`));
				const o = s.length;
				let a = 0, l = "", u = !1;
				const h = s.charCodeAt(0);
				if (1 === o) _t(h) && (a = 1, u = !0);
				else if (_t(h)) if (u = !0, _t(s.charCodeAt(1))) {
					let e = 2, t = e;
					for (; e < o && !_t(s.charCodeAt(e));) e++;
					if (e < o && e !== t) {
						const n = s.slice(t, e);
						for (t = e; e < o && _t(s.charCodeAt(e));) e++;
						if (e < o && e !== t) {
							for (t = e; e < o && !_t(s.charCodeAt(e));) e++;
							e !== o && e === t || (l = `\\\\${n}\\${s.slice(t, e)}`, a = e);
						}
					}
				} else a = 1;
				else yt(h) && s.charCodeAt(1) === ft && (l = s.slice(0, 2), a = 2, o > 2 && _t(s.charCodeAt(2)) && (u = !0, a = 3));
				if (l.length > 0) if (t.length > 0) {
					if (l.toLowerCase() !== t.toLowerCase()) continue;
				} else t = l;
				if (r) {
					if (t.length > 0) break;
				} else if (n = `${s.slice(a)}\\${n}`, r = u, u && t.length > 0) break;
			}
			return n = vt(n, !r, "\\", _t), r ? `${t}\\${n}` : `${t}${n}` || ".";
		},
		normalize(e) {
			bt(e, "path");
			const t = e.length;
			if (0 === t) return ".";
			let n, r = 0, i = !1;
			const s = e.charCodeAt(0);
			if (1 === t) return Ct(s) ? "\\" : e;
			if (_t(s)) if (i = !0, _t(e.charCodeAt(1))) {
				let i = 2, s = i;
				for (; i < t && !_t(e.charCodeAt(i));) i++;
				if (i < t && i !== s) {
					const o = e.slice(s, i);
					for (s = i; i < t && _t(e.charCodeAt(i));) i++;
					if (i < t && i !== s) {
						for (s = i; i < t && !_t(e.charCodeAt(i));) i++;
						if (i === t) return `\\\\${o}\\${e.slice(s)}\\`;
						i !== s && (n = `\\\\${o}\\${e.slice(s, i)}`, r = i);
					}
				}
			} else r = 1;
			else yt(s) && e.charCodeAt(1) === ft && (n = e.slice(0, 2), r = 2, t > 2 && _t(e.charCodeAt(2)) && (i = !0, r = 3));
			let o = r < t ? vt(e.slice(r), !i, "\\", _t) : "";
			if (0 !== o.length || i || (o = "."), o.length > 0 && _t(e.charCodeAt(t - 1)) && (o += "\\"), !i && void 0 === n && e.includes(":")) {
				if (o.length >= 2 && yt(o.charCodeAt(0)) && o.charCodeAt(1) === ft) return `.\\${o}`;
				let n = e.indexOf(":");
				do
					if (n === t - 1 || _t(e.charCodeAt(n + 1))) return `.\\${o}`;
				while (-1 !== (n = e.indexOf(":", n + 1)));
			}
			return void 0 === n ? i ? `\\${o}` : o : i ? `${n}\\${o}` : `${n}${o}`;
		},
		isAbsolute(e) {
			bt(e, "path");
			const t = e.length;
			if (0 === t) return !1;
			const n = e.charCodeAt(0);
			return _t(n) || t > 2 && yt(n) && e.charCodeAt(1) === ft && _t(e.charCodeAt(2));
		},
		join(...e) {
			if (0 === e.length) return ".";
			let t, n;
			for (let s = 0; s < e.length; ++s) {
				const r = e[s];
				bt(r, "path"), r.length > 0 && (void 0 === t ? t = n = r : t += `\\${r}`);
			}
			if (void 0 === t) return ".";
			let r = !0, i = 0;
			if ("string" == typeof n && _t(n.charCodeAt(0))) {
				++i;
				const e = n.length;
				e > 1 && _t(n.charCodeAt(1)) && (++i, e > 2 && (_t(n.charCodeAt(2)) ? ++i : r = !1));
			}
			if (r) {
				for (; i < t.length && _t(t.charCodeAt(i));) i++;
				i >= 2 && (t = `\\${t.slice(i)}`);
			}
			return Nt.normalize(t);
		},
		relative(e, t) {
			if (bt(e, "from"), bt(t, "to"), e === t) return "";
			const n = Nt.resolve(e), r = Nt.resolve(t);
			if (n === r) return "";
			if ((e = n.toLowerCase()) === (t = r.toLowerCase())) return "";
			if (n.length !== e.length || r.length !== t.length) {
				const e = n.split("\\"), t = r.split("\\");
				"" === e[e.length - 1] && e.pop(), "" === t[t.length - 1] && t.pop();
				const i = e.length, s = t.length, o = i < s ? i : s;
				let a;
				for (a = 0; a < o && e[a].toLowerCase() === t[a].toLowerCase(); a++);
				return 0 === a ? r : a === o ? s > o ? t.slice(a).join("\\") : i > o ? "..\\".repeat(i - 1 - a) + ".." : "" : "..\\".repeat(i - a) + t.slice(a).join("\\");
			}
			let i = 0;
			for (; i < e.length && e.charCodeAt(i) === mt;) i++;
			let s = e.length;
			for (; s - 1 > i && e.charCodeAt(s - 1) === mt;) s--;
			const o = s - i;
			let a = 0;
			for (; a < t.length && t.charCodeAt(a) === mt;) a++;
			let l = t.length;
			for (; l - 1 > a && t.charCodeAt(l - 1) === mt;) l--;
			const u = l - a, h = o < u ? o : u;
			let c = -1, d = 0;
			for (; d < h; d++) {
				const n = e.charCodeAt(i + d);
				if (n !== t.charCodeAt(a + d)) break;
				n === mt && (c = d);
			}
			if (d !== h) {
				if (-1 === c) return r;
			} else {
				if (u > h) {
					if (t.charCodeAt(a + d) === mt) return r.slice(a + d + 1);
					if (2 === d) return r.slice(a + d);
				}
				o > h && (e.charCodeAt(i + d) === mt ? c = d : 2 === d && (c = 3)), -1 === c && (c = 0);
			}
			let g = "";
			for (d = i + c + 1; d <= s; ++d) d !== s && e.charCodeAt(d) !== mt || (g += 0 === g.length ? ".." : "\\..");
			return a += c, g.length > 0 ? `${g}${r.slice(a, l)}` : (r.charCodeAt(a) === mt && ++a, r.slice(a, l));
		},
		toNamespacedPath(e) {
			if ("string" != typeof e || 0 === e.length) return e;
			const t = Nt.resolve(e);
			if (t.length <= 2) return e;
			if (t.charCodeAt(0) === mt) {
				if (t.charCodeAt(1) === mt) {
					const e = t.charCodeAt(2);
					if (63 !== e && e !== dt) return `\\\\?\\UNC\\${t.slice(2)}`;
				}
			} else if (yt(t.charCodeAt(0)) && t.charCodeAt(1) === ft && t.charCodeAt(2) === mt) return `\\\\?\\${t}`;
			return t;
		},
		dirname(e) {
			bt(e, "path");
			const t = e.length;
			if (0 === t) return ".";
			let n = -1, r = 0;
			const i = e.charCodeAt(0);
			if (1 === t) return _t(i) ? e : ".";
			if (_t(i)) {
				if (n = r = 1, _t(e.charCodeAt(1))) {
					let i = 2, s = i;
					for (; i < t && !_t(e.charCodeAt(i));) i++;
					if (i < t && i !== s) {
						for (s = i; i < t && _t(e.charCodeAt(i));) i++;
						if (i < t && i !== s) {
							for (s = i; i < t && !_t(e.charCodeAt(i));) i++;
							if (i === t) return e;
							i !== s && (n = r = i + 1);
						}
					}
				}
			} else yt(i) && e.charCodeAt(1) === ft && (n = t > 2 && _t(e.charCodeAt(2)) ? 3 : 2, r = n);
			let s = -1, o = !0;
			for (let a = t - 1; a >= r; --a) if (_t(e.charCodeAt(a))) {
				if (!o) {
					s = a;
					break;
				}
			} else o = !1;
			if (-1 === s) {
				if (-1 === n) return ".";
				s = n;
			}
			return e.slice(0, s);
		},
		basename(e, t) {
			void 0 !== t && bt(t, "suffix"), bt(e, "path");
			let n, r = 0, i = -1, s = !0;
			if (e.length >= 2 && yt(e.charCodeAt(0)) && e.charCodeAt(1) === ft && (r = 2), void 0 !== t && t.length > 0 && t.length <= e.length) {
				if (t === e) return "";
				let o = t.length - 1, a = -1;
				for (n = e.length - 1; n >= r; --n) {
					const l = e.charCodeAt(n);
					if (_t(l)) {
						if (!s) {
							r = n + 1;
							break;
						}
					} else -1 === a && (s = !1, a = n + 1), o >= 0 && (l === t.charCodeAt(o) ? -1 === --o && (i = n) : (o = -1, i = a));
				}
				return r === i ? i = a : -1 === i && (i = e.length), e.slice(r, i);
			}
			for (n = e.length - 1; n >= r; --n) if (_t(e.charCodeAt(n))) {
				if (!s) {
					r = n + 1;
					break;
				}
			} else -1 === i && (s = !1, i = n + 1);
			return -1 === i ? "" : e.slice(r, i);
		},
		extname(e) {
			bt(e, "path");
			let t = 0, n = -1, r = 0, i = -1, s = !0, o = 0;
			e.length >= 2 && e.charCodeAt(1) === ft && yt(e.charCodeAt(0)) && (t = r = 2);
			for (let a = e.length - 1; a >= t; --a) {
				const t = e.charCodeAt(a);
				if (_t(t)) {
					if (!s) {
						r = a + 1;
						break;
					}
				} else -1 === i && (s = !1, i = a + 1), t === dt ? -1 === n ? n = a : 1 !== o && (o = 1) : -1 !== n && (o = -1);
			}
			return -1 === n || -1 === i || 0 === o || 1 === o && n === i - 1 && n === r + 1 ? "" : e.slice(n, i);
		},
		format: Lt.bind(null, "\\"),
		parse(e) {
			bt(e, "path");
			const t = {
				root: "",
				dir: "",
				base: "",
				ext: "",
				name: ""
			};
			if (0 === e.length) return t;
			const n = e.length;
			let r = 0, i = e.charCodeAt(0);
			if (1 === n) return _t(i) ? (t.root = t.dir = e, t) : (t.base = t.name = e, t);
			if (_t(i)) {
				if (r = 1, _t(e.charCodeAt(1))) {
					let t = 2, i = t;
					for (; t < n && !_t(e.charCodeAt(t));) t++;
					if (t < n && t !== i) {
						for (i = t; t < n && _t(e.charCodeAt(t));) t++;
						if (t < n && t !== i) {
							for (i = t; t < n && !_t(e.charCodeAt(t));) t++;
							t === n ? r = t : t !== i && (r = t + 1);
						}
					}
				}
			} else if (yt(i) && e.charCodeAt(1) === ft) {
				if (n <= 2) return t.root = t.dir = e, t;
				if (r = 2, _t(e.charCodeAt(2))) {
					if (3 === n) return t.root = t.dir = e, t;
					r = 3;
				}
			}
			r > 0 && (t.root = e.slice(0, r));
			let s = -1, o = r, a = -1, l = !0, u = e.length - 1, h = 0;
			for (; u >= r; --u) if (i = e.charCodeAt(u), _t(i)) {
				if (!l) {
					o = u + 1;
					break;
				}
			} else -1 === a && (l = !1, a = u + 1), i === dt ? -1 === s ? s = u : 1 !== h && (h = 1) : -1 !== s && (h = -1);
			return -1 !== a && (-1 === s || 0 === h || 1 === h && s === a - 1 && s === o + 1 ? t.base = t.name = e.slice(o, a) : (t.name = e.slice(o, s), t.base = e.slice(o, a), t.ext = e.slice(s, a))), t.dir = o > 0 && o !== r ? e.slice(0, o - 1) : t.root, t;
		},
		sep: "\\",
		delimiter: ";",
		win32: null,
		posix: null
	}, Et = (() => {
		if (wt) {
			const e = /\\/g;
			return () => {
				const t = ut().replace(e, "/");
				return t.slice(t.indexOf("/"));
			};
		}
		return () => ut();
	})(), St = {
		resolve(...e) {
			let t = "", n = !1;
			for (let r = e.length - 1; r >= 0 && !n; r--) {
				const i = e[r];
				bt(i, `paths[${r}]`), 0 !== i.length && (t = `${i}/${t}`, n = i.charCodeAt(0) === gt);
			}
			if (!n) {
				const e = Et();
				t = `${e}/${t}`, n = e.charCodeAt(0) === gt;
			}
			return t = vt(t, !n, "/", Ct), n ? `/${t}` : t.length > 0 ? t : ".";
		},
		normalize(e) {
			if (bt(e, "path"), 0 === e.length) return ".";
			const t = e.charCodeAt(0) === gt, n = e.charCodeAt(e.length - 1) === gt;
			return 0 === (e = vt(e, !t, "/", Ct)).length ? t ? "/" : n ? "./" : "." : (n && (e += "/"), t ? `/${e}` : e);
		},
		isAbsolute: (e) => (bt(e, "path"), e.length > 0 && e.charCodeAt(0) === gt),
		join(...e) {
			if (0 === e.length) return ".";
			const t = [];
			for (let n = 0; n < e.length; ++n) {
				const r = e[n];
				bt(r, "path"), r.length > 0 && t.push(r);
			}
			return 0 === t.length ? "." : St.normalize(t.join("/"));
		},
		relative(e, t) {
			if (bt(e, "from"), bt(t, "to"), e === t) return "";
			if ((e = St.resolve(e)) === (t = St.resolve(t))) return "";
			const n = e.length, r = n - 1, i = t.length - 1, s = r < i ? r : i;
			let o = -1, a = 0;
			for (; a < s; a++) {
				const n = e.charCodeAt(1 + a);
				if (n !== t.charCodeAt(1 + a)) break;
				n === gt && (o = a);
			}
			if (a === s) if (i > s) {
				if (t.charCodeAt(1 + a) === gt) return t.slice(1 + a + 1);
				if (0 === a) return t.slice(1 + a);
			} else r > s && (e.charCodeAt(1 + a) === gt ? o = a : 0 === a && (o = 0));
			let l = "";
			for (a = 1 + o + 1; a <= n; ++a) a !== n && e.charCodeAt(a) !== gt || (l += 0 === l.length ? ".." : "/..");
			return `${l}${t.slice(1 + o)}`;
		},
		toNamespacedPath: (e) => e,
		dirname(e) {
			if (bt(e, "path"), 0 === e.length) return ".";
			const t = e.charCodeAt(0) === gt;
			let n = -1, r = !0;
			for (let i = e.length - 1; i >= 1; --i) if (e.charCodeAt(i) === gt) {
				if (!r) {
					n = i;
					break;
				}
			} else r = !1;
			return -1 === n ? t ? "/" : "." : t && 1 === n ? "//" : e.slice(0, n);
		},
		basename(e, t) {
			void 0 !== t && bt(t, "suffix"), bt(e, "path");
			let n, r = 0, i = -1, s = !0;
			if (void 0 !== t && t.length > 0 && t.length <= e.length) {
				if (t === e) return "";
				let o = t.length - 1, a = -1;
				for (n = e.length - 1; n >= 0; --n) {
					const l = e.charCodeAt(n);
					if (l === gt) {
						if (!s) {
							r = n + 1;
							break;
						}
					} else -1 === a && (s = !1, a = n + 1), o >= 0 && (l === t.charCodeAt(o) ? -1 === --o && (i = n) : (o = -1, i = a));
				}
				return r === i ? i = a : -1 === i && (i = e.length), e.slice(r, i);
			}
			for (n = e.length - 1; n >= 0; --n) if (e.charCodeAt(n) === gt) {
				if (!s) {
					r = n + 1;
					break;
				}
			} else -1 === i && (s = !1, i = n + 1);
			return -1 === i ? "" : e.slice(r, i);
		},
		extname(e) {
			bt(e, "path");
			let t = -1, n = 0, r = -1, i = !0, s = 0;
			for (let o = e.length - 1; o >= 0; --o) {
				const a = e[o];
				if ("/" !== a) -1 === r && (i = !1, r = o + 1), "." === a ? -1 === t ? t = o : 1 !== s && (s = 1) : -1 !== t && (s = -1);
				else if (!i) {
					n = o + 1;
					break;
				}
			}
			return -1 === t || -1 === r || 0 === s || 1 === s && t === r - 1 && t === n + 1 ? "" : e.slice(t, r);
		},
		format: Lt.bind(null, "/"),
		parse(e) {
			bt(e, "path");
			const t = {
				root: "",
				dir: "",
				base: "",
				ext: "",
				name: ""
			};
			if (0 === e.length) return t;
			const n = e.charCodeAt(0) === gt;
			let r;
			n ? (t.root = "/", r = 1) : r = 0;
			let i = -1, s = 0, o = -1, a = !0, l = e.length - 1, u = 0;
			for (; l >= r; --l) {
				const t = e.charCodeAt(l);
				if (t !== gt) -1 === o && (a = !1, o = l + 1), t === dt ? -1 === i ? i = l : 1 !== u && (u = 1) : -1 !== i && (u = -1);
				else if (!a) {
					s = l + 1;
					break;
				}
			}
			if (-1 !== o) {
				const r = 0 === s && n ? 1 : s;
				-1 === i || 0 === u || 1 === u && i === o - 1 && i === s + 1 ? t.base = t.name = e.slice(r, o) : (t.name = e.slice(r, i), t.base = e.slice(r, o), t.ext = e.slice(i, o));
			}
			return s > 0 ? t.dir = e.slice(0, s - 1) : n && (t.dir = "/"), t;
		},
		sep: "/",
		delimiter: ":",
		win32: null,
		posix: null
	};
	St.win32 = Nt.win32 = Nt, St.posix = Nt.posix = St;
	wt ? Nt.normalize : St.normalize, wt ? Nt.resolve : St.resolve, wt ? Nt.relative : St.relative, wt ? Nt.dirname : St.dirname, wt ? Nt.basename : St.basename, wt ? Nt.extname : St.extname, wt ? Nt.sep : St.sep;
	const Rt = /^\w[\w\d+.-]*$/, xt = /^\//, At = /^\/\//;
	const kt = "", Mt = "/", Ot = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
	var It = class e {
		static isUri(t) {
			return t instanceof e || !(!t || "object" != typeof t) && "string" == typeof t.authority && "string" == typeof t.fragment && "string" == typeof t.path && "string" == typeof t.query && "string" == typeof t.scheme && "string" == typeof t.fsPath && "function" == typeof t.with && "function" == typeof t.toString;
		}
		constructor(e, t, n, r, i, s = !1) {
			"object" == typeof e ? (this.scheme = e.scheme || kt, this.authority = e.authority || kt, this.path = e.path || kt, this.query = e.query || kt, this.fragment = e.fragment || kt) : (this.scheme = function(e, t) {
				return e || t ? e : "file";
			}(e, s), this.authority = t || kt, this.path = function(e, t) {
				switch (e) {
					case "https":
					case "http":
					case "file": t ? t[0] !== Mt && (t = Mt + t) : t = Mt;
				}
				return t;
			}(this.scheme, n || kt), this.query = r || kt, this.fragment = i || kt, function(e, t) {
				if (!e.scheme && t) throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${e.authority}", path: "${e.path}", query: "${e.query}", fragment: "${e.fragment}"}`);
				if (e.scheme && !Rt.test(e.scheme)) throw new Error("[UriError]: Scheme contains illegal characters.");
				if (e.path) {
					if (e.authority) {
						if (!xt.test(e.path)) throw new Error("[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash (\"/\") character");
					} else if (At.test(e.path)) throw new Error("[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters (\"//\")");
				}
			}(this, s));
		}
		get fsPath() {
			return Vt(this, !1);
		}
		with(e) {
			if (!e) return this;
			let { scheme: t, authority: n, path: r, query: i, fragment: s } = e;
			return void 0 === t ? t = this.scheme : null === t && (t = kt), void 0 === n ? n = this.authority : null === n && (n = kt), void 0 === r ? r = this.path : null === r && (r = kt), void 0 === i ? i = this.query : null === i && (i = kt), void 0 === s ? s = this.fragment : null === s && (s = kt), t === this.scheme && n === this.authority && r === this.path && i === this.query && s === this.fragment ? this : new Pt(t, n, r, i, s);
		}
		static parse(e, t = !1) {
			const n = Ot.exec(e);
			return n ? new Pt(n[2] || kt, $t(n[4] || kt), $t(n[5] || kt), $t(n[7] || kt), $t(n[9] || kt), t) : new Pt(kt, kt, kt, kt, kt);
		}
		static file(e) {
			let t = kt;
			if (H && (e = e.replace(/\\/g, Mt)), e[0] === Mt && e[1] === Mt) {
				const n = e.indexOf(Mt, 2);
				-1 === n ? (t = e.substring(2), e = Mt) : (t = e.substring(2, n), e = e.substring(n) || Mt);
			}
			return new Pt("file", t, e, kt, kt);
		}
		static from(e, t) {
			return new Pt(e.scheme, e.authority, e.path, e.query, e.fragment, t);
		}
		static joinPath(t, ...n) {
			if (!t.path) throw new Error("[UriError]: cannot call joinPath on URI without path");
			let r;
			return r = H && "file" === t.scheme ? e.file(Nt.join(Vt(t, !0), ...n)).path : St.join(t.path, ...n), t.with({ path: r });
		}
		toString(e = !1) {
			return Kt(this, e);
		}
		toJSON() {
			return this;
		}
		static revive(t) {
			if (t) {
				if (t instanceof e) return t;
				{
					const e = new Pt(t);
					return e._formatted = t.external ?? null, e._fsPath = t._sep === Tt ? t.fsPath ?? null : null, e;
				}
			}
			return t;
		}
	};
	const Tt = H ? 1 : void 0;
	var Pt = class extends It {
		constructor() {
			super(...arguments), this._formatted = null, this._fsPath = null;
		}
		get fsPath() {
			return this._fsPath || (this._fsPath = Vt(this, !1)), this._fsPath;
		}
		toString(e = !1) {
			return e ? Kt(this, !0) : (this._formatted || (this._formatted = Kt(this, !1)), this._formatted);
		}
		toJSON() {
			const e = { $mid: 1 };
			return this._fsPath && (e.fsPath = this._fsPath, e._sep = Tt), this._formatted && (e.external = this._formatted), this.path && (e.path = this.path), this.scheme && (e.scheme = this.scheme), this.authority && (e.authority = this.authority), this.query && (e.query = this.query), this.fragment && (e.fragment = this.fragment), e;
		}
	};
	const Ft = {
		58: "%3A",
		47: "%2F",
		63: "%3F",
		35: "%23",
		91: "%5B",
		93: "%5D",
		64: "%40",
		33: "%21",
		36: "%24",
		38: "%26",
		39: "%27",
		40: "%28",
		41: "%29",
		42: "%2A",
		43: "%2B",
		44: "%2C",
		59: "%3B",
		61: "%3D",
		32: "%20"
	};
	function Dt(e, t, n) {
		let r, i = -1;
		for (let s = 0; s < e.length; s++) {
			const o = e.charCodeAt(s);
			if (o >= 97 && o <= 122 || o >= 65 && o <= 90 || o >= 48 && o <= 57 || 45 === o || 46 === o || 95 === o || 126 === o || t && 47 === o || n && 91 === o || n && 93 === o || n && 58 === o) -1 !== i && (r += encodeURIComponent(e.substring(i, s)), i = -1), void 0 !== r && (r += e.charAt(s));
			else {
				void 0 === r && (r = e.substr(0, s));
				const t = Ft[o];
				void 0 !== t ? (-1 !== i && (r += encodeURIComponent(e.substring(i, s)), i = -1), r += t) : -1 === i && (i = s);
			}
		}
		return -1 !== i && (r += encodeURIComponent(e.substring(i))), void 0 !== r ? r : e;
	}
	function qt(e) {
		let t;
		for (let n = 0; n < e.length; n++) {
			const r = e.charCodeAt(n);
			35 === r || 63 === r ? (void 0 === t && (t = e.substr(0, n)), t += Ft[r]) : void 0 !== t && (t += e[n]);
		}
		return void 0 !== t ? t : e;
	}
	function Vt(e, t) {
		let n;
		return n = e.authority && e.path.length > 1 && "file" === e.scheme ? `//${e.authority}${e.path}` : 47 === e.path.charCodeAt(0) && (e.path.charCodeAt(1) >= 65 && e.path.charCodeAt(1) <= 90 || e.path.charCodeAt(1) >= 97 && e.path.charCodeAt(1) <= 122) && 58 === e.path.charCodeAt(2) ? t ? e.path.substr(1) : e.path[1].toLowerCase() + e.path.substr(2) : e.path, H && (n = n.replace(/\//g, "\\")), n;
	}
	function Kt(e, t) {
		const n = t ? qt : Dt;
		let r = "", { scheme: i, authority: s, path: o, query: a, fragment: l } = e;
		if (i && (r += i, r += ":"), (s || "file" === i) && (r += Mt, r += Mt), s) {
			let e = s.indexOf("@");
			if (-1 !== e) {
				const t = s.substr(0, e);
				s = s.substr(e + 1), e = t.lastIndexOf(":"), -1 === e ? r += n(t, !1, !1) : (r += n(t.substr(0, e), !1, !1), r += ":", r += n(t.substr(e + 1), !1, !0)), r += "@";
			}
			s = s.toLowerCase(), e = s.lastIndexOf(":"), -1 === e ? r += n(s, !1, !0) : (r += n(s.substr(0, e), !1, !0), r += s.substr(e));
		}
		if (o) {
			if (o.length >= 3 && 47 === o.charCodeAt(0) && 58 === o.charCodeAt(2)) {
				const e = o.charCodeAt(1);
				e >= 65 && e <= 90 && (o = `/${String.fromCharCode(e + 32)}:${o.substr(3)}`);
			} else if (o.length >= 2 && 58 === o.charCodeAt(1)) {
				const e = o.charCodeAt(0);
				e >= 65 && e <= 90 && (o = `${String.fromCharCode(e + 32)}:${o.substr(2)}`);
			}
			r += n(o, !0, !1);
		}
		return a && (r += "?", r += n(a, !1, !1)), l && (r += "#", r += t ? l : Dt(l, !1, !1)), r;
	}
	function Bt(e) {
		try {
			return decodeURIComponent(e);
		} catch {
			return e.length > 3 ? e.substr(0, 3) + Bt(e.substr(3)) : e;
		}
	}
	const Ut = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
	function $t(e) {
		return e.match(Ut) ? e.replace(Ut, (e) => Bt(e)) : e;
	}
	var Wt = class e extends qe {
		constructor(e, t, n, r) {
			super(e, t, n, r), this.selectionStartLineNumber = e, this.selectionStartColumn = t, this.positionLineNumber = n, this.positionColumn = r;
		}
		toString() {
			return "[" + this.selectionStartLineNumber + "," + this.selectionStartColumn + " -> " + this.positionLineNumber + "," + this.positionColumn + "]";
		}
		equalsSelection(t) {
			return e.selectionsEqual(this, t);
		}
		static selectionsEqual(e, t) {
			return e.selectionStartLineNumber === t.selectionStartLineNumber && e.selectionStartColumn === t.selectionStartColumn && e.positionLineNumber === t.positionLineNumber && e.positionColumn === t.positionColumn;
		}
		getDirection() {
			return this.selectionStartLineNumber === this.startLineNumber && this.selectionStartColumn === this.startColumn ? 0 : 1;
		}
		setEndPosition(t, n) {
			return 0 === this.getDirection() ? new e(this.startLineNumber, this.startColumn, t, n) : new e(t, n, this.startLineNumber, this.startColumn);
		}
		getPosition() {
			return new De(this.positionLineNumber, this.positionColumn);
		}
		getSelectionStart() {
			return new De(this.selectionStartLineNumber, this.selectionStartColumn);
		}
		setStartPosition(t, n) {
			return 0 === this.getDirection() ? new e(t, n, this.endLineNumber, this.endColumn) : new e(this.endLineNumber, this.endColumn, t, n);
		}
		static fromPositions(t, n = t) {
			return new e(t.lineNumber, t.column, n.lineNumber, n.column);
		}
		static fromRange(t, n) {
			return 0 === n ? new e(t.startLineNumber, t.startColumn, t.endLineNumber, t.endColumn) : new e(t.endLineNumber, t.endColumn, t.startLineNumber, t.startColumn);
		}
		static liftSelection(t) {
			return new e(t.selectionStartLineNumber, t.selectionStartColumn, t.positionLineNumber, t.positionColumn);
		}
		static selectionsArrEqual(e, t) {
			if (e && !t || !e && t) return !1;
			if (!e && !t) return !0;
			if (e.length !== t.length) return !1;
			for (let n = 0, r = e.length; n < r; n++) if (!this.selectionsEqual(e[n], t[n])) return !1;
			return !0;
		}
		static isISelection(e) {
			return !!e && "number" == typeof e.selectionStartLineNumber && "number" == typeof e.selectionStartColumn && "number" == typeof e.positionLineNumber && "number" == typeof e.positionColumn;
		}
		static createWithDirection(t, n, r, i, s) {
			return 0 === s ? new e(t, n, r, i) : new e(r, i, t, n);
		}
	};
	const zt = Object.create(null);
	function Ht(e, t) {
		if ("string" == typeof t) {
			const n = zt[t];
			if (void 0 === n) throw new Error(`${e} references an unknown codicon: ${t}`);
			t = n;
		}
		return zt[e] = t, { id: e };
	}
	const jt = {
		add: Ht("add", 6e4),
		plus: Ht("plus", 6e4),
		gistNew: Ht("gist-new", 6e4),
		repoCreate: Ht("repo-create", 6e4),
		lightbulb: Ht("lightbulb", 60001),
		lightBulb: Ht("light-bulb", 60001),
		repo: Ht("repo", 60002),
		repoDelete: Ht("repo-delete", 60002),
		gistFork: Ht("gist-fork", 60003),
		repoForked: Ht("repo-forked", 60003),
		gitPullRequest: Ht("git-pull-request", 60004),
		gitPullRequestAbandoned: Ht("git-pull-request-abandoned", 60004),
		recordKeys: Ht("record-keys", 60005),
		keyboard: Ht("keyboard", 60005),
		tag: Ht("tag", 60006),
		gitPullRequestLabel: Ht("git-pull-request-label", 60006),
		tagAdd: Ht("tag-add", 60006),
		tagRemove: Ht("tag-remove", 60006),
		person: Ht("person", 60007),
		personFollow: Ht("person-follow", 60007),
		personOutline: Ht("person-outline", 60007),
		personFilled: Ht("person-filled", 60007),
		sourceControl: Ht("source-control", 60008),
		mirror: Ht("mirror", 60009),
		mirrorPublic: Ht("mirror-public", 60009),
		star: Ht("star", 60010),
		starAdd: Ht("star-add", 60010),
		starDelete: Ht("star-delete", 60010),
		starEmpty: Ht("star-empty", 60010),
		comment: Ht("comment", 60011),
		commentAdd: Ht("comment-add", 60011),
		alert: Ht("alert", 60012),
		warning: Ht("warning", 60012),
		search: Ht("search", 60013),
		searchSave: Ht("search-save", 60013),
		logOut: Ht("log-out", 60014),
		signOut: Ht("sign-out", 60014),
		logIn: Ht("log-in", 60015),
		signIn: Ht("sign-in", 60015),
		eye: Ht("eye", 60016),
		eyeUnwatch: Ht("eye-unwatch", 60016),
		eyeWatch: Ht("eye-watch", 60016),
		circleFilled: Ht("circle-filled", 60017),
		primitiveDot: Ht("primitive-dot", 60017),
		closeDirty: Ht("close-dirty", 60017),
		debugBreakpoint: Ht("debug-breakpoint", 60017),
		debugBreakpointDisabled: Ht("debug-breakpoint-disabled", 60017),
		debugHint: Ht("debug-hint", 60017),
		terminalDecorationSuccess: Ht("terminal-decoration-success", 60017),
		primitiveSquare: Ht("primitive-square", 60018),
		edit: Ht("edit", 60019),
		pencil: Ht("pencil", 60019),
		info: Ht("info", 60020),
		issueOpened: Ht("issue-opened", 60020),
		gistPrivate: Ht("gist-private", 60021),
		gitForkPrivate: Ht("git-fork-private", 60021),
		lock: Ht("lock", 60021),
		mirrorPrivate: Ht("mirror-private", 60021),
		close: Ht("close", 60022),
		removeClose: Ht("remove-close", 60022),
		x: Ht("x", 60022),
		repoSync: Ht("repo-sync", 60023),
		sync: Ht("sync", 60023),
		clone: Ht("clone", 60024),
		desktopDownload: Ht("desktop-download", 60024),
		beaker: Ht("beaker", 60025),
		microscope: Ht("microscope", 60025),
		vm: Ht("vm", 60026),
		deviceDesktop: Ht("device-desktop", 60026),
		file: Ht("file", 60027),
		more: Ht("more", 60028),
		ellipsis: Ht("ellipsis", 60028),
		kebabHorizontal: Ht("kebab-horizontal", 60028),
		mailReply: Ht("mail-reply", 60029),
		reply: Ht("reply", 60029),
		organization: Ht("organization", 60030),
		organizationFilled: Ht("organization-filled", 60030),
		organizationOutline: Ht("organization-outline", 60030),
		newFile: Ht("new-file", 60031),
		fileAdd: Ht("file-add", 60031),
		newFolder: Ht("new-folder", 60032),
		fileDirectoryCreate: Ht("file-directory-create", 60032),
		trash: Ht("trash", 60033),
		trashcan: Ht("trashcan", 60033),
		history: Ht("history", 60034),
		clock: Ht("clock", 60034),
		folder: Ht("folder", 60035),
		fileDirectory: Ht("file-directory", 60035),
		symbolFolder: Ht("symbol-folder", 60035),
		logoGithub: Ht("logo-github", 60036),
		markGithub: Ht("mark-github", 60036),
		github: Ht("github", 60036),
		terminal: Ht("terminal", 60037),
		console: Ht("console", 60037),
		repl: Ht("repl", 60037),
		zap: Ht("zap", 60038),
		symbolEvent: Ht("symbol-event", 60038),
		error: Ht("error", 60039),
		stop: Ht("stop", 60039),
		variable: Ht("variable", 60040),
		symbolVariable: Ht("symbol-variable", 60040),
		array: Ht("array", 60042),
		symbolArray: Ht("symbol-array", 60042),
		symbolModule: Ht("symbol-module", 60043),
		symbolPackage: Ht("symbol-package", 60043),
		symbolNamespace: Ht("symbol-namespace", 60043),
		symbolObject: Ht("symbol-object", 60043),
		symbolMethod: Ht("symbol-method", 60044),
		symbolFunction: Ht("symbol-function", 60044),
		symbolConstructor: Ht("symbol-constructor", 60044),
		symbolBoolean: Ht("symbol-boolean", 60047),
		symbolNull: Ht("symbol-null", 60047),
		symbolNumeric: Ht("symbol-numeric", 60048),
		symbolNumber: Ht("symbol-number", 60048),
		symbolStructure: Ht("symbol-structure", 60049),
		symbolStruct: Ht("symbol-struct", 60049),
		symbolParameter: Ht("symbol-parameter", 60050),
		symbolTypeParameter: Ht("symbol-type-parameter", 60050),
		symbolKey: Ht("symbol-key", 60051),
		symbolText: Ht("symbol-text", 60051),
		symbolReference: Ht("symbol-reference", 60052),
		goToFile: Ht("go-to-file", 60052),
		symbolEnum: Ht("symbol-enum", 60053),
		symbolValue: Ht("symbol-value", 60053),
		symbolRuler: Ht("symbol-ruler", 60054),
		symbolUnit: Ht("symbol-unit", 60054),
		activateBreakpoints: Ht("activate-breakpoints", 60055),
		archive: Ht("archive", 60056),
		arrowBoth: Ht("arrow-both", 60057),
		arrowDown: Ht("arrow-down", 60058),
		arrowLeft: Ht("arrow-left", 60059),
		arrowRight: Ht("arrow-right", 60060),
		arrowSmallDown: Ht("arrow-small-down", 60061),
		arrowSmallLeft: Ht("arrow-small-left", 60062),
		arrowSmallRight: Ht("arrow-small-right", 60063),
		arrowSmallUp: Ht("arrow-small-up", 60064),
		arrowUp: Ht("arrow-up", 60065),
		bell: Ht("bell", 60066),
		bold: Ht("bold", 60067),
		book: Ht("book", 60068),
		bookmark: Ht("bookmark", 60069),
		debugBreakpointConditionalUnverified: Ht("debug-breakpoint-conditional-unverified", 60070),
		debugBreakpointConditional: Ht("debug-breakpoint-conditional", 60071),
		debugBreakpointConditionalDisabled: Ht("debug-breakpoint-conditional-disabled", 60071),
		debugBreakpointDataUnverified: Ht("debug-breakpoint-data-unverified", 60072),
		debugBreakpointData: Ht("debug-breakpoint-data", 60073),
		debugBreakpointDataDisabled: Ht("debug-breakpoint-data-disabled", 60073),
		debugBreakpointLogUnverified: Ht("debug-breakpoint-log-unverified", 60074),
		debugBreakpointLog: Ht("debug-breakpoint-log", 60075),
		debugBreakpointLogDisabled: Ht("debug-breakpoint-log-disabled", 60075),
		briefcase: Ht("briefcase", 60076),
		broadcast: Ht("broadcast", 60077),
		browser: Ht("browser", 60078),
		bug: Ht("bug", 60079),
		calendar: Ht("calendar", 60080),
		caseSensitive: Ht("case-sensitive", 60081),
		check: Ht("check", 60082),
		checklist: Ht("checklist", 60083),
		chevronDown: Ht("chevron-down", 60084),
		chevronLeft: Ht("chevron-left", 60085),
		chevronRight: Ht("chevron-right", 60086),
		chevronUp: Ht("chevron-up", 60087),
		chromeClose: Ht("chrome-close", 60088),
		chromeMaximize: Ht("chrome-maximize", 60089),
		chromeMinimize: Ht("chrome-minimize", 60090),
		chromeRestore: Ht("chrome-restore", 60091),
		circleOutline: Ht("circle-outline", 60092),
		circle: Ht("circle", 60092),
		debugBreakpointUnverified: Ht("debug-breakpoint-unverified", 60092),
		terminalDecorationIncomplete: Ht("terminal-decoration-incomplete", 60092),
		circleSlash: Ht("circle-slash", 60093),
		circuitBoard: Ht("circuit-board", 60094),
		clearAll: Ht("clear-all", 60095),
		clippy: Ht("clippy", 60096),
		closeAll: Ht("close-all", 60097),
		cloudDownload: Ht("cloud-download", 60098),
		cloudUpload: Ht("cloud-upload", 60099),
		code: Ht("code", 60100),
		collapseAll: Ht("collapse-all", 60101),
		colorMode: Ht("color-mode", 60102),
		commentDiscussion: Ht("comment-discussion", 60103),
		creditCard: Ht("credit-card", 60105),
		dash: Ht("dash", 60108),
		dashboard: Ht("dashboard", 60109),
		database: Ht("database", 60110),
		debugContinue: Ht("debug-continue", 60111),
		debugDisconnect: Ht("debug-disconnect", 60112),
		debugPause: Ht("debug-pause", 60113),
		debugRestart: Ht("debug-restart", 60114),
		debugStart: Ht("debug-start", 60115),
		debugStepInto: Ht("debug-step-into", 60116),
		debugStepOut: Ht("debug-step-out", 60117),
		debugStepOver: Ht("debug-step-over", 60118),
		debugStop: Ht("debug-stop", 60119),
		debug: Ht("debug", 60120),
		deviceCameraVideo: Ht("device-camera-video", 60121),
		deviceCamera: Ht("device-camera", 60122),
		deviceMobile: Ht("device-mobile", 60123),
		diffAdded: Ht("diff-added", 60124),
		diffIgnored: Ht("diff-ignored", 60125),
		diffModified: Ht("diff-modified", 60126),
		diffRemoved: Ht("diff-removed", 60127),
		diffRenamed: Ht("diff-renamed", 60128),
		diff: Ht("diff", 60129),
		diffSidebyside: Ht("diff-sidebyside", 60129),
		discard: Ht("discard", 60130),
		editorLayout: Ht("editor-layout", 60131),
		emptyWindow: Ht("empty-window", 60132),
		exclude: Ht("exclude", 60133),
		extensions: Ht("extensions", 60134),
		eyeClosed: Ht("eye-closed", 60135),
		fileBinary: Ht("file-binary", 60136),
		fileCode: Ht("file-code", 60137),
		fileMedia: Ht("file-media", 60138),
		filePdf: Ht("file-pdf", 60139),
		fileSubmodule: Ht("file-submodule", 60140),
		fileSymlinkDirectory: Ht("file-symlink-directory", 60141),
		fileSymlinkFile: Ht("file-symlink-file", 60142),
		fileZip: Ht("file-zip", 60143),
		files: Ht("files", 60144),
		filter: Ht("filter", 60145),
		flame: Ht("flame", 60146),
		foldDown: Ht("fold-down", 60147),
		foldUp: Ht("fold-up", 60148),
		fold: Ht("fold", 60149),
		folderActive: Ht("folder-active", 60150),
		folderOpened: Ht("folder-opened", 60151),
		gear: Ht("gear", 60152),
		gift: Ht("gift", 60153),
		gistSecret: Ht("gist-secret", 60154),
		gist: Ht("gist", 60155),
		gitCommit: Ht("git-commit", 60156),
		gitCompare: Ht("git-compare", 60157),
		compareChanges: Ht("compare-changes", 60157),
		gitMerge: Ht("git-merge", 60158),
		githubAction: Ht("github-action", 60159),
		githubAlt: Ht("github-alt", 60160),
		globe: Ht("globe", 60161),
		grabber: Ht("grabber", 60162),
		graph: Ht("graph", 60163),
		gripper: Ht("gripper", 60164),
		heart: Ht("heart", 60165),
		home: Ht("home", 60166),
		horizontalRule: Ht("horizontal-rule", 60167),
		hubot: Ht("hubot", 60168),
		inbox: Ht("inbox", 60169),
		issueReopened: Ht("issue-reopened", 60171),
		issues: Ht("issues", 60172),
		italic: Ht("italic", 60173),
		jersey: Ht("jersey", 60174),
		json: Ht("json", 60175),
		kebabVertical: Ht("kebab-vertical", 60176),
		key: Ht("key", 60177),
		law: Ht("law", 60178),
		lightbulbAutofix: Ht("lightbulb-autofix", 60179),
		linkExternal: Ht("link-external", 60180),
		link: Ht("link", 60181),
		listOrdered: Ht("list-ordered", 60182),
		listUnordered: Ht("list-unordered", 60183),
		liveShare: Ht("live-share", 60184),
		loading: Ht("loading", 60185),
		location: Ht("location", 60186),
		mailRead: Ht("mail-read", 60187),
		mail: Ht("mail", 60188),
		markdown: Ht("markdown", 60189),
		megaphone: Ht("megaphone", 60190),
		mention: Ht("mention", 60191),
		milestone: Ht("milestone", 60192),
		gitPullRequestMilestone: Ht("git-pull-request-milestone", 60192),
		mortarBoard: Ht("mortar-board", 60193),
		move: Ht("move", 60194),
		multipleWindows: Ht("multiple-windows", 60195),
		mute: Ht("mute", 60196),
		noNewline: Ht("no-newline", 60197),
		note: Ht("note", 60198),
		octoface: Ht("octoface", 60199),
		openPreview: Ht("open-preview", 60200),
		package: Ht("package", 60201),
		paintcan: Ht("paintcan", 60202),
		pin: Ht("pin", 60203),
		play: Ht("play", 60204),
		run: Ht("run", 60204),
		plug: Ht("plug", 60205),
		preserveCase: Ht("preserve-case", 60206),
		preview: Ht("preview", 60207),
		project: Ht("project", 60208),
		pulse: Ht("pulse", 60209),
		question: Ht("question", 60210),
		quote: Ht("quote", 60211),
		radioTower: Ht("radio-tower", 60212),
		reactions: Ht("reactions", 60213),
		references: Ht("references", 60214),
		refresh: Ht("refresh", 60215),
		regex: Ht("regex", 60216),
		remoteExplorer: Ht("remote-explorer", 60217),
		remote: Ht("remote", 60218),
		remove: Ht("remove", 60219),
		replaceAll: Ht("replace-all", 60220),
		replace: Ht("replace", 60221),
		repoClone: Ht("repo-clone", 60222),
		repoForcePush: Ht("repo-force-push", 60223),
		repoPull: Ht("repo-pull", 60224),
		repoPush: Ht("repo-push", 60225),
		report: Ht("report", 60226),
		requestChanges: Ht("request-changes", 60227),
		rocket: Ht("rocket", 60228),
		rootFolderOpened: Ht("root-folder-opened", 60229),
		rootFolder: Ht("root-folder", 60230),
		rss: Ht("rss", 60231),
		ruby: Ht("ruby", 60232),
		saveAll: Ht("save-all", 60233),
		saveAs: Ht("save-as", 60234),
		save: Ht("save", 60235),
		screenFull: Ht("screen-full", 60236),
		screenNormal: Ht("screen-normal", 60237),
		searchStop: Ht("search-stop", 60238),
		server: Ht("server", 60240),
		settingsGear: Ht("settings-gear", 60241),
		settings: Ht("settings", 60242),
		shield: Ht("shield", 60243),
		smiley: Ht("smiley", 60244),
		sortPrecedence: Ht("sort-precedence", 60245),
		splitHorizontal: Ht("split-horizontal", 60246),
		splitVertical: Ht("split-vertical", 60247),
		squirrel: Ht("squirrel", 60248),
		starFull: Ht("star-full", 60249),
		starHalf: Ht("star-half", 60250),
		symbolClass: Ht("symbol-class", 60251),
		symbolColor: Ht("symbol-color", 60252),
		symbolConstant: Ht("symbol-constant", 60253),
		symbolEnumMember: Ht("symbol-enum-member", 60254),
		symbolField: Ht("symbol-field", 60255),
		symbolFile: Ht("symbol-file", 60256),
		symbolInterface: Ht("symbol-interface", 60257),
		symbolKeyword: Ht("symbol-keyword", 60258),
		symbolMisc: Ht("symbol-misc", 60259),
		symbolOperator: Ht("symbol-operator", 60260),
		symbolProperty: Ht("symbol-property", 60261),
		wrench: Ht("wrench", 60261),
		wrenchSubaction: Ht("wrench-subaction", 60261),
		symbolSnippet: Ht("symbol-snippet", 60262),
		tasklist: Ht("tasklist", 60263),
		telescope: Ht("telescope", 60264),
		textSize: Ht("text-size", 60265),
		threeBars: Ht("three-bars", 60266),
		thumbsdown: Ht("thumbsdown", 60267),
		thumbsup: Ht("thumbsup", 60268),
		tools: Ht("tools", 60269),
		triangleDown: Ht("triangle-down", 60270),
		triangleLeft: Ht("triangle-left", 60271),
		triangleRight: Ht("triangle-right", 60272),
		triangleUp: Ht("triangle-up", 60273),
		twitter: Ht("twitter", 60274),
		unfold: Ht("unfold", 60275),
		unlock: Ht("unlock", 60276),
		unmute: Ht("unmute", 60277),
		unverified: Ht("unverified", 60278),
		verified: Ht("verified", 60279),
		versions: Ht("versions", 60280),
		vmActive: Ht("vm-active", 60281),
		vmOutline: Ht("vm-outline", 60282),
		vmRunning: Ht("vm-running", 60283),
		watch: Ht("watch", 60284),
		whitespace: Ht("whitespace", 60285),
		wholeWord: Ht("whole-word", 60286),
		window: Ht("window", 60287),
		wordWrap: Ht("word-wrap", 60288),
		zoomIn: Ht("zoom-in", 60289),
		zoomOut: Ht("zoom-out", 60290),
		listFilter: Ht("list-filter", 60291),
		listFlat: Ht("list-flat", 60292),
		listSelection: Ht("list-selection", 60293),
		selection: Ht("selection", 60293),
		listTree: Ht("list-tree", 60294),
		debugBreakpointFunctionUnverified: Ht("debug-breakpoint-function-unverified", 60295),
		debugBreakpointFunction: Ht("debug-breakpoint-function", 60296),
		debugBreakpointFunctionDisabled: Ht("debug-breakpoint-function-disabled", 60296),
		debugStackframeActive: Ht("debug-stackframe-active", 60297),
		circleSmallFilled: Ht("circle-small-filled", 60298),
		debugStackframeDot: Ht("debug-stackframe-dot", 60298),
		terminalDecorationMark: Ht("terminal-decoration-mark", 60298),
		debugStackframe: Ht("debug-stackframe", 60299),
		debugStackframeFocused: Ht("debug-stackframe-focused", 60299),
		debugBreakpointUnsupported: Ht("debug-breakpoint-unsupported", 60300),
		symbolString: Ht("symbol-string", 60301),
		debugReverseContinue: Ht("debug-reverse-continue", 60302),
		debugStepBack: Ht("debug-step-back", 60303),
		debugRestartFrame: Ht("debug-restart-frame", 60304),
		debugAlt: Ht("debug-alt", 60305),
		callIncoming: Ht("call-incoming", 60306),
		callOutgoing: Ht("call-outgoing", 60307),
		menu: Ht("menu", 60308),
		expandAll: Ht("expand-all", 60309),
		feedback: Ht("feedback", 60310),
		gitPullRequestReviewer: Ht("git-pull-request-reviewer", 60310),
		groupByRefType: Ht("group-by-ref-type", 60311),
		ungroupByRefType: Ht("ungroup-by-ref-type", 60312),
		account: Ht("account", 60313),
		gitPullRequestAssignee: Ht("git-pull-request-assignee", 60313),
		bellDot: Ht("bell-dot", 60314),
		debugConsole: Ht("debug-console", 60315),
		library: Ht("library", 60316),
		output: Ht("output", 60317),
		runAll: Ht("run-all", 60318),
		syncIgnored: Ht("sync-ignored", 60319),
		pinned: Ht("pinned", 60320),
		githubInverted: Ht("github-inverted", 60321),
		serverProcess: Ht("server-process", 60322),
		serverEnvironment: Ht("server-environment", 60323),
		pass: Ht("pass", 60324),
		issueClosed: Ht("issue-closed", 60324),
		stopCircle: Ht("stop-circle", 60325),
		playCircle: Ht("play-circle", 60326),
		record: Ht("record", 60327),
		debugAltSmall: Ht("debug-alt-small", 60328),
		vmConnect: Ht("vm-connect", 60329),
		cloud: Ht("cloud", 60330),
		merge: Ht("merge", 60331),
		export: Ht("export", 60332),
		graphLeft: Ht("graph-left", 60333),
		magnet: Ht("magnet", 60334),
		notebook: Ht("notebook", 60335),
		redo: Ht("redo", 60336),
		checkAll: Ht("check-all", 60337),
		pinnedDirty: Ht("pinned-dirty", 60338),
		passFilled: Ht("pass-filled", 60339),
		circleLargeFilled: Ht("circle-large-filled", 60340),
		circleLarge: Ht("circle-large", 60341),
		circleLargeOutline: Ht("circle-large-outline", 60341),
		combine: Ht("combine", 60342),
		gather: Ht("gather", 60342),
		table: Ht("table", 60343),
		variableGroup: Ht("variable-group", 60344),
		typeHierarchy: Ht("type-hierarchy", 60345),
		typeHierarchySub: Ht("type-hierarchy-sub", 60346),
		typeHierarchySuper: Ht("type-hierarchy-super", 60347),
		gitPullRequestCreate: Ht("git-pull-request-create", 60348),
		runAbove: Ht("run-above", 60349),
		runBelow: Ht("run-below", 60350),
		notebookTemplate: Ht("notebook-template", 60351),
		debugRerun: Ht("debug-rerun", 60352),
		workspaceTrusted: Ht("workspace-trusted", 60353),
		workspaceUntrusted: Ht("workspace-untrusted", 60354),
		workspaceUnknown: Ht("workspace-unknown", 60355),
		terminalCmd: Ht("terminal-cmd", 60356),
		terminalDebian: Ht("terminal-debian", 60357),
		terminalLinux: Ht("terminal-linux", 60358),
		terminalPowershell: Ht("terminal-powershell", 60359),
		terminalTmux: Ht("terminal-tmux", 60360),
		terminalUbuntu: Ht("terminal-ubuntu", 60361),
		terminalBash: Ht("terminal-bash", 60362),
		arrowSwap: Ht("arrow-swap", 60363),
		copy: Ht("copy", 60364),
		personAdd: Ht("person-add", 60365),
		filterFilled: Ht("filter-filled", 60366),
		wand: Ht("wand", 60367),
		debugLineByLine: Ht("debug-line-by-line", 60368),
		inspect: Ht("inspect", 60369),
		layers: Ht("layers", 60370),
		layersDot: Ht("layers-dot", 60371),
		layersActive: Ht("layers-active", 60372),
		compass: Ht("compass", 60373),
		compassDot: Ht("compass-dot", 60374),
		compassActive: Ht("compass-active", 60375),
		azure: Ht("azure", 60376),
		issueDraft: Ht("issue-draft", 60377),
		gitPullRequestClosed: Ht("git-pull-request-closed", 60378),
		gitPullRequestDraft: Ht("git-pull-request-draft", 60379),
		debugAll: Ht("debug-all", 60380),
		debugCoverage: Ht("debug-coverage", 60381),
		runErrors: Ht("run-errors", 60382),
		folderLibrary: Ht("folder-library", 60383),
		debugContinueSmall: Ht("debug-continue-small", 60384),
		beakerStop: Ht("beaker-stop", 60385),
		graphLine: Ht("graph-line", 60386),
		graphScatter: Ht("graph-scatter", 60387),
		pieChart: Ht("pie-chart", 60388),
		bracket: Ht("bracket", 60175),
		bracketDot: Ht("bracket-dot", 60389),
		bracketError: Ht("bracket-error", 60390),
		lockSmall: Ht("lock-small", 60391),
		azureDevops: Ht("azure-devops", 60392),
		verifiedFilled: Ht("verified-filled", 60393),
		newline: Ht("newline", 60394),
		layout: Ht("layout", 60395),
		layoutActivitybarLeft: Ht("layout-activitybar-left", 60396),
		layoutActivitybarRight: Ht("layout-activitybar-right", 60397),
		layoutPanelLeft: Ht("layout-panel-left", 60398),
		layoutPanelCenter: Ht("layout-panel-center", 60399),
		layoutPanelJustify: Ht("layout-panel-justify", 60400),
		layoutPanelRight: Ht("layout-panel-right", 60401),
		layoutPanel: Ht("layout-panel", 60402),
		layoutSidebarLeft: Ht("layout-sidebar-left", 60403),
		layoutSidebarRight: Ht("layout-sidebar-right", 60404),
		layoutStatusbar: Ht("layout-statusbar", 60405),
		layoutMenubar: Ht("layout-menubar", 60406),
		layoutCentered: Ht("layout-centered", 60407),
		target: Ht("target", 60408),
		indent: Ht("indent", 60409),
		recordSmall: Ht("record-small", 60410),
		errorSmall: Ht("error-small", 60411),
		terminalDecorationError: Ht("terminal-decoration-error", 60411),
		arrowCircleDown: Ht("arrow-circle-down", 60412),
		arrowCircleLeft: Ht("arrow-circle-left", 60413),
		arrowCircleRight: Ht("arrow-circle-right", 60414),
		arrowCircleUp: Ht("arrow-circle-up", 60415),
		layoutSidebarRightOff: Ht("layout-sidebar-right-off", 60416),
		layoutPanelOff: Ht("layout-panel-off", 60417),
		layoutSidebarLeftOff: Ht("layout-sidebar-left-off", 60418),
		blank: Ht("blank", 60419),
		heartFilled: Ht("heart-filled", 60420),
		map: Ht("map", 60421),
		mapHorizontal: Ht("map-horizontal", 60421),
		foldHorizontal: Ht("fold-horizontal", 60421),
		mapFilled: Ht("map-filled", 60422),
		mapHorizontalFilled: Ht("map-horizontal-filled", 60422),
		foldHorizontalFilled: Ht("fold-horizontal-filled", 60422),
		circleSmall: Ht("circle-small", 60423),
		bellSlash: Ht("bell-slash", 60424),
		bellSlashDot: Ht("bell-slash-dot", 60425),
		commentUnresolved: Ht("comment-unresolved", 60426),
		gitPullRequestGoToChanges: Ht("git-pull-request-go-to-changes", 60427),
		gitPullRequestNewChanges: Ht("git-pull-request-new-changes", 60428),
		searchFuzzy: Ht("search-fuzzy", 60429),
		commentDraft: Ht("comment-draft", 60430),
		send: Ht("send", 60431),
		sparkle: Ht("sparkle", 60432),
		insert: Ht("insert", 60433),
		mic: Ht("mic", 60434),
		thumbsdownFilled: Ht("thumbsdown-filled", 60435),
		thumbsupFilled: Ht("thumbsup-filled", 60436),
		coffee: Ht("coffee", 60437),
		snake: Ht("snake", 60438),
		game: Ht("game", 60439),
		vr: Ht("vr", 60440),
		chip: Ht("chip", 60441),
		piano: Ht("piano", 60442),
		music: Ht("music", 60443),
		micFilled: Ht("mic-filled", 60444),
		repoFetch: Ht("repo-fetch", 60445),
		copilot: Ht("copilot", 60446),
		lightbulbSparkle: Ht("lightbulb-sparkle", 60447),
		robot: Ht("robot", 60448),
		sparkleFilled: Ht("sparkle-filled", 60449),
		diffSingle: Ht("diff-single", 60450),
		diffMultiple: Ht("diff-multiple", 60451),
		surroundWith: Ht("surround-with", 60452),
		share: Ht("share", 60453),
		gitStash: Ht("git-stash", 60454),
		gitStashApply: Ht("git-stash-apply", 60455),
		gitStashPop: Ht("git-stash-pop", 60456),
		vscode: Ht("vscode", 60457),
		vscodeInsiders: Ht("vscode-insiders", 60458),
		codeOss: Ht("code-oss", 60459),
		runCoverage: Ht("run-coverage", 60460),
		runAllCoverage: Ht("run-all-coverage", 60461),
		coverage: Ht("coverage", 60462),
		githubProject: Ht("github-project", 60463),
		mapVertical: Ht("map-vertical", 60464),
		foldVertical: Ht("fold-vertical", 60464),
		mapVerticalFilled: Ht("map-vertical-filled", 60465),
		foldVerticalFilled: Ht("fold-vertical-filled", 60465),
		goToSearch: Ht("go-to-search", 60466),
		percentage: Ht("percentage", 60467),
		sortPercentage: Ht("sort-percentage", 60467),
		attach: Ht("attach", 60468),
		goToEditingSession: Ht("go-to-editing-session", 60469),
		editSession: Ht("edit-session", 60470),
		codeReview: Ht("code-review", 60471),
		copilotWarning: Ht("copilot-warning", 60472),
		python: Ht("python", 60473),
		copilotLarge: Ht("copilot-large", 60474),
		copilotWarningLarge: Ht("copilot-warning-large", 60475),
		keyboardTab: Ht("keyboard-tab", 60476),
		copilotBlocked: Ht("copilot-blocked", 60477),
		copilotNotConnected: Ht("copilot-not-connected", 60478),
		flag: Ht("flag", 60479),
		lightbulbEmpty: Ht("lightbulb-empty", 60480),
		symbolMethodArrow: Ht("symbol-method-arrow", 60481),
		copilotUnavailable: Ht("copilot-unavailable", 60482),
		repoPinned: Ht("repo-pinned", 60483),
		keyboardTabAbove: Ht("keyboard-tab-above", 60484),
		keyboardTabBelow: Ht("keyboard-tab-below", 60485),
		gitPullRequestDone: Ht("git-pull-request-done", 60486),
		mcp: Ht("mcp", 60487),
		extensionsLarge: Ht("extensions-large", 60488),
		layoutPanelDock: Ht("layout-panel-dock", 60489),
		layoutSidebarLeftDock: Ht("layout-sidebar-left-dock", 60490),
		layoutSidebarRightDock: Ht("layout-sidebar-right-dock", 60491),
		copilotInProgress: Ht("copilot-in-progress", 60492),
		copilotError: Ht("copilot-error", 60493),
		copilotSuccess: Ht("copilot-success", 60494),
		chatSparkle: Ht("chat-sparkle", 60495),
		searchSparkle: Ht("search-sparkle", 60496),
		editSparkle: Ht("edit-sparkle", 60497),
		copilotSnooze: Ht("copilot-snooze", 60498),
		sendToRemoteAgent: Ht("send-to-remote-agent", 60499),
		commentDiscussionSparkle: Ht("comment-discussion-sparkle", 60500),
		chatSparkleWarning: Ht("chat-sparkle-warning", 60501),
		chatSparkleError: Ht("chat-sparkle-error", 60502),
		collection: Ht("collection", 60503),
		newCollection: Ht("new-collection", 60504),
		thinking: Ht("thinking", 60505),
		build: Ht("build", 60506),
		commentDiscussionQuote: Ht("comment-discussion-quote", 60507),
		cursor: Ht("cursor", 60508),
		eraser: Ht("eraser", 60509),
		fileText: Ht("file-text", 60510),
		gitLens: Ht("git-lens", 60511),
		quotes: Ht("quotes", 60512),
		rename: Ht("rename", 60513),
		runWithDeps: Ht("run-with-deps", 60514),
		debugConnected: Ht("debug-connected", 60515),
		strikethrough: Ht("strikethrough", 60516),
		openInProduct: Ht("open-in-product", 60517),
		indexZero: Ht("index-zero", 60518),
		agent: Ht("agent", 60519),
		editCode: Ht("edit-code", 60520),
		repoSelected: Ht("repo-selected", 60521),
		skip: Ht("skip", 60522),
		mergeInto: Ht("merge-into", 60523),
		gitBranchChanges: Ht("git-branch-changes", 60524),
		gitBranchStagedChanges: Ht("git-branch-staged-changes", 60525),
		gitBranchConflicts: Ht("git-branch-conflicts", 60526),
		gitBranch: Ht("git-branch", 60527),
		gitBranchCreate: Ht("git-branch-create", 60527),
		gitBranchDelete: Ht("git-branch-delete", 60527),
		searchLarge: Ht("search-large", 60528),
		terminalGitBash: Ht("terminal-git-bash", 60529),
		dialogError: Ht("dialog-error", "error"),
		dialogWarning: Ht("dialog-warning", "warning"),
		dialogInfo: Ht("dialog-info", "info"),
		dialogClose: Ht("dialog-close", "close"),
		treeItemExpanded: Ht("tree-item-expanded", "chevron-down"),
		treeFilterOnTypeOn: Ht("tree-filter-on-type-on", "list-filter"),
		treeFilterOnTypeOff: Ht("tree-filter-on-type-off", "list-selection"),
		treeFilterClear: Ht("tree-filter-clear", "close"),
		treeItemLoading: Ht("tree-item-loading", "loading"),
		menuSelection: Ht("menu-selection", "check"),
		menuSubmenu: Ht("menu-submenu", "chevron-right"),
		menuBarMore: Ht("menubar-more", "more"),
		scrollbarButtonLeft: Ht("scrollbar-button-left", "triangle-left"),
		scrollbarButtonRight: Ht("scrollbar-button-right", "triangle-right"),
		scrollbarButtonUp: Ht("scrollbar-button-up", "triangle-up"),
		scrollbarButtonDown: Ht("scrollbar-button-down", "triangle-down"),
		toolBarMore: Ht("toolbar-more", "more"),
		quickInputBack: Ht("quick-input-back", "arrow-left"),
		dropDownButton: Ht("drop-down-button", 60084),
		symbolCustomColor: Ht("symbol-customcolor", 60252),
		exportIcon: Ht("export", 60332),
		workspaceUnspecified: Ht("workspace-unspecified", 60355),
		newLine: Ht("newline", 60394),
		thumbsDownFilled: Ht("thumbsdown-filled", 60435),
		thumbsUpFilled: Ht("thumbsup-filled", 60436),
		gitFetch: Ht("git-fetch", 60445),
		lightbulbSparkleAutofix: Ht("lightbulb-sparkle-autofix", 60447),
		debugBreakpointPending: Ht("debug-breakpoint-pending", 60377)
	};
	var Gt, Xt, Qt, Yt, Jt, Zt, en, tn, nn = class extends f {
		get isResolved() {
			return this._isResolved;
		}
		constructor(e, t, n) {
			super(), this._registry = e, this._languageId = t, this._factory = n, this._isDisposed = !1, this._resolvePromise = null, this._isResolved = !1;
		}
		dispose() {
			this._isDisposed = !0, super.dispose();
		}
		async resolve() {
			return this._resolvePromise || (this._resolvePromise = this._create()), this._resolvePromise;
		}
		async _create() {
			const e = await this._factory.tokenizationSupport;
			this._isResolved = !0, e && !this._isDisposed && this._register(this._registry.register(this._languageId, e));
		}
	}, rn = class {
		constructor(e, t, n) {
			this.offset = e, this.type = t, this.language = n, this._tokenBrand = void 0;
		}
		toString() {
			return "(" + this.offset + ", " + this.type + ")";
		}
	};
	(function(e) {
		e[e.Increase = 0] = "Increase", e[e.Decrease = 1] = "Decrease";
	})(Gt || (Gt = {})), function(e) {
		const t = /* @__PURE__ */ new Map();
		t.set(0, jt.symbolMethod), t.set(1, jt.symbolFunction), t.set(2, jt.symbolConstructor), t.set(3, jt.symbolField), t.set(4, jt.symbolVariable), t.set(5, jt.symbolClass), t.set(6, jt.symbolStruct), t.set(7, jt.symbolInterface), t.set(8, jt.symbolModule), t.set(9, jt.symbolProperty), t.set(10, jt.symbolEvent), t.set(11, jt.symbolOperator), t.set(12, jt.symbolUnit), t.set(13, jt.symbolValue), t.set(15, jt.symbolEnum), t.set(14, jt.symbolConstant), t.set(15, jt.symbolEnum), t.set(16, jt.symbolEnumMember), t.set(17, jt.symbolKeyword), t.set(28, jt.symbolSnippet), t.set(18, jt.symbolText), t.set(19, jt.symbolColor), t.set(20, jt.symbolFile), t.set(21, jt.symbolReference), t.set(22, jt.symbolCustomColor), t.set(23, jt.symbolFolder), t.set(24, jt.symbolTypeParameter), t.set(25, jt.account), t.set(26, jt.issues), t.set(27, jt.tools), e.toIcon = function(e) {
			let n = t.get(e);
			return n || (n = jt.symbolProperty), n;
		}, e.toLabel = function(e) {
			switch (e) {
				case 0: return O(728, "Method");
				case 1: return O(729, "Function");
				case 2: return O(730, "Constructor");
				case 3: return O(731, "Field");
				case 4: return O(732, "Variable");
				case 5: return O(733, "Class");
				case 6: return O(734, "Struct");
				case 7: return O(735, "Interface");
				case 8: return O(736, "Module");
				case 9: return O(737, "Property");
				case 10: return O(738, "Event");
				case 11: return O(739, "Operator");
				case 12: return O(740, "Unit");
				case 13: return O(741, "Value");
				case 14: return O(742, "Constant");
				case 15: return O(743, "Enum");
				case 16: return O(744, "Enum Member");
				case 17: return O(745, "Keyword");
				case 18: return O(746, "Text");
				case 19: return O(747, "Color");
				case 20: return O(748, "File");
				case 21: return O(749, "Reference");
				case 22: return O(750, "Custom Color");
				case 23: return O(751, "Folder");
				case 24: return O(752, "Type Parameter");
				case 25: return O(753, "User");
				case 26: return O(754, "Issue");
				case 27: return O(755, "Tool");
				case 28: return O(756, "Snippet");
				default: return "";
			}
		};
		const n = /* @__PURE__ */ new Map();
		n.set("method", 0), n.set("function", 1), n.set("constructor", 2), n.set("field", 3), n.set("variable", 4), n.set("class", 5), n.set("struct", 6), n.set("interface", 7), n.set("module", 8), n.set("property", 9), n.set("event", 10), n.set("operator", 11), n.set("unit", 12), n.set("value", 13), n.set("constant", 14), n.set("enum", 15), n.set("enum-member", 16), n.set("enumMember", 16), n.set("keyword", 17), n.set("snippet", 28), n.set("text", 18), n.set("color", 19), n.set("file", 20), n.set("reference", 21), n.set("customcolor", 22), n.set("folder", 23), n.set("type-parameter", 24), n.set("typeParameter", 24), n.set("account", 25), n.set("issue", 26), n.set("tool", 27), e.fromString = function(e, t) {
			let r = n.get(e);
			return void 0 !== r || t || (r = 9), r;
		};
	}(Xt || (Xt = {})), function(e) {
		e[e.Automatic = 0] = "Automatic", e[e.Explicit = 1] = "Explicit";
	}(Qt || (Qt = {})), function(e) {
		e[e.Code = 1] = "Code", e[e.Label = 2] = "Label";
	}(Yt || (Yt = {})), function(e) {
		e[e.Accepted = 0] = "Accepted", e[e.Rejected = 1] = "Rejected", e[e.Ignored = 2] = "Ignored";
	}(Jt || (Jt = {})), function(e) {
		e[e.Automatic = 0] = "Automatic", e[e.PasteAs = 1] = "PasteAs";
	}(Zt || (Zt = {})), function(e) {
		e[e.Invoke = 1] = "Invoke", e[e.TriggerCharacter = 2] = "TriggerCharacter", e[e.ContentChange = 3] = "ContentChange";
	}(en || (en = {})), function(e) {
		e[e.Text = 0] = "Text", e[e.Read = 1] = "Read", e[e.Write = 2] = "Write";
	}(tn || (tn = {}));
	O(757, "array"), O(758, "boolean"), O(759, "class"), O(760, "constant"), O(761, "constructor"), O(762, "enumeration"), O(763, "enumeration member"), O(764, "event"), O(765, "field"), O(766, "file"), O(767, "function"), O(768, "interface"), O(769, "key"), O(770, "method"), O(771, "module"), O(772, "namespace"), O(773, "null"), O(774, "number"), O(775, "object"), O(776, "operator"), O(777, "package"), O(778, "property"), O(779, "string"), O(780, "struct"), O(781, "type parameter"), O(782, "variable");
	var sn;
	(function(e) {
		const t = /* @__PURE__ */ new Map();
		t.set(0, jt.symbolFile), t.set(1, jt.symbolModule), t.set(2, jt.symbolNamespace), t.set(3, jt.symbolPackage), t.set(4, jt.symbolClass), t.set(5, jt.symbolMethod), t.set(6, jt.symbolProperty), t.set(7, jt.symbolField), t.set(8, jt.symbolConstructor), t.set(9, jt.symbolEnum), t.set(10, jt.symbolInterface), t.set(11, jt.symbolFunction), t.set(12, jt.symbolVariable), t.set(13, jt.symbolConstant), t.set(14, jt.symbolString), t.set(15, jt.symbolNumber), t.set(16, jt.symbolBoolean), t.set(17, jt.symbolArray), t.set(18, jt.symbolObject), t.set(19, jt.symbolKey), t.set(20, jt.symbolNull), t.set(21, jt.symbolEnumMember), t.set(22, jt.symbolStruct), t.set(23, jt.symbolEvent), t.set(24, jt.symbolOperator), t.set(25, jt.symbolTypeParameter), e.toIcon = function(e) {
			let n = t.get(e);
			return n || (n = jt.symbolProperty), n;
		};
		const n = /* @__PURE__ */ new Map();
		n.set(0, 20), n.set(1, 8), n.set(2, 8), n.set(3, 8), n.set(4, 5), n.set(5, 0), n.set(6, 9), n.set(7, 3), n.set(8, 2), n.set(9, 15), n.set(10, 7), n.set(11, 1), n.set(12, 4), n.set(13, 14), n.set(14, 18), n.set(15, 13), n.set(16, 13), n.set(17, 13), n.set(18, 13), n.set(19, 17), n.set(20, 13), n.set(21, 16), n.set(22, 6), n.set(23, 10), n.set(24, 11), n.set(25, 24), e.toCompletionKind = function(e) {
			let t = n.get(e);
			return void 0 === t && (t = 20), t;
		};
	})(sn || (sn = {}));
	var on, an, ln, un;
	(class e {
		static {
			this.Comment = new e("comment");
		}
		static {
			this.Imports = new e("imports");
		}
		static {
			this.Region = new e("region");
		}
		static fromValue(t) {
			switch (t) {
				case "comment": return e.Comment;
				case "imports": return e.Imports;
				case "region": return e.Region;
			}
			return new e(t);
		}
		constructor(e) {
			this.value = e;
		}
	});
	(function(e) {
		e[e.AIGenerated = 1] = "AIGenerated";
	})(on || (on = {})), function(e) {
		e[e.Invoke = 0] = "Invoke", e[e.Automatic = 1] = "Automatic";
	}(an || (an = {})), function(e) {
		e.is = function(e) {
			return !(!e || "object" != typeof e) && "string" == typeof e.id && "string" == typeof e.title;
		};
	}(ln || (ln = {})), function(e) {
		e[e.Type = 1] = "Type", e[e.Parameter = 2] = "Parameter";
	}(un || (un = {}));
	new class {
		constructor() {
			this._tokenizationSupports = /* @__PURE__ */ new Map(), this._factories = /* @__PURE__ */ new Map(), this._onDidChange = new R(), this.onDidChange = this._onDidChange.event, this._colorMap = null;
		}
		handleChange(e) {
			this._onDidChange.fire({
				changedLanguages: e,
				changedColorMap: !1
			});
		}
		register(e, t) {
			return this._tokenizationSupports.set(e, t), this.handleChange([e]), g(() => {
				this._tokenizationSupports.get(e) === t && (this._tokenizationSupports.delete(e), this.handleChange([e]));
			});
		}
		get(e) {
			return this._tokenizationSupports.get(e) || null;
		}
		registerFactory(e, t) {
			this._factories.get(e)?.dispose();
			const n = new nn(this, e, t);
			return this._factories.set(e, n), g(() => {
				const t = this._factories.get(e);
				t && t === n && (this._factories.delete(e), t.dispose());
			});
		}
		async getOrCreate(e) {
			const t = this.get(e);
			if (t) return t;
			const n = this._factories.get(e);
			return !n || n.isResolved ? null : (await n.resolve(), this.get(e));
		}
		isResolved(e) {
			if (this.get(e)) return !0;
			const t = this._factories.get(e);
			return !(t && !t.isResolved);
		}
		setColorMap(e) {
			this._colorMap = e, this._onDidChange.fire({
				changedLanguages: Array.from(this._tokenizationSupports.keys()),
				changedColorMap: !0
			});
		}
		getColorMap() {
			return this._colorMap;
		}
		getDefaultBackground() {
			return this._colorMap && this._colorMap.length > 2 ? this._colorMap[2] : null;
		}
	}();
	var hn, cn, dn, gn, mn, fn, pn, bn, wn, _n, Cn, yn, vn, Ln, Nn, En, Sn, Rn, xn, An, kn, Mn, On, In, Tn, Pn, Fn, Dn, qn, Vn, Kn, Bn, Un, $n, Wn, zn, Hn, jn, Gn, Xn, Qn, Yn, Jn, Zn, er, tr, nr, rr;
	(function(e) {
		e[e.Unknown = 0] = "Unknown", e[e.Disabled = 1] = "Disabled", e[e.Enabled = 2] = "Enabled";
	})(hn || (hn = {})), function(e) {
		e[e.Invoke = 1] = "Invoke", e[e.Auto = 2] = "Auto";
	}(cn || (cn = {})), function(e) {
		e[e.None = 0] = "None", e[e.KeepWhitespace = 1] = "KeepWhitespace", e[e.InsertAsSnippet = 4] = "InsertAsSnippet";
	}(dn || (dn = {})), function(e) {
		e[e.Method = 0] = "Method", e[e.Function = 1] = "Function", e[e.Constructor = 2] = "Constructor", e[e.Field = 3] = "Field", e[e.Variable = 4] = "Variable", e[e.Class = 5] = "Class", e[e.Struct = 6] = "Struct", e[e.Interface = 7] = "Interface", e[e.Module = 8] = "Module", e[e.Property = 9] = "Property", e[e.Event = 10] = "Event", e[e.Operator = 11] = "Operator", e[e.Unit = 12] = "Unit", e[e.Value = 13] = "Value", e[e.Constant = 14] = "Constant", e[e.Enum = 15] = "Enum", e[e.EnumMember = 16] = "EnumMember", e[e.Keyword = 17] = "Keyword", e[e.Text = 18] = "Text", e[e.Color = 19] = "Color", e[e.File = 20] = "File", e[e.Reference = 21] = "Reference", e[e.Customcolor = 22] = "Customcolor", e[e.Folder = 23] = "Folder", e[e.TypeParameter = 24] = "TypeParameter", e[e.User = 25] = "User", e[e.Issue = 26] = "Issue", e[e.Tool = 27] = "Tool", e[e.Snippet = 28] = "Snippet";
	}(gn || (gn = {})), function(e) {
		e[e.Deprecated = 1] = "Deprecated";
	}(mn || (mn = {})), function(e) {
		e[e.Invoke = 0] = "Invoke", e[e.TriggerCharacter = 1] = "TriggerCharacter", e[e.TriggerForIncompleteCompletions = 2] = "TriggerForIncompleteCompletions";
	}(fn || (fn = {})), function(e) {
		e[e.EXACT = 0] = "EXACT", e[e.ABOVE = 1] = "ABOVE", e[e.BELOW = 2] = "BELOW";
	}(pn || (pn = {})), function(e) {
		e[e.NotSet = 0] = "NotSet", e[e.ContentFlush = 1] = "ContentFlush", e[e.RecoverFromMarkers = 2] = "RecoverFromMarkers", e[e.Explicit = 3] = "Explicit", e[e.Paste = 4] = "Paste", e[e.Undo = 5] = "Undo", e[e.Redo = 6] = "Redo";
	}(bn || (bn = {})), function(e) {
		e[e.LF = 1] = "LF", e[e.CRLF = 2] = "CRLF";
	}(wn || (wn = {})), function(e) {
		e[e.Text = 0] = "Text", e[e.Read = 1] = "Read", e[e.Write = 2] = "Write";
	}(_n || (_n = {})), function(e) {
		e[e.None = 0] = "None", e[e.Keep = 1] = "Keep", e[e.Brackets = 2] = "Brackets", e[e.Advanced = 3] = "Advanced", e[e.Full = 4] = "Full";
	}(Cn || (Cn = {})), function(e) {
		e[e.acceptSuggestionOnCommitCharacter = 0] = "acceptSuggestionOnCommitCharacter", e[e.acceptSuggestionOnEnter = 1] = "acceptSuggestionOnEnter", e[e.accessibilitySupport = 2] = "accessibilitySupport", e[e.accessibilityPageSize = 3] = "accessibilityPageSize", e[e.allowOverflow = 4] = "allowOverflow", e[e.allowVariableLineHeights = 5] = "allowVariableLineHeights", e[e.allowVariableFonts = 6] = "allowVariableFonts", e[e.allowVariableFontsInAccessibilityMode = 7] = "allowVariableFontsInAccessibilityMode", e[e.ariaLabel = 8] = "ariaLabel", e[e.ariaRequired = 9] = "ariaRequired", e[e.autoClosingBrackets = 10] = "autoClosingBrackets", e[e.autoClosingComments = 11] = "autoClosingComments", e[e.screenReaderAnnounceInlineSuggestion = 12] = "screenReaderAnnounceInlineSuggestion", e[e.autoClosingDelete = 13] = "autoClosingDelete", e[e.autoClosingOvertype = 14] = "autoClosingOvertype", e[e.autoClosingQuotes = 15] = "autoClosingQuotes", e[e.autoIndent = 16] = "autoIndent", e[e.autoIndentOnPaste = 17] = "autoIndentOnPaste", e[e.autoIndentOnPasteWithinString = 18] = "autoIndentOnPasteWithinString", e[e.automaticLayout = 19] = "automaticLayout", e[e.autoSurround = 20] = "autoSurround", e[e.bracketPairColorization = 21] = "bracketPairColorization", e[e.guides = 22] = "guides", e[e.codeLens = 23] = "codeLens", e[e.codeLensFontFamily = 24] = "codeLensFontFamily", e[e.codeLensFontSize = 25] = "codeLensFontSize", e[e.colorDecorators = 26] = "colorDecorators", e[e.colorDecoratorsLimit = 27] = "colorDecoratorsLimit", e[e.columnSelection = 28] = "columnSelection", e[e.comments = 29] = "comments", e[e.contextmenu = 30] = "contextmenu", e[e.copyWithSyntaxHighlighting = 31] = "copyWithSyntaxHighlighting", e[e.cursorBlinking = 32] = "cursorBlinking", e[e.cursorSmoothCaretAnimation = 33] = "cursorSmoothCaretAnimation", e[e.cursorStyle = 34] = "cursorStyle", e[e.cursorSurroundingLines = 35] = "cursorSurroundingLines", e[e.cursorSurroundingLinesStyle = 36] = "cursorSurroundingLinesStyle", e[e.cursorWidth = 37] = "cursorWidth", e[e.cursorHeight = 38] = "cursorHeight", e[e.disableLayerHinting = 39] = "disableLayerHinting", e[e.disableMonospaceOptimizations = 40] = "disableMonospaceOptimizations", e[e.domReadOnly = 41] = "domReadOnly", e[e.dragAndDrop = 42] = "dragAndDrop", e[e.dropIntoEditor = 43] = "dropIntoEditor", e[e.editContext = 44] = "editContext", e[e.emptySelectionClipboard = 45] = "emptySelectionClipboard", e[e.experimentalGpuAcceleration = 46] = "experimentalGpuAcceleration", e[e.experimentalWhitespaceRendering = 47] = "experimentalWhitespaceRendering", e[e.extraEditorClassName = 48] = "extraEditorClassName", e[e.fastScrollSensitivity = 49] = "fastScrollSensitivity", e[e.find = 50] = "find", e[e.fixedOverflowWidgets = 51] = "fixedOverflowWidgets", e[e.folding = 52] = "folding", e[e.foldingStrategy = 53] = "foldingStrategy", e[e.foldingHighlight = 54] = "foldingHighlight", e[e.foldingImportsByDefault = 55] = "foldingImportsByDefault", e[e.foldingMaximumRegions = 56] = "foldingMaximumRegions", e[e.unfoldOnClickAfterEndOfLine = 57] = "unfoldOnClickAfterEndOfLine", e[e.fontFamily = 58] = "fontFamily", e[e.fontInfo = 59] = "fontInfo", e[e.fontLigatures = 60] = "fontLigatures", e[e.fontSize = 61] = "fontSize", e[e.fontWeight = 62] = "fontWeight", e[e.fontVariations = 63] = "fontVariations", e[e.formatOnPaste = 64] = "formatOnPaste", e[e.formatOnType = 65] = "formatOnType", e[e.glyphMargin = 66] = "glyphMargin", e[e.gotoLocation = 67] = "gotoLocation", e[e.hideCursorInOverviewRuler = 68] = "hideCursorInOverviewRuler", e[e.hover = 69] = "hover", e[e.inDiffEditor = 70] = "inDiffEditor", e[e.inlineSuggest = 71] = "inlineSuggest", e[e.letterSpacing = 72] = "letterSpacing", e[e.lightbulb = 73] = "lightbulb", e[e.lineDecorationsWidth = 74] = "lineDecorationsWidth", e[e.lineHeight = 75] = "lineHeight", e[e.lineNumbers = 76] = "lineNumbers", e[e.lineNumbersMinChars = 77] = "lineNumbersMinChars", e[e.linkedEditing = 78] = "linkedEditing", e[e.links = 79] = "links", e[e.matchBrackets = 80] = "matchBrackets", e[e.minimap = 81] = "minimap", e[e.mouseStyle = 82] = "mouseStyle", e[e.mouseWheelScrollSensitivity = 83] = "mouseWheelScrollSensitivity", e[e.mouseWheelZoom = 84] = "mouseWheelZoom", e[e.multiCursorMergeOverlapping = 85] = "multiCursorMergeOverlapping", e[e.multiCursorModifier = 86] = "multiCursorModifier", e[e.mouseMiddleClickAction = 87] = "mouseMiddleClickAction", e[e.multiCursorPaste = 88] = "multiCursorPaste", e[e.multiCursorLimit = 89] = "multiCursorLimit", e[e.occurrencesHighlight = 90] = "occurrencesHighlight", e[e.occurrencesHighlightDelay = 91] = "occurrencesHighlightDelay", e[e.overtypeCursorStyle = 92] = "overtypeCursorStyle", e[e.overtypeOnPaste = 93] = "overtypeOnPaste", e[e.overviewRulerBorder = 94] = "overviewRulerBorder", e[e.overviewRulerLanes = 95] = "overviewRulerLanes", e[e.padding = 96] = "padding", e[e.pasteAs = 97] = "pasteAs", e[e.parameterHints = 98] = "parameterHints", e[e.peekWidgetDefaultFocus = 99] = "peekWidgetDefaultFocus", e[e.placeholder = 100] = "placeholder", e[e.definitionLinkOpensInPeek = 101] = "definitionLinkOpensInPeek", e[e.quickSuggestions = 102] = "quickSuggestions", e[e.quickSuggestionsDelay = 103] = "quickSuggestionsDelay", e[e.readOnly = 104] = "readOnly", e[e.readOnlyMessage = 105] = "readOnlyMessage", e[e.renameOnType = 106] = "renameOnType", e[e.renderRichScreenReaderContent = 107] = "renderRichScreenReaderContent", e[e.renderControlCharacters = 108] = "renderControlCharacters", e[e.renderFinalNewline = 109] = "renderFinalNewline", e[e.renderLineHighlight = 110] = "renderLineHighlight", e[e.renderLineHighlightOnlyWhenFocus = 111] = "renderLineHighlightOnlyWhenFocus", e[e.renderValidationDecorations = 112] = "renderValidationDecorations", e[e.renderWhitespace = 113] = "renderWhitespace", e[e.revealHorizontalRightPadding = 114] = "revealHorizontalRightPadding", e[e.roundedSelection = 115] = "roundedSelection", e[e.rulers = 116] = "rulers", e[e.scrollbar = 117] = "scrollbar", e[e.scrollBeyondLastColumn = 118] = "scrollBeyondLastColumn", e[e.scrollBeyondLastLine = 119] = "scrollBeyondLastLine", e[e.scrollPredominantAxis = 120] = "scrollPredominantAxis", e[e.selectionClipboard = 121] = "selectionClipboard", e[e.selectionHighlight = 122] = "selectionHighlight", e[e.selectionHighlightMaxLength = 123] = "selectionHighlightMaxLength", e[e.selectionHighlightMultiline = 124] = "selectionHighlightMultiline", e[e.selectOnLineNumbers = 125] = "selectOnLineNumbers", e[e.showFoldingControls = 126] = "showFoldingControls", e[e.showUnused = 127] = "showUnused", e[e.snippetSuggestions = 128] = "snippetSuggestions", e[e.smartSelect = 129] = "smartSelect", e[e.smoothScrolling = 130] = "smoothScrolling", e[e.stickyScroll = 131] = "stickyScroll", e[e.stickyTabStops = 132] = "stickyTabStops", e[e.stopRenderingLineAfter = 133] = "stopRenderingLineAfter", e[e.suggest = 134] = "suggest", e[e.suggestFontSize = 135] = "suggestFontSize", e[e.suggestLineHeight = 136] = "suggestLineHeight", e[e.suggestOnTriggerCharacters = 137] = "suggestOnTriggerCharacters", e[e.suggestSelection = 138] = "suggestSelection", e[e.tabCompletion = 139] = "tabCompletion", e[e.tabIndex = 140] = "tabIndex", e[e.trimWhitespaceOnDelete = 141] = "trimWhitespaceOnDelete", e[e.unicodeHighlighting = 142] = "unicodeHighlighting", e[e.unusualLineTerminators = 143] = "unusualLineTerminators", e[e.useShadowDOM = 144] = "useShadowDOM", e[e.useTabStops = 145] = "useTabStops", e[e.wordBreak = 146] = "wordBreak", e[e.wordSegmenterLocales = 147] = "wordSegmenterLocales", e[e.wordSeparators = 148] = "wordSeparators", e[e.wordWrap = 149] = "wordWrap", e[e.wordWrapBreakAfterCharacters = 150] = "wordWrapBreakAfterCharacters", e[e.wordWrapBreakBeforeCharacters = 151] = "wordWrapBreakBeforeCharacters", e[e.wordWrapColumn = 152] = "wordWrapColumn", e[e.wordWrapOverride1 = 153] = "wordWrapOverride1", e[e.wordWrapOverride2 = 154] = "wordWrapOverride2", e[e.wrappingIndent = 155] = "wrappingIndent", e[e.wrappingStrategy = 156] = "wrappingStrategy", e[e.showDeprecated = 157] = "showDeprecated", e[e.inertialScroll = 158] = "inertialScroll", e[e.inlayHints = 159] = "inlayHints", e[e.wrapOnEscapedLineFeeds = 160] = "wrapOnEscapedLineFeeds", e[e.effectiveCursorStyle = 161] = "effectiveCursorStyle", e[e.editorClassName = 162] = "editorClassName", e[e.pixelRatio = 163] = "pixelRatio", e[e.tabFocusMode = 164] = "tabFocusMode", e[e.layoutInfo = 165] = "layoutInfo", e[e.wrappingInfo = 166] = "wrappingInfo", e[e.defaultColorDecorators = 167] = "defaultColorDecorators", e[e.colorDecoratorsActivatedOn = 168] = "colorDecoratorsActivatedOn", e[e.inlineCompletionsAccessibilityVerbose = 169] = "inlineCompletionsAccessibilityVerbose", e[e.effectiveEditContext = 170] = "effectiveEditContext", e[e.scrollOnMiddleClick = 171] = "scrollOnMiddleClick", e[e.effectiveAllowVariableFonts = 172] = "effectiveAllowVariableFonts";
	}(yn || (yn = {})), function(e) {
		e[e.TextDefined = 0] = "TextDefined", e[e.LF = 1] = "LF", e[e.CRLF = 2] = "CRLF";
	}(vn || (vn = {})), function(e) {
		e[e.LF = 0] = "LF", e[e.CRLF = 1] = "CRLF";
	}(Ln || (Ln = {})), function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 3] = "Right";
	}(Nn || (Nn = {})), function(e) {
		e[e.Increase = 0] = "Increase", e[e.Decrease = 1] = "Decrease";
	}(En || (En = {})), function(e) {
		e[e.None = 0] = "None", e[e.Indent = 1] = "Indent", e[e.IndentOutdent = 2] = "IndentOutdent", e[e.Outdent = 3] = "Outdent";
	}(Sn || (Sn = {})), function(e) {
		e[e.Both = 0] = "Both", e[e.Right = 1] = "Right", e[e.Left = 2] = "Left", e[e.None = 3] = "None";
	}(Rn || (Rn = {})), function(e) {
		e[e.Type = 1] = "Type", e[e.Parameter = 2] = "Parameter";
	}(xn || (xn = {})), function(e) {
		e[e.Accepted = 0] = "Accepted", e[e.Rejected = 1] = "Rejected", e[e.Ignored = 2] = "Ignored";
	}(An || (An = {})), function(e) {
		e[e.Code = 1] = "Code", e[e.Label = 2] = "Label";
	}(kn || (kn = {})), function(e) {
		e[e.Automatic = 0] = "Automatic", e[e.Explicit = 1] = "Explicit";
	}(Mn || (Mn = {})), function(e) {
		e[e.DependsOnKbLayout = -1] = "DependsOnKbLayout", e[e.Unknown = 0] = "Unknown", e[e.Backspace = 1] = "Backspace", e[e.Tab = 2] = "Tab", e[e.Enter = 3] = "Enter", e[e.Shift = 4] = "Shift", e[e.Ctrl = 5] = "Ctrl", e[e.Alt = 6] = "Alt", e[e.PauseBreak = 7] = "PauseBreak", e[e.CapsLock = 8] = "CapsLock", e[e.Escape = 9] = "Escape", e[e.Space = 10] = "Space", e[e.PageUp = 11] = "PageUp", e[e.PageDown = 12] = "PageDown", e[e.End = 13] = "End", e[e.Home = 14] = "Home", e[e.LeftArrow = 15] = "LeftArrow", e[e.UpArrow = 16] = "UpArrow", e[e.RightArrow = 17] = "RightArrow", e[e.DownArrow = 18] = "DownArrow", e[e.Insert = 19] = "Insert", e[e.Delete = 20] = "Delete", e[e.Digit0 = 21] = "Digit0", e[e.Digit1 = 22] = "Digit1", e[e.Digit2 = 23] = "Digit2", e[e.Digit3 = 24] = "Digit3", e[e.Digit4 = 25] = "Digit4", e[e.Digit5 = 26] = "Digit5", e[e.Digit6 = 27] = "Digit6", e[e.Digit7 = 28] = "Digit7", e[e.Digit8 = 29] = "Digit8", e[e.Digit9 = 30] = "Digit9", e[e.KeyA = 31] = "KeyA", e[e.KeyB = 32] = "KeyB", e[e.KeyC = 33] = "KeyC", e[e.KeyD = 34] = "KeyD", e[e.KeyE = 35] = "KeyE", e[e.KeyF = 36] = "KeyF", e[e.KeyG = 37] = "KeyG", e[e.KeyH = 38] = "KeyH", e[e.KeyI = 39] = "KeyI", e[e.KeyJ = 40] = "KeyJ", e[e.KeyK = 41] = "KeyK", e[e.KeyL = 42] = "KeyL", e[e.KeyM = 43] = "KeyM", e[e.KeyN = 44] = "KeyN", e[e.KeyO = 45] = "KeyO", e[e.KeyP = 46] = "KeyP", e[e.KeyQ = 47] = "KeyQ", e[e.KeyR = 48] = "KeyR", e[e.KeyS = 49] = "KeyS", e[e.KeyT = 50] = "KeyT", e[e.KeyU = 51] = "KeyU", e[e.KeyV = 52] = "KeyV", e[e.KeyW = 53] = "KeyW", e[e.KeyX = 54] = "KeyX", e[e.KeyY = 55] = "KeyY", e[e.KeyZ = 56] = "KeyZ", e[e.Meta = 57] = "Meta", e[e.ContextMenu = 58] = "ContextMenu", e[e.F1 = 59] = "F1", e[e.F2 = 60] = "F2", e[e.F3 = 61] = "F3", e[e.F4 = 62] = "F4", e[e.F5 = 63] = "F5", e[e.F6 = 64] = "F6", e[e.F7 = 65] = "F7", e[e.F8 = 66] = "F8", e[e.F9 = 67] = "F9", e[e.F10 = 68] = "F10", e[e.F11 = 69] = "F11", e[e.F12 = 70] = "F12", e[e.F13 = 71] = "F13", e[e.F14 = 72] = "F14", e[e.F15 = 73] = "F15", e[e.F16 = 74] = "F16", e[e.F17 = 75] = "F17", e[e.F18 = 76] = "F18", e[e.F19 = 77] = "F19", e[e.F20 = 78] = "F20", e[e.F21 = 79] = "F21", e[e.F22 = 80] = "F22", e[e.F23 = 81] = "F23", e[e.F24 = 82] = "F24", e[e.NumLock = 83] = "NumLock", e[e.ScrollLock = 84] = "ScrollLock", e[e.Semicolon = 85] = "Semicolon", e[e.Equal = 86] = "Equal", e[e.Comma = 87] = "Comma", e[e.Minus = 88] = "Minus", e[e.Period = 89] = "Period", e[e.Slash = 90] = "Slash", e[e.Backquote = 91] = "Backquote", e[e.BracketLeft = 92] = "BracketLeft", e[e.Backslash = 93] = "Backslash", e[e.BracketRight = 94] = "BracketRight", e[e.Quote = 95] = "Quote", e[e.OEM_8 = 96] = "OEM_8", e[e.IntlBackslash = 97] = "IntlBackslash", e[e.Numpad0 = 98] = "Numpad0", e[e.Numpad1 = 99] = "Numpad1", e[e.Numpad2 = 100] = "Numpad2", e[e.Numpad3 = 101] = "Numpad3", e[e.Numpad4 = 102] = "Numpad4", e[e.Numpad5 = 103] = "Numpad5", e[e.Numpad6 = 104] = "Numpad6", e[e.Numpad7 = 105] = "Numpad7", e[e.Numpad8 = 106] = "Numpad8", e[e.Numpad9 = 107] = "Numpad9", e[e.NumpadMultiply = 108] = "NumpadMultiply", e[e.NumpadAdd = 109] = "NumpadAdd", e[e.NUMPAD_SEPARATOR = 110] = "NUMPAD_SEPARATOR", e[e.NumpadSubtract = 111] = "NumpadSubtract", e[e.NumpadDecimal = 112] = "NumpadDecimal", e[e.NumpadDivide = 113] = "NumpadDivide", e[e.KEY_IN_COMPOSITION = 114] = "KEY_IN_COMPOSITION", e[e.ABNT_C1 = 115] = "ABNT_C1", e[e.ABNT_C2 = 116] = "ABNT_C2", e[e.AudioVolumeMute = 117] = "AudioVolumeMute", e[e.AudioVolumeUp = 118] = "AudioVolumeUp", e[e.AudioVolumeDown = 119] = "AudioVolumeDown", e[e.BrowserSearch = 120] = "BrowserSearch", e[e.BrowserHome = 121] = "BrowserHome", e[e.BrowserBack = 122] = "BrowserBack", e[e.BrowserForward = 123] = "BrowserForward", e[e.MediaTrackNext = 124] = "MediaTrackNext", e[e.MediaTrackPrevious = 125] = "MediaTrackPrevious", e[e.MediaStop = 126] = "MediaStop", e[e.MediaPlayPause = 127] = "MediaPlayPause", e[e.LaunchMediaPlayer = 128] = "LaunchMediaPlayer", e[e.LaunchMail = 129] = "LaunchMail", e[e.LaunchApp2 = 130] = "LaunchApp2", e[e.Clear = 131] = "Clear", e[e.MAX_VALUE = 132] = "MAX_VALUE";
	}(On || (On = {})), function(e) {
		e[e.Hint = 1] = "Hint", e[e.Info = 2] = "Info", e[e.Warning = 4] = "Warning", e[e.Error = 8] = "Error";
	}(In || (In = {})), function(e) {
		e[e.Unnecessary = 1] = "Unnecessary", e[e.Deprecated = 2] = "Deprecated";
	}(Tn || (Tn = {})), function(e) {
		e[e.Inline = 1] = "Inline", e[e.Gutter = 2] = "Gutter";
	}(Pn || (Pn = {})), function(e) {
		e[e.Normal = 1] = "Normal", e[e.Underlined = 2] = "Underlined";
	}(Fn || (Fn = {})), function(e) {
		e[e.UNKNOWN = 0] = "UNKNOWN", e[e.TEXTAREA = 1] = "TEXTAREA", e[e.GUTTER_GLYPH_MARGIN = 2] = "GUTTER_GLYPH_MARGIN", e[e.GUTTER_LINE_NUMBERS = 3] = "GUTTER_LINE_NUMBERS", e[e.GUTTER_LINE_DECORATIONS = 4] = "GUTTER_LINE_DECORATIONS", e[e.GUTTER_VIEW_ZONE = 5] = "GUTTER_VIEW_ZONE", e[e.CONTENT_TEXT = 6] = "CONTENT_TEXT", e[e.CONTENT_EMPTY = 7] = "CONTENT_EMPTY", e[e.CONTENT_VIEW_ZONE = 8] = "CONTENT_VIEW_ZONE", e[e.CONTENT_WIDGET = 9] = "CONTENT_WIDGET", e[e.OVERVIEW_RULER = 10] = "OVERVIEW_RULER", e[e.SCROLLBAR = 11] = "SCROLLBAR", e[e.OVERLAY_WIDGET = 12] = "OVERLAY_WIDGET", e[e.OUTSIDE_EDITOR = 13] = "OUTSIDE_EDITOR";
	}(Dn || (Dn = {})), function(e) {
		e[e.AIGenerated = 1] = "AIGenerated";
	}(qn || (qn = {})), function(e) {
		e[e.Invoke = 0] = "Invoke", e[e.Automatic = 1] = "Automatic";
	}(Vn || (Vn = {})), function(e) {
		e[e.TOP_RIGHT_CORNER = 0] = "TOP_RIGHT_CORNER", e[e.BOTTOM_RIGHT_CORNER = 1] = "BOTTOM_RIGHT_CORNER", e[e.TOP_CENTER = 2] = "TOP_CENTER";
	}(Kn || (Kn = {})), function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 4] = "Right", e[e.Full = 7] = "Full";
	}(Bn || (Bn = {})), function(e) {
		e[e.Word = 0] = "Word", e[e.Line = 1] = "Line", e[e.Suggest = 2] = "Suggest";
	}(Un || (Un = {})), function(e) {
		e[e.Left = 0] = "Left", e[e.Right = 1] = "Right", e[e.None = 2] = "None", e[e.LeftOfInjectedText = 3] = "LeftOfInjectedText", e[e.RightOfInjectedText = 4] = "RightOfInjectedText";
	}($n || ($n = {})), function(e) {
		e[e.Off = 0] = "Off", e[e.On = 1] = "On", e[e.Relative = 2] = "Relative", e[e.Interval = 3] = "Interval", e[e.Custom = 4] = "Custom";
	}(Wn || (Wn = {})), function(e) {
		e[e.None = 0] = "None", e[e.Text = 1] = "Text", e[e.Blocks = 2] = "Blocks";
	}(zn || (zn = {})), function(e) {
		e[e.Smooth = 0] = "Smooth", e[e.Immediate = 1] = "Immediate";
	}(Hn || (Hn = {})), function(e) {
		e[e.Auto = 1] = "Auto", e[e.Hidden = 2] = "Hidden", e[e.Visible = 3] = "Visible";
	}(jn || (jn = {})), function(e) {
		e[e.LTR = 0] = "LTR", e[e.RTL = 1] = "RTL";
	}(Gn || (Gn = {})), function(e) {
		e.Off = "off", e.OnCode = "onCode", e.On = "on";
	}(Xn || (Xn = {})), function(e) {
		e[e.Invoke = 1] = "Invoke", e[e.TriggerCharacter = 2] = "TriggerCharacter", e[e.ContentChange = 3] = "ContentChange";
	}(Qn || (Qn = {})), function(e) {
		e[e.File = 0] = "File", e[e.Module = 1] = "Module", e[e.Namespace = 2] = "Namespace", e[e.Package = 3] = "Package", e[e.Class = 4] = "Class", e[e.Method = 5] = "Method", e[e.Property = 6] = "Property", e[e.Field = 7] = "Field", e[e.Constructor = 8] = "Constructor", e[e.Enum = 9] = "Enum", e[e.Interface = 10] = "Interface", e[e.Function = 11] = "Function", e[e.Variable = 12] = "Variable", e[e.Constant = 13] = "Constant", e[e.String = 14] = "String", e[e.Number = 15] = "Number", e[e.Boolean = 16] = "Boolean", e[e.Array = 17] = "Array", e[e.Object = 18] = "Object", e[e.Key = 19] = "Key", e[e.Null = 20] = "Null", e[e.EnumMember = 21] = "EnumMember", e[e.Struct = 22] = "Struct", e[e.Event = 23] = "Event", e[e.Operator = 24] = "Operator", e[e.TypeParameter = 25] = "TypeParameter";
	}(Yn || (Yn = {})), function(e) {
		e[e.Deprecated = 1] = "Deprecated";
	}(Jn || (Jn = {})), function(e) {
		e[e.LTR = 0] = "LTR", e[e.RTL = 1] = "RTL";
	}(Zn || (Zn = {})), function(e) {
		e[e.Hidden = 0] = "Hidden", e[e.Blink = 1] = "Blink", e[e.Smooth = 2] = "Smooth", e[e.Phase = 3] = "Phase", e[e.Expand = 4] = "Expand", e[e.Solid = 5] = "Solid";
	}(er || (er = {})), function(e) {
		e[e.Line = 1] = "Line", e[e.Block = 2] = "Block", e[e.Underline = 3] = "Underline", e[e.LineThin = 4] = "LineThin", e[e.BlockOutline = 5] = "BlockOutline", e[e.UnderlineThin = 6] = "UnderlineThin";
	}(tr || (tr = {})), function(e) {
		e[e.AlwaysGrowsWhenTypingAtEdges = 0] = "AlwaysGrowsWhenTypingAtEdges", e[e.NeverGrowsWhenTypingAtEdges = 1] = "NeverGrowsWhenTypingAtEdges", e[e.GrowsOnlyWhenTypingBefore = 2] = "GrowsOnlyWhenTypingBefore", e[e.GrowsOnlyWhenTypingAfter = 3] = "GrowsOnlyWhenTypingAfter";
	}(nr || (nr = {})), function(e) {
		e[e.None = 0] = "None", e[e.Same = 1] = "Same", e[e.Indent = 2] = "Indent", e[e.DeepIndent = 3] = "DeepIndent";
	}(rr || (rr = {}));
	var ir, or, ar = class {
		static {
			this.CtrlCmd = 2048;
		}
		static {
			this.Shift = 1024;
		}
		static {
			this.Alt = 512;
		}
		static {
			this.WinCtrl = 256;
		}
		static chord(e, t) {
			return function(e, t) {
				return (e | (65535 & t) << 16 >>> 0) >>> 0;
			}(e, t);
		}
	};
	var lr = class {
		constructor(e, t) {
			this.uri = e, this.value = t;
		}
	};
	(class e {
		static {
			this.defaultToKey = (e) => e.toString();
		}
		constructor(t, n) {
			if (this[ir] = "ResourceMap", t instanceof e) this.map = new Map(t.map), this.toKey = n ?? e.defaultToKey;
			else if (function(e) {
				return Array.isArray(e);
			}(t)) {
				this.map = /* @__PURE__ */ new Map(), this.toKey = n ?? e.defaultToKey;
				for (const [e, n] of t) this.set(e, n);
			} else this.map = /* @__PURE__ */ new Map(), this.toKey = t ?? e.defaultToKey;
		}
		set(e, t) {
			return this.map.set(this.toKey(e), new lr(e, t)), this;
		}
		get(e) {
			return this.map.get(this.toKey(e))?.value;
		}
		has(e) {
			return this.map.has(this.toKey(e));
		}
		get size() {
			return this.map.size;
		}
		clear() {
			this.map.clear();
		}
		delete(e) {
			return this.map.delete(this.toKey(e));
		}
		forEach(e, t) {
			void 0 !== t && (e = e.bind(t));
			for (const [n, r] of this.map) e(r.value, r.uri, this);
		}
		*values() {
			for (const e of this.map.values()) yield e.value;
		}
		*keys() {
			for (const e of this.map.values()) yield e.uri;
		}
		*entries() {
			for (const e of this.map.values()) yield [e.uri, e.value];
		}
		*[(ir = Symbol.toStringTag, Symbol.iterator)]() {
			for (const [, e] of this.map) yield [e.uri, e.value];
		}
	});
	var hr = class {
		constructor() {
			this[or] = "LinkedMap", this._map = /* @__PURE__ */ new Map(), this._head = void 0, this._tail = void 0, this._size = 0, this._state = 0;
		}
		clear() {
			this._map.clear(), this._head = void 0, this._tail = void 0, this._size = 0, this._state++;
		}
		isEmpty() {
			return !this._head && !this._tail;
		}
		get size() {
			return this._size;
		}
		get first() {
			return this._head?.value;
		}
		get last() {
			return this._tail?.value;
		}
		has(e) {
			return this._map.has(e);
		}
		get(e, t = 0) {
			const n = this._map.get(e);
			if (n) return 0 !== t && this.touch(n, t), n.value;
		}
		set(e, t, n = 0) {
			let r = this._map.get(e);
			if (r) r.value = t, 0 !== n && this.touch(r, n);
			else {
				switch (r = {
					key: e,
					value: t,
					next: void 0,
					previous: void 0
				}, n) {
					case 0:
					case 2:
					default:
						this.addItemLast(r);
						break;
					case 1: this.addItemFirst(r);
				}
				this._map.set(e, r), this._size++;
			}
			return this;
		}
		delete(e) {
			return !!this.remove(e);
		}
		remove(e) {
			const t = this._map.get(e);
			if (t) return this._map.delete(e), this.removeItem(t), this._size--, t.value;
		}
		shift() {
			if (!this._head && !this._tail) return;
			if (!this._head || !this._tail) throw new Error("Invalid list");
			const e = this._head;
			return this._map.delete(e.key), this.removeItem(e), this._size--, e.value;
		}
		forEach(e, t) {
			const n = this._state;
			let r = this._head;
			for (; r;) {
				if (t ? e.bind(t)(r.value, r.key, this) : e(r.value, r.key, this), this._state !== n) throw new Error("LinkedMap got modified during iteration.");
				r = r.next;
			}
		}
		keys() {
			const e = this, t = this._state;
			let n = this._head;
			const r = {
				[Symbol.iterator]: () => r,
				next() {
					if (e._state !== t) throw new Error("LinkedMap got modified during iteration.");
					if (n) {
						const e = {
							value: n.key,
							done: !1
						};
						return n = n.next, e;
					}
					return {
						value: void 0,
						done: !0
					};
				}
			};
			return r;
		}
		values() {
			const e = this, t = this._state;
			let n = this._head;
			const r = {
				[Symbol.iterator]: () => r,
				next() {
					if (e._state !== t) throw new Error("LinkedMap got modified during iteration.");
					if (n) {
						const e = {
							value: n.value,
							done: !1
						};
						return n = n.next, e;
					}
					return {
						value: void 0,
						done: !0
					};
				}
			};
			return r;
		}
		entries() {
			const e = this, t = this._state;
			let n = this._head;
			const r = {
				[Symbol.iterator]: () => r,
				next() {
					if (e._state !== t) throw new Error("LinkedMap got modified during iteration.");
					if (n) {
						const e = {
							value: [n.key, n.value],
							done: !1
						};
						return n = n.next, e;
					}
					return {
						value: void 0,
						done: !0
					};
				}
			};
			return r;
		}
		[(or = Symbol.toStringTag, Symbol.iterator)]() {
			return this.entries();
		}
		trimOld(e) {
			if (e >= this.size) return;
			if (0 === e) return void this.clear();
			let t = this._head, n = this.size;
			for (; t && n > e;) this._map.delete(t.key), t = t.next, n--;
			this._head = t, this._size = n, t && (t.previous = void 0), this._state++;
		}
		trimNew(e) {
			if (e >= this.size) return;
			if (0 === e) return void this.clear();
			let t = this._tail, n = this.size;
			for (; t && n > e;) this._map.delete(t.key), t = t.previous, n--;
			this._tail = t, this._size = n, t && (t.next = void 0), this._state++;
		}
		addItemFirst(e) {
			if (this._head || this._tail) {
				if (!this._head) throw new Error("Invalid list");
				e.next = this._head, this._head.previous = e;
			} else this._tail = e;
			this._head = e, this._state++;
		}
		addItemLast(e) {
			if (this._head || this._tail) {
				if (!this._tail) throw new Error("Invalid list");
				e.previous = this._tail, this._tail.next = e;
			} else this._head = e;
			this._tail = e, this._state++;
		}
		removeItem(e) {
			if (e === this._head && e === this._tail) this._head = void 0, this._tail = void 0;
			else if (e === this._head) {
				if (!e.next) throw new Error("Invalid list");
				e.next.previous = void 0, this._head = e.next;
			} else if (e === this._tail) {
				if (!e.previous) throw new Error("Invalid list");
				e.previous.next = void 0, this._tail = e.previous;
			} else {
				const t = e.next, n = e.previous;
				if (!t || !n) throw new Error("Invalid list");
				t.previous = n, n.next = t;
			}
			e.next = void 0, e.previous = void 0, this._state++;
		}
		touch(e, t) {
			if (!this._head || !this._tail) throw new Error("Invalid list");
			if (1 === t || 2 === t) {
				if (1 === t) {
					if (e === this._head) return;
					const t = e.next, n = e.previous;
					e === this._tail ? (n.next = void 0, this._tail = n) : (t.previous = n, n.next = t), e.previous = void 0, e.next = this._head, this._head.previous = e, this._head = e, this._state++;
				} else if (2 === t) {
					if (e === this._tail) return;
					const t = e.next, n = e.previous;
					e === this._head ? (t.previous = void 0, this._head = t) : (t.previous = n, n.next = t), e.next = void 0, e.previous = this._tail, this._tail.next = e, this._tail = e, this._state++;
				}
			}
		}
		toJSON() {
			const e = [];
			return this.forEach((t, n) => {
				e.push([n, t]);
			}), e;
		}
		fromJSON(e) {
			this.clear();
			for (const [t, n] of e) this.set(t, n);
		}
	}, cr = class extends hr {
		constructor(e, t = 1) {
			super(), this._limit = e, this._ratio = Math.min(Math.max(0, t), 1);
		}
		get limit() {
			return this._limit;
		}
		set limit(e) {
			this._limit = e, this.checkTrim();
		}
		get(e, t = 2) {
			return super.get(e, t);
		}
		peek(e) {
			return super.get(e, 0);
		}
		set(e, t) {
			return super.set(e, t, 2), this;
		}
		checkTrim() {
			this.size > this._limit && this.trim(Math.round(this._limit * this._ratio));
		}
	}, dr = class {
		constructor() {
			this.map = /* @__PURE__ */ new Map();
		}
		add(e, t) {
			let n = this.map.get(e);
			n || (n = /* @__PURE__ */ new Set(), this.map.set(e, n)), n.add(t);
		}
		delete(e, t) {
			const n = this.map.get(e);
			n && (n.delete(t), 0 === n.size && this.map.delete(e));
		}
		forEach(e, t) {
			const n = this.map.get(e);
			n && n.forEach(t);
		}
	};
	new class extends cr {
		constructor(e, t = 1) {
			super(e, t);
		}
		trim(e) {
			this.trimOld(e);
		}
		set(e, t) {
			return super.set(e, t), this.checkTrim(), this;
		}
	}(10);
	var gr, mr, fr, pr;
	function br(e, t, n, r, i) {
		return function(e, t, n, r, i) {
			if (0 === r) return !0;
			const s = t.charCodeAt(r - 1);
			if (0 !== e.get(s)) return !0;
			if (13 === s || 10 === s) return !0;
			if (i > 0) {
				const n = t.charCodeAt(r);
				if (0 !== e.get(n)) return !0;
			}
			return !1;
		}(e, t, 0, r, i) && function(e, t, n, r, i) {
			if (r + i === n) return !0;
			const s = t.charCodeAt(r + i);
			if (0 !== e.get(s)) return !0;
			if (13 === s || 10 === s) return !0;
			if (i > 0) {
				const n = t.charCodeAt(r + i - 1);
				if (0 !== e.get(n)) return !0;
			}
			return !1;
		}(e, t, n, r, i);
	}
	(function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 4] = "Right", e[e.Full = 7] = "Full";
	})(gr || (gr = {})), function(e) {
		e[e.Left = 1] = "Left", e[e.Center = 2] = "Center", e[e.Right = 3] = "Right";
	}(mr || (mr = {})), function(e) {
		e[e.LTR = 0] = "LTR", e[e.RTL = 1] = "RTL";
	}(fr || (fr = {})), function(e) {
		e[e.Both = 0] = "Both", e[e.Right = 1] = "Right", e[e.Left = 2] = "Left", e[e.None = 3] = "None";
	}(pr || (pr = {}));
	var wr = class {
		constructor(e, t) {
			this._wordSeparators = e, this._searchRegex = t, this._prevMatchStartIndex = -1, this._prevMatchLength = 0;
		}
		reset(e) {
			this._searchRegex.lastIndex = e, this._prevMatchStartIndex = -1, this._prevMatchLength = 0;
		}
		next(e) {
			const t = e.length;
			let n;
			do {
				if (this._prevMatchStartIndex + this._prevMatchLength === t) return null;
				if (n = this._searchRegex.exec(e), !n) return null;
				const r = n.index, i = n[0].length;
				if (r === this._prevMatchStartIndex && i === this._prevMatchLength) {
					if (0 === i) {
						oe(e, t, this._searchRegex.lastIndex) > 65535 ? this._searchRegex.lastIndex += 2 : this._searchRegex.lastIndex += 1;
						continue;
					}
					return null;
				}
				if (this._prevMatchStartIndex = r, this._prevMatchLength = i, !this._wordSeparators || br(this._wordSeparators, e, t, r, i)) return n;
			} while (n);
			return null;
		}
	};
	const _r = function(e = "") {
		let t = "(-?\\d*\\.\\d\\w*)|([^";
		for (const n of "`~!@#$%^&*()-=+[{]}\\|;:'\",.<>/?") e.indexOf(n) >= 0 || (t += "\\" + n);
		return t += "\\s]+)", new RegExp(t, "g");
	}();
	function Cr(e) {
		let t = _r;
		if (e && e instanceof RegExp) if (e.global) t = e;
		else {
			let n = "g";
			e.ignoreCase && (n += "i"), e.multiline && (n += "m"), e.unicode && (n += "u"), t = new RegExp(e.source, n);
		}
		return t.lastIndex = 0, t;
	}
	const yr = new b();
	function vr(e, t, n, i, s) {
		if (t = Cr(t), s || (s = r.first(yr)), n.length > s.maxLen) {
			let r = e - s.maxLen / 2;
			return r < 0 ? r = 0 : i += r, vr(e, t, n = n.substring(r, e + s.maxLen / 2), i, s);
		}
		const o = Date.now(), a = e - 1 - i;
		let l = -1, u = null;
		for (let r = 1; !(Date.now() - o >= s.timeBudget); r++) {
			const e = a - s.windowSize * r;
			t.lastIndex = Math.max(0, e);
			const i = Lr(t, n, a, l);
			if (!i && u) break;
			if (u = i, e <= 0) break;
			l = e;
		}
		if (u) {
			const e = {
				word: u[0],
				startColumn: i + 1 + u.index,
				endColumn: i + 1 + u.index + u[0].length
			};
			return t.lastIndex = 0, e;
		}
		return null;
	}
	function Lr(e, t, n, r) {
		let i;
		for (; i = e.exec(t);) {
			const t = i.index || 0;
			if (t <= n && e.lastIndex >= n) return i;
			if (r > 0 && t > r) return null;
		}
		return null;
	}
	yr.unshift({
		maxLen: 1e3,
		windowSize: 15,
		timeBudget: 150
	});
	var Nr = class {
		static computeUnicodeHighlights(e, t, n) {
			const r = n ? n.startLineNumber : 1, i = n ? n.endLineNumber : e.getLineCount(), s = new Er(t), o = s.getCandidateCodePoints();
			let l;
			var u, h;
			l = "allNonBasicAscii" === o ? /* @__PURE__ */ new RegExp("[^\\t\\n\\r\\x20-\\x7E]", "g") : new RegExp((u = Array.from(o), `[${h = u.map((e) => String.fromCodePoint(e)).join(""), h.replace(/[\\\{\}\*\+\?\|\^\$\.\[\]\(\)]/g, "\\$&")}]`), "g");
			const c = new wr(null, l), d = [];
			let g, m = !1, f = 0, p = 0, b = 0;
			e: for (let w = r, _ = i; w <= _; w++) {
				const t = e.getLineContent(w), n = t.length;
				c.reset(0);
				do
					if (g = c.next(t), g) {
						let e = g.index, r = g.index + g[0].length;
						e > 0 && re(t.charCodeAt(e - 1)) && e--, r + 1 < n && re(t.charCodeAt(r - 1)) && r++;
						const i = t.substring(e, r);
						let o = vr(e + 1, _r, t, 0);
						o && o.endColumn <= e + 1 && (o = null);
						const l = s.shouldHighlightNonBasicASCII(i, o ? o.word : null);
						if (0 !== l) {
							if (3 === l ? f++ : 2 === l ? p++ : 1 === l ? b++ : a(), d.length >= 1e3) {
								m = !0;
								break e;
							}
							d.push(new qe(w, e + 1, w, r + 1));
						}
					}
				while (g);
			}
			return {
				ranges: d,
				hasMore: m,
				ambiguousCharacterCount: f,
				invisibleCharacterCount: p,
				nonBasicAsciiCharacterCount: b
			};
		}
		static computeUnicodeHighlightReason(e, t) {
			const n = new Er(t);
			switch (n.shouldHighlightNonBasicASCII(e, null)) {
				case 0: return null;
				case 2: return { kind: 1 };
				case 3: {
					const r = e.codePointAt(0), i = n.ambiguousCharacters.getPrimaryConfusable(r), s = ue.getLocales().filter((e) => !ue.getInstance(new Set([...t.allowedLocales, e])).isAmbiguous(r));
					return {
						kind: 0,
						confusableWith: String.fromCodePoint(i),
						notAmbiguousInLocales: s
					};
				}
				case 1: return { kind: 2 };
			}
		}
	};
	var Er = class {
		constructor(e) {
			this.options = e, this.allowedCodePoints = new Set(e.allowedCodePoints), this.ambiguousCharacters = ue.getInstance(new Set(e.allowedLocales));
		}
		getCandidateCodePoints() {
			if (this.options.nonBasicASCII) return "allNonBasicAscii";
			const e = /* @__PURE__ */ new Set();
			if (this.options.invisibleCharacters) for (const t of he.codePoints) Sr(String.fromCodePoint(t)) || e.add(t);
			if (this.options.ambiguousCharacters) for (const t of this.ambiguousCharacters.getConfusableCodePoints()) e.add(t);
			for (const t of this.allowedCodePoints) e.delete(t);
			return e;
		}
		shouldHighlightNonBasicASCII(e, t) {
			const n = e.codePointAt(0);
			if (this.allowedCodePoints.has(n)) return 0;
			if (this.options.nonBasicASCII) return 1;
			let r = !1, i = !1;
			if (t) for (const s of t) {
				const e = s.codePointAt(0), t = le(s);
				r = r || t, t || this.ambiguousCharacters.isAmbiguous(e) || he.isInvisibleCharacter(e) || (i = !0);
			}
			return !r && i ? 0 : this.options.invisibleCharacters && !Sr(e) && he.isInvisibleCharacter(n) ? 2 : this.options.ambiguousCharacters && this.ambiguousCharacters.isAmbiguous(n) ? 3 : 0;
		}
	};
	function Sr(e) {
		return " " === e || "\n" === e || "	" === e;
	}
	var Rr, xr = class {
		constructor(e, t, n) {
			this.changes = e, this.moves = t, this.hitTimeout = n;
		}
	}, Ar = class {
		constructor(e, t) {
			this.lineRangeMapping = e, this.changes = t;
		}
	};
	function kr(e, t) {
		return (n, r) => t(e(n), e(r));
	}
	(function(e) {
		e.isLessThan = function(e) {
			return e < 0;
		}, e.isLessThanOrEqual = function(e) {
			return e <= 0;
		}, e.isGreaterThan = function(e) {
			return e > 0;
		}, e.isNeitherLessOrGreaterThan = function(e) {
			return 0 === e;
		}, e.greaterThan = 1, e.lessThan = -1, e.neitherLessOrGreaterThan = 0;
	})(Rr || (Rr = {}));
	const Mr = (e, t) => e - t;
	(class e {
		static {
			this.empty = new e((e) => {});
		}
		constructor(e) {
			this.iterate = e;
		}
		toArray() {
			const e = [];
			return this.iterate((t) => (e.push(t), !0)), e;
		}
		filter(t) {
			return new e((e) => this.iterate((n) => !t(n) || e(n)));
		}
		map(t) {
			return new e((e) => this.iterate((n) => e(t(n))));
		}
		findLast(e) {
			let t;
			return this.iterate((n) => (e(n) && (t = n), !0)), t;
		}
		findLastMaxBy(e) {
			let t, n = !0;
			return this.iterate((r) => ((n || Rr.isGreaterThan(e(r, t))) && (n = !1, t = r), !0)), t;
		}
	});
	var Or = class e {
		static fromTo(t, n) {
			return new e(t, n);
		}
		static addRange(t, n) {
			let r = 0;
			for (; r < n.length && n[r].endExclusive < t.start;) r++;
			let i = r;
			for (; i < n.length && n[i].start <= t.endExclusive;) i++;
			if (r === i) n.splice(r, 0, t);
			else {
				const s = Math.min(t.start, n[r].start), o = Math.max(t.endExclusive, n[i - 1].endExclusive);
				n.splice(r, i - r, new e(s, o));
			}
		}
		static tryCreate(t, n) {
			if (!(t > n)) return new e(t, n);
		}
		static ofLength(t) {
			return new e(0, t);
		}
		static ofStartAndLength(t, n) {
			return new e(t, t + n);
		}
		static emptyAt(t) {
			return new e(t, t);
		}
		constructor(e, t) {
			if (this.start = e, this.endExclusive = t, e > t) throw new o(`Invalid range: ${this.toString()}`);
		}
		get isEmpty() {
			return this.start === this.endExclusive;
		}
		delta(t) {
			return new e(this.start + t, this.endExclusive + t);
		}
		deltaStart(t) {
			return new e(this.start + t, this.endExclusive);
		}
		deltaEnd(t) {
			return new e(this.start, this.endExclusive + t);
		}
		get length() {
			return this.endExclusive - this.start;
		}
		toString() {
			return `[${this.start}, ${this.endExclusive})`;
		}
		equals(e) {
			return this.start === e.start && this.endExclusive === e.endExclusive;
		}
		contains(e) {
			return this.start <= e && e < this.endExclusive;
		}
		join(t) {
			return new e(Math.min(this.start, t.start), Math.max(this.endExclusive, t.endExclusive));
		}
		intersect(t) {
			const n = Math.max(this.start, t.start), r = Math.min(this.endExclusive, t.endExclusive);
			if (n <= r) return new e(n, r);
		}
		intersectionLength(e) {
			const t = Math.max(this.start, e.start), n = Math.min(this.endExclusive, e.endExclusive);
			return Math.max(0, n - t);
		}
		intersects(e) {
			return Math.max(this.start, e.start) < Math.min(this.endExclusive, e.endExclusive);
		}
		intersectsOrTouches(e) {
			return Math.max(this.start, e.start) <= Math.min(this.endExclusive, e.endExclusive);
		}
		isBefore(e) {
			return this.endExclusive <= e.start;
		}
		isAfter(e) {
			return this.start >= e.endExclusive;
		}
		slice(e) {
			return e.slice(this.start, this.endExclusive);
		}
		substring(e) {
			return e.substring(this.start, this.endExclusive);
		}
		clip(e) {
			if (this.isEmpty) throw new o(`Invalid clipping range: ${this.toString()}`);
			return Math.max(this.start, Math.min(this.endExclusive - 1, e));
		}
		clipCyclic(e) {
			if (this.isEmpty) throw new o(`Invalid clipping range: ${this.toString()}`);
			return e < this.start ? this.endExclusive - (this.start - e) % this.length : e >= this.endExclusive ? this.start + (e - this.start) % this.length : e;
		}
		forEach(e) {
			for (let t = this.start; t < this.endExclusive; t++) e(t);
		}
		joinRightTouching(t) {
			if (this.endExclusive !== t.start) throw new o(`Invalid join: ${this.toString()} and ${t.toString()}`);
			return new e(this.start, t.endExclusive);
		}
	};
	function Ir(e, t) {
		const n = Tr(e, t);
		return -1 === n ? void 0 : e[n];
	}
	function Tr(e, t, n = 0, r = e.length) {
		let i = n, s = r;
		for (; i < s;) {
			const n = Math.floor((i + s) / 2);
			t(e[n]) ? i = n + 1 : s = n;
		}
		return i - 1;
	}
	function Pr(e, t, n = 0, r = e.length) {
		let i = n, s = r;
		for (; i < s;) {
			const n = Math.floor((i + s) / 2);
			t(e[n]) ? s = n : i = n + 1;
		}
		return i;
	}
	var Fr = class e {
		static {
			this.assertInvariants = !1;
		}
		constructor(e) {
			this._array = e, this._findLastMonotonousLastIdx = 0;
		}
		findLastMonotonous(t) {
			if (e.assertInvariants) {
				if (this._prevFindLastPredicate) {
					for (const e of this._array) if (this._prevFindLastPredicate(e) && !t(e)) throw new Error("MonotonousArray: current predicate must be weaker than (or equal to) the previous predicate.");
				}
				this._prevFindLastPredicate = t;
			}
			const n = Tr(this._array, t, this._findLastMonotonousLastIdx);
			return this._findLastMonotonousLastIdx = n + 1, -1 === n ? void 0 : this._array[n];
		}
	}, Dr = class e {
		static ofLength(t, n) {
			return new e(t, t + n);
		}
		static fromRange(t) {
			return new e(t.startLineNumber, t.endLineNumber);
		}
		static fromRangeInclusive(t) {
			return new e(t.startLineNumber, t.endLineNumber + 1);
		}
		static {
			this.compareByStart = kr((e) => e.startLineNumber, Mr);
		}
		static joinMany(e) {
			if (0 === e.length) return [];
			let t = new qr(e[0].slice());
			for (let n = 1; n < e.length; n++) t = t.getUnion(new qr(e[n].slice()));
			return t.ranges;
		}
		static join(t) {
			if (0 === t.length) throw new o("lineRanges cannot be empty");
			let n = t[0].startLineNumber, r = t[0].endLineNumberExclusive;
			for (let e = 1; e < t.length; e++) n = Math.min(n, t[e].startLineNumber), r = Math.max(r, t[e].endLineNumberExclusive);
			return new e(n, r);
		}
		static deserialize(t) {
			return new e(t[0], t[1]);
		}
		constructor(e, t) {
			if (e > t) throw new o(`startLineNumber ${e} cannot be after endLineNumberExclusive ${t}`);
			this.startLineNumber = e, this.endLineNumberExclusive = t;
		}
		contains(e) {
			return this.startLineNumber <= e && e < this.endLineNumberExclusive;
		}
		get isEmpty() {
			return this.startLineNumber === this.endLineNumberExclusive;
		}
		delta(t) {
			return new e(this.startLineNumber + t, this.endLineNumberExclusive + t);
		}
		deltaLength(t) {
			return new e(this.startLineNumber, this.endLineNumberExclusive + t);
		}
		get length() {
			return this.endLineNumberExclusive - this.startLineNumber;
		}
		join(t) {
			return new e(Math.min(this.startLineNumber, t.startLineNumber), Math.max(this.endLineNumberExclusive, t.endLineNumberExclusive));
		}
		toString() {
			return `[${this.startLineNumber},${this.endLineNumberExclusive})`;
		}
		intersect(t) {
			const n = Math.max(this.startLineNumber, t.startLineNumber), r = Math.min(this.endLineNumberExclusive, t.endLineNumberExclusive);
			if (n <= r) return new e(n, r);
		}
		intersectsStrict(e) {
			return this.startLineNumber < e.endLineNumberExclusive && e.startLineNumber < this.endLineNumberExclusive;
		}
		intersectsOrTouches(e) {
			return this.startLineNumber <= e.endLineNumberExclusive && e.startLineNumber <= this.endLineNumberExclusive;
		}
		equals(e) {
			return this.startLineNumber === e.startLineNumber && this.endLineNumberExclusive === e.endLineNumberExclusive;
		}
		toInclusiveRange() {
			return this.isEmpty ? null : new qe(this.startLineNumber, 1, this.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER);
		}
		toExclusiveRange() {
			return new qe(this.startLineNumber, 1, this.endLineNumberExclusive, 1);
		}
		mapToLineArray(e) {
			const t = [];
			for (let n = this.startLineNumber; n < this.endLineNumberExclusive; n++) t.push(e(n));
			return t;
		}
		forEach(e) {
			for (let t = this.startLineNumber; t < this.endLineNumberExclusive; t++) e(t);
		}
		serialize() {
			return [this.startLineNumber, this.endLineNumberExclusive];
		}
		toOffsetRange() {
			return new Or(this.startLineNumber - 1, this.endLineNumberExclusive - 1);
		}
		addMargin(t, n) {
			return new e(this.startLineNumber - t, this.endLineNumberExclusive + n);
		}
	}, qr = class e {
		constructor(e = []) {
			this._normalizedRanges = e;
		}
		get ranges() {
			return this._normalizedRanges;
		}
		addRange(e) {
			if (0 === e.length) return;
			const t = Pr(this._normalizedRanges, (t) => t.endLineNumberExclusive >= e.startLineNumber), n = Tr(this._normalizedRanges, (t) => t.startLineNumber <= e.endLineNumberExclusive) + 1;
			if (t === n) this._normalizedRanges.splice(t, 0, e);
			else if (t === n - 1) {
				const n = this._normalizedRanges[t];
				this._normalizedRanges[t] = n.join(e);
			} else {
				const r = this._normalizedRanges[t].join(this._normalizedRanges[n - 1]).join(e);
				this._normalizedRanges.splice(t, n - t, r);
			}
		}
		contains(e) {
			const t = Ir(this._normalizedRanges, (t) => t.startLineNumber <= e);
			return !!t && t.endLineNumberExclusive > e;
		}
		intersects(e) {
			const t = Ir(this._normalizedRanges, (t) => t.startLineNumber < e.endLineNumberExclusive);
			return !!t && t.endLineNumberExclusive > e.startLineNumber;
		}
		getUnion(t) {
			if (0 === this._normalizedRanges.length) return t;
			if (0 === t._normalizedRanges.length) return this;
			const n = [];
			let r = 0, i = 0, s = null;
			for (; r < this._normalizedRanges.length || i < t._normalizedRanges.length;) {
				let e = null;
				if (r < this._normalizedRanges.length && i < t._normalizedRanges.length) {
					const n = this._normalizedRanges[r], s = t._normalizedRanges[i];
					n.startLineNumber < s.startLineNumber ? (e = n, r++) : (e = s, i++);
				} else r < this._normalizedRanges.length ? (e = this._normalizedRanges[r], r++) : (e = t._normalizedRanges[i], i++);
				null === s ? s = e : s.endLineNumberExclusive >= e.startLineNumber ? s = new Dr(s.startLineNumber, Math.max(s.endLineNumberExclusive, e.endLineNumberExclusive)) : (n.push(s), s = e);
			}
			return null !== s && n.push(s), new e(n);
		}
		subtractFrom(t) {
			const n = Pr(this._normalizedRanges, (e) => e.endLineNumberExclusive >= t.startLineNumber), r = Tr(this._normalizedRanges, (e) => e.startLineNumber <= t.endLineNumberExclusive) + 1;
			if (n === r) return new e([t]);
			const i = [];
			let s = t.startLineNumber;
			for (let e = n; e < r; e++) {
				const t = this._normalizedRanges[e];
				t.startLineNumber > s && i.push(new Dr(s, t.startLineNumber)), s = t.endLineNumberExclusive;
			}
			return s < t.endLineNumberExclusive && i.push(new Dr(s, t.endLineNumberExclusive)), new e(i);
		}
		toString() {
			return this._normalizedRanges.map((e) => e.toString()).join(", ");
		}
		getIntersection(t) {
			const n = [];
			let r = 0, i = 0;
			for (; r < this._normalizedRanges.length && i < t._normalizedRanges.length;) {
				const e = this._normalizedRanges[r], s = t._normalizedRanges[i], o = e.intersect(s);
				o && !o.isEmpty && n.push(o), e.endLineNumberExclusive < s.endLineNumberExclusive ? r++ : i++;
			}
			return new e(n);
		}
		getWithDelta(t) {
			return new e(this._normalizedRanges.map((e) => e.delta(t)));
		}
	}, Vr = class e {
		static {
			this.zero = new e(0, 0);
		}
		static betweenPositions(t, n) {
			return t.lineNumber === n.lineNumber ? new e(0, n.column - t.column) : new e(n.lineNumber - t.lineNumber, n.column - 1);
		}
		static fromPosition(t) {
			return new e(t.lineNumber - 1, t.column - 1);
		}
		static ofRange(t) {
			return e.betweenPositions(t.getStartPosition(), t.getEndPosition());
		}
		static ofText(t) {
			let n = 0, r = 0;
			for (const e of t) "\n" === e ? (n++, r = 0) : r++;
			return new e(n, r);
		}
		constructor(e, t) {
			this.lineCount = e, this.columnCount = t;
		}
		isGreaterThanOrEqualTo(e) {
			return this.lineCount !== e.lineCount ? this.lineCount > e.lineCount : this.columnCount >= e.columnCount;
		}
		add(t) {
			return 0 === t.lineCount ? new e(this.lineCount, this.columnCount + t.columnCount) : new e(this.lineCount + t.lineCount, t.columnCount);
		}
		createRange(e) {
			return 0 === this.lineCount ? new qe(e.lineNumber, e.column, e.lineNumber, e.column + this.columnCount) : new qe(e.lineNumber, e.column, e.lineNumber + this.lineCount, this.columnCount + 1);
		}
		toRange() {
			return new qe(1, 1, this.lineCount + 1, this.columnCount + 1);
		}
		toLineRange() {
			return Dr.ofLength(1, this.lineCount + 1);
		}
		addToPosition(e) {
			return 0 === this.lineCount ? new De(e.lineNumber, e.column + this.columnCount) : new De(e.lineNumber + this.lineCount, this.columnCount + 1);
		}
		toString() {
			return `${this.lineCount},${this.columnCount}`;
		}
	}, Kr = class {
		getOffsetRange(e) {
			return new Or(this.getOffset(e.getStartPosition()), this.getOffset(e.getEndPosition()));
		}
		getRange(e) {
			return qe.fromPositions(this.getPosition(e.start), this.getPosition(e.endExclusive));
		}
		getStringReplacement(e) {
			return new Br.deps.StringReplacement(this.getOffsetRange(e.range), e.text);
		}
		getTextReplacement(e) {
			return new Br.deps.TextReplacement(this.getRange(e.replaceRange), e.newText);
		}
		getTextEdit(e) {
			const t = e.replacements.map((e) => this.getTextReplacement(e));
			return new Br.deps.TextEdit(t);
		}
	}, Br = class {
		static {
			this._deps = void 0;
		}
		static get deps() {
			if (!this._deps) throw new Error("Dependencies not set. Call _setDependencies first.");
			return this._deps;
		}
	}, Ur = class extends Kr {
		constructor(e) {
			super(), this.text = e, this.lineStartOffsetByLineIdx = [], this.lineEndOffsetByLineIdx = [], this.lineStartOffsetByLineIdx.push(0);
			for (let t = 0; t < e.length; t++) "\n" === e.charAt(t) && (this.lineStartOffsetByLineIdx.push(t + 1), t > 0 && "\r" === e.charAt(t - 1) ? this.lineEndOffsetByLineIdx.push(t - 1) : this.lineEndOffsetByLineIdx.push(t));
			this.lineEndOffsetByLineIdx.push(e.length);
		}
		getOffset(e) {
			const t = this._validatePosition(e);
			return this.lineStartOffsetByLineIdx[t.lineNumber - 1] + t.column - 1;
		}
		_validatePosition(e) {
			if (e.lineNumber < 1) return new De(1, 1);
			const t = this.textLength.lineCount + 1;
			if (e.lineNumber > t) return new De(t, this.getLineLength(t) + 1);
			if (e.column < 1) return new De(e.lineNumber, 1);
			const n = this.getLineLength(e.lineNumber);
			return e.column - 1 > n ? new De(e.lineNumber, n + 1) : e;
		}
		getPosition(e) {
			const t = Tr(this.lineStartOffsetByLineIdx, (t) => t <= e);
			return new De(t + 1, e - this.lineStartOffsetByLineIdx[t] + 1);
		}
		get textLength() {
			const e = this.lineStartOffsetByLineIdx.length - 1;
			return new Br.deps.TextLength(e, this.text.length - this.lineStartOffsetByLineIdx[e]);
		}
		getLineLength(e) {
			return this.lineEndOffsetByLineIdx[e - 1] - this.lineStartOffsetByLineIdx[e - 1];
		}
	}, $r = class {
		constructor() {
			this._transformer = void 0;
		}
		get endPositionExclusive() {
			return this.length.addToPosition(new De(1, 1));
		}
		get lineRange() {
			return this.length.toLineRange();
		}
		getValue() {
			return this.getValueOfRange(this.length.toRange());
		}
		getValueOfOffsetRange(e) {
			return this.getValueOfRange(this.getTransformer().getRange(e));
		}
		getLineLength(e) {
			return this.getValueOfRange(new qe(e, 1, e, Number.MAX_SAFE_INTEGER)).length;
		}
		getTransformer() {
			return this._transformer || (this._transformer = new Ur(this.getValue())), this._transformer;
		}
		getLineAt(e) {
			return this.getValueOfRange(new qe(e, 1, e, Number.MAX_SAFE_INTEGER));
		}
	}, Wr = class extends $r {
		constructor(e, t) {
			(function(e, t = "unexpected state") {
				if (!e) throw "string" == typeof t ? new o(`Assertion Failed: ${t}`) : t;
			})(t >= 1), super(), this._getLineContent = e, this._lineCount = t;
		}
		getValueOfRange(e) {
			if (e.startLineNumber === e.endLineNumber) return this._getLineContent(e.startLineNumber).substring(e.startColumn - 1, e.endColumn - 1);
			let t = this._getLineContent(e.startLineNumber).substring(e.startColumn - 1);
			for (let n = e.startLineNumber + 1; n < e.endLineNumber; n++) t += "\n" + this._getLineContent(n);
			return t += "\n" + this._getLineContent(e.endLineNumber).substring(0, e.endColumn - 1), t;
		}
		getLineLength(e) {
			return this._getLineContent(e).length;
		}
		get length() {
			const e = this._getLineContent(this._lineCount);
			return new Vr(this._lineCount - 1, e.length);
		}
	}, zr = class extends Wr {
		constructor(e) {
			super((t) => e[t - 1], e.length);
		}
	}, Hr = class e {
		static joinReplacements(t, n) {
			if (0 === t.length) throw new o();
			if (1 === t.length) return t[0];
			const r = t[0].range.getStartPosition(), i = t[t.length - 1].range.getEndPosition();
			let s = "";
			for (let e = 0; e < t.length; e++) {
				const r = t[e];
				if (s += r.text, e < t.length - 1) {
					const i = t[e + 1], o = qe.fromPositions(r.range.getEndPosition(), i.range.getStartPosition());
					s += n.getValueOfRange(o);
				}
			}
			return new e(qe.fromPositions(r, i), s);
		}
		static fromStringReplacement(t, n) {
			return new e(n.getTransformer().getRange(t.replaceRange), t.newText);
		}
		static delete(t) {
			return new e(t, "");
		}
		constructor(e, t) {
			this.range = e, this.text = t;
		}
		get isEmpty() {
			return this.range.isEmpty() && 0 === this.text.length;
		}
		static equals(e, t) {
			return e.range.equalsRange(t.range) && e.text === t.text;
		}
		equals(t) {
			return e.equals(this, t);
		}
		removeCommonPrefixAndSuffix(e) {
			return this.removeCommonPrefix(e).removeCommonSuffix(e);
		}
		removeCommonPrefix(t) {
			const n = t.getValueOfRange(this.range).replaceAll("\r\n", "\n"), r = this.text.replaceAll("\r\n", "\n"), i = function(e, t) {
				const n = Math.min(e.length, t.length);
				let r;
				for (r = 0; r < n; r++) if (e.charCodeAt(r) !== t.charCodeAt(r)) return r;
				return n;
			}(n, r), s = Vr.ofText(n.substring(0, i)).addToPosition(this.range.getStartPosition()), o = r.substring(i);
			return new e(qe.fromPositions(s, this.range.getEndPosition()), o);
		}
		removeCommonSuffix(t) {
			const n = t.getValueOfRange(this.range).replaceAll("\r\n", "\n"), r = this.text.replaceAll("\r\n", "\n"), i = function(e, t) {
				const n = Math.min(e.length, t.length);
				let r;
				const i = e.length - 1, s = t.length - 1;
				for (r = 0; r < n; r++) if (e.charCodeAt(i - r) !== t.charCodeAt(s - r)) return r;
				return n;
			}(n, r), s = Vr.ofText(n.substring(0, n.length - i)).addToPosition(this.range.getStartPosition()), o = r.substring(0, r.length - i);
			return new e(qe.fromPositions(this.range.getStartPosition(), s), o);
		}
		toString() {
			const e = this.range.getStartPosition(), t = this.range.getEndPosition();
			return `(${e.lineNumber},${e.column} -> ${t.lineNumber},${t.column}): "${this.text}"`;
		}
	}, jr = class e {
		static inverse(t, n, r) {
			const i = [];
			let s = 1, o = 1;
			for (const l of t) {
				const t = new e(new Dr(s, l.original.startLineNumber), new Dr(o, l.modified.startLineNumber));
				t.modified.isEmpty || i.push(t), s = l.original.endLineNumberExclusive, o = l.modified.endLineNumberExclusive;
			}
			const a = new e(new Dr(s, n + 1), new Dr(o, r + 1));
			return a.modified.isEmpty || i.push(a), i;
		}
		static clip(t, n, r) {
			const i = [];
			for (const s of t) {
				const t = s.original.intersect(n), o = s.modified.intersect(r);
				t && !t.isEmpty && o && !o.isEmpty && i.push(new e(t, o));
			}
			return i;
		}
		constructor(e, t) {
			this.original = e, this.modified = t;
		}
		toString() {
			return `{${this.original.toString()}->${this.modified.toString()}}`;
		}
		flip() {
			return new e(this.modified, this.original);
		}
		join(t) {
			return new e(this.original.join(t.original), this.modified.join(t.modified));
		}
		toRangeMapping() {
			const e = this.original.toInclusiveRange(), t = this.modified.toInclusiveRange();
			if (e && t) return new Yr(e, t);
			if (1 === this.original.startLineNumber || 1 === this.modified.startLineNumber) {
				if (1 !== this.modified.startLineNumber || 1 !== this.original.startLineNumber) throw new o("not a valid diff");
				return new Yr(new qe(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new qe(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1));
			}
			return new Yr(new qe(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), new qe(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER, this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER));
		}
		toRangeMapping2(e, t) {
			if (Xr(this.original.endLineNumberExclusive, e) && Xr(this.modified.endLineNumberExclusive, t)) return new Yr(new qe(this.original.startLineNumber, 1, this.original.endLineNumberExclusive, 1), new qe(this.modified.startLineNumber, 1, this.modified.endLineNumberExclusive, 1));
			if (!this.original.isEmpty && !this.modified.isEmpty) return new Yr(qe.fromPositions(new De(this.original.startLineNumber, 1), Gr(new De(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), qe.fromPositions(new De(this.modified.startLineNumber, 1), Gr(new De(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), t)));
			if (this.original.startLineNumber > 1 && this.modified.startLineNumber > 1) return new Yr(qe.fromPositions(Gr(new De(this.original.startLineNumber - 1, Number.MAX_SAFE_INTEGER), e), Gr(new De(this.original.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), e)), qe.fromPositions(Gr(new De(this.modified.startLineNumber - 1, Number.MAX_SAFE_INTEGER), t), Gr(new De(this.modified.endLineNumberExclusive - 1, Number.MAX_SAFE_INTEGER), t)));
			throw new o();
		}
	};
	function Gr(e, t) {
		if (e.lineNumber < 1) return new De(1, 1);
		if (e.lineNumber > t.length) return new De(t.length, t[t.length - 1].length + 1);
		const n = t[e.lineNumber - 1];
		return e.column > n.length + 1 ? new De(e.lineNumber, n.length + 1) : e;
	}
	function Xr(e, t) {
		return e >= 1 && e <= t.length;
	}
	var Qr = class e extends jr {
		static fromRangeMappings(t) {
			return new e(Dr.join(t.map((e) => Dr.fromRangeInclusive(e.originalRange))), Dr.join(t.map((e) => Dr.fromRangeInclusive(e.modifiedRange))), t);
		}
		constructor(e, t, n) {
			super(e, t), this.innerChanges = n;
		}
		flip() {
			return new e(this.modified, this.original, this.innerChanges?.map((e) => e.flip()));
		}
		withInnerChangesFromLineRanges() {
			return new e(this.original, this.modified, [this.toRangeMapping()]);
		}
	}, Yr = class e {
		static fromEdit(t) {
			const n = t.getNewRanges();
			return t.replacements.map((t, r) => new e(t.range, n[r]));
		}
		static assertSorted(e) {
			for (let t = 1; t < e.length; t++) {
				const n = e[t - 1], r = e[t];
				if (!n.originalRange.getEndPosition().isBeforeOrEqual(r.originalRange.getStartPosition()) || !n.modifiedRange.getEndPosition().isBeforeOrEqual(r.modifiedRange.getStartPosition())) throw new o("Range mappings must be sorted");
			}
		}
		constructor(e, t) {
			this.originalRange = e, this.modifiedRange = t;
		}
		toString() {
			return `{${this.originalRange.toString()}->${this.modifiedRange.toString()}}`;
		}
		flip() {
			return new e(this.modifiedRange, this.originalRange);
		}
		toTextEdit(e) {
			const t = e.getValueOfRange(this.modifiedRange);
			return new Hr(this.originalRange, t);
		}
	};
	function Jr(e, t, n, r = !1) {
		const i = [];
		for (const s of function* (e, t) {
			let n, r;
			for (const i of e) void 0 !== r && t(r, i) ? n.push(i) : (n && (yield n), n = [i]), r = i;
			n && (yield n);
		}(e.map((e) => function(e, t, n) {
			let r = 0, i = 0;
			1 === e.modifiedRange.endColumn && 1 === e.originalRange.endColumn && e.originalRange.startLineNumber + r <= e.originalRange.endLineNumber && e.modifiedRange.startLineNumber + r <= e.modifiedRange.endLineNumber && (i = -1);
			e.modifiedRange.startColumn - 1 >= n.getLineLength(e.modifiedRange.startLineNumber) && e.originalRange.startColumn - 1 >= t.getLineLength(e.originalRange.startLineNumber) && e.originalRange.startLineNumber <= e.originalRange.endLineNumber + i && e.modifiedRange.startLineNumber <= e.modifiedRange.endLineNumber + i && (r = 1);
			return new Qr(new Dr(e.originalRange.startLineNumber + r, e.originalRange.endLineNumber + 1 + i), new Dr(e.modifiedRange.startLineNumber + r, e.modifiedRange.endLineNumber + 1 + i), [e]);
		}(e, t, n)), (e, t) => e.original.intersectsOrTouches(t.original) || e.modified.intersectsOrTouches(t.modified))) {
			const e = s[0], t = s[s.length - 1];
			i.push(new Qr(e.original.join(t.original), e.modified.join(t.modified), s.map((e) => e.innerChanges[0])));
		}
		return l(() => {
			if (!r && i.length > 0) {
				if (i[0].modified.startLineNumber !== i[0].original.startLineNumber) return !1;
				if (n.length.lineCount - i[i.length - 1].modified.endLineNumberExclusive !== t.length.lineCount - i[i.length - 1].original.endLineNumberExclusive) return !1;
			}
			return u(i, (e, t) => t.original.startLineNumber - e.original.endLineNumberExclusive === t.modified.startLineNumber - e.modified.endLineNumberExclusive && e.original.endLineNumberExclusive < t.original.startLineNumber && e.modified.endLineNumberExclusive < t.modified.startLineNumber);
		}), i;
	}
	var Zr = class {
		computeDiff(e, t, n) {
			const r = new si(e, t, {
				maxComputationTime: n.maxComputationTimeMs,
				shouldIgnoreTrimWhitespace: n.ignoreTrimWhitespace,
				shouldComputeCharChanges: !0,
				shouldMakePrettyDiff: !0,
				shouldPostProcessCharChanges: !0
			}).computeDiff(), i = [];
			let s = null;
			for (const o of r.changes) {
				let e, t;
				e = 0 === o.originalEndLineNumber ? new Dr(o.originalStartLineNumber + 1, o.originalStartLineNumber + 1) : new Dr(o.originalStartLineNumber, o.originalEndLineNumber + 1), t = 0 === o.modifiedEndLineNumber ? new Dr(o.modifiedStartLineNumber + 1, o.modifiedStartLineNumber + 1) : new Dr(o.modifiedStartLineNumber, o.modifiedEndLineNumber + 1);
				let n = new Qr(e, t, o.charChanges?.map((e) => new Yr(new qe(e.originalStartLineNumber, e.originalStartColumn, e.originalEndLineNumber, e.originalEndColumn), new qe(e.modifiedStartLineNumber, e.modifiedStartColumn, e.modifiedEndLineNumber, e.modifiedEndColumn))));
				s && (s.modified.endLineNumberExclusive !== n.modified.startLineNumber && s.original.endLineNumberExclusive !== n.original.startLineNumber || (n = new Qr(s.original.join(n.original), s.modified.join(n.modified), s.innerChanges && n.innerChanges ? s.innerChanges.concat(n.innerChanges) : void 0), i.pop())), i.push(n), s = n;
			}
			return l(() => u(i, (e, t) => t.original.startLineNumber - e.original.endLineNumberExclusive === t.modified.startLineNumber - e.modified.endLineNumberExclusive && e.original.endLineNumberExclusive < t.original.startLineNumber && e.modified.endLineNumberExclusive < t.modified.startLineNumber)), new xr(i, [], r.quitEarly);
		}
	};
	function ei(e, t, n, r) {
		return new Fe(e, t, n).ComputeDiff(r);
	}
	var ti = class {
		constructor(e) {
			const t = [], n = [];
			for (let r = 0, i = e.length; r < i; r++) t[r] = oi(e[r], 1), n[r] = ai(e[r], 1);
			this.lines = e, this._startColumns = t, this._endColumns = n;
		}
		getElements() {
			const e = [];
			for (let t = 0, n = this.lines.length; t < n; t++) e[t] = this.lines[t].substring(this._startColumns[t] - 1, this._endColumns[t] - 1);
			return e;
		}
		getStrictElement(e) {
			return this.lines[e];
		}
		getStartLineNumber(e) {
			return e + 1;
		}
		getEndLineNumber(e) {
			return e + 1;
		}
		createCharSequence(e, t, n) {
			const r = [], i = [], s = [];
			let o = 0;
			for (let a = t; a <= n; a++) {
				const t = this.lines[a], l = e ? this._startColumns[a] : 1, u = e ? this._endColumns[a] : t.length + 1;
				for (let e = l; e < u; e++) r[o] = t.charCodeAt(e - 1), i[o] = a + 1, s[o] = e, o++;
				!e && a < n && (r[o] = 10, i[o] = a + 1, s[o] = t.length + 1, o++);
			}
			return new ni(r, i, s);
		}
	}, ni = class {
		constructor(e, t, n) {
			this._charCodes = e, this._lineNumbers = t, this._columns = n;
		}
		toString() {
			return "[" + this._charCodes.map((e, t) => (10 === e ? "\\n" : String.fromCharCode(e)) + `-(${this._lineNumbers[t]},${this._columns[t]})`).join(", ") + "]";
		}
		_assertIndex(e, t) {
			if (e < 0 || e >= t.length) throw new Error("Illegal index");
		}
		getElements() {
			return this._charCodes;
		}
		getStartLineNumber(e) {
			return e > 0 && e === this._lineNumbers.length ? this.getEndLineNumber(e - 1) : (this._assertIndex(e, this._lineNumbers), this._lineNumbers[e]);
		}
		getEndLineNumber(e) {
			return -1 === e ? this.getStartLineNumber(e + 1) : (this._assertIndex(e, this._lineNumbers), 10 === this._charCodes[e] ? this._lineNumbers[e] + 1 : this._lineNumbers[e]);
		}
		getStartColumn(e) {
			return e > 0 && e === this._columns.length ? this.getEndColumn(e - 1) : (this._assertIndex(e, this._columns), this._columns[e]);
		}
		getEndColumn(e) {
			return -1 === e ? this.getStartColumn(e + 1) : (this._assertIndex(e, this._columns), 10 === this._charCodes[e] ? 1 : this._columns[e] + 1);
		}
	}, ri = class e {
		constructor(e, t, n, r, i, s, o, a) {
			this.originalStartLineNumber = e, this.originalStartColumn = t, this.originalEndLineNumber = n, this.originalEndColumn = r, this.modifiedStartLineNumber = i, this.modifiedStartColumn = s, this.modifiedEndLineNumber = o, this.modifiedEndColumn = a;
		}
		static createFromDiffChange(t, n, r) {
			return new e(n.getStartLineNumber(t.originalStart), n.getStartColumn(t.originalStart), n.getEndLineNumber(t.originalStart + t.originalLength - 1), n.getEndColumn(t.originalStart + t.originalLength - 1), r.getStartLineNumber(t.modifiedStart), r.getStartColumn(t.modifiedStart), r.getEndLineNumber(t.modifiedStart + t.modifiedLength - 1), r.getEndColumn(t.modifiedStart + t.modifiedLength - 1));
		}
	};
	var ii = class e {
		constructor(e, t, n, r, i) {
			this.originalStartLineNumber = e, this.originalEndLineNumber = t, this.modifiedStartLineNumber = n, this.modifiedEndLineNumber = r, this.charChanges = i;
		}
		static createFromDiffResult(t, n, r, i, s, o, a) {
			let l, u, h, c, d;
			if (0 === n.originalLength ? (l = r.getStartLineNumber(n.originalStart) - 1, u = 0) : (l = r.getStartLineNumber(n.originalStart), u = r.getEndLineNumber(n.originalStart + n.originalLength - 1)), 0 === n.modifiedLength ? (h = i.getStartLineNumber(n.modifiedStart) - 1, c = 0) : (h = i.getStartLineNumber(n.modifiedStart), c = i.getEndLineNumber(n.modifiedStart + n.modifiedLength - 1)), o && n.originalLength > 0 && n.originalLength < 20 && n.modifiedLength > 0 && n.modifiedLength < 20 && s()) {
				const e = r.createCharSequence(t, n.originalStart, n.originalStart + n.originalLength - 1), o = i.createCharSequence(t, n.modifiedStart, n.modifiedStart + n.modifiedLength - 1);
				if (e.getElements().length > 0 && o.getElements().length > 0) {
					let t = ei(e, o, s, !0).changes;
					a && (t = function(e) {
						if (e.length <= 1) return e;
						const t = [e[0]];
						let n = t[0];
						for (let r = 1, i = e.length; r < i; r++) {
							const i = e[r], s = i.originalStart - (n.originalStart + n.originalLength), o = i.modifiedStart - (n.modifiedStart + n.modifiedLength);
							Math.min(s, o) < 3 ? (n.originalLength = i.originalStart + i.originalLength - n.originalStart, n.modifiedLength = i.modifiedStart + i.modifiedLength - n.modifiedStart) : (t.push(i), n = i);
						}
						return t;
					}(t)), d = [];
					for (let n = 0, r = t.length; n < r; n++) d.push(ri.createFromDiffChange(t[n], e, o));
				}
			}
			return new e(l, u, h, c, d);
		}
	}, si = class {
		constructor(e, t, n) {
			this.shouldComputeCharChanges = n.shouldComputeCharChanges, this.shouldPostProcessCharChanges = n.shouldPostProcessCharChanges, this.shouldIgnoreTrimWhitespace = n.shouldIgnoreTrimWhitespace, this.shouldMakePrettyDiff = n.shouldMakePrettyDiff, this.originalLines = e, this.modifiedLines = t, this.original = new ti(e), this.modified = new ti(t), this.continueLineDiff = li(n.maxComputationTime), this.continueCharDiff = li(0 === n.maxComputationTime ? 0 : Math.min(n.maxComputationTime, 5e3));
		}
		computeDiff() {
			if (1 === this.original.lines.length && 0 === this.original.lines[0].length) return 1 === this.modified.lines.length && 0 === this.modified.lines[0].length ? {
				quitEarly: !1,
				changes: []
			} : {
				quitEarly: !1,
				changes: [{
					originalStartLineNumber: 1,
					originalEndLineNumber: 1,
					modifiedStartLineNumber: 1,
					modifiedEndLineNumber: this.modified.lines.length,
					charChanges: void 0
				}]
			};
			if (1 === this.modified.lines.length && 0 === this.modified.lines[0].length) return {
				quitEarly: !1,
				changes: [{
					originalStartLineNumber: 1,
					originalEndLineNumber: this.original.lines.length,
					modifiedStartLineNumber: 1,
					modifiedEndLineNumber: 1,
					charChanges: void 0
				}]
			};
			const e = ei(this.original, this.modified, this.continueLineDiff, this.shouldMakePrettyDiff), t = e.changes, n = e.quitEarly;
			if (this.shouldIgnoreTrimWhitespace) {
				const e = [];
				for (let n = 0, r = t.length; n < r; n++) e.push(ii.createFromDiffResult(this.shouldIgnoreTrimWhitespace, t[n], this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges));
				return {
					quitEarly: n,
					changes: e
				};
			}
			const r = [];
			let i = 0, s = 0;
			for (let o = -1, a = t.length; o < a; o++) {
				const e = o + 1 < a ? t[o + 1] : null, n = e ? e.originalStart : this.originalLines.length, l = e ? e.modifiedStart : this.modifiedLines.length;
				for (; i < n && s < l;) {
					const e = this.originalLines[i], t = this.modifiedLines[s];
					if (e !== t) {
						{
							let n = oi(e, 1), o = oi(t, 1);
							for (; n > 1 && o > 1 && e.charCodeAt(n - 2) === t.charCodeAt(o - 2);) n--, o--;
							(n > 1 || o > 1) && this._pushTrimWhitespaceCharChange(r, i + 1, 1, n, s + 1, 1, o);
						}
						{
							let n = ai(e, 1), o = ai(t, 1);
							const a = e.length + 1, l = t.length + 1;
							for (; n < a && o < l && e.charCodeAt(n - 1) === e.charCodeAt(o - 1);) n++, o++;
							(n < a || o < l) && this._pushTrimWhitespaceCharChange(r, i + 1, n, a, s + 1, o, l);
						}
					}
					i++, s++;
				}
				e && (r.push(ii.createFromDiffResult(this.shouldIgnoreTrimWhitespace, e, this.original, this.modified, this.continueCharDiff, this.shouldComputeCharChanges, this.shouldPostProcessCharChanges)), i += e.originalLength, s += e.modifiedLength);
			}
			return {
				quitEarly: n,
				changes: r
			};
		}
		_pushTrimWhitespaceCharChange(e, t, n, r, i, s, o) {
			if (this._mergeTrimWhitespaceCharChange(e, t, n, r, i, s, o)) return;
			let a;
			this.shouldComputeCharChanges && (a = [new ri(t, n, t, r, i, s, i, o)]), e.push(new ii(t, t, i, i, a));
		}
		_mergeTrimWhitespaceCharChange(e, t, n, r, i, s, o) {
			const a = e.length;
			if (0 === a) return !1;
			const l = e[a - 1];
			return 0 !== l.originalEndLineNumber && 0 !== l.modifiedEndLineNumber && (l.originalEndLineNumber === t && l.modifiedEndLineNumber === i ? (this.shouldComputeCharChanges && l.charChanges && l.charChanges.push(new ri(t, n, t, r, i, s, i, o)), !0) : l.originalEndLineNumber + 1 === t && l.modifiedEndLineNumber + 1 === i && (l.originalEndLineNumber = t, l.modifiedEndLineNumber = i, this.shouldComputeCharChanges && l.charChanges && l.charChanges.push(new ri(t, n, t, r, i, s, i, o)), !0));
		}
	};
	function oi(e, t) {
		const n = function(e) {
			for (let t = 0, n = e.length; t < n; t++) {
				const n = e.charCodeAt(t);
				if (32 !== n && 9 !== n) return t;
			}
			return -1;
		}(e);
		return -1 === n ? t : n + 1;
	}
	function ai(e, t) {
		const n = function(e, t = e.length - 1) {
			for (let n = t; n >= 0; n--) {
				const t = e.charCodeAt(n);
				if (32 !== t && 9 !== t) return n;
			}
			return -1;
		}(e);
		return -1 === n ? t : n + 2;
	}
	function li(e) {
		if (0 === e) return () => !0;
		const t = Date.now();
		return () => Date.now() - t < e;
	}
	var ui = class e {
		static trivial(t, n) {
			return new e([new hi(Or.ofLength(t.length), Or.ofLength(n.length))], !1);
		}
		static trivialTimedOut(t, n) {
			return new e([new hi(Or.ofLength(t.length), Or.ofLength(n.length))], !0);
		}
		constructor(e, t) {
			this.diffs = e, this.hitTimeout = t;
		}
	}, hi = class e {
		static invert(t, n) {
			const r = [];
			return function(e, t) {
				for (let n = 0; n <= e.length; n++) t(0 === n ? void 0 : e[n - 1], n === e.length ? void 0 : e[n]);
			}(t, (t, i) => {
				r.push(e.fromOffsetPairs(t ? t.getEndExclusives() : ci.zero, i ? i.getStarts() : new ci(n, (t ? t.seq2Range.endExclusive - t.seq1Range.endExclusive : 0) + n)));
			}), r;
		}
		static fromOffsetPairs(t, n) {
			return new e(new Or(t.offset1, n.offset1), new Or(t.offset2, n.offset2));
		}
		static assertSorted(e) {
			let t;
			for (const n of e) {
				if (t && !(t.seq1Range.endExclusive <= n.seq1Range.start && t.seq2Range.endExclusive <= n.seq2Range.start)) throw new o("Sequence diffs must be sorted");
				t = n;
			}
		}
		constructor(e, t) {
			this.seq1Range = e, this.seq2Range = t;
		}
		swap() {
			return new e(this.seq2Range, this.seq1Range);
		}
		toString() {
			return `${this.seq1Range} <-> ${this.seq2Range}`;
		}
		join(t) {
			return new e(this.seq1Range.join(t.seq1Range), this.seq2Range.join(t.seq2Range));
		}
		delta(t) {
			return 0 === t ? this : new e(this.seq1Range.delta(t), this.seq2Range.delta(t));
		}
		deltaStart(t) {
			return 0 === t ? this : new e(this.seq1Range.deltaStart(t), this.seq2Range.deltaStart(t));
		}
		deltaEnd(t) {
			return 0 === t ? this : new e(this.seq1Range.deltaEnd(t), this.seq2Range.deltaEnd(t));
		}
		intersect(t) {
			const n = this.seq1Range.intersect(t.seq1Range), r = this.seq2Range.intersect(t.seq2Range);
			if (n && r) return new e(n, r);
		}
		getStarts() {
			return new ci(this.seq1Range.start, this.seq2Range.start);
		}
		getEndExclusives() {
			return new ci(this.seq1Range.endExclusive, this.seq2Range.endExclusive);
		}
	}, ci = class e {
		static {
			this.zero = new e(0, 0);
		}
		static {
			this.max = new e(Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
		}
		constructor(e, t) {
			this.offset1 = e, this.offset2 = t;
		}
		toString() {
			return `${this.offset1} <-> ${this.offset2}`;
		}
		delta(t) {
			return 0 === t ? this : new e(this.offset1 + t, this.offset2 + t);
		}
		equals(e) {
			return this.offset1 === e.offset1 && this.offset2 === e.offset2;
		}
	}, di = class e {
		static {
			this.instance = new e();
		}
		isValid() {
			return !0;
		}
	}, gi = class {
		constructor(e) {
			if (this.timeout = e, this.startTime = Date.now(), this.valid = !0, e <= 0) throw new o("timeout must be positive");
		}
		isValid() {
			return Date.now() - this.startTime < this.timeout || !this.valid || (this.valid = !1), this.valid;
		}
	}, mi = class {
		constructor(e, t) {
			this.width = e, this.height = t, this.array = [], this.array = new Array(e * t);
		}
		get(e, t) {
			return this.array[e + t * this.width];
		}
		set(e, t, n) {
			this.array[e + t * this.width] = n;
		}
	};
	function fi(e) {
		return 32 === e || 9 === e;
	}
	var pi = class e {
		static {
			this.chrKeys = /* @__PURE__ */ new Map();
		}
		static getKey(e) {
			let t = this.chrKeys.get(e);
			return void 0 === t && (t = this.chrKeys.size, this.chrKeys.set(e, t)), t;
		}
		constructor(t, n, r) {
			this.range = t, this.lines = n, this.source = r, this.histogram = [];
			let i = 0;
			for (let s = t.startLineNumber - 1; s < t.endLineNumberExclusive - 1; s++) {
				const t = n[s];
				for (let n = 0; n < t.length; n++) {
					i++;
					const r = t[n], s = e.getKey(r);
					this.histogram[s] = (this.histogram[s] || 0) + 1;
				}
				i++;
				const r = e.getKey("\n");
				this.histogram[r] = (this.histogram[r] || 0) + 1;
			}
			this.totalCount = i;
		}
		computeSimilarity(e) {
			let t = 0;
			const n = Math.max(this.histogram.length, e.histogram.length);
			for (let r = 0; r < n; r++) t += Math.abs((this.histogram[r] ?? 0) - (e.histogram[r] ?? 0));
			return 1 - t / (this.totalCount + e.totalCount);
		}
	}, bi = class {
		compute(e, t, n = di.instance, r) {
			if (0 === e.length || 0 === t.length) return ui.trivial(e, t);
			const i = new mi(e.length, t.length), s = new mi(e.length, t.length), o = new mi(e.length, t.length);
			for (let g = 0; g < e.length; g++) for (let a = 0; a < t.length; a++) {
				if (!n.isValid()) return ui.trivialTimedOut(e, t);
				const l = 0 === g ? 0 : i.get(g - 1, a), u = 0 === a ? 0 : i.get(g, a - 1);
				let h;
				e.getElement(g) === t.getElement(a) ? (h = 0 === g || 0 === a ? 0 : i.get(g - 1, a - 1), g > 0 && a > 0 && 3 === s.get(g - 1, a - 1) && (h += o.get(g - 1, a - 1)), h += r ? r(g, a) : 1) : h = -1;
				const c = Math.max(l, u, h);
				if (c === h) {
					const e = g > 0 && a > 0 ? o.get(g - 1, a - 1) : 0;
					o.set(g, a, e + 1), s.set(g, a, 3);
				} else c === l ? (o.set(g, a, 0), s.set(g, a, 1)) : c === u && (o.set(g, a, 0), s.set(g, a, 2));
				i.set(g, a, c);
			}
			const a = [];
			let l = e.length, u = t.length;
			function h(e, t) {
				e + 1 === l && t + 1 === u || a.push(new hi(new Or(e + 1, l), new Or(t + 1, u))), l = e, u = t;
			}
			let c = e.length - 1, d = t.length - 1;
			for (; c >= 0 && d >= 0;) 3 === s.get(c, d) ? (h(c, d), c--, d--) : 1 === s.get(c, d) ? c-- : d--;
			return h(-1, -1), a.reverse(), new ui(a, !1);
		}
	}, wi = class {
		compute(e, t, n = di.instance) {
			if (0 === e.length || 0 === t.length) return ui.trivial(e, t);
			const r = e, i = t;
			function s(e, t) {
				for (; e < r.length && t < i.length && r.getElement(e) === i.getElement(t);) e++, t++;
				return e;
			}
			let o = 0;
			const a = new Ci();
			a.set(0, s(0, 0));
			const l = new yi();
			l.set(0, 0 === a.get(0) ? null : new _i(null, 0, 0, a.get(0)));
			let u = 0;
			e: for (;;) {
				if (o++, !n.isValid()) return ui.trivialTimedOut(r, i);
				const e = -Math.min(o, i.length + o % 2), t = Math.min(o, r.length + o % 2);
				for (u = e; u <= t; u += 2) {
					const n = u === t ? -1 : a.get(u + 1), o = u === e ? -1 : a.get(u - 1) + 1, h = Math.min(Math.max(n, o), r.length), c = h - u;
					if (h > r.length || c > i.length) continue;
					const d = s(h, c);
					a.set(u, d);
					const g = h === n ? l.get(u + 1) : l.get(u - 1);
					if (l.set(u, d !== h ? new _i(g, h, c, d - h) : g), a.get(u) === r.length && a.get(u) - u === i.length) break e;
				}
			}
			let h = l.get(u);
			const c = [];
			let d = r.length, g = i.length;
			for (;;) {
				const e = h ? h.x + h.length : 0, t = h ? h.y + h.length : 0;
				if (e === d && t === g || c.push(new hi(new Or(e, d), new Or(t, g))), !h) break;
				d = h.x, g = h.y, h = h.prev;
			}
			return c.reverse(), new ui(c, !1);
		}
	}, _i = class {
		constructor(e, t, n, r) {
			this.prev = e, this.x = t, this.y = n, this.length = r;
		}
	}, Ci = class {
		constructor() {
			this.positiveArr = new Int32Array(10), this.negativeArr = new Int32Array(10);
		}
		get(e) {
			return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e];
		}
		set(e, t) {
			if (e < 0) {
				if ((e = -e - 1) >= this.negativeArr.length) {
					const e = this.negativeArr;
					this.negativeArr = new Int32Array(2 * e.length), this.negativeArr.set(e);
				}
				this.negativeArr[e] = t;
			} else {
				if (e >= this.positiveArr.length) {
					const e = this.positiveArr;
					this.positiveArr = new Int32Array(2 * e.length), this.positiveArr.set(e);
				}
				this.positiveArr[e] = t;
			}
		}
	}, yi = class {
		constructor() {
			this.positiveArr = [], this.negativeArr = [];
		}
		get(e) {
			return e < 0 ? (e = -e - 1, this.negativeArr[e]) : this.positiveArr[e];
		}
		set(e, t) {
			e < 0 ? (e = -e - 1, this.negativeArr[e] = t) : this.positiveArr[e] = t;
		}
	}, vi = class {
		constructor(e, t, n) {
			this.lines = e, this.range = t, this.considerWhitespaceChanges = n, this.elements = [], this.firstElementOffsetByLineIdx = [], this.lineStartOffsets = [], this.trimmedWsLengthsByLineIdx = [], this.firstElementOffsetByLineIdx.push(0);
			for (let r = this.range.startLineNumber; r <= this.range.endLineNumber; r++) {
				let t = e[r - 1], i = 0;
				r === this.range.startLineNumber && this.range.startColumn > 1 && (i = this.range.startColumn - 1, t = t.substring(i)), this.lineStartOffsets.push(i);
				let s = 0;
				if (!n) {
					const e = t.trimStart();
					s = t.length - e.length, t = e.trimEnd();
				}
				this.trimmedWsLengthsByLineIdx.push(s);
				const o = r === this.range.endLineNumber ? Math.min(this.range.endColumn - 1 - i - s, t.length) : t.length;
				for (let e = 0; e < o; e++) this.elements.push(t.charCodeAt(e));
				r < this.range.endLineNumber && (this.elements.push("\n".charCodeAt(0)), this.firstElementOffsetByLineIdx.push(this.elements.length));
			}
		}
		toString() {
			return `Slice: "${this.text}"`;
		}
		get text() {
			return this.getText(new Or(0, this.length));
		}
		getText(e) {
			return this.elements.slice(e.start, e.endExclusive).map((e) => String.fromCharCode(e)).join("");
		}
		getElement(e) {
			return this.elements[e];
		}
		get length() {
			return this.elements.length;
		}
		getBoundaryScore(e) {
			const t = Ri(e > 0 ? this.elements[e - 1] : -1), n = Ri(e < this.elements.length ? this.elements[e] : -1);
			if (7 === t && 8 === n) return 0;
			if (8 === t) return 150;
			let r = 0;
			return t !== n && (r += 10, 0 === t && 1 === n && (r += 1)), r += Si(t), r += Si(n), r;
		}
		translateOffset(e, t = "right") {
			const n = Tr(this.firstElementOffsetByLineIdx, (t) => t <= e), r = e - this.firstElementOffsetByLineIdx[n];
			return new De(this.range.startLineNumber + n, 1 + this.lineStartOffsets[n] + r + (0 === r && "left" === t ? 0 : this.trimmedWsLengthsByLineIdx[n]));
		}
		translateRange(e) {
			const t = this.translateOffset(e.start, "right"), n = this.translateOffset(e.endExclusive, "left");
			return n.isBefore(t) ? qe.fromPositions(n, n) : qe.fromPositions(t, n);
		}
		findWordContaining(e) {
			if (e < 0 || e >= this.elements.length) return;
			if (!Li(this.elements[e])) return;
			let t = e;
			for (; t > 0 && Li(this.elements[t - 1]);) t--;
			let n = e;
			for (; n < this.elements.length && Li(this.elements[n]);) n++;
			return new Or(t, n);
		}
		findSubWordContaining(e) {
			if (e < 0 || e >= this.elements.length) return;
			if (!Li(this.elements[e])) return;
			let t = e;
			for (; t > 0 && Li(this.elements[t - 1]) && !Ni(this.elements[t]);) t--;
			let n = e;
			for (; n < this.elements.length && Li(this.elements[n]) && !Ni(this.elements[n]);) n++;
			return new Or(t, n);
		}
		countLinesIn(e) {
			return this.translateOffset(e.endExclusive).lineNumber - this.translateOffset(e.start).lineNumber;
		}
		isStronglyEqual(e, t) {
			return this.elements[e] === this.elements[t];
		}
		extendToFullLines(e) {
			return new Or(Ir(this.firstElementOffsetByLineIdx, (t) => t <= e.start) ?? 0, function(e, t) {
				const n = Pr(e, t);
				return n === e.length ? void 0 : e[n];
			}(this.firstElementOffsetByLineIdx, (t) => e.endExclusive <= t) ?? this.elements.length);
		}
	};
	function Li(e) {
		return e >= 97 && e <= 122 || e >= 65 && e <= 90 || e >= 48 && e <= 57;
	}
	function Ni(e) {
		return e >= 65 && e <= 90;
	}
	const Ei = {
		0: 0,
		1: 0,
		2: 0,
		3: 10,
		4: 2,
		5: 30,
		6: 3,
		7: 10,
		8: 10
	};
	function Si(e) {
		return Ei[e];
	}
	function Ri(e) {
		return 10 === e ? 8 : 13 === e ? 7 : fi(e) ? 6 : e >= 97 && e <= 122 ? 0 : e >= 65 && e <= 90 ? 1 : e >= 48 && e <= 57 ? 2 : -1 === e ? 3 : 44 === e || 59 === e ? 5 : 4;
	}
	function xi(e, t, n, r, i, s) {
		let { moves: o, excludedChanges: a } = function(e, t, n, r) {
			const i = [], s = e.filter((e) => e.modified.isEmpty && e.original.length >= 3).map((e) => new pi(e.original, t, e)), o = new Set(e.filter((e) => e.original.isEmpty && e.modified.length >= 3).map((e) => new pi(e.modified, n, e))), a = /* @__PURE__ */ new Set();
			for (const l of s) {
				let e, t = -1;
				for (const n of o) {
					const r = l.computeSimilarity(n);
					r > t && (t = r, e = n);
				}
				if (t > .9 && e && (o.delete(e), i.push(new jr(l.range, e.range)), a.add(l.source), a.add(e.source)), !r.isValid()) return {
					moves: i,
					excludedChanges: a
				};
			}
			return {
				moves: i,
				excludedChanges: a
			};
		}(e, t, n, s);
		if (!s.isValid()) return [];
		const l = function(e, t, n, r, i, s) {
			const o = [], a = new dr();
			for (const g of e) for (let e = g.original.startLineNumber; e < g.original.endLineNumberExclusive - 2; e++) {
				const n = `${t[e - 1]}:${t[e + 1 - 1]}:${t[e + 2 - 1]}`;
				a.add(n, { range: new Dr(e, e + 3) });
			}
			const l = [];
			e.sort(kr((e) => e.modified.startLineNumber, Mr));
			for (const g of e) {
				let e = [];
				for (let t = g.modified.startLineNumber; t < g.modified.endLineNumberExclusive - 2; t++) {
					const r = `${n[t - 1]}:${n[t + 1 - 1]}:${n[t + 2 - 1]}`, i = new Dr(t, t + 3), s = [];
					a.forEach(r, ({ range: t }) => {
						for (const r of e) if (r.originalLineRange.endLineNumberExclusive + 1 === t.endLineNumberExclusive && r.modifiedLineRange.endLineNumberExclusive + 1 === i.endLineNumberExclusive) return r.originalLineRange = new Dr(r.originalLineRange.startLineNumber, t.endLineNumberExclusive), r.modifiedLineRange = new Dr(r.modifiedLineRange.startLineNumber, i.endLineNumberExclusive), void s.push(r);
						const n = {
							modifiedLineRange: i,
							originalLineRange: t
						};
						l.push(n), s.push(n);
					}), e = s;
				}
				if (!s.isValid()) return [];
			}
			l.sort((u = kr((e) => e.modifiedLineRange.length, Mr), (e, t) => -u(e, t)));
			var u;
			const h = new qr(), c = new qr();
			for (const g of l) {
				const e = g.modifiedLineRange.startLineNumber - g.originalLineRange.startLineNumber, t = h.subtractFrom(g.modifiedLineRange), n = c.subtractFrom(g.originalLineRange).getWithDelta(e), r = t.getIntersection(n);
				for (const i of r.ranges) {
					if (i.length < 3) continue;
					const t = i, n = i.delta(-e);
					o.push(new jr(n, t)), h.addRange(t), c.addRange(n);
				}
			}
			o.sort(kr((e) => e.original.startLineNumber, Mr));
			const d = new Fr(e);
			for (let g = 0; g < o.length; g++) {
				const t = o[g], n = d.findLastMonotonous((e) => e.original.startLineNumber <= t.original.startLineNumber), a = Ir(e, (e) => e.modified.startLineNumber <= t.modified.startLineNumber), l = Math.max(t.original.startLineNumber - n.original.startLineNumber, t.modified.startLineNumber - a.modified.startLineNumber), u = d.findLastMonotonous((e) => e.original.startLineNumber < t.original.endLineNumberExclusive), m = Ir(e, (e) => e.modified.startLineNumber < t.modified.endLineNumberExclusive), f = Math.max(u.original.endLineNumberExclusive - t.original.endLineNumberExclusive, m.modified.endLineNumberExclusive - t.modified.endLineNumberExclusive);
				let p, b;
				for (p = 0; p < l; p++) {
					const e = t.original.startLineNumber - p - 1, n = t.modified.startLineNumber - p - 1;
					if (e > r.length || n > i.length) break;
					if (h.contains(n) || c.contains(e)) break;
					if (!Ai(r[e - 1], i[n - 1], s)) break;
				}
				for (p > 0 && (c.addRange(new Dr(t.original.startLineNumber - p, t.original.startLineNumber)), h.addRange(new Dr(t.modified.startLineNumber - p, t.modified.startLineNumber))), b = 0; b < f; b++) {
					const e = t.original.endLineNumberExclusive + b, n = t.modified.endLineNumberExclusive + b;
					if (e > r.length || n > i.length) break;
					if (h.contains(n) || c.contains(e)) break;
					if (!Ai(r[e - 1], i[n - 1], s)) break;
				}
				b > 0 && (c.addRange(new Dr(t.original.endLineNumberExclusive, t.original.endLineNumberExclusive + b)), h.addRange(new Dr(t.modified.endLineNumberExclusive, t.modified.endLineNumberExclusive + b))), (p > 0 || b > 0) && (o[g] = new jr(new Dr(t.original.startLineNumber - p, t.original.endLineNumberExclusive + b), new Dr(t.modified.startLineNumber - p, t.modified.endLineNumberExclusive + b)));
			}
			return o;
		}(e.filter((e) => !a.has(e)), r, i, t, n, s);
		return function(e, t) {
			for (const n of t) e.push(n);
		}(o, l), o = function(e) {
			if (0 === e.length) return e;
			e.sort(kr((e) => e.original.startLineNumber, Mr));
			const t = [e[0]];
			for (let n = 1; n < e.length; n++) {
				const r = t[t.length - 1], i = e[n], s = i.original.startLineNumber - r.original.endLineNumberExclusive, o = i.modified.startLineNumber - r.modified.endLineNumberExclusive;
				s >= 0 && o >= 0 && s + o <= 2 ? t[t.length - 1] = r.join(i) : t.push(i);
			}
			return t;
		}(o), o = o.filter((e) => {
			const n = e.original.toOffsetRange().slice(t).map((e) => e.trim());
			return n.join("\n").length >= 15 && function(e, t) {
				let n = 0;
				for (const r of e) t(r) && n++;
				return n;
			}(n, (e) => e.length >= 2) >= 2;
		}), o = function(e, t) {
			const n = new Fr(e);
			return t = t.filter((t) => (n.findLastMonotonous((e) => e.original.startLineNumber < t.original.endLineNumberExclusive) || new jr(new Dr(1, 1), new Dr(1, 1))) !== Ir(e, (e) => e.modified.startLineNumber < t.modified.endLineNumberExclusive)), t;
		}(e, o), o;
	}
	function Ai(e, t, n) {
		if (e.trim() === t.trim()) return !0;
		if (e.length > 300 && t.length > 300) return !1;
		const r = new wi().compute(new vi([e], new qe(1, 1, 1, e.length), !1), new vi([t], new qe(1, 1, 1, t.length), !1), n);
		let i = 0;
		const s = hi.invert(r.diffs, e.length);
		for (const a of s) a.seq1Range.forEach((t) => {
			fi(e.charCodeAt(t)) || i++;
		});
		const o = function(t) {
			let n = 0;
			for (let r = 0; r < e.length; r++) fi(t.charCodeAt(r)) || n++;
			return n;
		}(e.length > t.length ? e : t);
		return i / o > .6 && o > 10;
	}
	function ki(e, t, n) {
		let r = n;
		return r = Mi(e, t, r), r = Mi(e, t, r), r = function(e, t, n) {
			if (!e.getBoundaryScore || !t.getBoundaryScore) return n;
			for (let r = 0; r < n.length; r++) {
				const i = r > 0 ? n[r - 1] : void 0, s = n[r], o = r + 1 < n.length ? n[r + 1] : void 0, a = new Or(i ? i.seq1Range.endExclusive + 1 : 0, o ? o.seq1Range.start - 1 : e.length), l = new Or(i ? i.seq2Range.endExclusive + 1 : 0, o ? o.seq2Range.start - 1 : t.length);
				s.seq1Range.isEmpty ? n[r] = Oi(s, e, t, a, l) : s.seq2Range.isEmpty && (n[r] = Oi(s.swap(), t, e, l, a).swap());
			}
			return n;
		}(e, t, r), r;
	}
	function Mi(e, t, n) {
		if (0 === n.length) return n;
		const r = [];
		r.push(n[0]);
		for (let s = 1; s < n.length; s++) {
			const i = r[r.length - 1];
			let o = n[s];
			if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
				const n = o.seq1Range.start - i.seq1Range.endExclusive;
				let s;
				for (s = 1; s <= n && e.getElement(o.seq1Range.start - s) === e.getElement(o.seq1Range.endExclusive - s) && t.getElement(o.seq2Range.start - s) === t.getElement(o.seq2Range.endExclusive - s); s++);
				if (s--, s === n) {
					r[r.length - 1] = new hi(new Or(i.seq1Range.start, o.seq1Range.endExclusive - n), new Or(i.seq2Range.start, o.seq2Range.endExclusive - n));
					continue;
				}
				o = o.delta(-s);
			}
			r.push(o);
		}
		const i = [];
		for (let s = 0; s < r.length - 1; s++) {
			const n = r[s + 1];
			let o = r[s];
			if (o.seq1Range.isEmpty || o.seq2Range.isEmpty) {
				const i = n.seq1Range.start - o.seq1Range.endExclusive;
				let a;
				for (a = 0; a < i && e.isStronglyEqual(o.seq1Range.start + a, o.seq1Range.endExclusive + a) && t.isStronglyEqual(o.seq2Range.start + a, o.seq2Range.endExclusive + a); a++);
				if (a === i) {
					r[s + 1] = new hi(new Or(o.seq1Range.start + i, n.seq1Range.endExclusive), new Or(o.seq2Range.start + i, n.seq2Range.endExclusive));
					continue;
				}
				a > 0 && (o = o.delta(a));
			}
			i.push(o);
		}
		return r.length > 0 && i.push(r[r.length - 1]), i;
	}
	function Oi(e, t, n, r, i) {
		let s = 1;
		for (; e.seq1Range.start - s >= r.start && e.seq2Range.start - s >= i.start && n.isStronglyEqual(e.seq2Range.start - s, e.seq2Range.endExclusive - s) && s < 100;) s++;
		s--;
		let o = 0;
		for (; e.seq1Range.start + o < r.endExclusive && e.seq2Range.endExclusive + o < i.endExclusive && n.isStronglyEqual(e.seq2Range.start + o, e.seq2Range.endExclusive + o) && o < 100;) o++;
		if (0 === s && 0 === o) return e;
		let a = 0, l = -1;
		for (let u = -s; u <= o; u++) {
			const r = e.seq2Range.start + u, i = e.seq2Range.endExclusive + u, s = e.seq1Range.start + u, o = t.getBoundaryScore(s) + n.getBoundaryScore(r) + n.getBoundaryScore(i);
			o > l && (l = o, a = u);
		}
		return e.delta(a);
	}
	function Ii(e, t, n, r, i = !1) {
		const s = hi.invert(n, e.length), o = [];
		let a = new ci(0, 0);
		function l(n, l) {
			if (n.offset1 < a.offset1 || n.offset2 < a.offset2) return;
			const u = r(e, n.offset1), h = r(t, n.offset2);
			if (!u || !h) return;
			let c = new hi(u, h);
			const d = c.intersect(l);
			let g = d.seq1Range.length, m = d.seq2Range.length;
			for (; s.length > 0;) {
				const n = s[0];
				if (!n.seq1Range.intersects(c.seq1Range) && !n.seq2Range.intersects(c.seq2Range)) break;
				const i = new hi(r(e, n.seq1Range.start), r(t, n.seq2Range.start)), o = i.intersect(n);
				if (g += o.seq1Range.length, m += o.seq2Range.length, c = c.join(i), !(c.seq1Range.endExclusive >= n.seq1Range.endExclusive)) break;
				s.shift();
			}
			(i && g + m < c.seq1Range.length + c.seq2Range.length || g + m < 2 * (c.seq1Range.length + c.seq2Range.length) / 3) && o.push(c), a = c.getEndExclusives();
		}
		for (; s.length > 0;) {
			const e = s.shift();
			e.seq1Range.isEmpty || (l(e.getStarts(), e), l(e.getEndExclusives().delta(-1), e));
		}
		return function(e, t) {
			const n = [];
			for (; e.length > 0 || t.length > 0;) {
				const r = e[0], i = t[0];
				let s;
				s = r && (!i || r.seq1Range.start < i.seq1Range.start) ? e.shift() : t.shift(), n.length > 0 && n[n.length - 1].seq1Range.endExclusive >= s.seq1Range.start ? n[n.length - 1] = n[n.length - 1].join(s) : n.push(s);
			}
			return n;
		}(n, o);
	}
	var Ti = class {
		constructor(e, t) {
			this.trimmedHash = e, this.lines = t;
		}
		getElement(e) {
			return this.trimmedHash[e];
		}
		get length() {
			return this.trimmedHash.length;
		}
		getBoundaryScore(e) {
			return 1e3 - ((0 === e ? 0 : Pi(this.lines[e - 1])) + (e === this.lines.length ? 0 : Pi(this.lines[e])));
		}
		getText(e) {
			return this.lines.slice(e.start, e.endExclusive).join("\n");
		}
		isStronglyEqual(e, t) {
			return this.lines[e] === this.lines[t];
		}
	};
	function Pi(e) {
		let t = 0;
		for (; t < e.length && (32 === e.charCodeAt(t) || 9 === e.charCodeAt(t));) t++;
		return t;
	}
	var Fi = class {
		constructor() {
			this.dynamicProgrammingDiffing = new bi(), this.myersDiffingAlgorithm = new wi();
		}
		computeDiff(e, t, n) {
			if (e.length <= 1 && function(e, t, n = (e, t) => e === t) {
				if (e === t) return !0;
				if (!e || !t) return !1;
				if (e.length !== t.length) return !1;
				for (let r = 0, i = e.length; r < i; r++) if (!n(e[r], t[r])) return !1;
				return !0;
			}(e, t, (e, t) => e === t)) return new xr([], [], !1);
			if (1 === e.length && 0 === e[0].length || 1 === t.length && 0 === t[0].length) return new xr([new Qr(new Dr(1, e.length + 1), new Dr(1, t.length + 1), [new Yr(new qe(1, 1, e.length, e[e.length - 1].length + 1), new qe(1, 1, t.length, t[t.length - 1].length + 1))])], [], !1);
			const r = 0 === n.maxComputationTimeMs ? di.instance : new gi(n.maxComputationTimeMs), i = !n.ignoreTrimWhitespace, s = /* @__PURE__ */ new Map();
			function o(e) {
				let t = s.get(e);
				return void 0 === t && (t = s.size, s.set(e, t)), t;
			}
			const a = e.map((e) => o(e.trim())), u = t.map((e) => o(e.trim())), h = new Ti(a, e), c = new Ti(u, t), d = h.length + c.length < 1700 ? this.dynamicProgrammingDiffing.compute(h, c, r, (n, r) => e[n] === t[r] ? 0 === t[r].length ? .1 : 1 + Math.log(1 + t[r].length) : .99) : this.myersDiffingAlgorithm.compute(h, c, r);
			let g = d.diffs, m = d.hitTimeout;
			g = ki(h, c, g), g = function(e, t, n) {
				let r = n;
				if (0 === r.length) return r;
				let i, s = 0;
				do {
					i = !1;
					const o = [r[0]];
					for (let a = 1; a < r.length; a++) {
						const l = r[a], u = o[o.length - 1];
						function h(t, n) {
							const r = new Or(u.seq1Range.endExclusive, l.seq1Range.start);
							return e.getText(r).replace(/\s/g, "").length <= 4 && (t.seq1Range.length + t.seq2Range.length > 5 || n.seq1Range.length + n.seq2Range.length > 5);
						}
						h(u, l) ? (i = !0, o[o.length - 1] = o[o.length - 1].join(l)) : o.push(l);
					}
					r = o;
				} while (s++ < 10 && i);
				return r;
			}(h, 0, g);
			const f = [], p = (s) => {
				if (i) for (let o = 0; o < s; o++) {
					const s = b + o, a = w + o;
					if (e[s] !== t[a]) {
						const o = this.refineDiff(e, t, new hi(new Or(s, s + 1), new Or(a, a + 1)), r, i, n);
						for (const e of o.mappings) f.push(e);
						o.hitTimeout && (m = !0);
					}
				}
			};
			let b = 0, w = 0;
			for (const y of g) {
				l(() => y.seq1Range.start - b === y.seq2Range.start - w), p(y.seq1Range.start - b), b = y.seq1Range.endExclusive, w = y.seq2Range.endExclusive;
				const s = this.refineDiff(e, t, y, r, i, n);
				s.hitTimeout && (m = !0);
				for (const e of s.mappings) f.push(e);
			}
			p(e.length - b);
			const _ = Jr(f, new zr(e), new zr(t));
			let C = [];
			return n.computeMoves && (C = this.computeMoves(_, e, t, a, u, r, i, n)), l(() => {
				function n(e, t) {
					if (e.lineNumber < 1 || e.lineNumber > t.length) return !1;
					const n = t[e.lineNumber - 1];
					return !(e.column < 1 || e.column > n.length + 1);
				}
				function r(e, t) {
					return !(e.startLineNumber < 1 || e.startLineNumber > t.length + 1) && !(e.endLineNumberExclusive < 1 || e.endLineNumberExclusive > t.length + 1);
				}
				for (const i of _) {
					if (!i.innerChanges) return !1;
					for (const r of i.innerChanges) if (!(n(r.modifiedRange.getStartPosition(), t) && n(r.modifiedRange.getEndPosition(), t) && n(r.originalRange.getStartPosition(), e) && n(r.originalRange.getEndPosition(), e))) return !1;
					if (!r(i.modified, t) || !r(i.original, e)) return !1;
				}
				return !0;
			}), new xr(_, C, m);
		}
		computeMoves(e, t, n, r, i, s, o, a) {
			return xi(e, t, n, r, i, s).map((e) => new Ar(e, Jr(this.refineDiff(t, n, new hi(e.original.toOffsetRange(), e.modified.toOffsetRange()), s, o, a).mappings, new zr(t), new zr(n), !0)));
		}
		refineDiff(e, t, n, r, i, s) {
			const o = (a = n, new jr(new Dr(a.seq1Range.start + 1, a.seq1Range.endExclusive + 1), new Dr(a.seq2Range.start + 1, a.seq2Range.endExclusive + 1))).toRangeMapping2(e, t);
			var a;
			const l = new vi(e, o.originalRange, i), u = new vi(t, o.modifiedRange, i), h = l.length + u.length < 500 ? this.dynamicProgrammingDiffing.compute(l, u, r) : this.myersDiffingAlgorithm.compute(l, u, r);
			let c = h.diffs;
			return c = ki(l, u, c), c = Ii(l, u, c, (e, t) => e.findWordContaining(t)), s.extendToSubwords && (c = Ii(l, u, c, (e, t) => e.findSubWordContaining(t), !0)), c = function(e, t, n) {
				const r = [];
				for (const i of n) {
					const e = r[r.length - 1];
					e && (i.seq1Range.start - e.seq1Range.endExclusive <= 2 || i.seq2Range.start - e.seq2Range.endExclusive <= 2) ? r[r.length - 1] = new hi(e.seq1Range.join(i.seq1Range), e.seq2Range.join(i.seq2Range)) : r.push(i);
				}
				return r;
			}(0, 0, c), c = function(e, t, n) {
				let r = n;
				if (0 === r.length) return r;
				let i, s = 0;
				do {
					i = !1;
					const a = [r[0]];
					for (let l = 1; l < r.length; l++) {
						const u = r[l], h = a[a.length - 1];
						function c(n, r) {
							const i = new Or(h.seq1Range.endExclusive, u.seq1Range.start);
							if (e.countLinesIn(i) > 5 || i.length > 500) return !1;
							const s = e.getText(i).trim();
							if (s.length > 20 || s.split(/\r\n|\r|\n/).length > 1) return !1;
							const o = e.countLinesIn(n.seq1Range), a = n.seq1Range.length, l = t.countLinesIn(n.seq2Range), c = n.seq2Range.length, d = e.countLinesIn(r.seq1Range), g = r.seq1Range.length, m = t.countLinesIn(r.seq2Range), f = r.seq2Range.length;
							function p(e) {
								return Math.min(e, 130);
							}
							return Math.pow(Math.pow(p(40 * o + a), 1.5) + Math.pow(p(40 * l + c), 1.5), 1.5) + Math.pow(Math.pow(p(40 * d + g), 1.5) + Math.pow(p(40 * m + f), 1.5), 1.5) > 74184.96480721243;
						}
						c(h, u) ? (i = !0, a[a.length - 1] = a[a.length - 1].join(u)) : a.push(u);
					}
					r = a;
				} while (s++ < 10 && i);
				const o = [];
				return function(e, t) {
					for (let n = 0; n < e.length; n++) t(0 === n ? void 0 : e[n - 1], e[n], n + 1 === e.length ? void 0 : e[n + 1]);
				}(r, (t, n, r) => {
					let i = n;
					function s(e) {
						return e.length > 0 && e.trim().length <= 3 && n.seq1Range.length + n.seq2Range.length > 100;
					}
					const a = e.extendToFullLines(n.seq1Range), l = e.getText(new Or(a.start, n.seq1Range.start));
					s(l) && (i = i.deltaStart(-l.length));
					const u = e.getText(new Or(n.seq1Range.endExclusive, a.endExclusive));
					s(u) && (i = i.deltaEnd(u.length));
					const h = hi.fromOffsetPairs(t ? t.getEndExclusives() : ci.zero, r ? r.getStarts() : ci.max), c = i.intersect(h);
					o.length > 0 && c.getStarts().equals(o[o.length - 1].getEndExclusives()) ? o[o.length - 1] = o[o.length - 1].join(c) : o.push(c);
				}), o;
			}(l, u, c), {
				mappings: c.map((e) => new Yr(l.translateRange(e.seq1Range), u.translateRange(e.seq2Range))),
				hitTimeout: h.hitTimeout
			};
		}
	};
	const Di = () => new Zr(), qi = () => new Fi();
	function Vi(e, t) {
		const n = Math.pow(10, t);
		return Math.round(e * n) / n;
	}
	var Ki = class {
		constructor(e, t, n, r = 1) {
			this._rgbaBrand = void 0, this.r = 0 | Math.min(255, Math.max(0, e)), this.g = 0 | Math.min(255, Math.max(0, t)), this.b = 0 | Math.min(255, Math.max(0, n)), this.a = Vi(Math.max(Math.min(1, r), 0), 3);
		}
		static equals(e, t) {
			return e.r === t.r && e.g === t.g && e.b === t.b && e.a === t.a;
		}
	}, Bi = class e {
		constructor(e, t, n, r) {
			this._hslaBrand = void 0, this.h = 0 | Math.max(Math.min(360, e), 0), this.s = Vi(Math.max(Math.min(1, t), 0), 3), this.l = Vi(Math.max(Math.min(1, n), 0), 3), this.a = Vi(Math.max(Math.min(1, r), 0), 3);
		}
		static equals(e, t) {
			return e.h === t.h && e.s === t.s && e.l === t.l && e.a === t.a;
		}
		static fromRGBA(t) {
			const n = t.r / 255, r = t.g / 255, i = t.b / 255, s = t.a, o = Math.max(n, r, i), a = Math.min(n, r, i);
			let l = 0, u = 0;
			const h = (a + o) / 2, c = o - a;
			if (c > 0) {
				switch (u = Math.min(h <= .5 ? c / (2 * h) : c / (2 - 2 * h), 1), o) {
					case n:
						l = (r - i) / c + (r < i ? 6 : 0);
						break;
					case r:
						l = (i - n) / c + 2;
						break;
					case i: l = (n - r) / c + 4;
				}
				l *= 60, l = Math.round(l);
			}
			return new e(l, u, h, s);
		}
		static _hue2rgb(e, t, n) {
			return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + 6 * (t - e) * n : n < .5 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
		}
		static toRGBA(t) {
			const n = t.h / 360, { s: r, l: i, a: s } = t;
			let o, a, l;
			if (0 === r) o = a = l = i;
			else {
				const t = i < .5 ? i * (1 + r) : i + r - i * r, s = 2 * i - t;
				o = e._hue2rgb(s, t, n + 1 / 3), a = e._hue2rgb(s, t, n), l = e._hue2rgb(s, t, n - 1 / 3);
			}
			return new Ki(Math.round(255 * o), Math.round(255 * a), Math.round(255 * l), s);
		}
	}, Ui = class e {
		constructor(e, t, n, r) {
			this._hsvaBrand = void 0, this.h = 0 | Math.max(Math.min(360, e), 0), this.s = Vi(Math.max(Math.min(1, t), 0), 3), this.v = Vi(Math.max(Math.min(1, n), 0), 3), this.a = Vi(Math.max(Math.min(1, r), 0), 3);
		}
		static equals(e, t) {
			return e.h === t.h && e.s === t.s && e.v === t.v && e.a === t.a;
		}
		static fromRGBA(t) {
			const n = t.r / 255, r = t.g / 255, i = t.b / 255, s = Math.max(n, r, i), o = s - Math.min(n, r, i), a = 0 === s ? 0 : o / s;
			let l;
			return l = 0 === o ? 0 : s === n ? ((r - i) / o % 6 + 6) % 6 : s === r ? (i - n) / o + 2 : (n - r) / o + 4, new e(Math.round(60 * l), a, s, t.a);
		}
		static toRGBA(e) {
			const { h: t, s: n, v: r, a: i } = e, s = r * n, o = s * (1 - Math.abs(t / 60 % 2 - 1)), a = r - s;
			let [l, u, h] = [
				0,
				0,
				0
			];
			return t < 60 ? (l = s, u = o) : t < 120 ? (l = o, u = s) : t < 180 ? (u = s, h = o) : t < 240 ? (u = o, h = s) : t < 300 ? (l = o, h = s) : t <= 360 && (l = s, h = o), l = Math.round(255 * (l + a)), u = Math.round(255 * (u + a)), h = Math.round(255 * (h + a)), new Ki(l, u, h, i);
		}
	}, $i = class e {
		static fromHex(t) {
			return e.Format.CSS.parseHex(t) || e.red;
		}
		static equals(e, t) {
			return !e && !t || !(!e || !t) && e.equals(t);
		}
		get hsla() {
			return this._hsla ? this._hsla : Bi.fromRGBA(this.rgba);
		}
		get hsva() {
			return this._hsva ? this._hsva : Ui.fromRGBA(this.rgba);
		}
		constructor(e) {
			if (!e) throw new Error("Color needs a value");
			if (e instanceof Ki) this.rgba = e;
			else if (e instanceof Bi) this._hsla = e, this.rgba = Bi.toRGBA(e);
			else {
				if (!(e instanceof Ui)) throw new Error("Invalid color ctor argument");
				this._hsva = e, this.rgba = Ui.toRGBA(e);
			}
		}
		equals(e) {
			return !!e && Ki.equals(this.rgba, e.rgba) && Bi.equals(this.hsla, e.hsla) && Ui.equals(this.hsva, e.hsva);
		}
		getRelativeLuminance() {
			return Vi(.2126 * e._relativeLuminanceForComponent(this.rgba.r) + .7152 * e._relativeLuminanceForComponent(this.rgba.g) + .0722 * e._relativeLuminanceForComponent(this.rgba.b), 4);
		}
		static _relativeLuminanceForComponent(e) {
			const t = e / 255;
			return t <= .03928 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4);
		}
		isLighter() {
			return (299 * this.rgba.r + 587 * this.rgba.g + 114 * this.rgba.b) / 1e3 >= 128;
		}
		isLighterThan(e) {
			return this.getRelativeLuminance() > e.getRelativeLuminance();
		}
		isDarkerThan(e) {
			return this.getRelativeLuminance() < e.getRelativeLuminance();
		}
		lighten(t) {
			return new e(new Bi(this.hsla.h, this.hsla.s, this.hsla.l + this.hsla.l * t, this.hsla.a));
		}
		darken(t) {
			return new e(new Bi(this.hsla.h, this.hsla.s, this.hsla.l - this.hsla.l * t, this.hsla.a));
		}
		transparent(t) {
			const { r: n, g: r, b: i, a: s } = this.rgba;
			return new e(new Ki(n, r, i, s * t));
		}
		isTransparent() {
			return 0 === this.rgba.a;
		}
		isOpaque() {
			return 1 === this.rgba.a;
		}
		opposite() {
			return new e(new Ki(255 - this.rgba.r, 255 - this.rgba.g, 255 - this.rgba.b, this.rgba.a));
		}
		mix(t, n = .5) {
			const r = Math.min(Math.max(n, 0), 1), i = this.rgba, s = t.rgba;
			return new e(new Ki(i.r + (s.r - i.r) * r, i.g + (s.g - i.g) * r, i.b + (s.b - i.b) * r, i.a + (s.a - i.a) * r));
		}
		makeOpaque(t) {
			if (this.isOpaque() || 1 !== t.rgba.a) return this;
			const { r: n, g: r, b: i, a: s } = this.rgba;
			return new e(new Ki(t.rgba.r - s * (t.rgba.r - n), t.rgba.g - s * (t.rgba.g - r), t.rgba.b - s * (t.rgba.b - i), 1));
		}
		toString() {
			return this._toString || (this._toString = e.Format.CSS.format(this)), this._toString;
		}
		toNumber32Bit() {
			return this._toNumber32Bit || (this._toNumber32Bit = (this.rgba.r << 24 | this.rgba.g << 16 | this.rgba.b << 8 | 255 * this.rgba.a) >>> 0), this._toNumber32Bit;
		}
		static getLighterColor(e, t, n) {
			if (e.isLighterThan(t)) return e;
			n = n || .5;
			const r = e.getRelativeLuminance(), i = t.getRelativeLuminance();
			return n = n * (i - r) / i, e.lighten(n);
		}
		static getDarkerColor(e, t, n) {
			if (e.isDarkerThan(t)) return e;
			n = n || .5;
			const r = e.getRelativeLuminance();
			return n = n * (r - t.getRelativeLuminance()) / r, e.darken(n);
		}
		static {
			this.white = new e(new Ki(255, 255, 255, 1));
		}
		static {
			this.black = new e(new Ki(0, 0, 0, 1));
		}
		static {
			this.red = new e(new Ki(255, 0, 0, 1));
		}
		static {
			this.blue = new e(new Ki(0, 0, 255, 1));
		}
		static {
			this.green = new e(new Ki(0, 255, 0, 1));
		}
		static {
			this.cyan = new e(new Ki(0, 255, 255, 1));
		}
		static {
			this.lightgrey = new e(new Ki(211, 211, 211, 1));
		}
		static {
			this.transparent = new e(new Ki(0, 0, 0, 0));
		}
	};
	function Wi(e) {
		const t = [];
		for (const n of e) {
			const e = Number(n);
			(e || 0 === e && "" !== n.replace(/\s/g, "")) && t.push(e);
		}
		return t;
	}
	function zi(e, t, n, r) {
		return {
			red: e / 255,
			blue: n / 255,
			green: t / 255,
			alpha: r
		};
	}
	function Hi(e, t) {
		const n = t.index, r = t[0].length;
		if (void 0 === n) return;
		const i = e.positionAt(n);
		return {
			startLineNumber: i.lineNumber,
			startColumn: i.column,
			endLineNumber: i.lineNumber,
			endColumn: i.column + r
		};
	}
	function ji(e, t) {
		if (!e) return;
		const n = $i.Format.CSS.parseHex(t);
		return n ? {
			range: e,
			color: zi(n.rgba.r, n.rgba.g, n.rgba.b, n.rgba.a)
		} : void 0;
	}
	function Gi(e, t, n) {
		if (!e || 1 !== t.length) return;
		const r = Wi(t[0].values());
		return {
			range: e,
			color: zi(r[0], r[1], r[2], n ? r[3] : 1)
		};
	}
	function Xi(e, t, n) {
		if (!e || 1 !== t.length) return;
		const r = Wi(t[0].values()), i = new $i(new Bi(r[0], r[1] / 100, r[2] / 100, n ? r[3] : 1));
		return {
			range: e,
			color: zi(i.rgba.r, i.rgba.g, i.rgba.b, i.rgba.a)
		};
	}
	function Qi(e, t) {
		return "string" == typeof e ? [...e.matchAll(t)] : e.findMatches(t);
	}
	function Yi(e) {
		return e && "function" == typeof e.getValue && "function" == typeof e.positionAt ? function(e) {
			const t = [], n = Qi(e, /\b(rgb|rgba|hsl|hsla)(\([0-9\s,.\%]*\))|^(#)([A-Fa-f0-9]{3})\b|^(#)([A-Fa-f0-9]{4})\b|^(#)([A-Fa-f0-9]{6})\b|^(#)([A-Fa-f0-9]{8})\b|(?<=['"\s])(#)([A-Fa-f0-9]{3})\b|(?<=['"\s])(#)([A-Fa-f0-9]{4})\b|(?<=['"\s])(#)([A-Fa-f0-9]{6})\b|(?<=['"\s])(#)([A-Fa-f0-9]{8})\b/gm);
			if (n.length > 0) for (const r of n) {
				const n = r.filter((e) => void 0 !== e), i = n[1], s = n[2];
				if (!s) continue;
				let o;
				"rgb" === i ? o = Gi(Hi(e, r), Qi(s, /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*\)$/gm), !1) : "rgba" === i ? o = Gi(Hi(e, r), Qi(s, /^\(\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\s*,\s*(0[.][0-9]+|[.][0-9]+|[01][.]|[01])\s*\)$/gm), !0) : "hsl" === i ? o = Xi(Hi(e, r), Qi(s, /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*\)$/gm), !1) : "hsla" === i ? o = Xi(Hi(e, r), Qi(s, /^\(\s*((?:360(?:\.0+)?|(?:36[0]|3[0-5][0-9]|[12][0-9][0-9]|[1-9]?[0-9])(?:\.\d+)?))\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(100|\d{1,2}[.]\d*|\d{1,2})%\s*[\s,]\s*(0[.][0-9]+|[.][0-9]+|[01][.]0*|[01])\s*\)$/gm), !0) : "#" === i && (o = ji(Hi(e, r), i + s)), o && t.push(o);
			}
			return t;
		}(e) : [];
	}
	(function(e) {
		var t;
		(function(t) {
			function n(e) {
				const t = e.toString(16);
				return 2 !== t.length ? "0" + t : t;
			}
			function r(t) {
				const n = t.length;
				if (0 === n) return null;
				if (35 !== t.charCodeAt(0)) return null;
				if (7 === n) return new e(new Ki(16 * i(t.charCodeAt(1)) + i(t.charCodeAt(2)), 16 * i(t.charCodeAt(3)) + i(t.charCodeAt(4)), 16 * i(t.charCodeAt(5)) + i(t.charCodeAt(6)), 1));
				if (9 === n) return new e(new Ki(16 * i(t.charCodeAt(1)) + i(t.charCodeAt(2)), 16 * i(t.charCodeAt(3)) + i(t.charCodeAt(4)), 16 * i(t.charCodeAt(5)) + i(t.charCodeAt(6)), (16 * i(t.charCodeAt(7)) + i(t.charCodeAt(8))) / 255));
				if (4 === n) {
					const n = i(t.charCodeAt(1)), r = i(t.charCodeAt(2)), s = i(t.charCodeAt(3));
					return new e(new Ki(16 * n + n, 16 * r + r, 16 * s + s));
				}
				if (5 === n) {
					const n = i(t.charCodeAt(1)), r = i(t.charCodeAt(2)), s = i(t.charCodeAt(3)), o = i(t.charCodeAt(4));
					return new e(new Ki(16 * n + n, 16 * r + r, 16 * s + s, (16 * o + o) / 255));
				}
				return null;
			}
			function i(e) {
				switch (e) {
					case 48: return 0;
					case 49: return 1;
					case 50: return 2;
					case 51: return 3;
					case 52: return 4;
					case 53: return 5;
					case 54: return 6;
					case 55: return 7;
					case 56: return 8;
					case 57: return 9;
					case 97:
					case 65: return 10;
					case 98:
					case 66: return 11;
					case 99:
					case 67: return 12;
					case 100:
					case 68: return 13;
					case 101:
					case 69: return 14;
					case 102:
					case 70: return 15;
				}
				return 0;
			}
			t.formatRGB = function(t) {
				return 1 === t.rgba.a ? `rgb(${t.rgba.r}, ${t.rgba.g}, ${t.rgba.b})` : e.Format.CSS.formatRGBA(t);
			}, t.formatRGBA = function(e) {
				return `rgba(${e.rgba.r}, ${e.rgba.g}, ${e.rgba.b}, ${+e.rgba.a.toFixed(2)})`;
			}, t.formatHSL = function(t) {
				return 1 === t.hsla.a ? `hsl(${t.hsla.h}, ${Math.round(100 * t.hsla.s)}%, ${Math.round(100 * t.hsla.l)}%)` : e.Format.CSS.formatHSLA(t);
			}, t.formatHSLA = function(e) {
				return `hsla(${e.hsla.h}, ${Math.round(100 * e.hsla.s)}%, ${Math.round(100 * e.hsla.l)}%, ${e.hsla.a.toFixed(2)})`;
			}, t.formatHex = function(e) {
				return `#${n(e.rgba.r)}${n(e.rgba.g)}${n(e.rgba.b)}`;
			}, t.formatHexA = function(t, r = !1) {
				return r && 1 === t.rgba.a ? e.Format.CSS.formatHex(t) : `#${n(t.rgba.r)}${n(t.rgba.g)}${n(t.rgba.b)}${n(Math.round(255 * t.rgba.a))}`;
			}, t.format = function(t) {
				return t.isOpaque() ? e.Format.CSS.formatHex(t) : e.Format.CSS.formatRGBA(t);
			}, t.parse = function(t) {
				if ("transparent" === t) return e.transparent;
				if (t.startsWith("#")) return r(t);
				if (t.startsWith("rgba(")) {
					const n = t.match(/rgba\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+), *(?<a>(?:\+|-)?\d+(\.\d+)?)\)/);
					if (!n) throw new Error("Invalid color format " + t);
					return new e(new Ki(parseInt(n.groups?.r ?? "0"), parseInt(n.groups?.g ?? "0"), parseInt(n.groups?.b ?? "0"), parseFloat(n.groups?.a ?? "0")));
				}
				if (t.startsWith("rgb(")) {
					const n = t.match(/rgb\((?<r>(?:\+|-)?\d+), *(?<g>(?:\+|-)?\d+), *(?<b>(?:\+|-)?\d+)\)/);
					if (!n) throw new Error("Invalid color format " + t);
					return new e(new Ki(parseInt(n.groups?.r ?? "0"), parseInt(n.groups?.g ?? "0"), parseInt(n.groups?.b ?? "0")));
				}
				return function(t) {
					switch (t) {
						case "aliceblue": return new e(new Ki(240, 248, 255, 1));
						case "antiquewhite": return new e(new Ki(250, 235, 215, 1));
						case "aqua":
						case "cyan": return new e(new Ki(0, 255, 255, 1));
						case "aquamarine": return new e(new Ki(127, 255, 212, 1));
						case "azure": return new e(new Ki(240, 255, 255, 1));
						case "beige": return new e(new Ki(245, 245, 220, 1));
						case "bisque": return new e(new Ki(255, 228, 196, 1));
						case "black": return new e(new Ki(0, 0, 0, 1));
						case "blanchedalmond": return new e(new Ki(255, 235, 205, 1));
						case "blue": return new e(new Ki(0, 0, 255, 1));
						case "blueviolet": return new e(new Ki(138, 43, 226, 1));
						case "brown": return new e(new Ki(165, 42, 42, 1));
						case "burlywood": return new e(new Ki(222, 184, 135, 1));
						case "cadetblue": return new e(new Ki(95, 158, 160, 1));
						case "chartreuse": return new e(new Ki(127, 255, 0, 1));
						case "chocolate": return new e(new Ki(210, 105, 30, 1));
						case "coral": return new e(new Ki(255, 127, 80, 1));
						case "cornflowerblue": return new e(new Ki(100, 149, 237, 1));
						case "cornsilk": return new e(new Ki(255, 248, 220, 1));
						case "crimson": return new e(new Ki(220, 20, 60, 1));
						case "darkblue": return new e(new Ki(0, 0, 139, 1));
						case "darkcyan": return new e(new Ki(0, 139, 139, 1));
						case "darkgoldenrod": return new e(new Ki(184, 134, 11, 1));
						case "darkgray":
						case "darkgrey": return new e(new Ki(169, 169, 169, 1));
						case "darkgreen": return new e(new Ki(0, 100, 0, 1));
						case "darkkhaki": return new e(new Ki(189, 183, 107, 1));
						case "darkmagenta": return new e(new Ki(139, 0, 139, 1));
						case "darkolivegreen": return new e(new Ki(85, 107, 47, 1));
						case "darkorange": return new e(new Ki(255, 140, 0, 1));
						case "darkorchid": return new e(new Ki(153, 50, 204, 1));
						case "darkred": return new e(new Ki(139, 0, 0, 1));
						case "darksalmon": return new e(new Ki(233, 150, 122, 1));
						case "darkseagreen": return new e(new Ki(143, 188, 143, 1));
						case "darkslateblue": return new e(new Ki(72, 61, 139, 1));
						case "darkslategray":
						case "darkslategrey": return new e(new Ki(47, 79, 79, 1));
						case "darkturquoise": return new e(new Ki(0, 206, 209, 1));
						case "darkviolet": return new e(new Ki(148, 0, 211, 1));
						case "deeppink": return new e(new Ki(255, 20, 147, 1));
						case "deepskyblue": return new e(new Ki(0, 191, 255, 1));
						case "dimgray":
						case "dimgrey": return new e(new Ki(105, 105, 105, 1));
						case "dodgerblue": return new e(new Ki(30, 144, 255, 1));
						case "firebrick": return new e(new Ki(178, 34, 34, 1));
						case "floralwhite": return new e(new Ki(255, 250, 240, 1));
						case "forestgreen": return new e(new Ki(34, 139, 34, 1));
						case "fuchsia":
						case "magenta": return new e(new Ki(255, 0, 255, 1));
						case "gainsboro": return new e(new Ki(220, 220, 220, 1));
						case "ghostwhite": return new e(new Ki(248, 248, 255, 1));
						case "gold": return new e(new Ki(255, 215, 0, 1));
						case "goldenrod": return new e(new Ki(218, 165, 32, 1));
						case "gray":
						case "grey": return new e(new Ki(128, 128, 128, 1));
						case "green": return new e(new Ki(0, 128, 0, 1));
						case "greenyellow": return new e(new Ki(173, 255, 47, 1));
						case "honeydew": return new e(new Ki(240, 255, 240, 1));
						case "hotpink": return new e(new Ki(255, 105, 180, 1));
						case "indianred": return new e(new Ki(205, 92, 92, 1));
						case "indigo": return new e(new Ki(75, 0, 130, 1));
						case "ivory": return new e(new Ki(255, 255, 240, 1));
						case "khaki": return new e(new Ki(240, 230, 140, 1));
						case "lavender": return new e(new Ki(230, 230, 250, 1));
						case "lavenderblush": return new e(new Ki(255, 240, 245, 1));
						case "lawngreen": return new e(new Ki(124, 252, 0, 1));
						case "lemonchiffon": return new e(new Ki(255, 250, 205, 1));
						case "lightblue": return new e(new Ki(173, 216, 230, 1));
						case "lightcoral": return new e(new Ki(240, 128, 128, 1));
						case "lightcyan": return new e(new Ki(224, 255, 255, 1));
						case "lightgoldenrodyellow": return new e(new Ki(250, 250, 210, 1));
						case "lightgray":
						case "lightgrey": return new e(new Ki(211, 211, 211, 1));
						case "lightgreen": return new e(new Ki(144, 238, 144, 1));
						case "lightpink": return new e(new Ki(255, 182, 193, 1));
						case "lightsalmon": return new e(new Ki(255, 160, 122, 1));
						case "lightseagreen": return new e(new Ki(32, 178, 170, 1));
						case "lightskyblue": return new e(new Ki(135, 206, 250, 1));
						case "lightslategray":
						case "lightslategrey": return new e(new Ki(119, 136, 153, 1));
						case "lightsteelblue": return new e(new Ki(176, 196, 222, 1));
						case "lightyellow": return new e(new Ki(255, 255, 224, 1));
						case "lime": return new e(new Ki(0, 255, 0, 1));
						case "limegreen": return new e(new Ki(50, 205, 50, 1));
						case "linen": return new e(new Ki(250, 240, 230, 1));
						case "maroon": return new e(new Ki(128, 0, 0, 1));
						case "mediumaquamarine": return new e(new Ki(102, 205, 170, 1));
						case "mediumblue": return new e(new Ki(0, 0, 205, 1));
						case "mediumorchid": return new e(new Ki(186, 85, 211, 1));
						case "mediumpurple": return new e(new Ki(147, 112, 219, 1));
						case "mediumseagreen": return new e(new Ki(60, 179, 113, 1));
						case "mediumslateblue": return new e(new Ki(123, 104, 238, 1));
						case "mediumspringgreen": return new e(new Ki(0, 250, 154, 1));
						case "mediumturquoise": return new e(new Ki(72, 209, 204, 1));
						case "mediumvioletred": return new e(new Ki(199, 21, 133, 1));
						case "midnightblue": return new e(new Ki(25, 25, 112, 1));
						case "mintcream": return new e(new Ki(245, 255, 250, 1));
						case "mistyrose": return new e(new Ki(255, 228, 225, 1));
						case "moccasin": return new e(new Ki(255, 228, 181, 1));
						case "navajowhite": return new e(new Ki(255, 222, 173, 1));
						case "navy": return new e(new Ki(0, 0, 128, 1));
						case "oldlace": return new e(new Ki(253, 245, 230, 1));
						case "olive": return new e(new Ki(128, 128, 0, 1));
						case "olivedrab": return new e(new Ki(107, 142, 35, 1));
						case "orange": return new e(new Ki(255, 165, 0, 1));
						case "orangered": return new e(new Ki(255, 69, 0, 1));
						case "orchid": return new e(new Ki(218, 112, 214, 1));
						case "palegoldenrod": return new e(new Ki(238, 232, 170, 1));
						case "palegreen": return new e(new Ki(152, 251, 152, 1));
						case "paleturquoise": return new e(new Ki(175, 238, 238, 1));
						case "palevioletred": return new e(new Ki(219, 112, 147, 1));
						case "papayawhip": return new e(new Ki(255, 239, 213, 1));
						case "peachpuff": return new e(new Ki(255, 218, 185, 1));
						case "peru": return new e(new Ki(205, 133, 63, 1));
						case "pink": return new e(new Ki(255, 192, 203, 1));
						case "plum": return new e(new Ki(221, 160, 221, 1));
						case "powderblue": return new e(new Ki(176, 224, 230, 1));
						case "purple": return new e(new Ki(128, 0, 128, 1));
						case "rebeccapurple": return new e(new Ki(102, 51, 153, 1));
						case "red": return new e(new Ki(255, 0, 0, 1));
						case "rosybrown": return new e(new Ki(188, 143, 143, 1));
						case "royalblue": return new e(new Ki(65, 105, 225, 1));
						case "saddlebrown": return new e(new Ki(139, 69, 19, 1));
						case "salmon": return new e(new Ki(250, 128, 114, 1));
						case "sandybrown": return new e(new Ki(244, 164, 96, 1));
						case "seagreen": return new e(new Ki(46, 139, 87, 1));
						case "seashell": return new e(new Ki(255, 245, 238, 1));
						case "sienna": return new e(new Ki(160, 82, 45, 1));
						case "silver": return new e(new Ki(192, 192, 192, 1));
						case "skyblue": return new e(new Ki(135, 206, 235, 1));
						case "slateblue": return new e(new Ki(106, 90, 205, 1));
						case "slategray":
						case "slategrey": return new e(new Ki(112, 128, 144, 1));
						case "snow": return new e(new Ki(255, 250, 250, 1));
						case "springgreen": return new e(new Ki(0, 255, 127, 1));
						case "steelblue": return new e(new Ki(70, 130, 180, 1));
						case "tan": return new e(new Ki(210, 180, 140, 1));
						case "teal": return new e(new Ki(0, 128, 128, 1));
						case "thistle": return new e(new Ki(216, 191, 216, 1));
						case "tomato": return new e(new Ki(255, 99, 71, 1));
						case "turquoise": return new e(new Ki(64, 224, 208, 1));
						case "violet": return new e(new Ki(238, 130, 238, 1));
						case "wheat": return new e(new Ki(245, 222, 179, 1));
						case "white": return new e(new Ki(255, 255, 255, 1));
						case "whitesmoke": return new e(new Ki(245, 245, 245, 1));
						case "yellow": return new e(new Ki(255, 255, 0, 1));
						case "yellowgreen": return new e(new Ki(154, 205, 50, 1));
						default: return null;
					}
				}(t);
			}, t.parseHex = r;
		})((t = e.Format || (e.Format = {})).CSS || (t.CSS = {}));
	})($i || ($i = {}));
	const Ji = /^-+|-+$/g, Zi = 100;
	function es(e, t) {
		let n = [];
		if (t.findRegionSectionHeaders && t.foldingRules?.markers) {
			const r = function(e, t) {
				const n = [], r = e.getLineCount();
				for (let i = 1; i <= r; i++) {
					const r = e.getLineContent(i), s = r.match(t.foldingRules.markers.start);
					if (s) {
						const e = {
							startLineNumber: i,
							startColumn: s[0].length + 1,
							endLineNumber: i,
							endColumn: r.length + 1
						};
						if (e.endColumn > e.startColumn) {
							const t = {
								range: e,
								...ts(r.substring(s[0].length)),
								shouldBeInComments: !1
							};
							(t.text || t.hasSeparatorLine) && n.push(t);
						}
					}
				}
				return n;
			}(e, t);
			n = n.concat(r);
		}
		if (t.findMarkSectionHeaders) {
			const r = function(e, t) {
				const n = [], r = e.getLineCount();
				if (!t.markSectionHeaderRegex || "" === t.markSectionHeaderRegex.trim()) return n;
				const i = function(e) {
					if (!e || 0 === e.length) return !1;
					for (let t = 0, n = e.length; t < n; t++) {
						const r = e.charCodeAt(t);
						if (10 === r) return !0;
						if (92 === r) {
							if (t++, t >= n) break;
							const r = e.charCodeAt(t);
							if (110 === r || 114 === r || 87 === r) return !0;
						}
					}
					return !1;
				}(t.markSectionHeaderRegex), s = new RegExp(t.markSectionHeaderRegex, "gdm" + (i ? "s" : ""));
				if (o = s, "^" !== o.source && "^$" !== o.source && "$" !== o.source && "^\\s*$" !== o.source && o.exec("") && 0 === o.lastIndex) return n;
				var o;
				for (let a = 1; a <= r; a += 95) {
					const t = Math.min(a + Zi - 1, r), i = [];
					for (let n = a; n <= t; n++) i.push(e.getLineContent(n));
					const o = i.join("\n");
					let l;
					for (s.lastIndex = 0; null !== (l = s.exec(o));) {
						const e = o.substring(0, l.index), t = a + (e.match(/\n/g) || []).length, r = l[0].split("\n"), i = r.length, u = t + i - 1, h = e.lastIndexOf("\n") + 1, c = l.index - h + 1, d = r[r.length - 1], g = {
							range: {
								startLineNumber: t,
								startColumn: c,
								endLineNumber: u,
								endColumn: 1 === i ? c + l[0].length : d.length + 1
							},
							text: (l.groups ?? {}).label ?? "",
							hasSeparatorLine: "" !== ((l.groups ?? {}).separator ?? ""),
							shouldBeInComments: !0
						};
						(g.text || g.hasSeparatorLine) && (0 === n.length || n[n.length - 1].range.endLineNumber < g.range.startLineNumber) && n.push(g), s.lastIndex = l.index + l[0].length;
					}
				}
				return n;
			}(e, t);
			n = n.concat(r);
		}
		return n;
	}
	function ts(e) {
		const t = (e = e.trim()).startsWith("-");
		return {
			text: e = e.replace(Ji, ""),
			hasSeparatorLine: t
		};
	}
	(function() {
		const e = globalThis;
		"function" != typeof e.requestIdleCallback || e.cancelIdleCallback;
	})();
	var is, ss = class {
		get isRejected() {
			return 1 === this.outcome?.outcome;
		}
		get isSettled() {
			return !!this.outcome;
		}
		constructor() {
			this.p = new Promise((e, t) => {
				this.completeCallback = e, this.errorCallback = t;
			});
		}
		complete(e) {
			return this.isSettled ? Promise.resolve() : new Promise((t) => {
				this.completeCallback(e), this.outcome = {
					outcome: 0,
					value: e
				}, t();
			});
		}
		error(e) {
			return this.isSettled ? Promise.resolve() : new Promise((t) => {
				this.errorCallback(e), this.outcome = {
					outcome: 1,
					value: e
				}, t();
			});
		}
		cancel() {
			return this.error(new i());
		}
	};
	(function(e) {
		e.settled = async function(e) {
			let t;
			const n = await Promise.all(e.map((e) => e.then((e) => e, (e) => {
				t || (t = e);
			})));
			if (void 0 !== t) throw t;
			return n;
		}, e.withAsyncBody = function(e) {
			return new Promise(async (t, n) => {
				try {
					await e(t, n);
				} catch (r) {
					n(r);
				}
			});
		};
	})(is || (is = {}));
	var os = class {
		constructor() {
			this._unsatisfiedConsumers = [], this._unconsumedValues = [];
		}
		get hasFinalValue() {
			return !!this._finalValue;
		}
		produce(e) {
			if (this._ensureNoFinalValue(), this._unsatisfiedConsumers.length > 0) {
				const t = this._unsatisfiedConsumers.shift();
				this._resolveOrRejectDeferred(t, e);
			} else this._unconsumedValues.push(e);
		}
		produceFinal(e) {
			this._ensureNoFinalValue(), this._finalValue = e;
			for (const t of this._unsatisfiedConsumers) this._resolveOrRejectDeferred(t, e);
			this._unsatisfiedConsumers.length = 0;
		}
		_ensureNoFinalValue() {
			if (this._finalValue) throw new o("ProducerConsumer: cannot produce after final value has been set");
		}
		_resolveOrRejectDeferred(e, t) {
			t.ok ? e.complete(t.value) : e.error(t.error);
		}
		consume() {
			if (this._unconsumedValues.length > 0 || this._finalValue) {
				const e = this._unconsumedValues.length > 0 ? this._unconsumedValues.shift() : this._finalValue;
				return e.ok ? Promise.resolve(e.value) : Promise.reject(e.error);
			}
			{
				const e = new ss();
				return this._unsatisfiedConsumers.push(e), e.p;
			}
		}
	}, as = (class e {
		constructor(e, t) {
			this._onReturn = t, this._producerConsumer = new os(), this._iterator = {
				next: () => this._producerConsumer.consume(),
				return: () => (this._onReturn?.(), Promise.resolve({
					done: !0,
					value: void 0
				})),
				throw: async (e) => (this._finishError(e), {
					done: !0,
					value: void 0
				})
			}, queueMicrotask(async () => {
				const t = e({
					emitOne: (e) => this._producerConsumer.produce({
						ok: !0,
						value: {
							done: !1,
							value: e
						}
					}),
					emitMany: (e) => {
						for (const t of e) this._producerConsumer.produce({
							ok: !0,
							value: {
								done: !1,
								value: t
							}
						});
					},
					reject: (e) => this._finishError(e)
				});
				if (!this._producerConsumer.hasFinalValue) try {
					await t, this._finishOk();
				} catch (n) {
					this._finishError(n);
				}
			});
		}
		static fromArray(t) {
			return new e((e) => {
				e.emitMany(t);
			});
		}
		static fromPromise(t) {
			return new e(async (e) => {
				e.emitMany(await t);
			});
		}
		static fromPromisesResolveOrder(t) {
			return new e(async (e) => {
				await Promise.all(t.map(async (t) => e.emitOne(await t)));
			});
		}
		static merge(t) {
			return new e(async (e) => {
				await Promise.all(t.map(async (t) => {
					for await (const n of t) e.emitOne(n);
				}));
			});
		}
		static {
			this.EMPTY = e.fromArray([]);
		}
		static map(t, n) {
			return new e(async (e) => {
				for await (const r of t) e.emitOne(n(r));
			});
		}
		map(t) {
			return e.map(this, t);
		}
		static coalesce(t) {
			return e.filter(t, (e) => !!e);
		}
		coalesce() {
			return e.coalesce(this);
		}
		static filter(t, n) {
			return new e(async (e) => {
				for await (const r of t) n(r) && e.emitOne(r);
			});
		}
		filter(t) {
			return e.filter(this, t);
		}
		_finishOk() {
			this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
				ok: !0,
				value: {
					done: !0,
					value: void 0
				}
			});
		}
		_finishError(e) {
			this._producerConsumer.hasFinalValue || this._producerConsumer.produceFinal({
				ok: !1,
				error: e
			});
		}
		[Symbol.asyncIterator]() {
			return this._iterator;
		}
	}, class {
		constructor(e) {
			this.values = e, this.prefixSum = new Uint32Array(e.length), this.prefixSumValidIndex = new Int32Array(1), this.prefixSumValidIndex[0] = -1;
		}
		insertValues(e, t) {
			e = Ke(e);
			const n = this.values, r = this.prefixSum, i = t.length;
			return 0 !== i && (this.values = new Uint32Array(n.length + i), this.values.set(n.subarray(0, e), 0), this.values.set(n.subarray(e), e + i), this.values.set(t, e), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSum = new Uint32Array(this.values.length), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(r.subarray(0, this.prefixSumValidIndex[0] + 1)), !0);
		}
		setValue(e, t) {
			return e = Ke(e), t = Ke(t), this.values[e] !== t && (this.values[e] = t, e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), !0);
		}
		removeValues(e, t) {
			e = Ke(e), t = Ke(t);
			const n = this.values, r = this.prefixSum;
			if (e >= n.length) return !1;
			const i = n.length - e;
			return t >= i && (t = i), 0 !== t && (this.values = new Uint32Array(n.length - t), this.values.set(n.subarray(0, e), 0), this.values.set(n.subarray(e + t), e), this.prefixSum = new Uint32Array(this.values.length), e - 1 < this.prefixSumValidIndex[0] && (this.prefixSumValidIndex[0] = e - 1), this.prefixSumValidIndex[0] >= 0 && this.prefixSum.set(r.subarray(0, this.prefixSumValidIndex[0] + 1)), !0);
		}
		getTotalSum() {
			return 0 === this.values.length ? 0 : this._getPrefixSum(this.values.length - 1);
		}
		getPrefixSum(e) {
			return e < 0 ? 0 : (e = Ke(e), this._getPrefixSum(e));
		}
		_getPrefixSum(e) {
			if (e <= this.prefixSumValidIndex[0]) return this.prefixSum[e];
			let t = this.prefixSumValidIndex[0] + 1;
			0 === t && (this.prefixSum[0] = this.values[0], t++), e >= this.values.length && (e = this.values.length - 1);
			for (let n = t; n <= e; n++) this.prefixSum[n] = this.prefixSum[n - 1] + this.values[n];
			return this.prefixSumValidIndex[0] = Math.max(this.prefixSumValidIndex[0], e), this.prefixSum[e];
		}
		getIndexOf(e) {
			e = Math.floor(e), this.getTotalSum();
			let t = 0, n = this.values.length - 1, r = 0, i = 0, s = 0;
			for (; t <= n;) if (r = t + (n - t) / 2 | 0, i = this.prefixSum[r], s = i - this.values[r], e < s) n = r - 1;
			else {
				if (!(e >= i)) break;
				t = r + 1;
			}
			return new ls(r, e - s);
		}
	}), ls = class {
		constructor(e, t) {
			this.index = e, this.remainder = t, this._prefixSumIndexOfResultBrand = void 0, this.index = e, this.remainder = t;
		}
	}, us = class {
		constructor(e, t, n, r) {
			this._uri = e, this._lines = t, this._eol = n, this._versionId = r, this._lineStarts = null, this._cachedTextValue = null;
		}
		dispose() {
			this._lines.length = 0;
		}
		get version() {
			return this._versionId;
		}
		getText() {
			return null === this._cachedTextValue && (this._cachedTextValue = this._lines.join(this._eol)), this._cachedTextValue;
		}
		onEvents(e) {
			e.eol && e.eol !== this._eol && (this._eol = e.eol, this._lineStarts = null);
			const t = e.changes;
			for (const n of t) this._acceptDeleteRange(n.range), this._acceptInsertText(new De(n.range.startLineNumber, n.range.startColumn), n.text);
			this._versionId = e.versionId, this._cachedTextValue = null;
		}
		_ensureLineStarts() {
			if (!this._lineStarts) {
				const e = this._eol.length, t = this._lines.length, n = new Uint32Array(t);
				for (let r = 0; r < t; r++) n[r] = this._lines[r].length + e;
				this._lineStarts = new as(n);
			}
		}
		_setLineText(e, t) {
			this._lines[e] = t, this._lineStarts && this._lineStarts.setValue(e, this._lines[e].length + this._eol.length);
		}
		_acceptDeleteRange(e) {
			if (e.startLineNumber !== e.endLineNumber) this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.endLineNumber - 1].substring(e.endColumn - 1)), this._lines.splice(e.startLineNumber, e.endLineNumber - e.startLineNumber), this._lineStarts && this._lineStarts.removeValues(e.startLineNumber, e.endLineNumber - e.startLineNumber);
			else {
				if (e.startColumn === e.endColumn) return;
				this._setLineText(e.startLineNumber - 1, this._lines[e.startLineNumber - 1].substring(0, e.startColumn - 1) + this._lines[e.startLineNumber - 1].substring(e.endColumn - 1));
			}
		}
		_acceptInsertText(e, t) {
			if (0 === t.length) return;
			const n = t.split(/\r\n|\r|\n/);
			if (1 === n.length) return void this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + n[0] + this._lines[e.lineNumber - 1].substring(e.column - 1));
			n[n.length - 1] += this._lines[e.lineNumber - 1].substring(e.column - 1), this._setLineText(e.lineNumber - 1, this._lines[e.lineNumber - 1].substring(0, e.column - 1) + n[0]);
			const r = new Uint32Array(n.length - 1);
			for (let i = 1; i < n.length; i++) this._lines.splice(e.lineNumber + i - 1, 0, n[i]), r[i - 1] = n[i].length + this._eol.length;
			this._lineStarts && this._lineStarts.insertValues(e.lineNumber, r);
		}
	}, hs = class {
		constructor() {
			this._models = Object.create(null);
		}
		getModel(e) {
			return this._models[e];
		}
		getModels() {
			const e = [];
			return Object.keys(this._models).forEach((t) => e.push(this._models[t])), e;
		}
		$acceptNewModel(e) {
			this._models[e.url] = new cs(It.parse(e.url), e.lines, e.EOL, e.versionId);
		}
		$acceptModelChanged(e, t) {
			this._models[e] && this._models[e].onEvents(t);
		}
		$acceptRemovedModel(e) {
			this._models[e] && delete this._models[e];
		}
	}, cs = class extends us {
		get uri() {
			return this._uri;
		}
		get eol() {
			return this._eol;
		}
		getValue() {
			return this.getText();
		}
		findMatches(e) {
			const t = [];
			for (let n = 0; n < this._lines.length; n++) {
				const r = this._lines[n], i = this.offsetAt(new De(n + 1, 1)), s = r.matchAll(e);
				for (const e of s) (e.index || 0 === e.index) && (e.index = e.index + i), t.push(e);
			}
			return t;
		}
		getLinesContent() {
			return this._lines.slice(0);
		}
		getLineCount() {
			return this._lines.length;
		}
		getLineContent(e) {
			return this._lines[e - 1];
		}
		getWordAtPosition(e, t) {
			const n = vr(e.column, Cr(t), this._lines[e.lineNumber - 1], 0);
			return n ? new qe(e.lineNumber, n.startColumn, e.lineNumber, n.endColumn) : null;
		}
		words(e) {
			const t = this._lines, n = this._wordenize.bind(this);
			let r = 0, i = "", s = 0, o = [];
			return { *[Symbol.iterator]() {
				for (;;) if (s < o.length) {
					const e = i.substring(o[s].start, o[s].end);
					s += 1, yield e;
				} else {
					if (!(r < t.length)) break;
					i = t[r], o = n(i, e), s = 0, r += 1;
				}
			} };
		}
		getLineWords(e, t) {
			const n = this._lines[e - 1], r = this._wordenize(n, t), i = [];
			for (const s of r) i.push({
				word: n.substring(s.start, s.end),
				startColumn: s.start + 1,
				endColumn: s.end + 1
			});
			return i;
		}
		_wordenize(e, t) {
			const n = [];
			let r;
			for (t.lastIndex = 0; (r = t.exec(e)) && 0 !== r[0].length;) n.push({
				start: r.index,
				end: r.index + r[0].length
			});
			return n;
		}
		getValueInRange(e) {
			if ((e = this._validateRange(e)).startLineNumber === e.endLineNumber) return this._lines[e.startLineNumber - 1].substring(e.startColumn - 1, e.endColumn - 1);
			const t = this._eol, n = e.startLineNumber - 1, r = e.endLineNumber - 1, i = [];
			i.push(this._lines[n].substring(e.startColumn - 1));
			for (let s = n + 1; s < r; s++) i.push(this._lines[s]);
			return i.push(this._lines[r].substring(0, e.endColumn - 1)), i.join(t);
		}
		offsetAt(e) {
			return e = this._validatePosition(e), this._ensureLineStarts(), this._lineStarts.getPrefixSum(e.lineNumber - 2) + (e.column - 1);
		}
		positionAt(e) {
			e = Math.floor(e), e = Math.max(0, e), this._ensureLineStarts();
			const t = this._lineStarts.getIndexOf(e), n = this._lines[t.index].length;
			return {
				lineNumber: 1 + t.index,
				column: 1 + Math.min(t.remainder, n)
			};
		}
		_validateRange(e) {
			const t = this._validatePosition({
				lineNumber: e.startLineNumber,
				column: e.startColumn
			}), n = this._validatePosition({
				lineNumber: e.endLineNumber,
				column: e.endColumn
			});
			return t.lineNumber !== e.startLineNumber || t.column !== e.startColumn || n.lineNumber !== e.endLineNumber || n.column !== e.endColumn ? {
				startLineNumber: t.lineNumber,
				startColumn: t.column,
				endLineNumber: n.lineNumber,
				endColumn: n.column
			} : e;
		}
		_validatePosition(e) {
			if (!De.isIPosition(e)) throw new Error("bad position");
			let { lineNumber: t, column: n } = e, r = !1;
			if (t < 1) t = 1, n = 1, r = !0;
			else if (t > this._lines.length) t = this._lines.length, n = this._lines[t - 1].length + 1, r = !0;
			else {
				const e = this._lines[t - 1].length + 1;
				n < 1 ? (n = 1, r = !0) : n > e && (n = e, r = !0);
			}
			return r ? {
				lineNumber: t,
				column: n
			} : e;
		}
	}, ds = class e {
		constructor(e = null) {
			this._foreignModule = e, this._requestHandlerBrand = void 0, this._workerTextModelSyncServer = new hs();
		}
		dispose() {}
		async $ping() {
			return "pong";
		}
		_getModel(e) {
			return this._workerTextModelSyncServer.getModel(e);
		}
		getModels() {
			return this._workerTextModelSyncServer.getModels();
		}
		$acceptNewModel(e) {
			this._workerTextModelSyncServer.$acceptNewModel(e);
		}
		$acceptModelChanged(e, t) {
			this._workerTextModelSyncServer.$acceptModelChanged(e, t);
		}
		$acceptRemovedModel(e) {
			this._workerTextModelSyncServer.$acceptRemovedModel(e);
		}
		async $computeUnicodeHighlights(e, t, n) {
			const r = this._getModel(e);
			return r ? Nr.computeUnicodeHighlights(r, t, n) : {
				ranges: [],
				hasMore: !1,
				ambiguousCharacterCount: 0,
				invisibleCharacterCount: 0,
				nonBasicAsciiCharacterCount: 0
			};
		}
		async $findSectionHeaders(e, t) {
			const n = this._getModel(e);
			return n ? es(n, t) : [];
		}
		async $computeDiff(t, n, r, i) {
			const s = this._getModel(t), o = this._getModel(n);
			return s && o ? e.computeDiff(s, o, r, i) : null;
		}
		static computeDiff(e, t, n, r) {
			const i = "advanced" === r ? qi() : Di(), s = e.getLinesContent(), o = t.getLinesContent(), a = i.computeDiff(s, o, n);
			function l(e) {
				return e.map((e) => [
					e.original.startLineNumber,
					e.original.endLineNumberExclusive,
					e.modified.startLineNumber,
					e.modified.endLineNumberExclusive,
					e.innerChanges?.map((e) => [
						e.originalRange.startLineNumber,
						e.originalRange.startColumn,
						e.originalRange.endLineNumber,
						e.originalRange.endColumn,
						e.modifiedRange.startLineNumber,
						e.modifiedRange.startColumn,
						e.modifiedRange.endLineNumber,
						e.modifiedRange.endColumn
					])
				]);
			}
			return {
				identical: !(a.changes.length > 0) && this._modelsAreIdentical(e, t),
				quitEarly: a.hitTimeout,
				changes: l(a.changes),
				moves: a.moves.map((e) => [
					e.lineRangeMapping.original.startLineNumber,
					e.lineRangeMapping.original.endLineNumberExclusive,
					e.lineRangeMapping.modified.startLineNumber,
					e.lineRangeMapping.modified.endLineNumberExclusive,
					l(e.changes)
				])
			};
		}
		static _modelsAreIdentical(e, t) {
			const n = e.getLineCount();
			if (n !== t.getLineCount()) return !1;
			for (let r = 1; r <= n; r++) if (e.getLineContent(r) !== t.getLineContent(r)) return !1;
			return !0;
		}
		static {
			this._diffLimit = 1e5;
		}
		async $computeMoreMinimalEdits(t, n, r) {
			const i = this._getModel(t);
			if (!i) return n;
			const s = [];
			let o;
			n = n.slice(0).sort((e, t) => e.range && t.range ? qe.compareRangesUsingStarts(e.range, t.range) : (e.range ? 0 : 1) - (t.range ? 0 : 1));
			let a = 0;
			for (let e = 1; e < n.length; e++) qe.getEndPosition(n[a].range).equals(qe.getStartPosition(n[e].range)) ? (n[a].range = qe.fromPositions(qe.getStartPosition(n[a].range), qe.getEndPosition(n[e].range)), n[a].text += n[e].text) : (a++, n[a] = n[e]);
			n.length = a + 1;
			for (let { range: l, text: u, eol: h } of n) {
				if ("number" == typeof h && (o = h), qe.isEmpty(l) && !u) continue;
				const t = i.getValueInRange(l);
				if (u = u.replace(/\r\n|\n|\r/g, i.eol), t === u) continue;
				if (Math.max(u.length, t.length) > e._diffLimit) {
					s.push({
						range: l,
						text: u
					});
					continue;
				}
				const n = Oe(t, u, r), a = i.offsetAt(qe.lift(l).getStartPosition());
				for (const e of n) {
					const t = i.positionAt(a + e.originalStart), n = i.positionAt(a + e.originalStart + e.originalLength), r = {
						text: u.substr(e.modifiedStart, e.modifiedLength),
						range: {
							startLineNumber: t.lineNumber,
							startColumn: t.column,
							endLineNumber: n.lineNumber,
							endColumn: n.column
						}
					};
					i.getValueInRange(r.range) !== r.text && s.push(r);
				}
			}
			return "number" == typeof o && s.push({
				eol: o,
				text: "",
				range: {
					startLineNumber: 0,
					startColumn: 0,
					endLineNumber: 0,
					endColumn: 0
				}
			}), s;
		}
		async $computeLinks(e) {
			const t = this._getModel(e);
			return t ? function(e) {
				return e && "function" == typeof e.getLineCount && "function" == typeof e.getLineContent ? He.computeLinks(e) : [];
			}(t) : null;
		}
		async $computeDefaultDocumentColors(e) {
			const t = this._getModel(e);
			return t ? Yi(t) : null;
		}
		static {
			this._suggestionsLimit = 1e4;
		}
		async $textualSuggest(t, n, r, i) {
			const s = new C(), o = new RegExp(r, i), a = /* @__PURE__ */ new Set();
			e: for (const l of t) {
				const t = this._getModel(l);
				if (t) {
					for (const r of t.words(o)) if (r !== n && isNaN(Number(r)) && (a.add(r), a.size > e._suggestionsLimit)) break e;
				}
			}
			return {
				words: Array.from(a),
				duration: s.elapsed()
			};
		}
		async $computeWordRanges(e, t, n, r) {
			const i = this._getModel(e);
			if (!i) return Object.create(null);
			const s = new RegExp(n, r), o = Object.create(null);
			for (let a = t.startLineNumber; a < t.endLineNumber; a++) {
				const e = i.getLineWords(a, s);
				for (const t of e) {
					if (!isNaN(Number(t.word))) continue;
					let e = o[t.word];
					e || (e = [], o[t.word] = e), e.push({
						startLineNumber: a,
						startColumn: t.startColumn,
						endLineNumber: a,
						endColumn: t.endColumn
					});
				}
			}
			return o;
		}
		async $navigateValueSet(e, t, n, r, i) {
			const s = this._getModel(e);
			if (!s) return null;
			const o = new RegExp(r, i);
			t.startColumn === t.endColumn && (t = {
				startLineNumber: t.startLineNumber,
				startColumn: t.startColumn,
				endLineNumber: t.endLineNumber,
				endColumn: t.endColumn + 1
			});
			const a = s.getValueInRange(t), l = s.getWordAtPosition({
				lineNumber: t.startLineNumber,
				column: t.startColumn
			}, o);
			if (!l) return null;
			const u = s.getValueInRange(l);
			return je.INSTANCE.navigateValueSet(t, a, l, u, n);
		}
		$fmr(e, t) {
			if (!this._foreignModule || "function" != typeof this._foreignModule[e]) return Promise.reject(/* @__PURE__ */ new Error("Missing requestHandler or method: " + e));
			try {
				return Promise.resolve(this._foreignModule[e].apply(this._foreignModule, t));
			} catch (fs) {
				return Promise.reject(fs);
			}
		}
	};
	"function" == typeof importScripts && (globalThis.monaco = {
		editor: void 0,
		languages: void 0,
		CancellationTokenSource: Ye,
		Emitter: R,
		KeyCode: On,
		KeyMod: ar,
		Position: De,
		Range: qe,
		Selection: Wt,
		SelectionDirection: Gn,
		MarkerSeverity: In,
		MarkerTag: Tn,
		Uri: It,
		Token: rn
	});
	var gs = class e {
		static {
			this.CHANNEL_NAME = "editorWorkerHost";
		}
		static getChannel(t) {
			return t.getChannel(e.CHANNEL_NAME);
		}
		static setChannel(t, n) {
			t.setChannel(e.CHANNEL_NAME, n);
		}
	};
	function ms(e) {
		let t;
		const n = function(e) {
			if (ye) throw new Error("WebWorker already initialized!");
			ye = !0;
			const t = new Ce((e) => globalThis.postMessage(e), (t) => e(t));
			return globalThis.onmessage = (e) => {
				t.onmessage(e.data);
			}, t;
		}((r) => {
			const i = gs.getChannel(r);
			return t = e({
				host: new Proxy({}, { get(e, t, n) {
					if ("then" !== t) {
						if ("string" != typeof t) throw new Error("Not supported");
						return (...e) => i.$fhr(t, e);
					}
				} }),
				getMirrorModels: () => n.requestHandler.getModels()
			}), new ds(t);
		});
		return t;
	}
	self.onmessage = () => {
		ms(() => ({}));
	};
})();
